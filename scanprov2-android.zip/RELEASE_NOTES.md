## ScanPro 1.4.0 · actualización (ruleta VIP, anuncios y actualizaciones automáticas)

**⭐ VIP y anuncios**
- **Panel VIP**: revisa tu estado, gira la **ruleta de premios** (15 min VIP, 1 h VIP o desbloqueo de una función) y consigue **1 hora de VIP** viendo 5 anuncios
- Botones de **VIP** y de **anuncios** en la pantalla de inicio: girar la ruleta, apoyar al creador o desbloquear VIP
- **Más funciones desbloqueables**: OCR, PDF con contraseña, exportación, QR, firmar, traducir, quitar fondo y dictado

**🔄 Actualizaciones automáticas**
- La app **revisa sola si hay una versión nueva** (una vez al día) y te ofrece actualizarla con un toque
- Al abrir la app después de actualizar, verás la **lista de novedades** de la versión instalada

**🛠 Detalles**
- Mejor legibilidad de la ruleta: el texto siempre se ve horizontal
- app-ads.txt incluido para la verificación de AdMob

## ScanPro 1.4.0 · la versión más grande hasta ahora

**🌍 Para todo el mundo**
- La primera vez te **saluda en muchos idiomas** («Hola», «Hello», «Olá»…), como un iPhone nuevo, y eliges **idioma y país**
- **Idiomas de la app**: español, inglés, portugués, francés, alemán e italiano (chino, hindi, indonesio, ruso, turco, vietnamita, japonés, coreano y árabe llegan en próximas actualizaciones; el árabe ya se muestra de derecha a izquierda)
- Según tu país cambian **fechas, moneda, papel (carta o A4)**, el nombre del documento de identidad, los tamaños de foto y las plantillas
- **Guías paso a paso** la primera vez que abres cada función y en tu primer escaneo
- **Más sonidos y vibración** al tocar (se pueden apagar en Ajustes)
- Abre **Excel, CSV, PowerPoint, EPUB, ZIP y correos (.eml)**

**🧠 Inteligencia (en el teléfono, sin internet)**
- **Se organiza solo**: al guardar lee el documento y le pone nombre («SOAT · KLM45F», «Factura de servicio · Air-e · octubre 2026»), carpeta y fecha de vencimiento
- **Pregúntale a tus documentos**: «¿Cuándo vence mi SOAT?», «¿Cuánto gasté en octubre?»
- **Revisar contrato**: resumen, valores, fechas y alertas (permanencia, multas, renovación automática, preaviso, codeudor…)
- **Llenar formularios** con tus datos guardados

**📷 Escanear mejor**
- Nuevo **escáner de Google** integrado: enfoca mucho mejor y detecta los bordes con IA (también para la cédula)
- **QR y códigos de barras**, **libro abierto** (dos páginas por foto), **escaneo por lotes**, **tarjeta de presentación a contacto** y **copiar texto al instante**
- Más formatos: HEIC, AVIF, TIFF, BMP, GIF, SVG, Word, ODT, RTF y TXT

**📄 Herramientas de PDF**
- Dividir, comprimir (500 KB a 5 MB), proteger o quitar contraseña, marca de agua, numerar páginas, PDF a imágenes y verificar si un PDF fue modificado
- PDF con búsqueda: el texto reconocido queda dentro del PDF

**✍️ Firmar y editar**
- Firmar, escribir, resaltar, **tachar**, **corrector**, **sello de recibido** y fecha
- Firmar el PDF que te enviaron y devolverlo en segundos
- **Tachar datos sensibles** automáticamente (cédula, cuentas, correos, direcciones)
- Editor de texto: abre y guarda Word y PDF; **plantillas de trámites** (derecho de petición, cuenta de cobro, poder, paz y salvo, autorización, renuncia, cotización)

**🌎 Texto e idiomas**
- **Traducir** a 15 idiomas (sin internet después de la primera vez), **leer en voz alta**, **dictar**, **tabla a Excel**, **lista con casillas** y **comparar** dos documentos

**🗂️ Mi vida en orden**
- **Carpetas de vida** (identidad, salud, vehículo, hogar, garantías, estudios, trabajo, mascotas) con **aviso de vencimiento**
- **Avisos** de medicamentos y pagos, **gastos** desde recibos, **etiquetas de colores** y **carpeta privada con huella**

**🎓 Estudio, trabajo y negocio**
- Resumen automático y tarjetas de estudio, libro de apuntes con portada e índice, presentar a pantalla completa y exportar a PowerPoint
- **Inventario** con código de barras y **catálogo en PDF**; imprimir y enviar a tu correo con un toque

**🖼️ Imagen y accesibilidad**
- **Quitar el fondo**, **foto tipo documento** (3×4, pasaporte, visa), filtro **pizarra** y **lupa**
- Alto contraste, letra grande y lectura fácil

Instala **ScanPro-1.4.0.apk** encima de la versión anterior: no se borran tus documentos.
