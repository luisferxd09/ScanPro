// Núcleo de procesamiento de imágenes. Se ejecuta dentro de un Web Worker (con OffscreenCanvas)
// para no bloquear la interfaz; si el navegador no lo permite, se usa en el hilo principal.
import { detectDocument, refineQuad } from './detect.js';
import { warpPerspective, outputSize } from './warp.js';
import { processPixels, NO_ADJ } from './filters.js';
import { sharpness, textRotation, PAGE_PX } from './quality.js';
export const FULL_MAX = 4000; // lado máximo con el que se trabaja una foto
export const STORE_MAX = 3508; // ≈ A4 a 300 ppp
export const STORE_JPEG = 0.9;
export const VIEW_MAX = 1600; // copia para mostrar en pantalla
export const BASE_MAX = 1200; // vista previa de filtros
const FULL_NORM = [0, 0, 1, 0, 1, 1, 0, 1];
const isFull = (n) => !n || n.every((v, i) => Math.abs(v - FULL_NORM[i]) < 1e-4);
export function mk(w, h) {
    if (typeof OffscreenCanvas !== 'undefined')
        return new OffscreenCanvas(w, h);
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
}
const ctx2d = (c) => c.getContext('2d', { willReadFrequently: true });
export async function encode(c, type, quality) {
    const b = 'convertToBlob' in c
        ? await c.convertToBlob({ type, quality })
        : await new Promise(r => c.toBlob(r, type, quality));
    if (!b || !b.size)
        throw new Error('No se pudo generar la imagen (memoria insuficiente).');
    return b;
}
function pixels(src, w, h) {
    const c = mk(w, h);
    const x = ctx2d(c);
    x.imageSmoothingQuality = 'high';
    x.drawImage(src, 0, 0, w, h);
    const d = x.getImageData(0, 0, w, h);
    return { data: d.data, width: w, height: h };
}
function toCanvas(img) {
    const c = mk(img.width, img.height);
    ctx2d(c).putImageData(new ImageData(img.data, img.width, img.height), 0, 0);
    return c;
}
function rotate(c, deg) {
    const r = ((deg % 360) + 360) % 360;
    if (!r)
        return c;
    const out = r === 180 ? mk(c.width, c.height) : mk(c.height, c.width);
    const x = ctx2d(out);
    x.translate(out.width / 2, out.height / 2);
    x.rotate((r * Math.PI) / 180);
    x.drawImage(c, -c.width / 2, -c.height / 2);
    return out;
}
function scaled(src, maxSide) {
    const s = Math.min(1, maxSide / Math.max(src.width, src.height));
    const c = mk(Math.max(1, Math.round(src.width * s)), Math.max(1, Math.round(src.height * s)));
    const x = ctx2d(c);
    x.imageSmoothingQuality = 'high';
    x.drawImage(src, 0, 0, c.width, c.height);
    return c;
}
export async function decodeBlob(b, maxSide = FULL_MAX) {
    if (!b.size)
        throw new Error('El archivo está vacío.');
    let bmp;
    try {
        bmp = await createImageBitmap(b, { imageOrientation: 'from-image' });
    }
    catch {
        throw new Error('No se pudo leer la imagen: archivo dañado o formato no compatible.');
    }
    if (!bmp.width || !bmp.height)
        throw new Error('La imagen no tiene dimensiones válidas.');
    if (Math.max(bmp.width, bmp.height) <= maxSide)
        return bmp;
    const s = maxSide / Math.max(bmp.width, bmp.height);
    const r = await createImageBitmap(bmp, { resizeWidth: Math.round(bmp.width * s), resizeHeight: Math.round(bmp.height * s), resizeQuality: 'high' });
    bmp.close();
    return r;
}
/** Detección aproximada en una imagen pequeña. Devuelve esquinas normalizadas o null. */
export function detectSmall(src, maxSide = 360) {
    const s = Math.min(1, maxSide / Math.max(src.width, src.height));
    const w = Math.max(1, Math.round(src.width * s)), h = Math.max(1, Math.round(src.height * s));
    const q = detectDocument(pixels(src, w, h));
    return q ? q.flatMap(p => [p.x / w, p.y / h]) : null;
}
/** Nitidez de un recorte (para la vista en vivo y para elegir el mejor fotograma de una ráfaga). */
export function sharpOf(src, maxSide = 520) {
    const s = Math.min(1, maxSide / Math.max(src.width, src.height));
    const w = Math.max(16, Math.round(src.width * s)), h = Math.max(16, Math.round(src.height * s));
    return sharpness(pixels(src, w, h));
}
/** Vista en vivo: detección en el fotograma reducido + nitidez del centro del documento (recorte a resolución nativa). */
export function frameInfo(small, crop) {
    const quad = detectSmall(small, 360);
    const sharp = crop ? sharpOf(crop, 480) : null;
    return { quad, sharp };
}
/** Detección precisa: aproximada (o la sugerida por la vista en vivo) + refinamiento a 1200 px. */
export function detectPrecise(src, hint) {
    const coarse = detectSmall(src, 480) ?? hint;
    if (!coarse)
        return null;
    const s = Math.min(1, BASE_MAX / Math.max(src.width, src.height));
    const w = Math.round(src.width * s), h = Math.round(src.height * s);
    const q = [0, 1, 2, 3].map(i => ({ x: coarse[i * 2] * w, y: coarse[i * 2 + 1] * h }));
    const r = refineQuad(pixels(src, w, h), q);
    return r.flatMap(p => [p.x / w, p.y / h]);
}
class Lru {
    max;
    dispose;
    m = new Map();
    constructor(max, dispose = () => { }) {
        this.max = max;
        this.dispose = dispose;
    }
    get(k) { const v = this.m.get(k); if (v !== undefined) {
        this.m.delete(k);
        this.m.set(k, v);
    } return v; }
    set(k, v) {
        const old = this.m.get(k);
        if (old !== undefined && old !== v)
            this.dispose(old);
        this.m.delete(k);
        this.m.set(k, v);
        while (this.m.size > this.max) {
            const [ok, ov] = this.m.entries().next().value;
            this.m.delete(ok);
            this.dispose(ov);
        }
    }
    delete(k) { const v = this.m.get(k); if (v !== undefined) {
        this.dispose(v);
        this.m.delete(k);
    } }
}
/** Estado y operaciones del motor (mismo código en worker y en hilo principal). */
export class Engine {
    // pocas fotos completas en memoria: los móviles de gama baja tienen poca RAM
    full = new Lru(2, b => b.close());
    base = new Lru(2);
    orig = new Map();
    async getFull(key, fallback) {
        const f = this.full.get(key);
        if (f)
            return f;
        if (!fallback)
            throw new Error('La imagen ya no está en memoria.');
        const b = await decodeBlob(fallback);
        this.full.set(key, b);
        return b;
    }
    /** Recibe una foto (fotograma de cámara o archivo), la guarda en memoria y detecta la hoja. */
    async ingest(key, src, hint, detect) {
        const bmp = src instanceof Blob ? await decodeBlob(src) : src;
        this.full.set(key, bmp);
        if (!(src instanceof Blob)) {
            // el JPEG original se codifica en paralelo; no depende de que la foto siga en memoria
            const c = mk(bmp.width, bmp.height);
            ctx2d(c).drawImage(bmp, 0, 0);
            this.orig.set(key, encode(c, 'image/jpeg', 0.92));
        }
        const corners = detect ? detectPrecise(bmp, hint) : null;
        // calidad de la página ya enderezada, a escala de papel (lado corto ≈ A4 a 150 ppp)
        let sharp = 0, rotation = 0;
        try {
            let page = this.crop(bmp, corners, 2200);
            const short = Math.min(page.width, page.height);
            const k = PAGE_PX / short;
            if (Math.abs(k - 1) > 0.05) {
                const c = mk(Math.round(page.width * k), Math.round(page.height * k));
                const x = ctx2d(c);
                x.imageSmoothingQuality = 'high';
                x.drawImage(page, 0, 0, c.width, c.height);
                page = c;
            }
            const img = pixels(page, page.width, page.height);
            sharp = sharpness(img);
            rotation = textRotation(img);
        }
        catch { /* la medición es opcional */ }
        return { width: bmp.width, height: bmp.height, corners, detected: !!corners, sharp, rotation };
    }
    /** Copia reducida para mostrar en pantalla. */
    async view(key, fallback, maxSide = VIEW_MAX) {
        const f = await this.getFull(key, fallback);
        const s = Math.min(1, maxSide / Math.max(f.width, f.height));
        return createImageBitmap(f, { resizeWidth: Math.round(f.width * s), resizeHeight: Math.round(f.height * s), resizeQuality: 'medium' });
    }
    async encodeOriginal(key, quality = 0.92) {
        const p = this.orig.get(key);
        if (p) {
            this.orig.delete(key);
            return p;
        }
        const f = await this.getFull(key);
        const c = mk(f.width, f.height);
        ctx2d(c).drawImage(f, 0, 0);
        return encode(c, 'image/jpeg', quality);
    }
    async detectAgain(key, fallback) {
        return detectPrecise(await this.getFull(key, fallback), null);
    }
    crop(f, corners, maxSide) {
        if (isFull(corners))
            return scaled(f, maxSide);
        // se trabaja a la resolución justa: si la salida es menor que la foto, se reduce antes de enderezar
        const qFull = [0, 1, 2, 3].map(i => ({ x: corners[i * 2] * f.width, y: corners[i * 2 + 1] * f.height }));
        const want = outputSize(qFull, maxSide);
        const natural = outputSize(qFull, 1e9);
        const k = Math.min(1, Math.max(want.w / natural.w, want.h / natural.h) * 1.15);
        const sw = Math.max(8, Math.round(f.width * k)), sh = Math.max(8, Math.round(f.height * k));
        const src = pixels(f, sw, sh);
        const q = [0, 1, 2, 3].map(i => ({ x: corners[i * 2] * sw, y: corners[i * 2 + 1] * sh }));
        return toCanvas(warpPerspective(src, q, want.w, want.h));
    }
    /** Resultado final a máxima calidad + miniatura. */
    async render(key, fallback, p) {
        const f = await this.getFull(key, fallback);
        const c = this.crop(f, p.corners, STORE_MAX);
        const img = pixels(c, c.width, c.height);
        processPixels(img, p.filter, p.adjust);
        const out = rotate(toCanvas(img), p.rotation);
        const [image, thumb] = await Promise.all([encode(out, 'image/jpeg', STORE_JPEG), encode(scaled(out, 320), 'image/jpeg', 0.8)]);
        return { image, thumb, width: out.width, height: out.height };
    }
    /** Prepara la base (recortada, sin filtro) para la vista previa de filtros. */
    async setBase(key, fallback, corners) {
        const f = await this.getFull(key, fallback);
        const c = this.crop(f, corners, BASE_MAX);
        this.base.set(key, { key, img: pixels(c, c.width, c.height) });
    }
    async preview(key, rotation, filter, adjust) {
        const b = this.base.get(key);
        if (!b)
            throw new Error('Vista previa no preparada.');
        const img = { data: new Uint8ClampedArray(b.img.data), width: b.img.width, height: b.img.height };
        processPixels(img, filter, adjust);
        return createImageBitmap(rotate(toCanvas(img), rotation));
    }
    async thumbs(key, rotation, filters) {
        const b = this.base.get(key);
        if (!b)
            throw new Error('Vista previa no preparada.');
        const small = scaled(toCanvas(b.img), 120);
        const base = pixels(small, small.width, small.height);
        const out = [];
        for (const f of filters) {
            const img = { data: new Uint8ClampedArray(base.data), width: base.width, height: base.height };
            processPixels(img, f, NO_ADJ);
            out.push(await createImageBitmap(rotate(toCanvas(img), rotation)));
        }
        return out;
    }
    drop(key) { this.full.delete(key); this.base.delete(key); this.orig.delete(key); }
}
