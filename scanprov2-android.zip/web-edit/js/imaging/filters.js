export const FILTERS = [
    { id: 'original', label: 'Original' },
    { id: 'magic', label: 'Sin sombras' },
    { id: 'enhanced', label: 'Mejorado' },
    { id: 'gray', label: 'Grises' },
    { id: 'bw', label: 'B / N' },
    { id: 'contrast', label: 'Contraste' },
    { id: 'pizarra', label: 'Pizarra' },
];
const clamp = (v) => (v < 0 ? 0 : v > 255 ? 255 : v);
export function luminance(img) {
    const { data, width, height } = img;
    const out = new Uint8ClampedArray(width * height);
    for (let i = 0, j = 0; j < out.length; i += 4, j++)
        out[j] = (data[i] * 77 + data[i + 1] * 150 + data[i + 2] * 29) >> 8;
    return out;
}
function percentile(hist, total, p) {
    const target = total * p;
    let acc = 0;
    for (let i = 0; i < 256; i++) {
        acc += hist[i];
        if (acc >= target)
            return i;
    }
    return 255;
}
function histogram(gray) {
    const h = new Uint32Array(256);
    for (let i = 0; i < gray.length; i++)
        h[gray[i]]++;
    return h;
}
/**
 * Estima el brillo del papel (fondo) en cada punto: máximo por bloques,
 * dilatación y suavizado, y luego interpolación bilineal a tamaño completo.
 * Dividir por este mapa elimina sombras y ilumina el papel de forma uniforme.
 */
export function backgroundMap(gray, w, h) {
    const b = Math.max(4, Math.ceil(Math.max(w, h) / 96));
    const gw = Math.ceil(w / b), gh = Math.ceil(h / b);
    let grid = new Float32Array(gw * gh);
    for (let gy = 0; gy < gh; gy++) {
        for (let gx = 0; gx < gw; gx++) {
            // percentil alto aproximado del bloque: máximo de la media de filas (robusto a ruido)
            let m = 0;
            const y0 = gy * b, y1 = Math.min(h, y0 + b), x0 = gx * b, x1 = Math.min(w, x0 + b);
            for (let y = y0; y < y1; y += 2) {
                const row = y * w;
                for (let x = x0; x < x1; x += 2) {
                    const v = gray[row + x];
                    if (v > m)
                        m = v;
                }
            }
            grid[gy * gw + gx] = m;
        }
    }
    // dilatación 3x3 (cubre trazos de texto gruesos)
    const dil = new Float32Array(gw * gh);
    for (let y = 0; y < gh; y++)
        for (let x = 0; x < gw; x++) {
            let m = 0;
            for (let dy = -1; dy <= 1; dy++)
                for (let dx = -1; dx <= 1; dx++) {
                    const yy = Math.min(gh - 1, Math.max(0, y + dy)), xx = Math.min(gw - 1, Math.max(0, x + dx));
                    const v = grid[yy * gw + xx];
                    if (v > m)
                        m = v;
                }
            dil[y * gw + x] = m;
        }
    grid = dil;
    // dos pasadas de desenfoque de caja 5x5
    for (let pass = 0; pass < 2; pass++) {
        const out = new Float32Array(gw * gh);
        for (let y = 0; y < gh; y++)
            for (let x = 0; x < gw; x++) {
                let s = 0, n = 0;
                for (let dy = -2; dy <= 2; dy++)
                    for (let dx = -2; dx <= 2; dx++) {
                        const yy = y + dy, xx = x + dx;
                        if (yy < 0 || xx < 0 || yy >= gh || xx >= gw)
                            continue;
                        s += grid[yy * gw + xx];
                        n++;
                    }
                out[y * gw + x] = s / n;
            }
        grid = out;
    }
    const full = new Float32Array(w * h);
    for (let y = 0; y < h; y++) {
        const fy = Math.min(gh - 1, Math.max(0, (y + 0.5) / b - 0.5));
        const y0 = Math.floor(fy), y1 = Math.min(gh - 1, y0 + 1), ty = fy - y0;
        for (let x = 0; x < w; x++) {
            const fx = Math.min(gw - 1, Math.max(0, (x + 0.5) / b - 0.5));
            const x0 = Math.floor(fx), x1 = Math.min(gw - 1, x0 + 1), tx = fx - x0;
            const a = grid[y0 * gw + x0] * (1 - tx) + grid[y0 * gw + x1] * tx;
            const c = grid[y1 * gw + x0] * (1 - tx) + grid[y1 * gw + x1] * tx;
            full[y * w + x] = Math.max(30, a * (1 - ty) + c * ty);
        }
    }
    return full;
}
function saturate(d, i, f) {
    const l = (d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) / 256;
    d[i] = clamp(l + (d[i] - l) * f);
    d[i + 1] = clamp(l + (d[i + 1] - l) * f);
    d[i + 2] = clamp(l + (d[i + 2] - l) * f);
}
/** Escala de grises normalizada (sin sombras) — base de B/N y Contraste. */
function normalizedGray(img) {
    const gray = luminance(img);
    const bg = backgroundMap(gray, img.width, img.height);
    const out = new Uint8ClampedArray(gray.length);
    for (let i = 0; i < gray.length; i++)
        out[i] = clamp((gray[i] * 255) / bg[i]);
    return out;
}
function writeGray(img, g) {
    const d = img.data;
    for (let i = 0, j = 0; j < g.length; i += 4, j++) {
        d[i] = d[i + 1] = d[i + 2] = g[j];
    }
}
export function applyFilter(img, id) {
    const d = img.data;
    switch (id) {
        case 'original':
            return img;
        case 'gray': {
            writeGray(img, luminance(img));
            return img;
        }
        case 'enhanced': {
            const gray = luminance(img);
            const hist = histogram(gray);
            const lo = percentile(hist, gray.length, 0.01);
            const hi = Math.max(lo + 30, percentile(hist, gray.length, 0.99));
            const k = 255 / (hi - lo);
            for (let i = 0; i < d.length; i += 4) {
                d[i] = clamp((d[i] - lo) * k);
                d[i + 1] = clamp((d[i + 1] - lo) * k);
                d[i + 2] = clamp((d[i + 2] - lo) * k);
                saturate(d, i, 1.15);
            }
            unsharp(img, 0.5);
            return img;
        }
        case 'pizarra': {
            // tablero blanco o de clase: fondo plano sin reflejos y trazos de colores saturados
            const gray = luminance(img);
            const bg = backgroundMap(gray, img.width, img.height);
            for (let i = 0, j = 0; j < bg.length; i += 4, j++) {
                const s = 255 / Math.max(40, bg[j]), dark = gray[j] < bg[j] * 0.86;
                if (!dark) {
                    d[i] = d[i + 1] = d[i + 2] = 255;
                    continue;
                }
                d[i] = clamp((d[i] * s - 40) * 1.2);
                d[i + 1] = clamp((d[i + 1] * s - 40) * 1.2);
                d[i + 2] = clamp((d[i + 2] * s - 40) * 1.2);
                saturate(d, i, 1.8);
            }
            unsharp(img, 0.6);
            return img;
        }
        case 'magic': {
            const gray = luminance(img);
            const bg = backgroundMap(gray, img.width, img.height);
            // balance de blancos con el propio papel: neutraliza el tono amarillo/rosado de la luz
            let sr = 0, sg = 0, sb = 0, n = 0;
            for (let i = 0, j = 0; j < bg.length; i += 4 * 7, j += 7) {
                if (gray[j] > bg[j] * 0.92) {
                    sr += d[i];
                    sg += d[i + 1];
                    sb += d[i + 2];
                    n++;
                }
            }
            const avg = n ? (sr + sg + sb) / (3 * n) : 1;
            const gr = n ? avg / Math.max(1, sr / n) : 1, gg = n ? avg / Math.max(1, sg / n) : 1, gb = n ? avg / Math.max(1, sb / n) : 1;
            for (let i = 0, j = 0; j < bg.length; i += 4, j++) {
                const s = 255 / bg[j];
                // blanqueo del papel + ligero realce de la tinta
                d[i] = clamp((d[i] * gr * s - 18) * 1.08);
                d[i + 1] = clamp((d[i + 1] * gg * s - 18) * 1.08);
                d[i + 2] = clamp((d[i + 2] * gb * s - 18) * 1.08);
                saturate(d, i, 1.15);
            }
            unsharp(img, 0.7);
            return img;
        }
        case 'contrast': {
            const g = normalizedGray(img);
            const hist = histogram(g);
            const lo = percentile(hist, g.length, 0.02);
            const hi = Math.max(lo + 40, percentile(hist, g.length, 0.6));
            const k = 255 / (hi - lo);
            for (let j = 0; j < g.length; j++) {
                const v = clamp((g[j] - lo) * k) / 255;
                g[j] = clamp(Math.pow(v, 1.8) * 255);
            }
            writeGray(img, g);
            return img;
        }
        case 'bw': {
            const g = normalizedGray(img);
            const w = img.width, h = img.height;
            const integ = new Float64Array((w + 1) * (h + 1));
            for (let y = 0; y < h; y++) {
                let row = 0;
                for (let x = 0; x < w; x++) {
                    row += g[y * w + x];
                    integ[(y + 1) * (w + 1) + x + 1] = integ[y * (w + 1) + x + 1] + row;
                }
            }
            const r = Math.max(7, Math.round(Math.min(w, h) / 40));
            const out = new Uint8ClampedArray(g.length);
            for (let y = 0; y < h; y++) {
                const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
                for (let x = 0; x < w; x++) {
                    const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
                    const area = (y1 - y0) * (x1 - x0);
                    const sum = integ[y1 * (w + 1) + x1] - integ[y0 * (w + 1) + x1] - integ[y1 * (w + 1) + x0] + integ[y0 * (w + 1) + x0];
                    const mean = sum / area;
                    const v = g[y * w + x];
                    out[y * w + x] = v < mean * 0.86 && v < 215 ? 0 : 255;
                }
            }
            writeGray(img, out);
            return img;
        }
    }
    return img;
}
/** Brillo, contraste, saturación (−100…100) y nitidez (0…100). */
export function applyAdjust(img, a) {
    const d = img.data;
    if (a.sharpness > 0)
        sharpen(img, a.sharpness / 100);
    if (a.brightness === 0 && a.contrast === 0 && a.saturation === 0)
        return img;
    const b = a.brightness * 1.2;
    const c = a.contrast * 1.28;
    const cf = (259 * (c + 255)) / (255 * (259 - c));
    const sf = 1 + a.saturation / 100;
    const lut = new Uint8ClampedArray(256);
    for (let v = 0; v < 256; v++)
        lut[v] = clamp(cf * (v + b - 128) + 128);
    for (let i = 0; i < d.length; i += 4) {
        d[i] = lut[d[i]];
        d[i + 1] = lut[d[i + 1]];
        d[i + 2] = lut[d[i + 2]];
        if (sf !== 1)
            saturate(d, i, sf);
    }
    return img;
}
/**
 * Máscara de enfoque sobre la luminancia (sin halos de color), con radio proporcional
 * al tamaño de la página: realza el borde de las letras sin amplificar el grano del papel.
 */
export function unsharp(img, amount) {
    const { data: d, width: w, height: h } = img;
    const r = Math.max(1, Math.round(Math.min(w, h) / 900));
    const L = luminance(img);
    const tmp = new Float32Array(w * h), blur = new Float32Array(w * h);
    const win = 2 * r + 1;
    for (let y = 0; y < h; y++) {
        let acc = 0;
        const row = y * w;
        for (let x = -r; x <= r; x++)
            acc += L[row + Math.min(w - 1, Math.max(0, x))];
        for (let x = 0; x < w; x++) {
            tmp[row + x] = acc / win;
            acc += L[row + Math.min(w - 1, x + r + 1)] - L[row + Math.max(0, x - r)];
        }
    }
    for (let x = 0; x < w; x++) {
        let acc = 0;
        for (let y = -r; y <= r; y++)
            acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
        for (let y = 0; y < h; y++) {
            blur[y * w + x] = acc / win;
            acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
        }
    }
    for (let j = 0, i = 0; j < L.length; j++, i += 4) {
        const diff = L[j] - blur[j];
        if (Math.abs(diff) < 3)
            continue; // umbral: no realza el ruido
        const add = diff * amount;
        d[i] = clamp(d[i] + add);
        d[i + 1] = clamp(d[i + 1] + add);
        d[i + 2] = clamp(d[i + 2] + add);
    }
}
function sharpen(img, amount) {
    const { data: d, width: w, height: h } = img;
    const src = new Uint8ClampedArray(d);
    const k = amount * 1.6;
    for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
            const i = (y * w + x) * 4;
            for (let ch = 0; ch < 3; ch++) {
                const c = src[i + ch];
                const blur = (src[i + ch - 4] + src[i + ch + 4] + src[i + ch - w * 4] + src[i + ch + w * 4]) / 4;
                d[i + ch] = clamp(c + (c - blur) * k);
            }
        }
    }
}
export function processPixels(img, filter, adjust) {
    applyFilter(img, filter);
    applyAdjust(img, adjust);
    return img;
}
export const NO_ADJ = { brightness: 0, contrast: 0, saturation: 0, sharpness: 0 };
