// MD5 y RC4 para el cifrado estándar de PDF (contraseña de apertura, RC4 de 128 bits, revisión 3).
const K = new Int32Array(64).map((_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32) | 0);
const R = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
export function md5(data) {
    const n = data.length, len = ((n + 8 >> 6) + 1) << 6, m = new Uint8Array(len);
    m.set(data);
    m[n] = 0x80;
    const bits = n * 8;
    for (let i = 0; i < 8; i++)
        m[len - 8 + i] = i < 4 ? (bits >>> (8 * i)) & 255 : Math.floor(bits / 2 ** (8 * i)) & 255;
    let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
    const w = new Int32Array(16);
    for (let o = 0; o < len; o += 64) {
        for (let i = 0; i < 16; i++)
            w[i] = m[o + i * 4] | m[o + i * 4 + 1] << 8 | m[o + i * 4 + 2] << 16 | m[o + i * 4 + 3] << 24;
        let a = a0, b = b0, c = c0, d = d0;
        for (let i = 0; i < 64; i++) {
            let f, g;
            if (i < 16) {
                f = (b & c) | (~b & d);
                g = i;
            }
            else if (i < 32) {
                f = (d & b) | (~d & c);
                g = (5 * i + 1) % 16;
            }
            else if (i < 48) {
                f = b ^ c ^ d;
                g = (3 * i + 5) % 16;
            }
            else {
                f = c ^ (b | ~d);
                g = (7 * i) % 16;
            }
            const t = d;
            d = c;
            c = b;
            const x = (a + f + K[i] + w[g]) | 0;
            b = (b + ((x << R[i]) | (x >>> (32 - R[i])))) | 0;
            a = t;
        }
        a0 = (a0 + a) | 0;
        b0 = (b0 + b) | 0;
        c0 = (c0 + c) | 0;
        d0 = (d0 + d) | 0;
    }
    const out = new Uint8Array(16);
    [a0, b0, c0, d0].forEach((v, i) => { for (let j = 0; j < 4; j++)
        out[i * 4 + j] = (v >>> (8 * j)) & 255; });
    return out;
}
export function rc4(key, data) {
    const S = new Uint8Array(256).map((_, i) => i);
    let j = 0;
    for (let i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % key.length]) & 255;
        [S[i], S[j]] = [S[j], S[i]];
    }
    const out = new Uint8Array(data.length);
    let i = 0;
    j = 0;
    for (let k = 0; k < data.length; k++) {
        i = (i + 1) & 255;
        j = (j + S[i]) & 255;
        [S[i], S[j]] = [S[j], S[i]];
        out[k] = data[k] ^ S[(S[i] + S[j]) & 255];
    }
    return out;
}
const PAD = new Uint8Array([0x28, 0xbf, 0x4e, 0x5e, 0x4e, 0x75, 0x8a, 0x41, 0x64, 0x00, 0x4e, 0x56, 0xff, 0xfa, 0x01, 0x08, 0x2e, 0x2e, 0x00, 0xb6, 0xd0, 0x68, 0x3e, 0x80, 0x2f, 0x0c, 0xa9, 0xfe, 0x64, 0x53, 0x69, 0x7a]);
const latin = (s) => new Uint8Array([...s].map(c => c.charCodeAt(0) & 255));
function padPw(pw) { const b = latin(pw).slice(0, 32), o = new Uint8Array(32); o.set(b); o.set(PAD.subarray(0, 32 - b.length), b.length); return o; }
const cat = (...a) => { const o = new Uint8Array(a.reduce((s, x) => s + x.length, 0)); let k = 0; for (const x of a) {
    o.set(x, k);
    k += x.length;
} return o; };
/** Prepara el cifrado: misma contraseña para abrir; la de propietario es aleatoria. */
export function pdfCrypt(userPw, id) {
    const ownerPw = Array.from(crypto.getRandomValues(new Uint8Array(16)), b => String.fromCharCode(97 + b % 26)).join('');
    let h = md5(padPw(ownerPw));
    for (let i = 0; i < 50; i++)
        h = md5(h);
    let O = rc4(h, padPw(userPw));
    for (let i = 1; i < 20; i++)
        O = rc4(h.map(b => b ^ i), O);
    const P = -4, Pb = new Uint8Array([P & 255, (P >> 8) & 255, (P >> 16) & 255, (P >> 24) & 255]);
    let key = md5(cat(padPw(userPw), O, Pb, id));
    for (let i = 0; i < 50; i++)
        key = md5(key);
    let U = rc4(key, md5(cat(PAD, id)));
    for (let i = 1; i < 20; i++)
        U = rc4(key.map(b => b ^ i), U);
    return { O, U: cat(U, new Uint8Array(16)), P, id, key };
}
export function objKey(c, num) {
    return md5(cat(c.key, new Uint8Array([num & 255, (num >> 8) & 255, (num >> 16) & 255, 0, 0]))).subarray(0, 16);
}
export const hex = (b) => Array.from(b, x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
