// Canalización de imagen en el navegador: decodificar, detectar, enderezar, filtrar, codificar.
import { processPixels } from './filters.js';
import { detectDocument, fullQuad } from './detect.js';
import { warpPerspective, outputSize } from './warp.js';
export const MAX_DECODE = 4000; // lado máximo al que se decodifica la foto original
export const STORE_MAX = 3508; // ≈ A4 a 300 ppp: resolución guardada de cada página
export const STORE_JPEG = 0.9;
export class ImageError extends Error {
}
export async function decode(blob, maxSide = MAX_DECODE) {
    if (!blob.size)
        throw new ImageError('El archivo está vacío.');
    let src;
    let sw, sh;
    try {
        src = await createImageBitmap(blob, { imageOrientation: 'from-image' });
        sw = src.width;
        sh = src.height;
    }
    catch {
        try {
            const url = URL.createObjectURL(blob);
            src = await new Promise((res, rej) => {
                const im = new Image();
                im.onload = () => res(im);
                im.onerror = () => rej(new Error('decode'));
                im.src = url;
            });
            URL.revokeObjectURL(url);
            sw = src.naturalWidth;
            sh = src.naturalHeight;
        }
        catch {
            throw new ImageError('No se pudo leer la imagen. El archivo puede estar dañado o tener un formato no compatible (usa JPG, PNG, WEBP o HEIC compatible con tu navegador).');
        }
    }
    if (!sw || !sh)
        throw new ImageError('La imagen no tiene dimensiones válidas.');
    const s = Math.min(1, maxSide / Math.max(sw, sh));
    const w = Math.round(sw * s), h = Math.round(sh * s);
    const canvas = makeCanvas(w, h);
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, w, h);
    if ('close' in src)
        src.close();
    return { canvas, width: w, height: h };
}
export function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
}
export function readPixels(c) {
    const d = c.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, c.width, c.height);
    return { data: d.data, width: d.width, height: d.height };
}
export function imgToCanvas(img, into) {
    const c = into ?? makeCanvas(img.width, img.height);
    c.width = img.width;
    c.height = img.height;
    c.getContext('2d').putImageData(new ImageData(img.data, img.width, img.height), 0, 0);
    return c;
}
export function scaledCanvas(src, maxSide) {
    const s = Math.min(1, maxSide / Math.max(src.width, src.height));
    const c = makeCanvas(Math.max(1, Math.round(src.width * s)), Math.max(1, Math.round(src.height * s)));
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return c;
}
/** Detección sobre una versión reducida; devuelve esquinas normalizadas (0…1) o null. */
export function detectNormalized(src, w, h) {
    const s = Math.min(1, 420 / Math.max(w, h));
    const c = makeCanvas(Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)));
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(src, 0, 0, c.width, c.height);
    const q = detectDocument(readPixels(c));
    if (!q)
        return null;
    return q.flatMap(p => [p.x / c.width, p.y / c.height]);
}
export function denormalize(n, w, h) {
    return [0, 1, 2, 3].map(i => ({ x: n[i * 2] * w, y: n[i * 2 + 1] * h }));
}
export const FULL_NORM = [0, 0, 1, 0, 1, 1, 0, 1];
export function rotateCanvas(c, deg) {
    const r = ((deg % 360) + 360) % 360;
    if (!r)
        return c;
    const out = r === 180 ? makeCanvas(c.width, c.height) : makeCanvas(c.height, c.width);
    const ctx = out.getContext('2d', { willReadFrequently: true });
    ctx.translate(out.width / 2, out.height / 2);
    ctx.rotate((r * Math.PI) / 180);
    ctx.drawImage(c, -c.width / 2, -c.height / 2);
    return out;
}
/** Endereza y rota: devuelve un lienzo con la página recortada (sin filtros). */
export function cropAndRotate(dec, cornersNorm, rotation, maxSide) {
    const n = cornersNorm ?? FULL_NORM;
    const isFull = n.every((v, i) => Math.abs(v - FULL_NORM[i]) < 1e-4);
    let out;
    if (isFull) {
        out = scaledCanvas(dec.canvas, maxSide);
    }
    else {
        const q = denormalize(n, dec.width, dec.height);
        const { w, h } = outputSize(q, maxSide);
        out = imgToCanvas(warpPerspective(readPixels(dec.canvas), q, w, h));
    }
    return rotateCanvas(out, rotation);
}
export function filtered(c, filter, adjust, into) {
    const img = readPixels(c);
    processPixels(img, filter, adjust);
    return imgToCanvas(img, into);
}
export function toBlob(c, type, quality) {
    return new Promise((res, rej) => {
        c.toBlob(b => {
            if (!b || !b.size)
                rej(new ImageError('No se pudo generar la imagen (memoria insuficiente o formato no compatible).'));
            else
                res(b);
        }, type, quality);
    });
}
/** Comprueba que el navegador codifica de verdad el tipo pedido (p. ej. WEBP en Safari antiguo). */
export async function encodeAs(c, type, quality) {
    const b = await toBlob(c, type, quality);
    if (b.type !== type)
        throw new ImageError(`Tu navegador no puede generar ${type.split('/')[1].toUpperCase()}. Elige otro formato.`);
    return b;
}
export async function thumbBlob(c) {
    return toBlob(scaledCanvas(c, 320), 'image/jpeg', 0.8);
}
export async function blobToCanvas(b, maxSide = 100000) {
    return (await decode(b, maxSide)).canvas;
}
export { fullQuad };
