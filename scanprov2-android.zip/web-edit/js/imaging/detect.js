// Detección automática de los cuatro bordes de una hoja (puro, sin DOM).
// Combina dos estrategias y elige la más rectangular:
//  A) región clara (umbral de Otsu + cierre morfológico + mayor componente)
//  B) contorno por gradiente (Sobel + relleno desde los bordes de la imagen)
// Después: envolvente convexa → cuadrilátero de área máxima → orden horario.
import { luminance } from './filters.js';
function boxBlur(src, w, h, r) {
    const tmp = new Uint8ClampedArray(src.length);
    const out = new Uint8ClampedArray(src.length);
    for (let y = 0; y < h; y++) {
        let s = 0;
        const row = y * w;
        for (let x = -r; x <= r; x++)
            s += src[row + Math.min(w - 1, Math.max(0, x))];
        for (let x = 0; x < w; x++) {
            tmp[row + x] = s / (2 * r + 1);
            s += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)];
        }
    }
    for (let x = 0; x < w; x++) {
        let s = 0;
        for (let y = -r; y <= r; y++)
            s += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
        for (let y = 0; y < h; y++) {
            out[y * w + x] = s / (2 * r + 1);
            s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
        }
    }
    return out;
}
export function otsu(gray) {
    const hist = new Float64Array(256);
    for (let i = 0; i < gray.length; i++)
        hist[gray[i]]++;
    const total = gray.length;
    let sum = 0;
    for (let i = 0; i < 256; i++)
        sum += i * hist[i];
    let sumB = 0, wB = 0, best = 0, t = 127;
    for (let i = 0; i < 256; i++) {
        wB += hist[i];
        if (!wB)
            continue;
        const wF = total - wB;
        if (!wF)
            break;
        sumB += i * hist[i];
        const mB = sumB / wB, mF = (sum - sumB) / wF;
        const between = wB * wF * (mB - mF) ** 2;
        if (between > best) {
            best = between;
            t = i;
        }
    }
    return t;
}
function morph(mask, w, h, r, dilate) {
    // separable: horizontal y luego vertical
    const tmp = new Uint8Array(mask.length);
    const out = new Uint8Array(mask.length);
    const want = dilate ? 1 : 0;
    for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
            let v = dilate ? 0 : 1;
            for (let dx = -r; dx <= r && v !== want; dx++) {
                const xx = x + dx;
                if (xx < 0 || xx >= w)
                    continue;
                if (mask[y * w + xx] === want)
                    v = want;
            }
            tmp[y * w + x] = v;
        }
    for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
            let v = dilate ? 0 : 1;
            for (let dy = -r; dy <= r && v !== want; dy++) {
                const yy = y + dy;
                if (yy < 0 || yy >= h)
                    continue;
                if (tmp[yy * w + x] === want)
                    v = want;
            }
            out[y * w + x] = v;
        }
    return out;
}
/** Mayor componente conexa (4-vecinos). Devuelve extremos por fila y área. */
function largestComponent(mask, w, h) {
    const label = new Int32Array(mask.length);
    const stack = new Int32Array(mask.length);
    let bestArea = 0, bestLabel = 0, next = 1;
    for (let i = 0; i < mask.length; i++) {
        if (!mask[i] || label[i])
            continue;
        let sp = 0, area = 0;
        stack[sp++] = i;
        label[i] = next;
        while (sp) {
            const p = stack[--sp];
            area++;
            const x = p % w, y = (p - x) / w;
            if (x > 0 && mask[p - 1] && !label[p - 1]) {
                label[p - 1] = next;
                stack[sp++] = p - 1;
            }
            if (x < w - 1 && mask[p + 1] && !label[p + 1]) {
                label[p + 1] = next;
                stack[sp++] = p + 1;
            }
            if (y > 0 && mask[p - w] && !label[p - w]) {
                label[p - w] = next;
                stack[sp++] = p - w;
            }
            if (y < h - 1 && mask[p + w] && !label[p + w]) {
                label[p + w] = next;
                stack[sp++] = p + w;
            }
        }
        if (area > bestArea) {
            bestArea = area;
            bestLabel = next;
        }
        next++;
    }
    if (!bestLabel)
        return null;
    const rows = new Map();
    for (let y = 0; y < h; y++) {
        let l = -1, r = -1;
        for (let x = 0; x < w; x++)
            if (label[y * w + x] === bestLabel) {
                if (l < 0)
                    l = x;
                r = x;
            }
        if (l >= 0)
            rows.set(y, [l, r]);
    }
    return { rows, area: bestArea };
}
function cross(o, a, b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); }
export function convexHull(pts) {
    const p = [...pts].sort((a, b) => a.x - b.x || a.y - b.y);
    if (p.length < 3)
        return p;
    const lower = [];
    for (const q of p) {
        while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], q) <= 0)
            lower.pop();
        lower.push(q);
    }
    const upper = [];
    for (let i = p.length - 1; i >= 0; i--) {
        const q = p[i];
        while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], q) <= 0)
            upper.pop();
        upper.push(q);
    }
    upper.pop();
    lower.pop();
    return lower.concat(upper);
}
export function polyArea(p) {
    let a = 0;
    for (let i = 0; i < p.length; i++) {
        const j = (i + 1) % p.length;
        a += p[i].x * p[j].y - p[j].x * p[i].y;
    }
    return Math.abs(a) / 2;
}
function simplify(hull, maxPts) {
    // elimina repetidamente el vértice que menos área aporta (Visvalingam)
    const p = [...hull];
    while (p.length > maxPts) {
        let mi = 0, ma = Infinity;
        for (let i = 0; i < p.length; i++) {
            const a = p[(i - 1 + p.length) % p.length], b = p[i], c = p[(i + 1) % p.length];
            const ar = Math.abs(cross(a, b, c));
            if (ar < ma) {
                ma = ar;
                mi = i;
            }
        }
        p.splice(mi, 1);
    }
    return p;
}
function maxAreaQuad(hull) {
    const p = simplify(hull, 22);
    if (p.length < 4)
        return null;
    let best = null, bestA = 0;
    const n = p.length;
    for (let a = 0; a < n; a++)
        for (let b = a + 1; b < n; b++)
            for (let c = b + 1; c < n; c++)
                for (let d = c + 1; d < n; d++) {
                    const q = [p[a], p[b], p[c], p[d]];
                    const ar = polyArea(q);
                    if (ar > bestA) {
                        bestA = ar;
                        best = q;
                    }
                }
    return best;
}
export function orderQuad(pts) {
    const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
    const cy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
    const sorted = [...pts].sort((a, b) => Math.atan2(a.y - cy, a.x - cx) - Math.atan2(b.y - cy, b.x - cx));
    // empezar por el de menor x+y (sup-izq); el orden por ángulo ya es horario en coordenadas de pantalla
    let start = 0;
    for (let i = 1; i < 4; i++)
        if (sorted[i].x + sorted[i].y < sorted[start].x + sorted[start].y)
            start = i;
    return [0, 1, 2, 3].map(i => sorted[(start + i) % 4]);
}
export function isConvexQuad(q) {
    let sign = 0;
    for (let i = 0; i < 4; i++) {
        const c = cross(q[i], q[(i + 1) % 4], q[(i + 2) % 4]);
        if (Math.abs(c) < 1e-6)
            return false;
        const s = Math.sign(c);
        if (!sign)
            sign = s;
        else if (s !== sign)
            return false;
    }
    return true;
}
function candidateFrom(mask, w, h) {
    const comp = largestComponent(mask, w, h);
    if (!comp)
        return null;
    const frac = comp.area / (w * h);
    if (frac < 0.08)
        return null;
    const pts = [];
    for (const [y, [l, r]] of comp.rows) {
        pts.push({ x: l, y }, { x: r + 1, y }, { x: l, y: y + 1 }, { x: r + 1, y: y + 1 });
    }
    const hull = convexHull(pts);
    const quad = maxAreaQuad(hull);
    if (!quad)
        return null;
    const qa = polyArea(quad);
    const ha = polyArea(hull);
    const rect = Math.min(comp.area / qa, qa / comp.area); // ~1 si el componente es un cuadrilátero lleno
    const fit = qa / ha;
    if (rect < 0.75 || fit < 0.88)
        return null;
    const ordered = orderQuad(quad);
    if (!isConvexQuad(ordered))
        return null;
    // penaliza la imagen completa (no aporta recorte) y las regiones pequeñas
    const full = qa / (w * h);
    // casi toda la imagen: no hay bordes que recortar (la foto ya está encuadrada o no hay hoja)
    if (full > 0.965)
        return null;
    const score = rect * fit * Math.min(1, full * 2.2);
    return { quad: ordered, score };
}
/** Detecta la hoja. Recibe una imagen pequeña (≈ 300–500 px). Devuelve null si no hay confianza. */
export function detectDocument(img) {
    const { width: w, height: h } = img;
    const gray = boxBlur(luminance(img), w, h, 2);
    const cands = [];
    // A) región clara
    const t = otsu(gray);
    let maskA = new Uint8Array(w * h);
    for (let i = 0; i < gray.length; i++)
        maskA[i] = gray[i] > t ? 1 : 0;
    const r = Math.max(2, Math.round(Math.min(w, h) / 80));
    maskA = morph(morph(maskA, w, h, r, true), w, h, r, false); // cierre: tapa el texto
    maskA = morph(morph(maskA, w, h, r, false), w, h, r, true); // apertura: quita ruido
    const a = candidateFrom(maskA, w, h);
    if (a)
        cands.push(a);
    // B) bordes por gradiente
    const mag = new Uint8ClampedArray(w * h);
    for (let y = 1; y < h - 1; y++)
        for (let x = 1; x < w - 1; x++) {
            const i = y * w + x;
            const gx = -gray[i - w - 1] - 2 * gray[i - 1] - gray[i + w - 1] + gray[i - w + 1] + 2 * gray[i + 1] + gray[i + w + 1];
            const gy = -gray[i - w - 1] - 2 * gray[i - w] - gray[i - w + 1] + gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1];
            mag[i] = Math.min(255, Math.sqrt(gx * gx + gy * gy) / 4);
        }
    const hist = new Uint32Array(256);
    for (let i = 0; i < mag.length; i++)
        hist[mag[i]]++;
    let acc = 0, p85 = 255;
    for (let i = 0; i < 256; i++) {
        acc += hist[i];
        if (acc >= mag.length * 0.88) {
            p85 = i;
            break;
        }
    }
    const et = Math.max(12, p85);
    let edges = new Uint8Array(w * h);
    for (let i = 0; i < mag.length; i++)
        edges[i] = mag[i] > et ? 1 : 0;
    edges = morph(edges, w, h, 1, true);
    // relleno desde el marco: lo que no se alcanza es el interior de la hoja
    const outside = new Uint8Array(w * h);
    const stack = [];
    const pushIf = (i) => { if (!edges[i] && !outside[i]) {
        outside[i] = 1;
        stack.push(i);
    } };
    for (let x = 0; x < w; x++) {
        pushIf(x);
        pushIf((h - 1) * w + x);
    }
    for (let y = 0; y < h; y++) {
        pushIf(y * w);
        pushIf(y * w + w - 1);
    }
    while (stack.length) {
        const p = stack.pop();
        const x = p % w, y = (p - x) / w;
        if (x > 0)
            pushIf(p - 1);
        if (x < w - 1)
            pushIf(p + 1);
        if (y > 0)
            pushIf(p - w);
        if (y < h - 1)
            pushIf(p + w);
    }
    let maskB = new Uint8Array(w * h);
    for (let i = 0; i < maskB.length; i++)
        maskB[i] = outside[i] ? 0 : 1;
    maskB = morph(maskB, w, h, 1, false);
    const b = candidateFrom(maskB, w, h);
    if (b)
        cands.push(b);
    if (!cands.length)
        return null;
    cands.sort((x, y) => y.score - x.score);
    return cands[0].score > 0.35 ? cands[0].quad : null;
}
export function fullQuad(w, h, inset = 0) {
    const ix = w * inset, iy = h * inset;
    return [{ x: ix, y: iy }, { x: w - ix, y: iy }, { x: w - ix, y: h - iy }, { x: ix, y: h - iy }];
}
// ---------------------------------------------------------------------------
// Refinamiento fino de los bordes a mayor resolución.
// Para cada lado del cuadrilátero aproximado se buscan, en perpendicular, los puntos
// de máximo gradiente; se ajusta una recta robusta (mínimos cuadrados totales con
// descarte de atípicos) y las esquinas se recalculan como intersección de rectas.
// Así las esquinas quedan a nivel de subpíxel aunque estén redondeadas o tapadas.
// ---------------------------------------------------------------------------
function sample(g, w, h, x, y) {
    if (x < 0)
        x = 0;
    else if (x > w - 1.001)
        x = w - 1.001;
    if (y < 0)
        y = 0;
    else if (y > h - 1.001)
        y = h - 1.001;
    const x0 = x | 0, y0 = y | 0, tx = x - x0, ty = y - y0, i = y0 * w + x0;
    return (g[i] * (1 - tx) + g[i + 1] * tx) * (1 - ty) + (g[i + w] * (1 - tx) + g[i + w + 1] * tx) * ty;
}
function fitLine(pts) {
    if (pts.length < 2)
        return null;
    let mx = 0, my = 0;
    for (const p of pts) {
        mx += p.x;
        my += p.y;
    }
    mx /= pts.length;
    my /= pts.length;
    let sxx = 0, syy = 0, sxy = 0;
    for (const p of pts) {
        const dx = p.x - mx, dy = p.y - my;
        sxx += dx * dx;
        syy += dy * dy;
        sxy += dx * dy;
    }
    const ang = 0.5 * Math.atan2(2 * sxy, sxx - syy);
    return { px: mx, py: my, dx: Math.cos(ang), dy: Math.sin(ang) };
}
const resid = (l, p) => Math.abs((p.x - l.px) * l.dy - (p.y - l.py) * l.dx);
function intersect(a, b) {
    const den = a.dx * b.dy - a.dy * b.dx;
    if (Math.abs(den) < 1e-6)
        return null;
    const t = ((b.px - a.px) * b.dy - (b.py - a.py) * b.dx) / den;
    return { x: a.px + a.dx * t, y: a.py + a.dy * t };
}
/** Ajusta el cuadrilátero `q` (en píxeles de `img`) a los bordes reales. */
export function refineQuad(img, q) {
    const { width: w, height: h } = img;
    const g = boxBlur(luminance(img), w, h, 1);
    const R = Math.max(5, Math.round(Math.max(w, h) * 0.022));
    const lines = [];
    for (let e = 0; e < 4; e++) {
        const a = q[e], b = q[(e + 1) % 4];
        const len = Math.hypot(b.x - a.x, b.y - a.y);
        if (len < 10) {
            lines.push(null);
            continue;
        }
        const ux = (b.x - a.x) / len, uy = (b.y - a.y) / len, nx = -uy, ny = ux;
        const K = Math.min(60, Math.max(12, Math.round(len / 6)));
        const pts = [];
        for (let k = 0; k < K; k++) {
            const t = 0.08 + 0.84 * (k / (K - 1));
            const cx = a.x + (b.x - a.x) * t, cy = a.y + (b.y - a.y) * t;
            let best = 0, bs = 0, prev = 0, cur = 0, next = 0;
            const prof = [];
            for (let s = -R; s <= R; s++)
                prof.push(Math.abs(sample(g, w, h, cx + nx * (s + 1), cy + ny * (s + 1)) - sample(g, w, h, cx + nx * (s - 1), cy + ny * (s - 1))));
            for (let i = 1; i < prof.length - 1; i++)
                if (prof[i] > best) {
                    best = prof[i];
                    bs = i;
                }
            if (best < 14 || bs === 0)
                continue;
            prev = prof[bs - 1];
            cur = prof[bs];
            next = prof[bs + 1];
            const den = prev - 2 * cur + next;
            const off = den < 0 ? 0.5 * (prev - next) / den : 0; // máximo subpíxel (parábola)
            const s = bs - R + off;
            pts.push({ x: cx + nx * s, y: cy + ny * s });
        }
        if (pts.length < Math.max(6, K * 0.3)) {
            lines.push(null);
            continue;
        }
        let line = fitLine(pts);
        for (let it = 0; it < 3; it++) {
            const rs = pts.map(p => resid(line, p)).sort((x, y) => x - y);
            const thr = Math.max(1.2, rs[Math.floor(rs.length / 2)] * 2.5);
            const keep = pts.filter(p => resid(line, p) <= thr);
            if (keep.length < 6)
                break;
            line = fitLine(keep);
        }
        lines.push(line);
    }
    const out = [];
    for (let i = 0; i < 4; i++) {
        const prev = lines[(i + 3) % 4], cur = lines[i];
        const p = prev && cur ? intersect(prev, cur) : null;
        out.push(p && Math.hypot(p.x - q[i].x, p.y - q[i].y) < R * 2.5 ? { x: Math.min(w, Math.max(0, p.x)), y: Math.min(h, Math.max(0, p.y)) } : q[i]);
    }
    return isConvexQuad(out) ? out : q;
}
