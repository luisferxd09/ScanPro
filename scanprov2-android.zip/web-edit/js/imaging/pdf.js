// Generador de PDF propio: incrusta las páginas JPEG tal cual (DCTDecode), sin recomprimir.
// Puro (sin DOM); válido para PDF 1.7. Se verifica en las pruebas con pdfinfo/qpdf.
import { pdfCrypt, objKey, rc4, hex } from './crypt.js';
export const SIZES = {
    a4: [595.28, 841.89],
    letter: [612, 792],
};
/** Lee ancho, alto y nº de componentes del marcador SOF de un JPEG. */
export function jpegInfo(b) {
    if (b[0] !== 0xff || b[1] !== 0xd8)
        throw new Error('La imagen no es un JPEG válido.');
    let i = 2;
    while (i < b.length) {
        if (b[i] !== 0xff) {
            i++;
            continue;
        }
        const m = b[i + 1];
        if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) {
            i += 2;
            continue;
        }
        const len = (b[i + 2] << 8) | b[i + 3];
        if ((m >= 0xc0 && m <= 0xcf) && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
            return { height: (b[i + 5] << 8) | b[i + 6], width: (b[i + 7] << 8) | b[i + 8], components: b[i + 9] };
        }
        i += 2 + len;
    }
    throw new Error('JPEG dañado: no se encontró el tamaño de la imagen.');
}
const enc = new TextEncoder();
function pdfDate(d = new Date()) {
    const p = (n) => String(n).padStart(2, '0');
    return `D:${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}Z`;
}
const f = (n) => (Math.round(n * 100) / 100).toString();
/** Calcula tamaño de página y rectángulo de la imagen (encajada, centrada, sin deformar). */
export function layoutPage(imgW, imgH, o) {
    let pw, ph;
    if (o.size === 'original') {
        const dpi = o.dpiOriginal ?? 200;
        const s = 72 / dpi;
        pw = imgW * s + o.margin * 2;
        ph = imgH * s + o.margin * 2;
    }
    else {
        [pw, ph] = SIZES[o.size];
        const land = o.orientation === 'landscape' || (o.orientation === 'auto' && imgW > imgH);
        if (land)
            [pw, ph] = [ph, pw];
    }
    const aw = Math.max(1, pw - o.margin * 2), ah = Math.max(1, ph - o.margin * 2);
    const s = Math.min(aw / imgW, ah / imgH);
    const w = imgW * s, h = imgH * s;
    return { pw, ph, w, h, x: (pw - w) / 2, y: (ph - h) / 2 };
}
// texto en WinAnsi (español: tildes, ñ, ¿¡ incluidos); lo demás se sustituye por «?»
function winAnsi(t) {
    const out = [];
    for (const ch of t.normalize('NFC')) {
        const c = ch.charCodeAt(0);
        out.push(c < 256 && ch.length === 1 ? c : ch === '€' ? 0x80 : ch === '“' ? 0x93 : ch === '”' ? 0x94 : ch === '–' ? 0x96 : ch === '—' ? 0x97 : ch === '‘' ? 0x91 : ch === '’' ? 0x92 : ch === '…' ? 0x85 : 63);
    }
    return new Uint8Array(out);
}
export function buildPdf(pages, o) {
    if (!pages.length)
        throw new Error('No hay páginas que exportar.');
    const chunks = [];
    const offsets = [];
    let pos = 0;
    const push = (c) => { const u = typeof c === 'string' ? enc.encode(c) : c; chunks.push(u); pos += u.length; };
    const obj = (n, body) => {
        offsets[n] = pos;
        if (typeof body === 'string')
            push(`${n} 0 obj\n${body}\nendobj\n`);
        else {
            push(`${n} 0 obj\n`);
            body.forEach(push);
            push(`\nendobj\n`);
        }
    };
    const id = crypto.getRandomValues(new Uint8Array(16));
    const cr = o.password ? pdfCrypt(o.password, id) : null;
    const sealed = (num, data) => cr ? rc4(objKey(cr, num), data) : data;
    const str = (num, data) => `<${hex(sealed(num, data))}>`;
    const stream = (num, dict, data) => { const d = sealed(num, data); return [enc.encode(`<< ${dict} /Length ${d.length} >>\nstream\n`), d, enc.encode('\nendstream')]; };
    push('%PDF-1.7\n');
    push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));
    const n = pages.length;
    // 1 catálogo, 2 páginas, 3 info, 4 fuente, 5 cifrado; cada página usa 3 objetos (página, contenido, imagen)
    const pageObj = (i) => 6 + i * 3;
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Count ${n} /Kids [${pages.map((_, i) => `${pageObj(i)} 0 R`).join(' ')}] >>`);
    const u16 = (t) => { const b = [0xfe, 0xff]; for (const ch of t) {
        const cp = ch.codePointAt(0);
        if (cp > 0xffff) {
            const v = cp - 0x10000, hi = 0xd800 + (v >> 10), lo = 0xdc00 + (v & 0x3ff);
            b.push(hi >> 8, hi & 255, lo >> 8, lo & 255);
        }
        else
            b.push(cp >> 8, cp & 255);
    } return new Uint8Array(b); };
    obj(3, `<< /Producer ${str(3, enc.encode('ScanPro'))} /Creator ${str(3, enc.encode('ScanPro'))} /CreationDate ${str(3, enc.encode(pdfDate()))}${o.title ? ` /Title ${str(3, u16(o.title))}` : ''} >>`);
    obj(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    if (cr)
        obj(5, `<< /Filter /Standard /V 2 /R 3 /Length 128 /P ${cr.P} /O <${hex(cr.O)}> /U <${hex(cr.U)}> >>`);
    else
        obj(5, '<< >>');
    pages.forEach((p, i) => {
        const info = jpegInfo(p.jpeg);
        const L = layoutPage(info.width, info.height, o);
        const po = pageObj(i), co = po + 1, io = po + 2;
        let content = `q\n${f(L.w)} 0 0 ${f(L.h)} ${f(L.x)} ${f(L.y)} cm\n/Im0 Do\nQ\n`;
        // capa de texto invisible (modo 3): permite buscar, seleccionar y copiar
        if (p.lines?.length) {
            const sw = p.srcW ?? info.width, sh = p.srcH ?? info.height, kx = L.w / sw, ky = L.h / sh;
            content += 'BT\n3 Tr\n';
            for (const ln of p.lines) {
                const bytes = winAnsi(ln.t);
                if (!bytes.length)
                    continue;
                const size = Math.max(1, (ln.y1 - ln.y0) * ky * 0.92), width = (ln.x1 - ln.x0) * kx;
                const tz = Math.max(10, Math.min(500, width / (bytes.length * size * 0.5) * 100));
                content += `/F1 ${f(size)} Tf ${f(tz)} Tz 1 0 0 1 ${f(L.x + ln.x0 * kx)} ${f(L.y + (sh - ln.y1) * ky + size * 0.12)} Tm <${hex(bytes)}> Tj\n`;
            }
            content += 'ET\n';
        }
        obj(po, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(L.pw)} ${f(L.ph)}] /Resources << /XObject << /Im0 ${io} 0 R >> /Font << /F1 4 0 R >> >> /Contents ${co} 0 R >>`);
        obj(co, stream(co, '', enc.encode(content)));
        const cs = info.components === 1 ? '/DeviceGray' : info.components === 4 ? '/DeviceCMYK' : '/DeviceRGB';
        obj(io, stream(io, `/Type /XObject /Subtype /Image /Width ${info.width} /Height ${info.height} /ColorSpace ${cs} /BitsPerComponent 8 /Filter /DCTDecode`, p.jpeg));
    });
    const total = 6 + n * 3;
    const xref = pos;
    let x = `xref\n0 ${total}\n0000000000 65535 f \n`;
    for (let i = 1; i < total; i++)
        x += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    push(x);
    push(`trailer\n<< /Size ${total} /Root 1 0 R /Info 3 0 R${cr ? ' /Encrypt 5 0 R' : ''} /ID [<${hex(id)}> <${hex(id)}>] >>\nstartxref\n${xref}\n%%EOF\n`);
    const out = new Uint8Array(pos);
    let k = 0;
    for (const c of chunks) {
        out.set(c, k);
        k += c.length;
    }
    return out;
}
