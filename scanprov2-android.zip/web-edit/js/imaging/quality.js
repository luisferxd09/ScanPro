// Calidad de la foto (puro, sin DOM): nitidez y orientación del texto.
import { luminance } from './filters.js';
/**
 * Nitidez de 0 a ~1: pendiente de los bordes más fuertes respecto al contraste de la imagen.
 * Un borde de texto nítido sube de oscuro a claro en 1–2 píxeles; uno desenfocado, en muchos.
 * Se evalúa la página con su lado corto a PAGE_PX (≈ A4 a 150 ppp), así el valor mide
 * el desenfoque sobre el papel y no depende de la resolución de la cámara.
 */
export function sharpness(img) {
    const { width: w, height: h } = img;
    const g = luminance(img);
    // solo la zona interior (evita el borde del papel y el fondo)
    const x0 = Math.round(w * 0.08), x1 = Math.round(w * 0.92), y0 = Math.round(h * 0.08), y1 = Math.round(h * 0.92);
    const R = 4;
    const vals = [];
    const mags = [];
    // primera pasada: magnitud del gradiente para elegir los bordes más fuertes
    const mag = new Float32Array(w * h);
    for (let y = Math.max(1, y0); y < Math.min(h - 1, y1); y++)
        for (let x = Math.max(1, x0); x < Math.min(w - 1, x1); x++) {
            const i = y * w + x;
            const gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1];
            const gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1];
            mag[i] = Math.sqrt(gx * gx + gy * gy) / 8;
            mags.push(mag[i]);
        }
    if (!mags.length)
        return 0;
    const sorted = Float32Array.from(mags).sort();
    const thr = Math.max(4, sorted[Math.floor(sorted.length * 0.985)]);
    // segunda pasada: en cada borde fuerte, pendiente / contraste local (9×9). Nítido → ~0,5; borroso → bajo
    for (let y = Math.max(R, y0); y < Math.min(h - R, y1); y += 1)
        for (let x = Math.max(R, x0); x < Math.min(w - R, x1); x += 1) {
            const i = y * w + x;
            if (mag[i] < thr)
                continue;
            let lo = 255, hi = 0;
            for (let dy = -R; dy <= R; dy += 2) {
                const row = (y + dy) * w;
                for (let dx = -R; dx <= R; dx += 2) {
                    const v = g[row + x + dx];
                    if (v < lo)
                        lo = v;
                    if (v > hi)
                        hi = v;
                }
            }
            if (hi - lo < 20)
                continue;
            vals.push(mag[i] / (hi - lo));
            if (vals.length > 40000)
                break;
        }
    if (vals.length < 50)
        return 0;
    vals.sort((a, b) => a - b);
    return vals[Math.floor(vals.length * 0.5)];
}
export const PAGE_PX = 1240;
/** Umbral por debajo del cual se avisa de que la foto está borrosa (calibrado con fotos reales). */
export const BLURRY = 0.34;
/**
 * Orientación del texto. Devuelve 0, 90 o 270: los grados que hay que girar (en sentido horario)
 * para que las líneas de texto queden horizontales y legibles. Si no hay suficiente certeza, 0.
 */
export function textRotation(img) {
    const { width: w, height: h } = img;
    const g = luminance(img);
    // tinta = píxeles claramente más oscuros que su entorno (umbral local con imagen integral)
    const ink = new Uint8Array(w * h);
    const integ = new Float64Array((w + 1) * (h + 1));
    for (let y = 0; y < h; y++) {
        let row = 0;
        for (let x = 0; x < w; x++) {
            row += g[y * w + x];
            integ[(y + 1) * (w + 1) + x + 1] = integ[y * (w + 1) + x + 1] + row;
        }
    }
    const r = Math.max(6, Math.round(Math.min(w, h) / 30));
    let inkCount = 0;
    for (let y = 0; y < h; y++) {
        const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
        for (let x = 0; x < w; x++) {
            const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
            const mean = (integ[y1 * (w + 1) + x1] - integ[y0 * (w + 1) + x1] - integ[y1 * (w + 1) + x0] + integ[y0 * (w + 1) + x0]) / ((y1 - y0) * (x1 - x0));
            if (g[y * w + x] < mean * 0.82 && g[y * w + x] < 200) {
                ink[y * w + x] = 1;
                inkCount++;
            }
        }
    }
    if (inkCount < w * h * 0.004)
        return 0; // casi sin texto
    // ignora un margen del 4 % (bordes del papel y sombras)
    const mx = Math.round(w * 0.04), my = Math.round(h * 0.04);
    const rows = new Float64Array(h), cols = new Float64Array(w);
    for (let y = my; y < h - my; y++)
        for (let x = mx; x < w - mx; x++)
            if (ink[y * w + x]) {
                rows[y]++;
                cols[x]++;
            }
    // las líneas de texto alternan tinta/hueco: el perfil perpendicular a ellas (suavizado a escala
    // de letra) varía mucho más que el paralelo, donde los trazos se promedian
    const variation = (p, from, to) => {
        const k = Math.max(2, Math.round((to - from) / 150));
        const sm = [];
        for (let i = from; i < to; i++) {
            let a = 0, n = 0;
            for (let j = i - k; j <= i + k; j++)
                if (j >= from && j < to) {
                    a += p[j];
                    n++;
                }
            sm.push(a / n);
        }
        const m = sm.reduce((x, y) => x + y, 0) / sm.length;
        return Math.sqrt(sm.reduce((x, y) => x + (y - m) ** 2, 0) / sm.length) / Math.max(1e-6, m);
    };
    // solo dentro del bloque de texto (sin márgenes en blanco ni zonas vacías al final)
    const bounds = (p, from, to) => {
        let tot = 0;
        for (let i = from; i < to; i++)
            tot += p[i];
        let acc = 0, a = from, b = to;
        for (let i = from; i < to; i++) {
            acc += p[i];
            if (acc >= tot * 0.02) {
                a = i;
                break;
            }
        }
        acc = 0;
        for (let i = to - 1; i >= from; i--) {
            acc += p[i];
            if (acc >= tot * 0.02) {
                b = i + 1;
                break;
            }
        }
        return b - a > 20 ? [a, b] : [from, to];
    };
    const [ry0, ry1] = bounds(rows, my, h - my), [cx0, cx1] = bounds(cols, mx, w - mx);
    const rowW = variation(rows, ry0, ry1), colW = variation(cols, cx0, cx1);
    if (globalThis.__qdebug)
        console.log('variación', rowW.toFixed(3), colW.toFixed(3));
    if (rowW >= colW * 1.25)
        return 0; // texto horizontal
    if (colW < rowW * 1.35)
        return 0; // no hay certeza suficiente
    // texto vertical: ¿girar 90 o 270? Las líneas empiezan alineadas (margen izquierdo recto)
    // y terminan desiguales. Tras girar 90° horario, el inicio de las líneas queda arriba en la imagen original
    // si el texto se lee de arriba abajo.
    const lineStarts = [], lineEnds = [];
    let inLine = false, a = 0;
    const thr = Math.max(...Array.from(cols)) * 0.12;
    for (let x = mx; x <= w - mx; x++) {
        const on = x < w - mx && cols[x] > thr;
        if (on && !inLine) {
            inLine = true;
            a = x;
        }
        if (!on && inLine) {
            inLine = false;
            if (x - a < 3)
                continue;
            let top = -1, bot = -1;
            for (let y = my; y < h - my; y++) {
                let any = false;
                for (let xx = a; xx < x && !any; xx++)
                    if (ink[y * w + xx])
                        any = true;
                if (any) {
                    if (top < 0)
                        top = y;
                    bot = y;
                }
            }
            if (top >= 0 && bot - top > h * 0.08) {
                lineStarts.push(top);
                lineEnds.push(bot);
            }
        }
    }
    if (lineStarts.length < 3)
        return 0;
    const sd = (v) => { const m = v.reduce((s, x) => s + x, 0) / v.length; return Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / v.length); };
    const sTop = sd(lineStarts), sBot = sd(lineEnds);
    // alineado arriba → el texto se lee de arriba abajo → girar 270° (antihorario) lo endereza
    if (sTop < sBot * 0.8)
        return 270;
    if (sBot < sTop * 0.8)
        return 90;
    return 0;
}
