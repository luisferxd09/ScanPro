// Web Worker de imagen: todo el trabajo pesado ocurre aquí, fuera del hilo de la interfaz.
import { Engine, detectSmall, frameInfo, sharpOf } from './engine-core.js';
const engine = new Engine();
const ops = {
    ping: () => typeof OffscreenCanvas !== 'undefined' && !!new OffscreenCanvas(2, 2).getContext('2d') && typeof createImageBitmap === 'function',
    detectFrame: (bmp) => { try {
        return detectSmall(bmp, 360);
    }
    finally {
        bmp.close();
    } },
    frameInfo: (bmp, crop) => { try {
        return frameInfo(bmp, crop);
    }
    finally {
        bmp.close();
        crop?.close();
    } },
    sharpOf: (bmp) => { try {
        return sharpOf(bmp);
    }
    finally {
        bmp.close();
    } },
    ingest: (key, src, hint, detect) => engine.ingest(key, src, hint, detect),
    view: (key, fb, max) => engine.view(key, fb, max),
    encodeOriginal: (key, q) => engine.encodeOriginal(key, q),
    detectAgain: (key, fb) => engine.detectAgain(key, fb),
    render: (key, fb, p) => engine.render(key, fb, p),
    setBase: (key, fb, c) => engine.setBase(key, fb, c),
    preview: (key, r, f, a) => engine.preview(key, r, f, a),
    thumbs: (key, r, f) => engine.thumbs(key, r, f),
    drop: (key) => engine.drop(key),
};
self.onmessage = async (ev) => {
    const { id, op, args } = ev.data;
    try {
        const result = await ops[op](...args);
        const transfer = [];
        if (result instanceof ImageBitmap)
            transfer.push(result);
        else if (Array.isArray(result))
            for (const r of result)
                if (r instanceof ImageBitmap)
                    transfer.push(r);
        self.postMessage({ id, ok: true, result }, transfer);
    }
    catch (e) {
        self.postMessage({ id, ok: false, error: e?.message ?? String(e) });
    }
};
