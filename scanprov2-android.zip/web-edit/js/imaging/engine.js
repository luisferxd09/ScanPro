// Cliente del motor de imagen: usa el Web Worker si el navegador lo permite (Chrome Android 80+),
// y si no, ejecuta el mismo código en el hilo principal.
import { Engine, detectSmall, frameInfo, sharpOf } from './engine-core.js';
let worker = null;
let ready = null;
let local = null;
let seq = 0;
const pending = new Map();
function failAll(msg) {
    for (const p of pending.values())
        p.rej(new Error(msg));
    pending.clear();
}
function boot() {
    if (ready)
        return ready;
    ready = new Promise(resolve => {
        try {
            worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
        }
        catch {
            resolve(false);
            return;
        }
        worker.onmessage = (ev) => {
            const p = pending.get(ev.data.id);
            if (!p)
                return;
            pending.delete(ev.data.id);
            if (ev.data.ok)
                p.res(ev.data.result);
            else
                p.rej(new Error(ev.data.error));
        };
        worker.onerror = () => { failAll('El procesador de imágenes se detuvo (memoria insuficiente). Vuelve a intentarlo.'); worker?.terminate(); worker = null; ready = Promise.resolve(false); resolve(false); };
        const t = setTimeout(() => resolve(false), 3000);
        call('ping', []).then(ok => { clearTimeout(t); resolve(!!ok); }, () => { clearTimeout(t); resolve(false); });
    }).then(ok => { if (!ok) {
        worker?.terminate();
        worker = null;
    } return ok; });
    return ready;
}
function call(op, args, transfer = []) {
    return new Promise((res, rej) => {
        const id = ++seq;
        pending.set(id, { res: res, rej });
        worker.postMessage({ id, op, args }, transfer);
    });
}
async function run(op, args, transfer = []) {
    if (await boot())
        return call(op, args, transfer);
    local ??= new Engine();
    if (op === 'detectFrame') {
        const b = args[0];
        try {
            return detectSmall(b, 360);
        }
        finally {
            b.close();
        }
    }
    if (op === 'frameInfo') {
        const [b, c] = args;
        try {
            return frameInfo(b, c);
        }
        finally {
            b.close();
            c?.close();
        }
    }
    if (op === 'sharpOf') {
        const b = args[0];
        try {
            return sharpOf(b);
        }
        finally {
            b.close();
        }
    }
    return local[op](...args);
}
export const engine = {
    /** true si el trabajo pesado corre en segundo plano. */
    async inBackground() { return boot(); },
    detectFrame: (bmp) => run('detectFrame', [bmp], [bmp]),
    frameInfo: (bmp, crop) => run('frameInfo', [bmp, crop], crop ? [bmp, crop] : [bmp]),
    sharpOf: (bmp) => run('sharpOf', [bmp], [bmp]),
    ingest: (key, src, hint, detect) => run('ingest', [key, src, hint, detect], src instanceof ImageBitmap ? [src] : []),
    view: (key, fallback, maxSide) => run('view', [key, fallback, maxSide]),
    encodeOriginal: (key, q) => run('encodeOriginal', [key, q]),
    detectAgain: (key, fallback) => run('detectAgain', [key, fallback]),
    render: (key, fallback, p) => run('render', [key, fallback, p]),
    setBase: (key, fallback, corners) => run('setBase', [key, fallback, corners]),
    preview: (key, rotation, filter, adjust) => run('preview', [key, rotation, filter, adjust]),
    thumbs: (key, rotation, filters) => run('thumbs', [key, rotation, filters]),
    drop: (key) => run('drop', [key]),
};
// arranca el worker en cuanto se carga la app, para que la primera foto no espere
void boot();
