const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
/** Resuelve A·x = b (8×8) con eliminación gaussiana y pivoteo parcial. */
function solve(A, b) {
    const n = b.length;
    const M = A.map((row, i) => [...row, b[i]]);
    for (let c = 0; c < n; c++) {
        let piv = c;
        for (let r = c + 1; r < n; r++)
            if (Math.abs(M[r][c]) > Math.abs(M[piv][c]))
                piv = r;
        if (Math.abs(M[piv][c]) < 1e-12)
            throw new Error('Esquinas degeneradas: no forman un cuadrilátero válido.');
        [M[c], M[piv]] = [M[piv], M[c]];
        for (let r = 0; r < n; r++) {
            if (r === c)
                continue;
            const f = M[r][c] / M[c][c];
            for (let k = c; k <= n; k++)
                M[r][k] -= f * M[c][k];
        }
    }
    return M.map((row, i) => row[n] / row[i]);
}
/** Homografía H (3×3, fila mayor) que lleva src[i] → dst[i]. */
export function homography(src, dst) {
    const A = [];
    const b = [];
    for (let i = 0; i < 4; i++) {
        const { x, y } = src[i], { x: u, y: v } = dst[i];
        A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]);
        b.push(u);
        A.push([0, 0, 0, x, y, 1, -v * x, -v * y]);
        b.push(v);
    }
    const h = solve(A, b);
    return [...h, 1];
}
export function applyH(H, p) {
    const w = H[6] * p.x + H[7] * p.y + H[8];
    return { x: (H[0] * p.x + H[1] * p.y + H[2]) / w, y: (H[3] * p.x + H[4] * p.y + H[5]) / w };
}
/** Tamaño de salida que conserva la resolución de los bordes más largos. */
export function outputSize(q, maxSide) {
    let w = Math.max(dist(q[0], q[1]), dist(q[3], q[2]));
    let h = Math.max(dist(q[0], q[3]), dist(q[1], q[2]));
    const s = Math.min(1, maxSide / Math.max(w, h));
    w = Math.max(8, Math.round(w * s));
    h = Math.max(8, Math.round(h * s));
    return { w, h };
}
/** Endereza el cuadrilátero q de la imagen src a un rectángulo w×h. */
export function warpPerspective(src, q, w, h) {
    // mapeo inverso: destino → origen
    const H = homography([{ x: 0, y: 0 }, { x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h }], q);
    const out = new Uint8ClampedArray(w * h * 4);
    const sd = src.data, sw = src.width, sh = src.height;
    const s32 = new Uint32Array(sd.buffer, sd.byteOffset, sd.byteLength >> 2);
    const o32 = new Uint32Array(out.buffer);
    for (let y = 0; y < h; y++) {
        const py = y + 0.5;
        // términos que solo dependen de y
        const ax = H[1] * py + H[2], ay = H[4] * py + H[5], aw = H[7] * py + H[8];
        for (let x = 0; x < w; x++) {
            const px = x + 0.5;
            const iw = 1 / (H[6] * px + aw);
            let fx = (H[0] * px + ax) * iw - 0.5;
            let fy = (H[3] * px + ay) * iw - 0.5;
            if (fx < 0)
                fx = 0;
            else if (fx > sw - 1)
                fx = sw - 1;
            if (fy < 0)
                fy = 0;
            else if (fy > sh - 1)
                fy = sh - 1;
            const x0 = fx | 0, y0 = fy | 0;
            const x1 = x0 + 1 < sw ? x0 + 1 : x0, y1 = y0 + 1 < sh ? y0 + 1 : y0;
            const tx = fx - x0, ty = fy - y0;
            const i00 = (y0 * sw + x0) * 4, i10 = (y0 * sw + x1) * 4, i01 = (y1 * sw + x0) * 4, i11 = (y1 * sw + x1) * 4;
            const w00 = (1 - tx) * (1 - ty), w10 = tx * (1 - ty), w01 = (1 - tx) * ty, w11 = tx * ty;
            const r = sd[i00] * w00 + sd[i10] * w10 + sd[i01] * w01 + sd[i11] * w11;
            const g = sd[i00 + 1] * w00 + sd[i10 + 1] * w10 + sd[i01 + 1] * w01 + sd[i11 + 1] * w11;
            const b = sd[i00 + 2] * w00 + sd[i10 + 2] * w10 + sd[i01 + 2] * w01 + sd[i11 + 2] * w11;
            o32[y * w + x] = (255 << 24) | ((b + 0.5) << 16) | ((g + 0.5) << 8) | (r + 0.5);
        }
    }
    void s32;
    return { data: out, width: w, height: h };
}
export function scaleQuad(q, s) {
    return q.map(p => ({ x: p.x * s, y: p.y * s }));
}
export function quadToArray(q) { return q.flatMap(p => [p.x, p.y]); }
export function arrayToQuad(a) {
    return [0, 1, 2, 3].map(i => ({ x: a[i * 2], y: a[i * 2 + 1] }));
}
