// Formatos de imagen y documento: convierte lo que el navegador no sabe leer.
import { isNative, nativeConvertImage } from './native.js';
import { loadVendor } from './exporter.js';
const canDecode = async (b) => { try {
    const bm = await createImageBitmap(b);
    bm.close();
    return true;
}
catch {
    return false;
} };
const head = async (b, n = 12) => new Uint8Array(await b.slice(0, n).arrayBuffer());
export const isTiff = async (f) => { const b = await head(f, 4); return /\.tiff?$/i.test(f.name) || f.type === 'image/tiff' || (b[0] === 0x49 && b[1] === 0x49 && b[2] === 42) || (b[0] === 0x4d && b[1] === 0x4d && b[3] === 42); };
export const IMAGE_RX = /\.(jpe?g|jpe|jfif|pjpeg|png|apng|webp|gif|bmp|dib|heic|heif|hif|avif|tiff?|dng|ico|svg)$/i;
/** TIFF (también de varias páginas) → imágenes PNG. */
async function tiffToBlobs(f) {
    await loadVendor(isNative ? 'vendor/utif.js' : 'https://cdn.jsdelivr.net/npm/utif@3.1.0/UTIF.js');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const U = window.UTIF;
    const buf = await f.arrayBuffer(), ifds = U.decode(buf), out = [];
    for (const ifd of ifds) {
        if (!ifd.t256)
            continue;
        U.decodeImage(buf, ifd, ifds);
        const rgba = U.toRGBA8(ifd), w = ifd.width, h = ifd.height;
        if (!w || !h)
            continue;
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(rgba.buffer, rgba.byteOffset, w * h * 4), w, h), 0, 0);
        out.push(await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('tiff')), 'image/png')));
    }
    if (!out.length)
        throw new Error('TIFF sin páginas legibles.');
    return out;
}
/** SVG → PNG (a 2000 px por el lado mayor). */
async function svgToBlob(f) {
    const url = URL.createObjectURL(new Blob([await f.text()], { type: 'image/svg+xml' }));
    try {
        const im = new Image();
        im.src = url;
        await im.decode();
        const k = 2000 / Math.max(im.naturalWidth || 1000, im.naturalHeight || 1000), c = document.createElement('canvas');
        c.width = Math.round((im.naturalWidth || 1000) * k);
        c.height = Math.round((im.naturalHeight || 1000) * k);
        const g = c.getContext('2d');
        g.fillStyle = '#fff';
        g.fillRect(0, 0, c.width, c.height);
        g.drawImage(im, 0, 0, c.width, c.height);
        return await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('svg')), 'image/png'));
    }
    finally {
        URL.revokeObjectURL(url);
    }
}
/** Devuelve una o varias imágenes que la app sí sabe procesar. Lanza 'formato' si no hay forma. */
export async function toDecodableImages(f) {
    if (await isTiff(f))
        return tiffToBlobs(f);
    if (/\.svg$/i.test(f.name) || f.type === 'image/svg+xml')
        return [await svgToBlob(f)];
    if (await canDecode(f))
        return [f];
    if (isNative) {
        const b = await nativeConvertImage(f);
        if (await canDecode(b))
            return [b];
    }
    throw new Error('formato');
}
// ---------- hojas de cálculo: XLSX, ODS, CSV y TSV → páginas con tabla ----------
export const SHEET_RX = /\.(xlsx|xlsm|ods|csv|tsv)$/i;
async function zipOf(f) { await loadVendor('vendor/jszip.min.js'); return window.JSZip.loadAsync(f); }
const xml = (s) => new DOMParser().parseFromString(s, 'application/xml');
const colIdx = (ref) => { let n = 0; for (const c of ref.replace(/\d+/g, ''))
    n = n * 26 + c.charCodeAt(0) - 64; return n - 1; };
async function readSheets(f) {
    const n = f.name.toLowerCase();
    if (/\.(csv|tsv)$/.test(n)) {
        const txt = await f.text(), sep = /\.tsv$/.test(n) ? '\t' : (txt.split('\n')[0].split(';').length > txt.split('\n')[0].split(',').length ? ';' : ',');
        const rows = [];
        let row = [], cell = '', q = false;
        for (let i = 0; i < txt.length; i++) {
            const c = txt[i];
            if (q) {
                if (c === '"' && txt[i + 1] === '"') {
                    cell += '"';
                    i++;
                }
                else if (c === '"')
                    q = false;
                else
                    cell += c;
            }
            else if (c === '"')
                q = true;
            else if (c === sep) {
                row.push(cell);
                cell = '';
            }
            else if (c === '\n' || c === '\r') {
                if (c === '\r' && txt[i + 1] === '\n')
                    i++;
                row.push(cell);
                rows.push(row);
                row = [];
                cell = '';
            }
            else
                cell += c;
        }
        if (cell || row.length) {
            row.push(cell);
            rows.push(row);
        }
        return [{ name: f.name, rows }];
    }
    const z = await zipOf(f);
    if (/\.ods$/.test(n)) {
        const d = xml(await z.file('content.xml').async('string')), T = 'urn:oasis:names:tc:opendocument:xmlns:table:1.0';
        return Array.from(d.getElementsByTagNameNS(T, 'table')).map(tb => ({ name: tb.getAttributeNS(T, 'name') ?? '', rows: Array.from(tb.getElementsByTagNameNS(T, 'table-row')).slice(0, 500).map(r => Array.from(r.getElementsByTagNameNS(T, 'table-cell')).flatMap(c => Array(Math.min(20, Number(c.getAttributeNS(T, 'number-columns-repeated') ?? 1))).fill(c.textContent ?? ''))) }));
    }
    const ss = z.file('xl/sharedStrings.xml') ? Array.from(xml(await z.file('xl/sharedStrings.xml').async('string')).getElementsByTagName('si')).map(si => Array.from(si.getElementsByTagName('t')).map(t => t.textContent).join('')) : [];
    const wb = xml(await z.file('xl/workbook.xml').async('string')), names = Array.from(wb.getElementsByTagName('sheet')).map(s => s.getAttribute('name') ?? '');
    const out = [];
    for (let i = 1; z.file(`xl/worksheets/sheet${i}.xml`); i++) {
        const d = xml(await z.file(`xl/worksheets/sheet${i}.xml`).async('string')), rows = [];
        for (const r of Array.from(d.getElementsByTagName('row')).slice(0, 500)) {
            const row = [];
            for (const c of Array.from(r.getElementsByTagName('c'))) {
                const v = c.getElementsByTagName('v')[0]?.textContent ?? c.getElementsByTagName('t')[0]?.textContent ?? '', t = c.getAttribute('t');
                row[colIdx(c.getAttribute('r') ?? 'A1')] = t === 's' ? ss[Number(v)] ?? '' : v;
            }
            rows.push(Array.from(row, x => x ?? ''));
        }
        out.push({ name: names[i - 1] ?? `Hoja ${i}`, rows });
    }
    return out;
}
/** Dibuja tablas en páginas apaisadas. Devuelve imágenes y el texto de cada página (para buscar). */
export async function sheetToPages(f) {
    const sheets = (await readSheets(f)).filter(s => s.rows.some(r => r.some(c => c.trim())));
    const W = 1754, H = 1240, M = 60, out = [];
    for (const sh of sheets) {
        const rows = sh.rows.filter(r => r.some(c => c.trim())), cols = Math.min(14, Math.max(...rows.map(r => r.length)));
        const c0 = document.createElement('canvas').getContext('2d');
        c0.font = '22px Helvetica, Arial';
        const widths = Array.from({ length: cols }, (_, j) => Math.min(380, Math.max(60, ...rows.slice(0, 200).map(r => c0.measureText(String(r[j] ?? '')).width + 20))));
        const k = Math.min(1, (W - 2 * M) / widths.reduce((a, b) => a + b, 0)), fs = Math.max(13, Math.round(22 * k)), rh = Math.round(fs * 1.7);
        const per = Math.floor((H - 2 * M - 50) / rh);
        for (let p = 0; p < rows.length; p += per) {
            const c = document.createElement('canvas');
            c.width = W;
            c.height = H;
            const g = c.getContext('2d');
            g.fillStyle = '#fff';
            g.fillRect(0, 0, W, H);
            g.fillStyle = '#1b1a2a';
            g.font = `700 ${Math.round(fs * 1.2)}px Helvetica, Arial`;
            g.fillText(sh.name, M, M + 10);
            let y = M + 40;
            const slice = rows.slice(p, p + per);
            slice.forEach((r, i) => {
                if ((p + i) % 2 === 0) {
                    g.fillStyle = '#f4f2fb';
                    g.fillRect(M, y, W - 2 * M, rh);
                }
                let x = M;
                g.font = `${p + i === 0 ? 700 : 400} ${fs}px Helvetica, Arial`;
                g.fillStyle = '#1b1a2a';
                for (let j = 0; j < cols; j++) {
                    const w = widths[j] * k;
                    g.save();
                    g.beginPath();
                    g.rect(x, y, w - 4, rh);
                    g.clip();
                    g.fillText(String(r[j] ?? ''), x + 8, y + rh * 0.68);
                    g.restore();
                    g.strokeStyle = '#e2def0';
                    g.strokeRect(x, y, w, rh);
                    x += w;
                }
                y += rh;
            });
            out.push({ img: await new Promise(res => c.toBlob(b => res(b), 'image/jpeg', 0.9)), text: slice.map(r => r.join('\t')).join('\n') });
        }
    }
    if (!out.length)
        throw new Error('La hoja de cálculo está vacía.');
    return out;
}
// ---------- ZIP: se importan los archivos compatibles que tenga dentro ----------
export async function unzipFiles(f) {
    const z = await zipOf(f), out = [];
    for (const name of Object.keys(z.files)) {
        if (name.endsWith('/') || /(^|\/)(__MACOSX|\.)/.test(name))
            continue;
        const b = await z.file(name).async('blob'), base = name.split('/').pop();
        out.push(new File([b], base, { type: /\.pdf$/i.test(base) ? 'application/pdf' : /\.(jpe?g)$/i.test(base) ? 'image/jpeg' : /\.png$/i.test(base) ? 'image/png' : '' }));
        if (out.length >= 200)
            break;
    }
    return out;
}
