// Persistencia local con IndexedDB: documentos, páginas (imágenes como Blob) y carpetas.
import { isPrivate, privateUnlocked } from './meta.js';
export const NO_ADJUST = { brightness: 0, contrast: 0, saturation: 0, sharpness: 0 };
const DB_NAME = 'scanpro';
const DB_VERSION = 1;
let dbp = null;
export class StorageError extends Error {
    quota;
    constructor(message, quota = false) {
        super(message);
        this.quota = quota;
    }
}
function open() {
    if (dbp)
        return dbp;
    dbp = new Promise((resolve, reject) => {
        if (!('indexedDB' in globalThis)) {
            reject(new StorageError('Este navegador no permite guardar datos locales.'));
            return;
        }
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains('docs'))
                db.createObjectStore('docs', { keyPath: 'id' });
            if (!db.objectStoreNames.contains('pages'))
                db.createObjectStore('pages', { keyPath: 'id' }).createIndex('docId', 'docId');
            if (!db.objectStoreNames.contains('folders'))
                db.createObjectStore('folders', { keyPath: 'id' });
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(new StorageError('No se pudo abrir el almacenamiento local. ' + (req.error?.message ?? '')));
        req.onblocked = () => reject(new StorageError('Cierra otras pestañas de ScanPro y vuelve a intentarlo.'));
    });
    return dbp;
}
function wrapErr(e) {
    const err = e;
    if (err && (err.name === 'QuotaExceededError' || /quota/i.test(err.message ?? ''))) {
        return new StorageError('No hay espacio suficiente en el dispositivo. Libera espacio o elimina documentos y vuelve a intentarlo.', true);
    }
    if (e instanceof StorageError)
        return e;
    return new StorageError('Error de almacenamiento: ' + (err?.message ?? String(e)));
}
async function tx(stores, mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
        let result;
        let t;
        try {
            t = db.transaction(stores, mode);
        }
        catch (e) {
            reject(wrapErr(e));
            return;
        }
        t.oncomplete = () => resolve(result);
        t.onerror = () => reject(wrapErr(t.error));
        t.onabort = () => reject(wrapErr(t.error ?? new Error('Operación cancelada')));
        Promise.resolve(fn(t)).then(r => { result = r; }, e => { try {
            t.abort();
        }
        catch { /* ya terminada */ } reject(wrapErr(e)); });
    });
}
function req(r) {
    return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}
// ---------- Documentos ----------
/** Documentos visibles. Los de la carpeta privada solo aparecen si está desbloqueada (o includePrivate). */
export async function listDocs(includePrivate = false) {
    const all = await tx(['docs'], 'readonly', t => req(t.objectStore('docs').getAll()));
    return includePrivate || privateUnlocked() ? all : all.filter(d => !isPrivate(d.id));
}
export async function getDoc(id) {
    return tx(['docs'], 'readonly', t => req(t.objectStore('docs').get(id)));
}
export async function putDoc(doc) {
    await tx(['docs'], 'readwrite', t => { t.objectStore('docs').put(doc); });
}
export async function getPages(doc) {
    const pages = await tx(['pages'], 'readonly', t => Promise.all(doc.pageIds.map(id => req(t.objectStore('pages').get(id)))));
    return pages.filter((p) => !!p);
}
export async function getPage(id) {
    return tx(['pages'], 'readonly', t => req(t.objectStore('pages').get(id)));
}
function sumSize(pages) {
    return pages.reduce((a, p) => a + p.image.size + p.original.size + p.thumb.size, 0);
}
function joinOcr(pages) {
    return pages.map(p => p.ocrText ?? '').filter(Boolean).join('\n\n');
}
/** Crea un documento con sus páginas en una única transacción. */
export async function createDoc(name, pages, folderId = null) {
    const now = Date.now();
    const id = pages.length ? 'd' + pages[0].id : 'd' + now.toString(36);
    const full = pages.map(p => ({ ...p, docId: id }));
    const doc = { id, name, createdAt: now, updatedAt: now, folderId, favorite: false, pageIds: full.map(p => p.id), ocrText: joinOcr(full), size: sumSize(full) };
    await tx(['docs', 'pages'], 'readwrite', t => {
        const ps = t.objectStore('pages');
        for (const p of full)
            ps.put(p);
        t.objectStore('docs').put(doc);
    });
    return doc;
}
/** Añade páginas al final de un documento existente. */
export async function addPages(docId, pages) {
    return tx(['docs', 'pages'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const ps = t.objectStore('pages');
        const doc = await req(ds.get(docId));
        if (!doc)
            throw new StorageError('El documento ya no existe.');
        for (const p of pages)
            ps.put({ ...p, docId });
        doc.pageIds = [...doc.pageIds, ...pages.map(p => p.id)];
        const all = await Promise.all(doc.pageIds.map(id => req(ps.get(id))));
        doc.size = sumSize(all.filter(Boolean));
        doc.ocrText = joinOcr(all.filter(Boolean));
        doc.updatedAt = Date.now();
        ds.put(doc);
        return doc;
    });
}
export async function updatePage(page) {
    await tx(['docs', 'pages'], 'readwrite', async (t) => {
        const ps = t.objectStore('pages');
        ps.put(page);
        const ds = t.objectStore('docs');
        const doc = await req(ds.get(page.docId));
        if (doc) {
            const all = await Promise.all(doc.pageIds.map(id => id === page.id ? page : req(ps.get(id))));
            doc.size = sumSize(all.filter(Boolean));
            doc.ocrText = joinOcr(all.filter(Boolean));
            doc.updatedAt = Date.now();
            ds.put(doc);
        }
    });
}
export async function setPageOrder(docId, pageIds) {
    await tx(['docs'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const doc = await req(ds.get(docId));
        if (!doc)
            throw new StorageError('El documento ya no existe.');
        if (pageIds.length !== doc.pageIds.length || !pageIds.every(id => doc.pageIds.includes(id)))
            throw new StorageError('El orden de páginas no es válido.');
        doc.pageIds = pageIds;
        doc.updatedAt = Date.now();
        ds.put(doc);
    });
}
export async function deletePage(docId, pageId) {
    return tx(['docs', 'pages'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const ps = t.objectStore('pages');
        const doc = await req(ds.get(docId));
        if (!doc)
            throw new StorageError('El documento ya no existe.');
        if (doc.pageIds.length <= 1)
            throw new StorageError('Un documento debe tener al menos una página. Elimina el documento completo si ya no lo necesitas.');
        ps.delete(pageId);
        doc.pageIds = doc.pageIds.filter(id => id !== pageId);
        const all = await Promise.all(doc.pageIds.map(id => req(ps.get(id))));
        doc.size = sumSize(all.filter(Boolean));
        doc.ocrText = joinOcr(all.filter(Boolean));
        doc.updatedAt = Date.now();
        ds.put(doc);
        return doc;
    });
}
/** Elimina el documento y todas sus páginas (y solo las suyas). */
export async function deleteDoc(id) {
    await tx(['docs', 'pages'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const ps = t.objectStore('pages');
        const doc = await req(ds.get(id));
        if (!doc)
            return;
        const keys = await req(ps.index('docId').getAllKeys(IDBKeyRange.only(id)));
        for (const k of new Set([...keys, ...doc.pageIds])) {
            const p = await req(ps.get(k));
            if (p && p.docId === id)
                ps.delete(k);
        }
        ds.delete(id);
    });
}
export async function patchDoc(id, patch) {
    return tx(['docs'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const doc = await req(ds.get(id));
        if (!doc)
            throw new StorageError('El documento ya no existe.');
        Object.assign(doc, patch);
        if ('name' in patch)
            doc.updatedAt = Date.now();
        ds.put(doc);
        return doc;
    });
}
/**
 * Une documentos en uno nuevo copiando sus páginas (los originales no se modifican).
 * Devuelve el documento nuevo. Falla si alguna página falta o está dañada.
 */
export async function mergeDocs(docIds, name, newId) {
    return tx(['docs', 'pages'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const ps = t.objectStore('pages');
        const copies = [];
        const docId = 'd' + newId();
        for (const id of docIds) {
            const d = await req(ds.get(id));
            if (!d)
                throw new StorageError('Uno de los documentos seleccionados ya no existe.');
            for (const pid of d.pageIds) {
                const p = await req(ps.get(pid));
                if (!p || !(p.image instanceof Blob) || p.image.size === 0)
                    throw new StorageError(`«${d.name}» tiene una página dañada o ilegible. No se ha combinado nada.`);
                copies.push({ ...p, id: newId(), docId });
            }
        }
        const now = Date.now();
        const doc = { id: docId, name, createdAt: now, updatedAt: now, folderId: null, favorite: false, pageIds: copies.map(p => p.id), ocrText: joinOcr(copies), size: sumSize(copies) };
        for (const p of copies)
            ps.put(p);
        ds.put(doc);
        return doc;
    });
}
// ---------- Carpetas ----------
export async function listFolders() {
    return tx(['folders'], 'readonly', t => req(t.objectStore('folders').getAll()));
}
export async function putFolder(f) {
    await tx(['folders'], 'readwrite', t => { t.objectStore('folders').put(f); });
}
/** Borra la carpeta; sus documentos se conservan y pasan a "sin carpeta". */
export async function deleteFolder(id) {
    await tx(['folders', 'docs'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        const docs = await req(ds.getAll());
        for (const d of docs)
            if (d.folderId === id) {
                d.folderId = null;
                ds.put(d);
            }
        t.objectStore('folders').delete(id);
    });
}
// ---------- Mantenimiento ----------
export async function clearAll() {
    await tx(['docs', 'pages', 'folders'], 'readwrite', t => {
        t.objectStore('docs').clear();
        t.objectStore('pages').clear();
        t.objectStore('folders').clear();
    });
}
export async function allPages() {
    return tx(['pages'], 'readonly', t => req(t.objectStore('pages').getAll()));
}
export async function importRecords(docs, pages, folders) {
    return tx(['docs', 'pages', 'folders'], 'readwrite', async (t) => {
        const ds = t.objectStore('docs');
        let added = 0;
        for (const f of folders)
            t.objectStore('folders').put(f);
        for (const p of pages)
            t.objectStore('pages').put(p);
        for (const d of docs) {
            const exists = await req(ds.getKey(d.id));
            if (!exists)
                added++;
            ds.put(d);
        }
        return added;
    });
}
