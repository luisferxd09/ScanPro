// Elección de la mejor cámara trasera para documentos y su configuración.
// Chrome en Android no dice qué lente es cada cámara: se abre cada una un instante,
// se leen sus capacidades (enfoque automático, resolución, distancia mínima de enfoque)
// y se puntúan. El resultado se guarda para no repetir la prueba.
/** Puntuación de una cámara para escanear documentos de cerca (función pura, probada aparte). */
export function scoreCamera(label, caps, index) {
    const reasons = [];
    let score = 0;
    const l = label.toLowerCase();
    const facing = caps.facingMode ?? [];
    if (facing.includes('user') || /front|frontal|delantera|user/.test(l))
        return { score: -1000, reasons: ['cámara frontal'] };
    if (facing.includes('environment') || /back|rear|trasera|environment/.test(l)) {
        score += 100;
        reasons.push('trasera');
    }
    if (/ultra|0[.,]5|gran ?angular/.test(l)) {
        score -= 70;
        reasons.push('gran angular (enfoque fijo, se ve lejos)');
    }
    if (/tele|zoom|periscop/.test(l)) {
        score -= 45;
        reasons.push('teleobjetivo (no enfoca de cerca)');
    }
    if (/depth|macro|mono|ir\b|infrared|profundidad/.test(l)) {
        score -= 90;
        reasons.push('sensor auxiliar');
    }
    const fm = caps.focusMode ?? [];
    if (fm.includes('continuous') || fm.includes('single-shot')) {
        score += 50;
        reasons.push('enfoque automático');
    }
    else if (fm.length) {
        score -= 35;
        reasons.push('enfoque fijo');
    }
    const near = caps.focusDistance?.min;
    if (typeof near === 'number' && near > 0.25) {
        score -= 30;
        reasons.push(`no enfoca a menos de ${Math.round(near * 100)} cm`);
    }
    const mp = ((caps.width?.max ?? 0) * (caps.height?.max ?? 0)) / 1e6;
    if (mp) {
        score += Math.min(40, mp * 3);
        reasons.push(`${mp.toFixed(1)} MP`);
    }
    if (caps.zoom && (caps.zoom.max ?? 1) > 1)
        score += 4;
    // en Android la cámara principal suele ser la de menor número («camera2 0»)
    const n = l.match(/camera2? ?(\d+)/);
    score -= (n ? Number(n[1]) : index) * 2;
    return { score, reasons };
}
const KEY = 'scanpro.camera.v1';
const read = () => { try {
    return JSON.parse(localStorage.getItem(KEY) ?? 'null');
}
catch {
    return null;
} };
const write = (s) => { try {
    localStorage.setItem(KEY, JSON.stringify(s));
}
catch { /* sin almacenamiento */ } };
export async function backCameras() {
    const all = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput');
    const back = all.filter(d => !/front|frontal|user|delantera/i.test(d.label));
    return back.length ? back : all;
}
function poolKey(devs) { return devs.map(d => d.deviceId).sort().join('|'); }
/** Cámara guardada si sigue existiendo el mismo conjunto de cámaras. */
export async function savedChoice() {
    const s = read();
    if (!s)
        return null;
    try {
        const devs = await backCameras();
        if (poolKey(devs) !== s.pool || !devs.some(d => d.deviceId === s.deviceId))
            return null;
    }
    catch {
        return null;
    }
    return s;
}
export function rememberChoice(deviceId, list, userPicked, pool) {
    write({ deviceId, pool, userPicked, list });
}
/** Abre brevemente cada cámara trasera, lee sus capacidades y las ordena (mejor primero). */
export async function probeCameras(onStep) {
    const devs = await backCameras();
    const list = [];
    for (let i = 0; i < devs.length; i++) {
        onStep?.(i, devs.length);
        const d = devs[i];
        let caps = {};
        try {
            const s = await Promise.race([
                navigator.mediaDevices.getUserMedia({ audio: false, video: { deviceId: { exact: d.deviceId }, width: { ideal: 640 } } }),
                new Promise((_, rej) => setTimeout(() => rej(new Error('tiempo')), 3000)),
            ]);
            const t = s.getVideoTracks()[0];
            caps = (t?.getCapabilities?.() ?? {});
            s.getTracks().forEach(x => x.stop());
        }
        catch {
            continue;
        } // cámara ocupada o no disponible
        const { score, reasons } = scoreCamera(d.label, caps, i);
        const fm = caps.focusMode ?? [];
        list.push({ deviceId: d.deviceId, label: d.label || `Cámara ${i + 1}`, score, megapixels: ((caps.width?.max ?? 0) * (caps.height?.max ?? 0)) / 1e6, autofocus: fm.includes('continuous') || fm.includes('single-shot'), reasons });
    }
    list.sort((a, b) => b.score - a.score);
    return { list, pool: poolKey(devs) };
}
/** Nombre corto y comprensible para el selector de lente. */
export function lensName(c, i, best) {
    const tag = /ultra|0[.,]5/i.test(c.label) ? 'Gran angular' : /tele|zoom/i.test(c.label) ? 'Teleobjetivo' : best ? 'Principal' : `Cámara ${i + 1}`;
    return tag;
}
/** Resolución de vídeo a pedir: la máxima que admite el lente, limitada para no ahogar móviles lentos. */
export function videoTarget(caps, lowEnd) {
    const limitLong = lowEnd ? 1920 : 2560, limitShort = lowEnd ? 1440 : 1920;
    const mw = caps.width?.max ?? 1920, mh = caps.height?.max ?? 1080;
    return { width: Math.min(mw, limitLong), height: Math.min(mh, limitShort) };
}
