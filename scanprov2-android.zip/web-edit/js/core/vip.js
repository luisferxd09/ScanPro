// Sistema centralizado de permisos ScanPro VIP.
// Combina el estado nativo (compras verificadas, Pro legado) con recompensas locales.
import { nativeTier, nativeVipUntil, nativeVipFeature, nativeBuyVip, onVip as onNativeVip, isNative, nativeAd } from './native.js';
import { getActiveReward, setFullTempReward, setFeatureReward, getAdProgress, incrementAdProgress, resetAdProgress } from './vip-state.js';

let nativeTierCache = nativeTier();
let nativeUntilCache = nativeVipUntil();
let nativeFeatureCache = nativeVipFeature();

const subs = new Set();

function notify() {
    const t = tier();
    const u = featureExpiry();
    const f = featureName();
    subs.forEach(cb => cb(t, u, f));
}

onNativeVip((tier, until, feature) => {
    nativeTierCache = tier || 'free';
    nativeUntilCache = until || 0;
    nativeFeatureCache = feature || '';
    notify();
});

function computeTier() {
    const now = Date.now();

    // El tier nativo tiene caducidad propia.
    if (nativeUntilCache && now >= nativeUntilCache) {
        return 'free';
    }

    // Compras verificadas o Pro legado otorgan acceso VIP completo.
    if (['legacy_pro_verified', 'legacy_pro_local', 'subscribed'].includes(nativeTierCache)) {
        return nativeTierCache;
    }

    // Recompensas locales (ruleta / 5 anuncios).
    const reward = getActiveReward();
    if (reward) {
        if (reward.type === 'full')
            return 'full_temp';
        if (reward.type === 'feature')
            return 'feature_temp';
    }

    return nativeTierCache || 'free';
}

export function tier() {
    const t = computeTier();
    return t === 'expired' ? 'free' : t;
}

export function isVip() {
    const t = tier();
    return t !== 'free' && t !== 'expired';
}

export function canUse(feature) {
    const t = tier();
    if (['legacy_pro_verified', 'legacy_pro_local', 'subscribed', 'full_temp'].includes(t))
        return true;
    if (t === 'feature_temp') {
        const reward = getActiveReward();
        return reward && (reward.feature === feature || reward.feature === 'all');
    }
    return false;
}

export function featureExpiry() {
    if (nativeUntilCache)
        return nativeUntilCache;
    const reward = getActiveReward();
    return reward ? reward.until : 0;
}

export function featureName() {
    if (nativeFeatureCache)
        return nativeFeatureCache;
    const reward = getActiveReward();
    return reward ? reward.feature : '';
}

export function onVip(f) {
    subs.add(f);
    return () => subs.delete(f);
}

export function vipAvailable() {
    // El sistema VIP está disponible solo en la app nativa (no en navegador/PWA).
    return isNative;
}

/** Botón/compra VIP: hoy es informativo; no realiza cobros. */
export function buyVip() {
    const r = nativeBuyVip();
    return r.startsWith('error:') ? r.slice(6) : null;
}

export function vipStatusText() {
    const t = tier();
    if (t === 'legacy_pro_verified') return 'Pro verificado (sin anuncios)';
    if (t === 'legacy_pro_local') return 'Pro legado (sin anuncios)';
    if (t === 'subscribed') return 'Suscripción VIP activa';
    if (t === 'full_temp') {
        const r = getActiveReward();
        const mins = r ? Math.max(0, Math.ceil((r.until - Date.now()) / 60000)) : 0;
        return `VIP temporal · ${mins} min`;
    }
    if (t === 'feature_temp') {
        const r = getActiveReward();
        const mins = r ? Math.max(0, Math.ceil((r.until - Date.now()) / 60000)) : 0;
        return `Función desbloqueada · ${mins} min`;
    }
    return 'Gratuito';
}

export function formatVipExpiry() {
    const until = featureExpiry();
    if (!until) return '';
    const d = new Date(until);
    return d.toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

const FEATURES = ['ocr', 'password', 'export', 'qr', 'sign', 'translate', 'removebg', 'dictate'];
const REWARDS = [
    { type: 'none', weight: 40 },
    { type: 'full', duration: 15 * 60 * 1000, weight: 25 },
    { type: 'full', duration: 60 * 60 * 1000, weight: 15 },
    { type: 'feature', duration: 30 * 60 * 1000, weight: 20 }
];

function pickReward() {
    const total = REWARDS.reduce((a, r) => a + r.weight, 0);
    let n = Math.random() * total;
    for (const r of REWARDS) {
        n -= r.weight;
        if (n <= 0) return r;
    }
    return REWARDS[0];
}

export async function spinRoulette() {
    const raw = pickReward();
    if (raw.type === 'none') return { type: 'none', message: 'No premiado. ¡Inténtalo de nuevo!' };
    const until = Date.now() + raw.duration;
    if (raw.type === 'full') {
        setFullTempReward(until);
        return { type: 'full', until, duration: raw.duration };
    }
    const feature = FEATURES[Math.floor(Math.random() * FEATURES.length)];
    setFeatureReward(feature, until);
    return { type: 'feature', feature, until, duration: raw.duration };
}

export async function watchAdForRoulette() {
    return nativeAd('rewarded', 60000);
}

export async function watchAdToSupport() {
    const r = await nativeAd('rewarded', 60000);
    return r;
}

export async function watchAdForTempFeature(feature) {
    const r = await nativeAd('rewarded', 60000);
    if (r === 'rewarded') {
        const until = Date.now() + 30 * 60 * 1000;
        setFeatureReward(feature, until);
        return { ok: true, until };
    }
    return { ok: false };
}

const ADS_FOR_FULL = 5;

export function adsForFullProgress() {
    return { current: getAdProgress().count, total: ADS_FOR_FULL };
}

export async function watchAdForFullProgress() {
    const r = await nativeAd('rewarded', 60000);
    if (r === 'rewarded') {
        const count = incrementAdProgress();
        if (count >= ADS_FOR_FULL) {
            resetAdProgress();
            const until = Date.now() + 60 * 60 * 1000;
            setFullTempReward(until);
            return { ok: true, reward: true, count, until };
        }
        return { ok: true, reward: false, count };
    }
    return { ok: false };
}

// Re-exportaciones con nomenclatura Pro para compatibilidad con módulos antiguos.
export const isPro = isVip;
export const proAvailable = vipAvailable;
export const onPro = onVip;
export const buyPro = buyVip;
