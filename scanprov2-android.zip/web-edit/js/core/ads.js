// Anuncio en CADA exportación o compartido (APK, sin Pro). Si Google no entrega anuncio
// (sin internet, app aún en revisión en AdMob…), se muestra un anuncio propio de ScanPro.
import { isNative, nativeAd } from './native.js';
import { isPro, buyPro, proAvailable } from './pro.js';
import { h, ic } from '../ui/dom.js';
/** Anuncio propio a pantalla completa: se puede cerrar a los 5 segundos. */
export function houseAd() {
    return new Promise(resolve => {
        let left = 5;
        const closeBtn = h('button', { class: 'house-ad-close', disabled: true, 'aria-label': 'Cerrar anuncio' }, String(left));
        const el = h('div', { class: 'house-ad', role: 'dialog', 'aria-label': 'Anuncio' }, closeBtn, h('div', { class: 'house-ad-tag' }, 'Anuncio'), h('img', { src: 'icons/icon-192.png', alt: '', class: 'house-ad-logo' }), h('h2', null, 'ScanPro VIP'), h('p', null, 'Exporta sin anuncios y desbloquea funciones premium.'), h('ul', null, ...['Sin anuncios al exportar', 'PDF con contraseña sin esperas', 'Apoyas a un desarrollador independiente'].map(t => h('li', null, ic('check'), t))), proAvailable() ? h('button', { class: 'btn primary block', onclick: () => { const e = buyPro(); if (e) {
                el.querySelector('.house-ad-note').textContent = e;
            } } }, 'Quitar anuncios') : null, h('p', { class: 'house-ad-note xs' }, 'Gracias por usar ScanPro gratis 💜'));
        const done = () => { clearInterval(iv); el.classList.add('out'); setTimeout(() => { el.remove(); resolve(); }, 220); };
        const iv = setInterval(() => { left--; if (left > 0)
            closeBtn.textContent = String(left);
        else {
            clearInterval(iv);
            closeBtn.disabled = false;
            closeBtn.replaceChildren(ic('x'));
        } }, 1000);
        closeBtn.addEventListener('click', () => { if (!closeBtn.disabled)
            done(); });
        document.body.append(el);
    });
}
export async function maybeInterstitial() {
    if (!isNative || isPro())
        return;
    const r = navigator.onLine ? await nativeAd('interstitial', 15000) : 'none';
    if (r === 'none' && !isPro())
        await houseAd();
}
