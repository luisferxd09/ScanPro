// Capa de compatibilidad con el sistema Pro anterior.
// El sistema real de permisos vive ahora en vip.js. Este archivo conserva la API
// isPro / buyPro / proAvailable / onPro para no romper módulos existentes.
import { isVip, onVip, vipAvailable } from './vip.js';

const bridge = globalThis.ScanProAndroid;

// Callback legacy para quienes escuchen __scanproPro directamente.
const subs = new Set();
globalThis.__scanproPro = (v, msg) => { subs.forEach(f => f(v, msg)); };

export const isPro = () => isVip();
export const proAvailable = () => vipAvailable();
export function onPro(f) {
    // Se suscribe también a cambios de tier del nuevo sistema VIP.
    const unsubscribe = onVip(() => f(isVip(), null));
    subs.add(f);
    return () => { unsubscribe(); subs.delete(f); };
}

/** Abre la compra del producto legado scanpro_pro.
 *  Conserva compatibilidad con compradores anteriores. */
export function buyPro() {
    const r = bridge?.buyPro?.() ?? 'error:Disponible en la app instalada desde Google Play.';
    return r.startsWith('error:') ? r.slice(6) : null;
}
