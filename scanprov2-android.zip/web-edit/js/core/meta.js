import { loc } from './locale.js';
// Datos extra de ScanPro guardados en el teléfono: etiquetas, privados, vencimientos, gastos, inventario y avisos.
import { nativeSchedule, nativeUnschedule } from './native.js';
export const TAGS = [
    { id: 'urgente', label: 'Urgente', color: '#e5484d' }, { id: 'pendiente', label: 'Pendiente', color: '#f5a524' },
    { id: 'pagado', label: 'Pagado', color: '#30a46c' }, { id: 'personal', label: 'Personal', color: '#8c7cf7' }, { id: 'trabajo', label: 'Trabajo', color: '#3e8ef7' },
];
function load(k, d) { try {
    const v = localStorage.getItem('scanpro.' + k);
    return v ? JSON.parse(v) : d;
}
catch {
    return d;
} }
function save(k, v) { try {
    localStorage.setItem('scanpro.' + k, JSON.stringify(v));
}
catch { /* sin espacio */ } }
export const allMeta = () => load('meta.v1', {});
export const metaOf = (docId) => allMeta()[docId] ?? {};
export function setMeta(docId, patch) { const m = allMeta(); m[docId] = { ...m[docId], ...patch }; save('meta.v1', m); }
export const isPrivate = (docId) => !!metaOf(docId).priv;
let unlocked = false;
export const privateUnlocked = () => unlocked;
export const setPrivateUnlocked = (v) => { unlocked = v; };
export const expenses = () => load('expenses.v1', []);
export const saveExpenses = (e) => save('expenses.v1', e);
export const items = () => load('inventory.v1', []);
export const saveItems = (i) => save('inventory.v1', i);
export const settingsX = () => load('extra.v1', {});
export const setSettingsX = (p) => save('extra.v1', { ...settingsX(), ...p });
export const exportHashes = () => load('hashes.v1', []);
export function rememberHash(h, name) { const l = exportHashes(); if (!l.some(x => x.h === h)) {
    l.push({ h, name, at: Date.now() });
    save('hashes.v1', l.slice(-500));
} }
export const reminders = () => load('reminders.v1', []);
export function saveReminder(r) {
    const l = reminders().filter(x => x.id !== r.id);
    l.push(r);
    save('reminders.v1', l);
    nativeSchedule(r.id, r.at, r.repeatH * 3600000, r.title, r.text);
}
export function deleteReminder(id) { save('reminders.v1', reminders().filter(x => x.id !== id)); nativeUnschedule(id); }
/** Al abrir la app se vuelven a programar los avisos (Android los borra al reiniciar el teléfono). */
export function rescheduleAll() {
    const now = Date.now();
    for (const r of reminders()) {
        if (r.repeatH > 0) {
            let at = r.at;
            while (at < now)
                at += r.repeatH * 3600000;
            nativeSchedule(r.id, at, r.repeatH * 3600000, r.title, r.text);
        }
        else if (r.at > now)
            nativeSchedule(r.id, r.at, 0, r.title, r.text);
    }
}
/** Aviso de vencimiento: 7 días antes (o el mismo día si falta menos). */
export function scheduleExpiry(docId, name, expires) {
    const id = Math.abs([...docId].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7)) % 2000000000;
    if (!expires) {
        deleteReminder(id);
        return;
    }
    const at = Math.max(Date.now() + 60000, expires - 7 * 86400000);
    saveReminder({ id, title: `«${name}» vence pronto`, text: `Vence el ${new Date(expires).toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' })}. Ábrelo en ScanPro para renovarlo a tiempo.`, at, repeatH: 0, docId });
}
