import { nativeBars } from './native.js';
const KEY = 'scanpro.settings.v1';
const DEFAULTS = {
    onboardingDone: false,
    theme: 'system',
    quality: 'alta',
    defaultFilter: 'magic',
    ocrLang: 'spa',
    autoDetect: true,
    sort: 'updated',
    view: 'list',
    motion: 'auto',
    autoCapture: true,
    captureQuality: 'auto',
    autoRotate: true,
    sounds: true,
    lang: 'auto',
    country: '',
    haptics: true,
    helloDone: false,
    scanner: 'google',
    lastBackup: 0,
};
/** Teléfono de gama baja: poca memoria o pocos núcleos. */
export function isLowEnd() {
    const n = navigator;
    return (n.deviceMemory ?? 4) <= 2 || (navigator.hardwareConcurrency ?? 4) <= 4;
}
/** «nítida»: foto del sensor (enfoque y procesado de la cámara de fotos); «rápida»: mejor fotograma del vídeo. */
export function captureQuality() {
    const q = getSettings().captureQuality;
    if (q === 'rapida')
        return 'rapida';
    return 'nitida'; // «auto» y los valores antiguos («alta», «maxima»)
}
let cache = null;
export function getSettings() {
    if (cache)
        return cache;
    try {
        const raw = localStorage.getItem(KEY);
        cache = { ...DEFAULTS, ...(raw ? JSON.parse(raw) : {}) };
    }
    catch {
        cache = { ...DEFAULTS };
    }
    return cache;
}
export function setSettings(patch) {
    cache = { ...getSettings(), ...patch };
    try {
        localStorage.setItem(KEY, JSON.stringify(cache));
    }
    catch { /* modo privado */ }
    if ('theme' in patch || 'motion' in patch)
        applyTheme();
    return cache;
}
export function applyTheme() {
    const t = getSettings().theme;
    const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    const html = document.documentElement;
    html.dataset.theme = dark ? 'dark' : 'light';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0f0e17' : '#f3f1f8');
    nativeBars(dark ? '#0f0e17' : '#f3f1f8', dark);
    const m = getSettings().motion;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    html.classList.toggle('lite', m === 'lite' || m === 'off' || (m === 'auto' && (isLowEnd() || reduce)));
    html.classList.toggle('no-motion', m === 'off');
}
export const QUALITY = {
    alta: { label: 'Alta', desc: 'Máxima nitidez, sin recomprimir', maxSide: 4000, jpeg: 0.92 },
    equilibrada: { label: 'Equilibrada', desc: 'Casi idéntica, ~50 % más ligera', maxSide: 2480, jpeg: 0.84 },
    compacta: { label: 'Compacta', desc: 'Ideal para enviar por chat', maxSide: 1754, jpeg: 0.74 },
};
export const APP_VERSION = '1.4.0';
/** correo para «Enviar comentarios» y la política de privacidad */
export const CONTACT_EMAIL = '__CONTACT_EMAIL__';
