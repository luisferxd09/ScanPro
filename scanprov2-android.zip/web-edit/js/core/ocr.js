// OCR real con Tesseract.js (se ejecuta en el dispositivo, en un Web Worker).
// La primera vez descarga el motor (~2 MB) y el idioma (~1–3 MB) desde jsDelivr; después quedan en caché.
// En el APK el motor y los idiomas van incluidos (vendor/tesseract) y funciona sin Internet.
import { isNative } from './native.js';
const TESS_URL = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
const LOCAL_DIR = 'vendor/tesseract/';
let local = false;
let loading = null;
export class OcrError extends Error {
}
function loadScript(src) {
    return new Promise((res, rej) => {
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.crossOrigin = 'anonymous';
        s.onload = () => res();
        s.onerror = () => { s.remove(); rej(new OcrError('No se pudo descargar el motor de OCR. La primera vez se necesita conexión a Internet; después funciona sin conexión.')); };
        document.head.appendChild(s);
    });
}
async function tess() {
    const g = window.Tesseract;
    if (g)
        return g;
    if (!loading)
        loading = (isNative ? loadScript(LOCAL_DIR + 'tesseract.min.js').then(() => { local = true; }).catch(() => loadScript(TESS_URL)) : loadScript(TESS_URL)).then(() => window.Tesseract).catch(e => { loading = null; throw e; });
    return loading;
}
const STATUS = {
    'loading tesseract core': 'Cargando motor de OCR…',
    'initializing tesseract': 'Iniciando OCR…',
    'loading language traineddata': 'Descargando idioma (solo la primera vez)…',
    'loading language traineddata (from cache)': 'Cargando idioma…',
    'initializing api': 'Preparando…',
    'recognizing text': 'Reconociendo texto…',
};
/** Reconoce el texto de varias imágenes en orden. Se puede cancelar con signal. */
export async function recognize(images, lang, onProgress, signal) {
    const T = await tess();
    let page = 0;
    const base = new URL(LOCAL_DIR, location.href).href;
    const dir = base.replace(/\/$/, ''); // Tesseract añade «/archivo» por su cuenta
    const allLocal = lang.split('+').every(l => OCR_BUNDLED.includes(l));
    // los idiomas incluidos se leen del APK; los demás se descargan una vez (jsDelivr) y quedan en caché
    const paths = local ? (allLocal ? { workerPath: base + 'worker.min.js', corePath: dir, langPath: dir, gzip: false, workerBlobURL: false, cacheMethod: 'none' } : { workerPath: base + 'worker.min.js', corePath: dir, workerBlobURL: false }) : {};
    const worker = await T.createWorker(lang, 1, {
        ...paths,
        logger: (m) => onProgress({ page, total: images.length, status: STATUS[m.status] ?? 'Procesando…', progress: m.progress ?? 0 }),
        errorHandler: () => { },
    }).catch(() => { throw new OcrError('No se pudo iniciar el OCR. ' + (local ? 'Reinicia la app e inténtalo de nuevo.' : 'Comprueba tu conexión la primera vez que lo uses.')); });
    const abort = () => { void worker.terminate(); };
    signal?.addEventListener('abort', abort);
    const texts = [], confidence = [], lines = [];
    try {
        for (page = 0; page < images.length; page++) {
            if (signal?.aborted)
                throw new OcrError('OCR cancelado.');
            onProgress({ page, total: images.length, status: 'Reconociendo texto…', progress: 0 });
            const r = await worker.recognize(images[page], {}, { text: true, blocks: true });
            texts.push(cleanText(r.data.text));
            const raw = r.data.lines ?? (r.data.blocks ?? []).flatMap(b => (b.paragraphs ?? []).flatMap(pp => pp.lines ?? []));
            lines.push(raw.filter(l => l.text?.trim()).map(l => ({ t: l.text.trim(), x0: l.bbox.x0, y0: l.bbox.y0, x1: l.bbox.x1, y1: l.bbox.y1 })));
            confidence.push(r.data.confidence);
        }
    }
    catch (e) {
        if (signal?.aborted)
            throw new OcrError('OCR cancelado.');
        throw e instanceof OcrError ? e : new OcrError('El reconocimiento falló: ' + (e.message ?? e));
    }
    finally {
        signal?.removeEventListener('abort', abort);
        if (!signal?.aborted)
            await worker.terminate().catch(() => { });
    }
    return { texts, confidence, lines };
}
export function cleanText(t) {
    return t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
const OCR_NAMES = { spa: 'Español', eng: 'English', por: 'Português', fra: 'Français', deu: 'Deutsch', ita: 'Italiano', chi_sim: '中文', chi_tra: '中文 (繁體)', hin: 'हिन्दी', ind: 'Indonesia', rus: 'Русский', tur: 'Türkçe', vie: 'Tiếng Việt', jpn: '日本語', kor: '한국어', ara: 'العربية' };
/** Idiomas de OCR que vienen dentro de la app (los demás se descargan una vez y quedan guardados). */
export const OCR_BUNDLED = ['spa', 'eng', 'por', 'fra', 'deu', 'ita'];
/** Opciones de idioma del documento según el idioma de la app. */
export function ocrOptions(base) {
    const other = base === 'eng' ? 'spa' : 'eng';
    return [[base, OCR_NAMES[base] ?? base], [`${base}+${other}`, `${OCR_NAMES[base] ?? base} + ${OCR_NAMES[other]}`]];
}
export const OCR_LANGS = ocrOptions('spa');
