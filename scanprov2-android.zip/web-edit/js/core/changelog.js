// Novedades por versión: se muestran en el cuadro que aparece al iniciar
// después de que la app se actualizó. Usa números de versión sin la «v».
export const CHANGELOG = {
    '1.4.0': [
        'Panel VIP con ruleta de premios, anuncios de apoyo y desbloqueo temporal',
        'Botones de VIP y de anuncios en la pantalla de inicio',
        'Actualizaciones automáticas: la app te avisa cuando hay una versión nueva',
        'Este cuadro de novedades al abrir la app después de actualizar',
        'Corrección del nombre y el paquete: ScanPro 1.4.0 oficial, sin «test»'
    ]
};
