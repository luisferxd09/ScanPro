const norm = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
/** Tarjeta de presentación → contacto. */
export function parseContact(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean), c = {};
    const email = text.match(/[\w.+-]+@[\w-]+\.[\w.-]+/);
    if (email)
        c.email = email[0];
    const phone = text.replace(/[ ().-]/g, '').match(/(\+?57)?3\d{9}|\+?\d{10,13}|\d{7}/);
    if (phone)
        c.phone = phone[0];
    const web = text.match(/(https?:\/\/)?(www\.)[\w.-]+\.\w+/i);
    const jobRx = /gerente|director|ingenier|abogad|doctor|dr\.|asesor|coordinador|ejecutiv|jefe|analista|contador|arquitect|ceo|manager|vendedor|consultor/i;
    const title = lines.find(l => jobRx.test(l));
    if (title)
        c.title = title;
    const company = lines.find(l => /s\.?a\.?s|ltda|s\.a\.|inc|corp|grupo|empresa|compañ/i.test(l));
    if (company)
        c.company = company;
    const name = lines.find(l => /^[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ.]+){1,3}$/.test(l) && l !== title && l !== company)
        ?? lines.find(l => /^[A-ZÁÉÍÓÚÑ ]{5,40}$/.test(l) && l.split(' ').length >= 2 && l !== company);
    if (name)
        c.name = name.replace(/\b([A-ZÁÉÍÓÚÑ])([A-ZÁÉÍÓÚÑ]+)\b/g, (_, a, b) => a + b.toLowerCase());
    if (web)
        c.notes = web[0];
    return c;
}
const money = (s) => {
    const t = s.replace(/[^\d.,]/g, '');
    if (/,\d{2}$/.test(t))
        return Number(t.replace(/\./g, '').replace(',', '.'));
    if (/\.\d{2}$/.test(t) && (t.match(/\./g) ?? []).length === 1 && t.length > 6 === false)
        return Number(t.replace(/,/g, ''));
    return Number(t.replace(/[.,]/g, ''));
};
/** Recibo o factura → comercio, fecha, total y fecha límite. */
export function parseReceipt(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const merchant = lines.find(l => /[a-záéíóúñ]{3}/i.test(l) && !/factura|recibo|nit|fecha|tel|dir/i.test(l))?.slice(0, 60) ?? 'Compra';
    const dates = [...text.matchAll(/(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/g)].map(m => { const y = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]); return new Date(y, Number(m[2]) - 1, Number(m[1])).getTime(); }).filter(t => !isNaN(t));
    let total = 0;
    for (const l of lines)
        if (/total|valor a pagar|neto|pagar/i.test(norm(l))) {
            const v = l.match(/\$?\s?[\d.,]{3,}/g);
            if (v)
                total = Math.max(total, ...v.map(money));
        }
    if (!total) {
        const all = [...text.matchAll(/\$\s?[\d.,]{3,}/g)].map(m => money(m[0]));
        if (all.length)
            total = Math.max(...all);
    }
    const dueLine = lines.find(l => /limite|vence|pago oportuno|pagar antes/i.test(norm(l)));
    const dueM = dueLine?.match(/(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/);
    const due = dueM ? new Date(Number(dueM[3]) < 100 ? 2000 + Number(dueM[3]) : Number(dueM[3]), Number(dueM[2]) - 1, Number(dueM[1])).getTime() : null;
    return { merchant, date: dates[0] ?? null, total: isFinite(total) ? total : 0, due };
}
const STOP = new Set('de la que el en y a los del se las por un para con no una su al lo como más pero sus le ya o este sí porque esta entre cuando muy sin sobre también me hasta hay donde quien desde todo nos durante todos uno les ni contra otros ese eso ante ellos e esto mí antes algunos qué unos yo otro otras otra él tanto esa estos mucho quienes nada muchos cual poco ella estar estas algunas algo nosotros es son fue ser ha han'.split(' '));
const sentences = (t) => t.replace(/\s+/g, ' ').split(/(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÑ¿¡0-9])/).map(s => s.trim()).filter(s => s.length > 25);
/** Resumen extractivo: las oraciones con más palabras importantes, en su orden original. */
export function summarize(text, ratio = 0.3) {
    const ss = sentences(text);
    if (ss.length <= 3)
        return ss;
    const freq = new Map();
    for (const w of norm(text).match(/[a-zñ]{4,}/g) ?? [])
        if (!STOP.has(w))
            freq.set(w, (freq.get(w) ?? 0) + 1);
    const score = ss.map((s, i) => { const ws = norm(s).match(/[a-zñ]{4,}/g) ?? []; return { i, s, v: ws.reduce((a, w) => a + (freq.get(w) ?? 0), 0) / Math.sqrt(ws.length + 1) + (i === 0 ? 2 : 0) }; });
    const k = Math.max(3, Math.min(10, Math.round(ss.length * ratio)));
    return score.sort((a, b) => b.v - a.v).slice(0, k).sort((a, b) => a.i - b.i).map(x => x.s);
}
/** Tarjetas de estudio: definiciones («X es…», «X: …») y oraciones clave con una palabra oculta. */
export function flashcards(text) {
    const out = [];
    for (const s of sentences(text)) {
        const m = s.match(/^(.{3,60}?)\s+(es|son|se define como|consiste en|significa)\s+(.{10,})$/i) ?? s.match(/^([^:]{3,50}):\s+(.{10,})$/);
        if (m)
            out.push(m.length === 4 ? { q: `¿Qué ${/son/i.test(m[2]) ? 'son' : 'es'} ${m[1].replace(/^(el|la|los|las)\s+/i, '')}?`, a: m[3] } : { q: `${m[1]}…`, a: m[2] });
        if (out.length >= 20)
            break;
    }
    if (out.length < 5)
        for (const s of summarize(text, 0.4)) {
            const ws = s.split(' ').filter(w => w.length > 6 && !STOP.has(norm(w)));
            if (!ws.length)
                continue;
            const w = ws.sort((a, b) => b.length - a.length)[0].replace(/[.,;:]/g, '');
            out.push({ q: s.replace(w, '_____'), a: w });
            if (out.length >= 12)
                break;
        }
    return out;
}
/** Líneas OCR con posición → filas y columnas de una tabla. */
export function tableFromLines(lines, text) {
    if (!lines.length)
        return text.split('\n').filter(l => l.trim()).map(l => l.split(/\s{2,}|\t|;|\|/).map(c => c.trim()));
    return lines.slice().sort((a, b) => a.y0 - b.y0).map(l => l.t.split(/\s{2,}|\t|\|/).length > 1 ? l.t.split(/\s{2,}|\t|\|/) : l.t.split(/\s(?=[$\d])/)).map(r => r.map(c => c.trim()).filter(Boolean));
}
/** Diferencias palabra por palabra (LCS). */
export function diffWords(a, b) {
    const A = a.split(/(\s+)/).filter(Boolean).slice(0, 3000), Bw = b.split(/(\s+)/).filter(Boolean).slice(0, 3000);
    const n = A.length, m = Bw.length, dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
    for (let i = n - 1; i >= 0; i--)
        for (let j = m - 1; j >= 0; j--)
            dp[i][j] = A[i] === Bw[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const out = [];
    let i = 0, j = 0;
    while (i < n && j < m) {
        if (A[i] === Bw[j]) {
            out.push({ t: A[i], k: 'same' });
            i++;
            j++;
        }
        else if (dp[i + 1][j] >= dp[i][j + 1])
            out.push({ t: A[i++], k: 'del' });
        else
            out.push({ t: Bw[j++], k: 'add' });
    }
    while (i < n)
        out.push({ t: A[i++], k: 'del' });
    while (j < m)
        out.push({ t: Bw[j++], k: 'add' });
    return out;
}
/** Líneas con datos sensibles: números largos (cédula, cuentas), correos, teléfonos, direcciones. */
export function sensitiveLines(lines) {
    return lines.filter(l => /\d[\d.\s-]{6,}\d|[\w.+-]+@[\w-]+\.\w+|\b(calle|carrera|cra|cl|avenida|av|diagonal|transversal)\b\.?\s*\d/i.test(l.t));
}
/** Texto → lista con casillas (una línea por elemento). */
export const checklist = (t) => t.split('\n').map(l => l.replace(/^[\s\-•*·\d.)]+/, '').trim()).filter(l => l.length > 1);
