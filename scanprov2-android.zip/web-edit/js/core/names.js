// Validación de nombres de documentos (pura, sin DOM: se prueba en Node).
export const MAX_NAME = 80;
const INVALID = /[\\/:*?"<>|\u0000-\u001f]/;
export function normalizeName(s) {
    return s.replace(/\s+/g, ' ').trim();
}
export function validateName(raw, existing, currentName) {
    const name = normalizeName(raw);
    if (!name)
        return { ok: false, error: 'El nombre no puede estar vacío.' };
    if (name.length > MAX_NAME)
        return { ok: false, error: `Usa como máximo ${MAX_NAME} caracteres (ahora tiene ${name.length}).` };
    const bad = name.match(INVALID);
    if (bad)
        return { ok: false, error: `El carácter «${bad[0]}» no está permitido en nombres de archivo.` };
    if (/^\.+$/.test(name))
        return { ok: false, error: 'El nombre no puede estar formado solo por puntos.' };
    const lower = name.toLocaleLowerCase('es');
    const taken = existing.some(n => n.toLocaleLowerCase('es') === lower && n !== currentName);
    if (taken && name !== currentName)
        return { ok: false, error: 'Ya existe un documento con ese nombre.', suggestion: uniqueName(name, existing) };
    return { ok: true, name };
}
export function uniqueName(base, existing) {
    const set = new Set(existing.map(n => n.toLocaleLowerCase('es')));
    const clean = normalizeName(base).replace(/\s\(\d+\)$/, '') || 'Documento';
    if (!set.has(clean.toLocaleLowerCase('es')))
        return clean;
    for (let i = 2; i < 10000; i++) {
        const c = `${clean} (${i})`;
        if (!set.has(c.toLocaleLowerCase('es')))
            return c;
    }
    return `${clean} ${Date.now()}`;
}
export function defaultDocName(now = new Date()) {
    const p = (n) => String(n).padStart(2, '0');
    return `Escaneo ${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}.${p(now.getMinutes())}`;
}
/** Nombre seguro para archivos exportados. */
export function fileSafe(name) {
    return normalizeName(name).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 80) || 'documento';
}
