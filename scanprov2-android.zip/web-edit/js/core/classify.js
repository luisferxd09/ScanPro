import { loc, fmtMoney, monthYear, fmtDay } from './locale.js';
import { t } from '../i18n/index.js';
// Entiende qué documento es (sin internet): tipo, nombre automático, carpeta de vida, vencimiento y datos clave.
const norm = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
export const KINDS = [
    { id: 'soat', label: 'SOAT', life: 'vehiculo', rx: /\bsoat\b|seguro obligatorio de accidentes|insurance card|proof of insurance|carte verte|attestation d.assurance|dpvat|versicherungskarte/, expiry: true },
    { id: 'tecnomecanica', label: 'Revisión técnico-mecánica', life: 'vehiculo', rx: /tecnico ?-?mecanica|revision tecnico|cda\b/, expiry: true },
    { id: 'propiedad', label: 'Tarjeta de propiedad', life: 'vehiculo', rx: /licencia de transito|tarjeta de propiedad/ },
    { id: 'licencia', label: 'Licencia de conducción', life: 'identidad', rx: /licencia de conduccion|driver.?s licen[cs]e|carteira (nacional )?de habilitacao|permis de conduire|fuhrerschein|patente di guida|驾驶证|運転免許|운전면허|ehliyet|giay phep lai xe|водительское удостоверение|رخصة القيادة/, expiry: true },
    { id: 'pasaporte', label: 'Pasaporte', life: 'identidad', rx: /pasaporte|passport|passaporte|passeport|reisepass|passaporto|护照|旅券|여권|pasaport|ho chieu|паспорт|جواز السفر/, expiry: true },
    { id: 'cedula', label: 'Cédula', life: 'identidad', rx: /cedula de ciudadania|registraduria|republica de colombia.{0,40}identificacion|documento (nacional )?de identidad|\bnuip\b|identity card|carteira de identidade|registro geral|carte (nationale )?d.identite|personalausweis|carta d.identita|身份证|身分證|マイナンバー|주민등록|kimlik kart|kartu tanda penduduk|can cuoc|удостоверение личности|بطاقة الهوية|national id|aadhaar|\bine\b|credencial para votar/ },
    { id: 'formula', label: 'Fórmula médica', life: 'salud', rx: /formula medica|prescripcion|receta medica|posologia|\bmg\b.{0,30}cada \d+ ?h|prescription|receita|ordonnance|rezept|ricetta|处方|処方箋|처방전|recete|don thuoc|рецепт|وصفة طبية/ },
    { id: 'orden', label: 'Orden médica', life: 'salud', rx: /orden medica|autorizacion de servicios|remision a|solicitud de examen/ },
    { id: 'incapacidad', label: 'Incapacidad', life: 'salud', rx: /incapacidad (medica|temporal)|dias de incapacidad/ },
    { id: 'examen', label: 'Resultado de examen', life: 'salud', rx: /resultado(s)? de laboratorio|hemograma|glicemia|colesterol|valores de referencia/ },
    { id: 'vacunas', label: 'Carné de vacunas', life: 'salud', rx: /carne de vacunacion|esquema de vacunacion|vacuna/ },
    { id: 'mascota', label: 'Documento de mascota', life: 'mascotas', rx: /veterinari|mascota|canino|felino|antirrabica/ },
    { id: 'arriendo', label: 'Contrato de arriendo', life: 'hogar', rx: /contrato de arrendamiento|arrendador|arrendatario|lease agreement|tenancy agreement|landlord|contrato de locacao|bail d.habitation|mietvertrag|contratto di locazione|租赁合同|賃貸借契約|임대차/ },
    { id: 'laboral', label: 'Contrato laboral', life: 'trabajo', rx: /contrato (individual )?de trabajo|empleador.{0,80}trabajador|employment (contract|agreement)|contrato de trabalho|contrat de travail|arbeitsvertrag|contratto di lavoro|劳动合同|雇用契約|근로계약/ },
    { id: 'contrato', label: 'Contrato', rx: /contrato|clausula|contract|agreement|contrat|vertrag|contratto|合同|契約|계약|sozlesme|hop dong|договор|عقد/ },
    { id: 'nomina', label: 'Desprendible de nómina', life: 'trabajo', tags: ['trabajo'], rx: /desprendible|comprobante de (pago de )?nomina|devengado|deducciones|payslip|pay stub|holerite|contracheque|bulletin de (paie|salaire)|gehaltsabrechnung|busta paga|工资单|給与明細/ },
    { id: 'certlaboral', label: 'Certificado laboral', life: 'trabajo', rx: /certifica que.{0,120}(labora|trabaja|presta sus servicios)|certificado laboral/ },
    { id: 'diploma', label: 'Diploma', life: 'estudios', rx: /diploma|confiere el titulo|acta de grado|degree|certificate of completion|diplome|zeugnis|毕业证|卒業証書|학위/ },
    { id: 'certestudio', label: 'Certificado de estudios', life: 'estudios', rx: /certificado de (estudios|notas)|calificaciones|boletin/ },
    { id: 'extracto', label: 'Extracto bancario', tags: ['personal'], rx: /extracto|saldo anterior|saldo actual|movimientos del periodo|bank statement|account statement|extrato|releve de compte|kontoauszug|estratto conto|对账单|明細書/ },
    { id: 'servicio', label: 'Factura de servicio', life: 'hogar', tags: ['pendiente'], rx: /air-?e|epm\b|electricaribe|codensa|enel\b|acueducto|alcantarillado|gases del caribe|vanti|surtigas|triple a|kwh|m3 consumidos|consumo facturado|claro|movistar|tigo|etb\b|\bcfe\b|telmex|telcel|iberdrola|endesa|naturgy|edesur|edenor|metrogas|sabesp|cemig|copel|light s\.?a|vivo\b|electricity bill|utility bill|water bill|gas bill|conta de luz|facture d.electricite|edf\b|engie|stromrechnung|nebenkosten|bolletta|电费|電気料金|전기요금|elektrik faturasi|tien dien|квитанция|فاتورة الكهرباء/ },
    { id: 'garantia', label: 'Factura de compra', life: 'garantias', rx: /garantia|numero de serie|imei|electrodomestic/ },
    { id: 'factura', label: 'Factura', tags: ['pendiente'], rx: /factura( electronica)?( de venta)?|cufe|nit\b.{0,60}iva|invoice|nota fiscal|\bfatura\b|facture|rechnung|fattura|发票|請求書|インボイス|청구서|fatura|hoa don|счет|فاتورة/ },
    { id: 'cotizacion', label: 'Cotización', rx: /cotizacion|propuesta economica|quotation|\bquote\b|orcamento|devis|angebot|preventivo|报价|見積|견적/ },
    { id: 'cobro', label: 'Cuenta de cobro', rx: /cuenta de cobro|debe a/ },
    { id: 'recibo', label: 'Recibo', tags: ['pagado'], rx: /recibo|comprobante de pago|total pagado|tirilla|efectivo|cambio\b|receipt|cupom|recu|quittung|kassenbon|ricevuta|scontrino|收据|小票|領収書|レシート|영수증|fis\b|bien lai|чек|إيصال/ },
    { id: 'peticion', label: 'Derecho de petición', rx: /derecho de peticion/ },
    { id: 'carta', label: 'Carta', rx: /^(senor|senores|estimad|respetad)|atentamente|cordialmente/m },
    { id: 'apuntes', label: 'Apuntes', life: 'estudios', rx: /tema \d|ejercicio|definicion|capitulo|unidad \d/ },
];
const PROVIDERS = ['CFE', 'Telmex', 'Telcel', 'Iberdrola', 'Endesa', 'Naturgy', 'Edenor', 'Edesur', 'Sabesp', 'Cemig', 'Vivo', 'Itaú', 'Bradesco', 'Santander', 'Nubank', 'Caixa', 'EDF', 'Engie', 'Orange', 'Verizon', 'AT&T', 'Comcast', 'T-Mobile', 'PG&E', 'Chase', 'Wells Fargo', 'Bank of America', 'Vodafone', 'Telekom', 'TIM', 'Enel Energia', 'Air-e', 'EPM', 'Enel', 'Codensa', 'Triple A', 'Gases del Caribe', 'Vanti', 'Surtigas', 'Claro', 'Movistar', 'Tigo', 'ETB', 'Bancolombia', 'Davivienda', 'BBVA', 'Banco de Bogotá', 'Nequi', 'Daviplata', 'Sura', 'Sanitas', 'Nueva EPS', 'Compensar', 'Coomeva', 'Famisanar', 'Salud Total', 'Éxito', 'Olímpica', 'Jumbo', 'D1', 'Ara', 'Falabella', 'Alkosto'];
const DATE_RX = /(\d{1,2})\s*[/.-]\s*(\d{1,2})\s*[/.-]\s*(\d{2,4})|(\d{1,2}) de (enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)( de)? (\d{4})/gi;
export function findDates(text) {
    const out = [];
    for (const m of text.matchAll(DATE_RX)) {
        let d;
        if (m[1]) {
            const y = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]);
            d = new Date(y, Number(m[2]) - 1, Number(m[1]));
        }
        else
            d = new Date(Number(m[7]), MONTHS.indexOf(norm(m[5])), Number(m[4]));
        if (!isNaN(d.getTime()) && d.getFullYear() > 1950 && d.getFullYear() < 2100)
            out.push({ at: d.getTime(), i: m.index ?? 0, raw: m[0] });
    }
    return out;
}
/** Fecha de vencimiento: la que está cerca de «vence / vigencia hasta / válido hasta». */
export function findExpiry(text) {
    const n = norm(text), dates = findDates(text);
    for (const k of ['vigencia hasta', 'valido hasta', 'fecha de vencimiento', 'vence', 'vencimiento', 'hasta el', 'fin de vigencia', 'expira']) {
        let i = n.indexOf(k);
        while (i >= 0) {
            const d = dates.find(x => x.i >= i && x.i - i < 60);
            if (d)
                return d.at;
            i = n.indexOf(k, i + 1);
        }
    }
    return null;
}
export const money = (s) => { const t = s.replace(/[^\d.,]/g, ''); return /,\d{2}$/.test(t) ? Number(t.replace(/\./g, '').replace(',', '.')) : Number(t.replace(/[.,]/g, '')); };
export function findAmounts(text) {
    return [...text.matchAll(/\$\s?[\d.,]{3,}|\b\d{1,3}(?:\.\d{3}){1,3}(?:,\d{2})?\b/g)].map(m => ({ v: money(m[0]), ctx: text.slice(Math.max(0, (m.index ?? 0) - 40), (m.index ?? 0) + m[0].length).replace(/\s+/g, ' ') })).filter(x => x.v >= 1000);
}
export function analyze(text) {
    const n = norm(text);
    const kind = KINDS.find(k => k.rx.test(n)) ?? null;
    const provider = PROVIDERS.find(p => new RegExp(`(^|[^a-z0-9])${norm(p).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`).test(n)) ?? null;
    const plate = text.match(/\b[A-Z]{3}[- ]?\d{2}[A-Z0-9]\b/)?.[0].replace(/[- ]/, '') ?? null;
    const person = text.match(/(?:nombres?|apellidos?|señor\(a\)|paciente|titular|cliente|arrendatario)\s*:?\s*([A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑa-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑa-záéíóúñ]+){1,3})/)?.[1] ?? null;
    const expires = kind?.expiry ? findExpiry(text) : findExpiry(text);
    const d = findDates(text).map(x => x.at).filter(t => t < Date.now() + 86400000).sort((a, b) => b - a)[0];
    const when = d ? new Date(d) : new Date();
    const month = monthYear(when.getTime());
    let name = null;
    if (kind) {
        const extra = kind.id === 'servicio' || kind.id === 'factura' || kind.id === 'recibo' || kind.id === 'extracto' ? [provider, month].filter(Boolean).join(' · ')
            : kind.id === 'soat' || kind.id === 'tecnomecanica' || kind.id === 'propiedad' ? plate ?? ''
                : kind.life === 'identidad' ? person ?? '' : kind.life === 'salud' ? [provider, fmtDay(when.getTime(), { day: 'numeric', month: 'short', year: 'numeric' })].filter(Boolean).join(' · ')
                    : kind.id === 'nomina' ? month : String(when.getFullYear());
        name = extra ? `${t(kind.label)} · ${extra}` : t(kind.label);
    }
    return { kind, name, expires: expires && expires > Date.now() - 365 * 86400000 ? expires : null, provider, plate, person };
}
const RULES = [
    [/permanencia|clausula de permanencia|plazo minimo|minimum term|lock-?in|fidelidade|periode d.engagement|mindestlaufzeit|vincolo/, 'alta', 'Cláusula de permanencia'],
    [/clausula penal|multa|penalidad|sancion|penalty|liquidated damages|fine of|penalite|vertragsstrafe|penale/, 'alta', 'Multa o cláusula penal'],
    [/prorroga automatica|renovara automaticamente|se prorrogara|renovacion automatica|automatic(ally)? renew|auto-?renew|renovacao automatica|renouvel(le|ement) automatique|verlangert sich automatisch|rinnovo (tacito|automatico)/, 'alta', 'Renovación automática'],
    [/preaviso|con (una )?antelacion (minima )?de|aviso previo|notice period|prior (written )?notice|preavis|kundigungsfrist|preavviso/, 'media', 'Necesita aviso previo para terminar'],
    [/intereses? (de )?mora|tasa maxima|late (payment )?(fee|interest)|juros de mora|interets de retard|verzugszinsen|interessi di mora/, 'media', 'Intereses de mora'],
    [/incremento|reajuste|\bipc\b|aumentara|increase|inflation|\bcpi\b|indexation|erhohung|aumento|adeguamento/, 'media', 'Aumento de precio o canon'],
    [/fiador|codeudor|deudor solidario|guarantor|co-?signer|caution solidaire|burge|garante|fideiussore/, 'media', 'Pide fiador o codeudor'],
    [/deposito|garantia de cumplimiento|poliza/, 'info', 'Depósito, póliza o garantía'],
    [/exclusividad|no competencia/, 'media', 'Exclusividad o no competencia'],
    [/confidencialidad|reserva de la informacion/, 'info', 'Confidencialidad'],
    [/terminar unilateralmente|terminacion unilateral|dar por terminado/, 'media', 'Terminación unilateral'],
    [/datos personales|habeas data|ley 1581/, 'info', 'Uso de tus datos personales'],
    [/renuncia(r)? a (los )?requerimientos|renuncia expresa/, 'alta', 'Renuncias a derechos'],
    [/pagare|carta de instrucciones/, 'alta', 'Firma de pagaré'],
    [/cobro juridico|honorarios de cobranza|gastos de cobranza/, 'media', 'Cobros de cobranza'],
];
export function reviewText(text) {
    const sentences = text.replace(/\s+/g, ' ').split(/(?<=[.;:])\s+/);
    const out = [];
    for (const [rx, level, title] of RULES) {
        const s = sentences.find(x => rx.test(norm(x)));
        if (s)
            out.push({ level, title, quote: s.length > 260 ? s.slice(0, 257) + '…' : s });
    }
    const order = { alta: 0, media: 1, info: 2 };
    return out.sort((a, b) => order[a.level] - order[b.level]);
}
export function keyFacts(text) {
    const out = [];
    const a = analyze(text);
    if (a.kind)
        out.push({ label: 'Tipo', value: a.kind.label });
    if (a.provider)
        out.push({ label: 'Entidad', value: a.provider });
    if (a.person)
        out.push({ label: 'Persona', value: a.person });
    const ids = [...text.matchAll(/(?:c\.?c\.?|cedula|nit|documento)\s*(?:no\.?|n°|#)?\s*:?\s*([\d.\-]{6,})/gi)].map(m => m[1]);
    if (ids.length)
        out.push({ label: 'Documentos de identidad / NIT', value: [...new Set(ids)].slice(0, 4).join(' · ') });
    const amts = findAmounts(text).sort((x, y) => y.v - x.v).slice(0, 4);
    if (amts.length)
        out.push({ label: 'Valores', value: amts.map(x => fmtMoney(x.v)).join(' · ') });
    const ds = [...new Set(findDates(text).map(x => new Date(x.at).toLocaleDateString(loc(), { day: 'numeric', month: 'short', year: 'numeric' })))].slice(0, 6);
    if (ds.length)
        out.push({ label: 'Fechas', value: ds.join(' · ') });
    if (a.expires)
        out.push({ label: 'Vence', value: new Date(a.expires).toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' }) });
    const dur = norm(text).match(/(termino|duracion|plazo) de (\w+ \(?\d*\)? ?(meses|anos|dias))/);
    if (dur)
        out.push({ label: 'Duración', value: dur[2] });
    return out;
}
export { MONTHS, norm };
