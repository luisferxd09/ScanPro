// Sonidos breves sintetizados (sin archivos): obturador, listo, borrar, toque y error.
import { getSettings } from './settings.js';
let ac = null;
const silent = () => { try {
    return !!globalThis.ScanProAndroid?.silent?.();
}
catch {
    return false;
} };
function tone(f, at, dur, type = 'sine', gain = .12, f2) {
    const o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime + at;
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (f2)
        o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + .005);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g).connect(ac.destination);
    o.start(t);
    o.stop(t + dur + .02);
}
function noise(at, dur, gain = .2) {
    const n = Math.floor(ac.sampleRate * dur), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++)
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 6);
    const s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    s.buffer = b;
    f.type = 'highpass';
    f.frequency.value = 1800;
    g.gain.value = gain;
    s.connect(f).connect(g).connect(ac.destination);
    s.start(ac.currentTime + at);
}
export function play(kind) {
    if (!getSettings().sounds || silent())
        return;
    try {
        ac ??= new AudioContext();
        if (ac.state === 'suspended')
            void ac.resume();
        if (kind === 'shutter') {
            noise(0, .05, .35);
            noise(.06, .04, .25);
        }
        else if (kind === 'success') {
            tone(880, 0, .18, 'sine', .1);
            tone(1320, .09, .28, 'sine', .09);
        }
        else if (kind === 'delete')
            tone(520, 0, .22, 'triangle', .1, 180);
        else if (kind === 'tap') {
            tone(1800, 0, .025, 'sine', .045);
            tone(900, .004, .03, 'triangle', .025);
        }
        else if (kind === 'pop') {
            tone(420, 0, .09, 'sine', .09, 880);
        }
        else if (kind === 'close') {
            tone(760, 0, .08, 'sine', .07, 380);
        }
        else if (kind === 'toggle') {
            tone(1200, 0, .04, 'triangle', .06);
            tone(1600, .045, .04, 'triangle', .05);
        }
        else if (kind === 'chime') {
            [523, 659, 784, 1047].forEach((f, i) => tone(f, i * .09, .5, 'sine', .07));
        }
        else if (kind === 'swipe')
            noise(0, .07, .06);
        else if (kind === 'step') {
            tone(660, 0, .08, 'sine', .07);
            tone(990, .07, .12, 'sine', .07);
        }
        else if (kind === 'warn') {
            tone(440, 0, .12, 'triangle', .08);
            tone(330, .12, .16, 'triangle', .08);
        }
        else
            tone(220, 0, .18, 'square', .05);
    }
    catch { /* sin audio */ }
}
/** Vibración corta (háptica) al tocar; usa el motor del teléfono si está en el APK. */
export function haptic(kind = 'light') {
    if (getSettings().haptics === false)
        return;
    try {
        const b = globalThis.ScanProAndroid;
        if (b?.haptic) {
            b.haptic(kind);
            return;
        }
        navigator.vibrate?.(kind === 'success' ? [12, 60, 18] : kind === 'error' ? [30, 50, 30] : kind === 'medium' ? 18 : 8);
    }
    catch { /* sin vibración */ }
}
