// Importar PDF: cada página se convierte en imagen (pdf.js). En el APK va incluido; en la web se descarga.
import { isNative } from './native.js';
const CDN = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/legacy/build/';
let lib = null;
async function load() {
    const tryBase = async (base) => { const m = await import(/* @vite-ignore */ base + 'pdf.min.mjs'); m.GlobalWorkerOptions.workerSrc = base + 'pdf.worker.min.mjs'; return m; };
    const local = new URL('vendor/pdfjs/', location.href).href;
    lib ??= (isNative ? tryBase(local).catch(() => tryBase(CDN)) : tryBase(CDN)).catch(e => { lib = null; throw new Error('No se pudo cargar el lector de PDF' + (isNative ? '.' : ': la primera vez se necesita internet.') + ' (' + e.message + ')'); });
    return lib;
}
/** Convierte las páginas de un PDF en imágenes JPEG (máx. 2200 px por lado). */
export async function pdfToImages(file, onPage, password) {
    const pdfjs = await load();
    let doc;
    try {
        doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()), password }).promise;
    }
    catch (e) {
        const n = e.name;
        throw new Error(n === 'PasswordException' ? 'PDF_PASSWORD' : 'El PDF está dañado o no se puede leer.');
    }
    const out = [];
    try {
        for (let i = 1; i <= doc.numPages; i++) {
            onPage(i - 1, doc.numPages);
            const page = await doc.getPage(i), v1 = page.getViewport({ scale: 1 }), scale = Math.min(4, 2200 / Math.max(v1.width, v1.height));
            const vp = page.getViewport({ scale }), c = document.createElement('canvas');
            c.width = Math.round(vp.width);
            c.height = Math.round(vp.height);
            const g = c.getContext('2d');
            g.fillStyle = '#fff';
            g.fillRect(0, 0, c.width, c.height);
            await page.render({ canvasContext: g, viewport: vp }).promise;
            page.cleanup();
            out.push(await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('No se pudo convertir la página.')), 'image/jpeg', .9)));
            c.width = c.height = 1;
        }
    }
    finally {
        await doc.destroy();
    }
    return out;
}
