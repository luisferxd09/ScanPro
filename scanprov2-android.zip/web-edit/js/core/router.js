const routes = new Map();
let root;
let current = { name: '', params: {} };
let cleanups = [];
let guard = null;
let renderSeq = 0;
let beforeRender = null;
let afterRender = null;
export function setBeforeRender(fn) { beforeRender = fn; }
export function setAfterRender(fn) { afterRender = fn; }
const overlays = [];
let overlaySeq = 0;
let popWaiters = [];
let ignorePop = 0;
export const TABS = ['home', 'docs', 'tools', 'settings'];
export function register(name, render, opts = {}) {
    routes.set(name, { render, transient: opts.transient, modal: opts.modal });
}
const isModal = (name) => !!routes.get(name)?.modal;
/** Registra una función que se ejecuta al abandonar la pantalla actual (p. ej. apagar la cámara). */
export function onLeave(fn) { cleanups.push(fn); }
/** Protege la pantalla actual (p. ej. un escaneo sin guardar). Devuelve true para permitir salir. */
export function setGuard(fn) { guard = fn; }
export function currentRoute() { return current; }
function toHash(r) {
    const q = new URLSearchParams(r.params).toString();
    return `#/${r.name}${q ? '?' + q : ''}`;
}
function fromHash() {
    const m = location.hash.match(/^#\/([\w-]+)(?:\?(.*))?$/);
    if (!m)
        return null;
    return { name: m[1], params: Object.fromEntries(new URLSearchParams(m[2] ?? '')) };
}
/** Guarda la posición de desplazamiento en la entrada actual para restaurarla al volver. */
function saveScroll() {
    try {
        history.replaceState({ ...(history.state ?? {}), scroll: window.scrollY }, '', location.href);
    }
    catch { /* sin historial */ }
}
let animMs = 0;
function pushMs() {
    if (!animMs)
        animMs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--t-push')) || 420;
    return animMs;
}
/** Monta la pantalla nueva animando la salida de la anterior (solo transform/opacity). */
function mount(el, kind, scroll) {
    el.classList.add('screen');
    root.querySelectorAll(':scope > .leaving').forEach(n => n.remove());
    const old = root.firstElementChild;
    const noMotion = document.documentElement.classList.contains('no-motion');
    if (!old || kind === 'none' || noMotion) {
        root.replaceChildren(el);
        window.scrollTo(0, scroll);
        return;
    }
    const rect = root.getBoundingClientRect();
    old.classList.add('leaving', 'frozen');
    old.style.top = `${-window.scrollY}px`;
    old.style.left = `${rect.left}px`;
    old.style.width = `${rect.width}px`;
    old.setAttribute('aria-hidden', 'true');
    el.classList.add('entering');
    root.appendChild(el);
    window.scrollTo(0, scroll);
    const [inC, outC] = {
        push: ['t-push-in', 't-push-out'], pop: ['t-pop-in', 't-pop-out'], fade: ['t-fade-in', 't-fade-out'],
        'modal-in': ['t-modal-in', ''], 'modal-out': ['', 't-modal-out'], none: ['', ''],
    }[kind];
    if (inC)
        el.classList.add(inC);
    if (outC)
        old.classList.add(outC);
    let finished = false;
    const done = () => {
        if (finished)
            return;
        finished = true;
        old.remove();
        el.classList.remove('entering', inC || 'x');
    };
    (outC ? old : el).addEventListener('animationend', e => { if (e.target === (outC ? old : el))
        done(); });
    setTimeout(done, (kind === 'fade' ? 260 : pushMs()) + 120);
}
async function render(r, kind = 'none', scroll = 0) {
    const seq = ++renderSeq;
    const def = routes.get(r.name) ?? routes.get('home');
    for (const c of cleanups.splice(0)) {
        try {
            c();
        }
        catch { /* ignorar */ }
    }
    guard = null;
    beforeRender?.();
    current = r;
    let el;
    try {
        el = await def.render(r.params);
    }
    catch (e) {
        console.error(e);
        el = document.createElement('div');
        el.className = 'screen';
        el.innerHTML = `<div class="empty"><h3>No se pudo abrir esta pantalla</h3><p>${e.message ?? ''}</p></div>`;
    }
    if (seq !== renderSeq)
        return;
    mount(el, kind, scroll);
    afterRender?.(r);
}
export function go(name, params = {}, opts = {}) {
    const r = { name, params };
    const replace = opts.replace ?? (TABS.includes(name) && TABS.includes(current.name));
    const kind = replace ? (isModal(current.name) && !isModal(name) ? 'modal-out' : 'fade') : isModal(name) && !isModal(current.name) ? 'modal-in' : 'push';
    if (replace)
        history.replaceState({ route: r, depth: history.state?.depth }, '', toHash(r));
    else {
        saveScroll();
        history.pushState({ route: r }, '', toHash(r));
    }
    void render(r, kind);
}
/** Vuelve atrás; si no hay historial propio, va al inicio. */
export function back(fallback = { name: 'home', params: {} }) {
    if (history.state?.route && history.length > 1 && history.state.depth !== 0)
        history.back();
    else
        go(fallback.name, fallback.params, { replace: true });
}
/**
 * Retrocede `steps` entradas del historial y, opcionalmente, sustituye la entrada
 * resultante por `route`. Sirve para cerrar un flujo (escaneo → revisión) al terminar.
 */
export function replaceBack(steps, route) {
    guard = null;
    if (steps <= 0) {
        if (route)
            go(route.name, route.params, { replace: true });
        return;
    }
    pendingBack = { route };
    history.go(-steps);
}
let pendingBack = null;
/** Abre una superposición asociada a una entrada del historial. */
export function pushOverlay(close) {
    const id = ++overlaySeq;
    overlays.push({ id, close });
    history.pushState({ route: current, overlay: id }, '', toHash(current));
    return id;
}
/** Cierra la superposición desde la interfaz; resuelve cuando el historial se ha actualizado. */
export function popOverlay(id) {
    const idx = overlays.findIndex(o => o.id === id);
    if (idx < 0)
        return Promise.resolve();
    return new Promise(res => { popWaiters.push(res); history.back(); });
}
export function closeAllOverlays() {
    const n = overlays.length;
    if (!n)
        return Promise.resolve();
    return new Promise(res => { popWaiters.push(res); history.go(-n); });
}
export function start(el, initial) {
    root = el;
    window.addEventListener('popstate', async (ev) => {
        if (ignorePop) {
            ignorePop--;
            return;
        }
        if (pendingBack) {
            const { route } = pendingBack;
            pendingBack = null;
            const st0 = ev.state;
            const r = route ?? st0?.route ?? { name: 'home', params: {} };
            if (route)
                history.replaceState({ route: r, depth: st0?.depth }, '', toHash(r));
            void render(r, isModal(current.name) && !isModal(r.name) ? 'modal-out' : 'pop', route ? 0 : st0?.scroll ?? 0);
            return;
        }
        const st = ev.state;
        // 1) cerrar superposiciones que ya no corresponden a la entrada actual
        const keep = st?.overlay ?? 0;
        let closed = false;
        while (overlays.length && overlays[overlays.length - 1].id > keep) {
            overlays.pop().close();
            closed = true;
        }
        const waiters = popWaiters.splice(0);
        waiters.forEach(w => w());
        if (closed || waiters.length) {
            if (!st?.route || st.route.name === current.name)
                return;
        }
        // 2) cambio de pantalla, respetando la protección de la pantalla actual
        const target = st?.route ?? fromHash() ?? { name: 'home', params: {} };
        if (guard) {
            const g = guard;
            // restaura la entrada mientras se pregunta
            ignorePop = 0;
            history.pushState({ route: current }, '', toHash(current));
            const ok = await g();
            if (!ok)
                return;
            guard = null;
            history.replaceState({ route: target }, '', toHash(target));
            void render(target, isModal(current.name) && !isModal(target.name) ? 'modal-out' : 'pop');
            return;
        }
        void render(target, isModal(current.name) && !isModal(target.name) ? 'modal-out' : 'pop', st?.scroll ?? 0);
    });
    let r = fromHash() ?? initial;
    if (!routes.has(r.name) || routes.get(r.name).transient)
        r = initial;
    // base del historial: inicio debajo de cualquier pantalla abierta por enlace
    if (r.name !== 'home' && r.name !== 'onboarding') {
        history.replaceState({ route: { name: 'home', params: {} }, depth: 0 }, '', toHash({ name: 'home', params: {} }));
        history.pushState({ route: r }, '', toHash(r));
    }
    else {
        history.replaceState({ route: r, depth: 0 }, '', toHash(r));
    }
    void render(r);
}
