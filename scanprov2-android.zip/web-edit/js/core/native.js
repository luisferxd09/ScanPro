import { loc } from './locale.js';
const bridge = globalThis.ScanProAndroid;
/** true cuando ScanPro corre dentro del APK (sin navegador ni Internet). */
export const isNative = !!bridge;
function toB64(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i += 0x8000)
        s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
}
/** Copia un archivo al lado nativo por trozos (no bloquea la interfaz ni agota memoria). */
async function stage(f) {
    const token = bridge.begin(f.name, f.type || 'application/octet-stream');
    if (!token)
        throw new Error('No se pudo preparar el archivo.');
    const CH = 3 * 128 * 1024; // múltiplo de 3: cada trozo se codifica sin relleno intermedio
    for (let o = 0; o < f.size || o === 0; o += CH) {
        const part = new Uint8Array(await f.slice(o, o + CH).arrayBuffer());
        if (!bridge.append(token, toB64(part)))
            throw new Error('No hay espacio suficiente para preparar el archivo.');
        if (o + CH < f.size)
            await new Promise(r => setTimeout(r, 0));
        if (f.size === 0)
            break;
    }
    return token;
}
/** Guarda en Descargas/ScanPro. Devuelve la carpeta donde quedó. */
export async function nativeSave(files) {
    let where = '';
    for (const f of files) {
        const r = bridge.save(await stage(f));
        if (!r.startsWith('ok:'))
            throw new Error(r.replace(/^error:/, '') || 'No se pudo guardar el archivo.');
        where = r.slice(3);
    }
    return where;
}
export async function nativeShare(files, title) {
    const tokens = [];
    for (const f of files)
        tokens.push(await stage(f));
    return bridge.share(JSON.stringify(tokens), title) === 'ok';
}
export function nativeShareText(text, title) {
    return bridge.shareText(text, title) === 'ok';
}
/** Colorea la barra de estado y la de navegación de Android según el tema. */
export function nativeBars(color, dark) {
    try {
        bridge?.setBars(color, dark);
    }
    catch { /* versión antigua del APK */ }
}
// ---------- anuncios (AdMob, solo en el APK) ----------
const adWaiters = new Map();
globalThis.__scanproAd = (id, r) => { adWaiters.get(id)?.(r); adWaiters.delete(id); };
/** Muestra un anuncio y espera a que se cierre. Resultado: 'closed' | 'rewarded' | 'none'. */
export function nativeAd(kind, timeoutMs = 60000) {
    if (!bridge?.showAd)
        return Promise.resolve('none');
    const id = Math.random().toString(36).slice(2);
    return new Promise(res => {
        const t = setTimeout(() => { adWaiters.delete(id); res('none'); }, timeoutMs);
        adWaiters.set(id, r => { clearTimeout(t); res(r); });
        bridge.showAd(kind, id);
    });
}
export function nativeAdStatus() { try {
    return bridge?.adStatus?.() ?? 'APK sin diagnóstico';
}
catch {
    return 'desconocido';
} }
export function nativeTestAds(on) { try {
    bridge?.setTestAds?.(on);
}
catch { /* APK antiguo */ } }
// ---------- estado VIP / permisos ----------
const vipSubs = new Set();
globalThis.__scanproVip = (tier, until, feature) => {
    vipSubs.forEach(f => f(tier || 'free', until || 0, feature || ''));
};
export function onVip(f) {
    vipSubs.add(f);
    return () => vipSubs.delete(f);
}
export function nativeTier() {
    try {
        return bridge?.tier?.() ?? 'free';
    }
    catch {
        return 'free';
    }
}
export function nativeVipUntil() {
    try {
        return bridge?.vipUntil?.() ?? 0;
    }
    catch {
        return 0;
    }
}
export function nativeVipFeature() {
    try {
        return bridge?.vipFeature?.() ?? '';
    }
    catch {
        return '';
    }
}
export function nativeIsVip() {
    try {
        return !!bridge?.isVip?.();
    }
    catch {
        return false;
    }
}
export function nativeBuyVip() {
    try {
        return bridge?.buyVip?.() ?? 'error:No disponible';
    }
    catch {
        return 'error:No disponible';
    }
}
/** Comparte con una app concreta (si no está, abre el menú normal). */
export async function nativeShareTo(files, title, pkg) {
    const tokens = [];
    for (const f of files)
        tokens.push(await stage(f));
    return (bridge.shareTo ? bridge.shareTo(JSON.stringify(tokens), title, pkg) : bridge.share(JSON.stringify(tokens), title)) === 'ok';
}
// ---------- escáner de documentos de Google (enfoque y bordes nativos) ----------
/** true si el APK trae el escáner de Google (ML Kit). */
export const hasNativeScanner = !!bridge?.scanDocs;
let scanWaiter = null;
globalThis.__scanproScan = r => { const w = scanWaiter; scanWaiter = null; w?.(r); };
/** Abre el escáner de Google. Devuelve 'ok:N', 'cancel' o 'error:…'. Las páginas llegan luego por __scanproShared. */
export function nativeScan(limit = 0) {
    return new Promise(res => { scanWaiter = res; try {
        bridge.scanDocs(limit);
    }
    catch (e) {
        scanWaiter = null;
        res('error:' + e.message);
    } });
}
/** Convierte con Android una imagen que la web no sabe leer (HEIC, AVIF, DNG…) a JPEG. */
export async function nativeConvertImage(f) {
    if (!bridge?.convertImage)
        throw new Error('formato');
    const r = bridge.convertImage(await stage(f));
    if (r.startsWith('error:'))
        throw new Error('formato');
    return (await fetch(r)).blob();
}
// ---------- herramientas nativas con respuesta asíncrona ----------
const cbs = new Map();
globalThis.__scanproCb = (id, r) => { const f = cbs.get(id); cbs.delete(id); f?.(r); };
function call(fn, timeoutMs = 600000) {
    const id = Math.random().toString(36).slice(2);
    return new Promise(res => {
        const t = setTimeout(() => { cbs.delete(id); res('error:tiempo agotado'); }, timeoutMs);
        cbs.set(id, r => { clearTimeout(t); res(r); });
        try {
            fn(id);
        }
        catch (e) {
            cbs.delete(id);
            clearTimeout(t);
            res('error:' + e.message);
        }
    });
}
export const nativeHas = (k) => !!bridge && typeof bridge[k] === 'function';
export const nativeScanCode = () => call(id => bridge.scanCode(id), 300000);
export const nativeTranslate = (text, from, to) => call(id => bridge.translate(text, from, to, id));
export const nativeSpeak = (text, lang = loc()) => { try {
    bridge?.speak?.(text, lang);
}
catch { /* */ } };
export const nativeStopSpeak = () => { try {
    bridge?.stopSpeak?.();
}
catch { /* */ } };
export const nativeDictate = async () => { const r = await call(id => bridge.dictate(id, loc()), 300000); return r === 'error:nodictation' ? 'error:Este teléfono no tiene dictado por voz.' : r; };
export const nativeAddContact = (c) => bridge?.addContact?.(JSON.stringify(c));
export async function nativePrint(f) { if (!bridge?.print)
    return false; return bridge.print(await stage(f), f.name).startsWith('ok'); }
export const nativeAuth = (title) => call(id => bridge.authenticate(id, title), 300000);
export const nativeSchedule = (id, at, repeatMs, title, text) => { try {
    bridge?.schedule?.(id, at, repeatMs, title, text);
}
catch { /* */ } };
export const nativeUnschedule = (id) => { try {
    bridge?.unschedule?.(id);
}
catch { /* */ } };
export async function nativeRemoveBg(f) {
    const token = await stage(f);
    const r = await call(id => bridge.removeBg(token, id), 180000);
    if (!r.startsWith('ok:'))
        throw new Error(r.replace(/^error:/, '') || 'No se pudo quitar el fondo.');
    return (await fetch(r.slice(3))).blob();
}
export async function nativeShareEmail(files, title, to) {
    if (!bridge?.shareEmail)
        return false;
    const tokens = [];
    for (const f of files)
        tokens.push(await stage(f));
    return bridge.shareEmail(JSON.stringify(tokens), title, to) === 'ok';
}
