// Persistencia local de recompensas VIP (ruleta y progreso de 5 anuncios).
// Este estado es local al dispositivo y no reemplaza la verificación de compras
// por Play Billing ni la validación Server-Side de AdMob.
const KEY = 'scanpro.vip.v1';

export function loadVipState() {
    try {
        const raw = localStorage.getItem(KEY);
        return raw ? JSON.parse(raw) : {};
    }
    catch {
        return {};
    }
}

export function saveVipState(patch) {
    const next = { ...loadVipState(), ...patch };
    try {
        localStorage.setItem(KEY, JSON.stringify(next));
    }
    catch {
        // Sin espacio o modo privado.
    }
    return next;
}

/** Elimina recompensas vencidas y devuelve el estado limpio. */
export function cleanupVipState() {
    const state = loadVipState();
    const now = Date.now();
    let changed = false;
    if (state.fullUntil && state.fullUntil <= now) {
        delete state.fullUntil;
        changed = true;
    }
    if (state.featureUntil && state.featureUntil <= now) {
        delete state.featureUntil;
        delete state.feature;
        changed = true;
    }
    if (changed)
        saveVipState(state);
    return state;
}

export function setFullTempReward(until) {
    saveVipState({ fullUntil: until });
}

export function setFeatureReward(feature, until) {
    saveVipState({ feature, featureUntil: until });
}

/** Devuelve { type: 'full'|'feature', feature?, until } o null. */
export function getActiveReward() {
    const state = cleanupVipState();
    const now = Date.now();
    if (state.fullUntil && state.fullUntil > now) {
        return { type: 'full', until: state.fullUntil };
    }
    if (state.featureUntil && state.featureUntil > now) {
        return { type: 'feature', feature: state.feature, until: state.featureUntil };
    }
    return null;
}

// ---------- progreso de anuncios para recompensas ----------
const AD_PROGRESS_KEY = 'scanpro.vip.adProgress.v1';

export function getAdProgress() {
    try {
        const raw = localStorage.getItem(AD_PROGRESS_KEY);
        return raw ? JSON.parse(raw) : { count: 0, lastRewardAt: 0 };
    }
    catch {
        return { count: 0, lastRewardAt: 0 };
    }
}

export function setAdProgress(progress) {
    localStorage.setItem(AD_PROGRESS_KEY, JSON.stringify(progress));
}

export function incrementAdProgress() {
    const p = getAdProgress();
    p.count = (p.count || 0) + 1;
    setAdProgress(p);
    return p.count;
}

export function resetAdProgress() {
    setAdProgress({ count: 0, lastRewardAt: Date.now() });
}
