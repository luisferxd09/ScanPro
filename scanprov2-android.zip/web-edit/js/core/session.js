import { paperDefault } from './locale.js';
// Sesión de escaneo en curso: páginas capturadas o importadas antes de guardarlas.
// El trabajo pesado (detectar, enderezar, filtrar, codificar) lo hace el motor en segundo plano,
// así el obturador responde al instante y la interfaz nunca se congela.
import { uid } from '../ui/dom.js';
import { engine } from '../imaging/engine.js';
import { getSettings } from './settings.js';
import { NO_ADJUST, createDoc, addPages, updatePage, getPage } from './db.js';
import { composeIdPage } from './idcard.js';
let session = null;
const listeners = new Set();
export function getSession() { return session; }
export function startSession(targetDocId = null, mode) {
    if (session)
        for (const p of session.pages)
            void engine.drop(p.id).catch(() => { });
    session = { pages: [], targetDocId, editPageId: null, mode, idOptions: mode === 'id' ? { paper: paperDefault(), scale: 'real' } : undefined };
    return session;
}
export function endSession() {
    if (session)
        for (const p of session.pages)
            void engine.drop(p.id).catch(() => { });
    session = null;
    dropViews();
}
export function hasUnsaved() { return !!session && !session.editPageId && session.pages.length > 0; }
/** Avisa cuando el resultado de una página está listo (para refrescar miniaturas). */
export function onPageReady(fn) { listeners.add(fn); return () => listeners.delete(fn); }
/**
 * Añade una página al instante y la prepara en segundo plano (no bloquea el obturador).
 * `src`: fotograma de la cámara, o promesa de una foto (takePhoto / archivo).
 * `hint`: esquinas de la vista en vivo, válidas solo para el mismo fotograma.
 */
export function addCapture(src, hint, detect = true) {
    if (!session)
        startSession();
    const st = getSettings();
    const id = uid();
    let resolveOrig, rejectOrig;
    const originalP = new Promise((res, rej) => { resolveOrig = res; rejectOrig = rej; });
    originalP.catch(() => { });
    const dp = { id, originalP, width: 0, height: 0, corners: null, detected: false, sharp: 0, autoRotated: 0, rotation: 0, filter: session.mode === 'id' ? 'enhanced' : st.defaultFilter, adjust: { ...NO_ADJUST }, version: 0, ready: Promise.resolve() };
    dp.ready = (async () => {
        const s = await src;
        const r = await engine.ingest(id, s, s instanceof Blob ? null : hint, st.autoDetect && detect);
        dp.width = r.width;
        dp.height = r.height;
        dp.corners = r.corners;
        dp.detected = r.detected;
        dp.sharp = r.sharp;
        if (st.autoRotate && detect && session?.mode !== 'id' && r.rotation && dp.rotation === 0) {
            dp.rotation = r.rotation;
            dp.autoRotated = r.rotation;
        }
        if (s instanceof Blob)
            resolveOrig(s);
        else
            engine.encodeOriginal(id, 0.92).then(resolveOrig, rejectOrig);
    })();
    dp.ready.catch(e => { rejectOrig(e); removePage(dp); });
    originalP.then(b => { dp.original = b; }, () => { });
    session.pages.push(dp);
    return dp;
}
/** Foto importada: espera a que esté lista (lanza si el archivo no es válido). */
export async function addFile(file) {
    const dp = addCapture(file, null);
    await dp.ready;
    return dp;
}
export function removePage(dp) {
    if (!session)
        return;
    const i = session.pages.indexOf(dp);
    if (i >= 0)
        session.pages.splice(i, 1);
    void engine.drop(dp.id).catch(() => { });
}
/** Ejecuta una operación del motor; si la foto salió de memoria, se vuelve a leer del original. */
export async function withSource(dp, fn) {
    try {
        return await fn(dp.original);
    }
    catch (e) {
        if (!/memoria/.test(e.message))
            throw e;
        return fn(await dp.originalP);
    }
}
/** Calcula en segundo plano el resultado final a máxima calidad. */
export function scheduleRender(dp) {
    const v = ++dp.version;
    dp.outP = dp.ready.then(() => withSource(dp, fb => engine.render(dp.id, fb, { corners: dp.corners, rotation: dp.rotation, filter: dp.filter, adjust: { ...dp.adjust } }))).then(r => {
        if (v !== dp.version)
            return;
        dp.out = r;
        listeners.forEach(l => l(dp));
    });
    return dp.outP;
}
export async function ensureRendered(dp) {
    for (let i = 0; i < 4; i++) {
        const p = dp.outP ?? scheduleRender(dp);
        await p;
        if (dp.out && p === dp.outP)
            return;
    }
    throw new Error('No se pudo procesar una página.');
}
// Copias para pantalla (pocas a la vez para cuidar la memoria)
const views = new Map();
export function viewOf(dp) {
    let v = views.get(dp.id);
    if (!v) {
        v = dp.ready.then(() => withSource(dp, fb => engine.view(dp.id, fb)));
        views.set(dp.id, v);
        while (views.size > 2) {
            const [k, old] = views.entries().next().value;
            views.delete(k);
            void old.then(b => b.close(), () => { });
        }
    }
    return v;
}
function dropViews() { for (const v of views.values())
    void v.then(b => b.close(), () => { }); views.clear(); }
function toRecord(dp) {
    if (!dp.out || !dp.original)
        throw new Error('Página sin procesar');
    return {
        id: dp.sourcePageId ?? uid(), image: dp.out.image, original: dp.original, thumb: dp.out.thumb,
        width: dp.out.width, height: dp.out.height, corners: dp.corners, filter: dp.filter,
        adjust: dp.adjust, rotation: dp.rotation, ocrText: dp.ocrText, ocrLines: dp.ocrLines, createdAt: Date.now(),
    };
}
/** Guarda la sesión. Espera a que terminen los cálculos pendientes. */
export async function saveSession(name, folderId, onProgress) {
    if (!session || !session.pages.length)
        throw new Error('No hay páginas que guardar.');
    const pages = session.pages;
    let done = 0;
    onProgress?.(0, pages.length);
    for (const p of pages) {
        await p.originalP;
        await ensureRendered(p);
        onProgress?.(++done, pages.length);
    }
    let recs = pages.map(toRecord);
    if (session.mode === 'id') {
        // las dos caras se combinan en una sola hoja a tamaño real
        const out = await composeIdPage(pages[0].out.image, pages[1]?.out?.image ?? null, session.idOptions ?? { paper: 'carta', scale: 'real' });
        recs = [{ id: uid(), image: out.image, original: out.image, thumb: out.thumb, width: out.width, height: out.height, corners: null, filter: 'original', adjust: { ...NO_ADJUST }, rotation: 0, createdAt: Date.now() }];
    }
    const docId = session.targetDocId ? (await addPages(session.targetDocId, recs)).id : (await createDoc(name, recs, folderId)).id;
    endSession();
    return docId;
}
/** Prepara una sesión para editar una página ya guardada (recorte, filtros, rotación). */
export async function editStoredPage(pageId) {
    const p = await getPage(pageId);
    if (!p)
        throw new Error('La página ya no existe.');
    endSession();
    session = { pages: [], targetDocId: p.docId, editPageId: p.id };
    const id = uid();
    const r = await engine.ingest(id, p.original, null, false);
    const dp = { id, original: p.original, originalP: Promise.resolve(p.original), width: r.width, height: r.height, corners: p.corners, detected: !!p.corners, sharp: 0, autoRotated: 0, rotation: p.rotation, filter: p.filter, adjust: { ...p.adjust }, sourcePageId: p.id, out: { image: p.image, thumb: p.thumb, width: p.width, height: p.height }, version: 0, ready: Promise.resolve() };
    session.pages.push(dp);
    return dp;
}
export async function saveEditedPage(dp) {
    const p = await getPage(dp.sourcePageId);
    if (!p)
        throw new Error('La página ya no existe.');
    await scheduleRender(dp);
    await updatePage({ ...p, image: dp.out.image, thumb: dp.out.thumb, width: dp.out.width, height: dp.out.height, corners: dp.corners, filter: dp.filter, adjust: dp.adjust, rotation: dp.rotation });
    const docId = p.docId;
    endSession();
    return docId;
}
