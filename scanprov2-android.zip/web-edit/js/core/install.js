import { isNative } from './native.js';
let deferred = null;
const listeners = new Set();
export function initInstall() {
    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; listeners.forEach(l => l()); });
    window.addEventListener('appinstalled', () => { deferred = null; listeners.forEach(l => l()); });
}
export function canInstall() { return !!deferred; }
export function isInstalled() { return isNative || matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; }
export function onInstallChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export async function promptInstall() {
    if (!deferred)
        return false;
    await deferred.prompt();
    const r = await deferred.userChoice;
    deferred = null;
    return r.outcome === 'accepted';
}
