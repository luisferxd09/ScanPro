// Idiomas y países: formato de fechas y moneda, papel, nombre del documento de identidad, foto tipo documento y OCR.
import { getSettings } from './settings.js';
const C = (code, name, currency, paper, idName, photo) => ({ code, name, currency, paper, idName, photo });
export const LANGS = [
    { code: 'es', name: 'Español', hello: 'Hola', cont: 'Continuar', ocr: 'spa', countries: [
            C('CO', 'Colombia', 'COP', 'carta', 'Cédula', '3x4'), C('MX', 'México', 'MXN', 'carta', 'INE', 'infantil'), C('ES', 'España', 'EUR', 'a4', 'DNI', '32x26'), C('AR', 'Argentina', 'ARS', 'a4', 'DNI', '4x4'),
            C('CL', 'Chile', 'CLP', 'carta', 'Carnet', '3x4'), C('PE', 'Perú', 'PEN', 'a4', 'DNI', '3x4'), C('EC', 'Ecuador', 'USD', 'a4', 'Cédula', '3x4'), C('VE', 'Venezuela', 'VES', 'carta', 'Cédula', '3x4'),
            C('GT', 'Guatemala', 'GTQ', 'carta', 'DPI', '3x4'), C('DO', 'República Dominicana', 'DOP', 'carta', 'Cédula', '2x2'), C('BO', 'Bolivia', 'BOB', 'carta', 'Cédula', '3x4'), C('HN', 'Honduras', 'HNL', 'carta', 'DNI', '3x4'),
            C('PY', 'Paraguay', 'PYG', 'a4', 'Cédula', '3x4'), C('SV', 'El Salvador', 'USD', 'carta', 'DUI', '3x4'), C('NI', 'Nicaragua', 'NIO', 'carta', 'Cédula', '3x4'), C('CR', 'Costa Rica', 'CRC', 'carta', 'Cédula', '3x4'),
            C('PA', 'Panamá', 'USD', 'carta', 'Cédula', '3x4'), C('UY', 'Uruguay', 'UYU', 'a4', 'Cédula', '3x4'), C('PR', 'Puerto Rico', 'USD', 'carta', 'ID', '2x2'), C('CU', 'Cuba', 'CUP', 'carta', 'Carné', '3x4'),
            C('US', 'Estados Unidos', 'USD', 'carta', 'ID', '2x2')
        ] },
    { code: 'en', name: 'English', hello: 'Hello', cont: 'Continue', ocr: 'eng', countries: [
            C('US', 'United States', 'USD', 'carta', 'ID card', '2x2'), C('GB', 'United Kingdom', 'GBP', 'a4', 'ID card', '35x45'), C('CA', 'Canada', 'CAD', 'carta', 'ID card', '50x70'), C('AU', 'Australia', 'AUD', 'a4', 'ID card', '35x45'),
            C('IN', 'India', 'INR', 'a4', 'Aadhaar', '35x45'), C('NG', 'Nigeria', 'NGN', 'a4', 'NIN', '35x45'), C('PH', 'Philippines', 'PHP', 'carta', 'ID card', '2x2'), C('ZA', 'South Africa', 'ZAR', 'a4', 'ID card', '35x45'),
            C('IE', 'Ireland', 'EUR', 'a4', 'ID card', '35x45'), C('NZ', 'New Zealand', 'NZD', 'a4', 'ID card', '35x45'), C('SG', 'Singapore', 'SGD', 'a4', 'NRIC', '35x45'), C('KE', 'Kenya', 'KES', 'a4', 'ID card', '35x45'),
            C('PK', 'Pakistan', 'PKR', 'a4', 'CNIC', '35x45'), C('GH', 'Ghana', 'GHS', 'a4', 'Ghana Card', '35x45')
        ] },
    { code: 'pt', name: 'Português', hello: 'Olá', cont: 'Continuar', ocr: 'por', countries: [
            C('BR', 'Brasil', 'BRL', 'a4', 'RG', '3x4'), C('PT', 'Portugal', 'EUR', 'a4', 'Cartão de Cidadão', '35x45'), C('AO', 'Angola', 'AOA', 'a4', 'BI', '3x4'), C('MZ', 'Moçambique', 'MZN', 'a4', 'BI', '3x4')
        ] },
    { code: 'fr', name: 'Français', hello: 'Bonjour', cont: 'Continuer', ocr: 'fra', countries: [
            C('FR', 'France', 'EUR', 'a4', "Carte d'identité", '35x45'), C('CA', 'Canada', 'CAD', 'carta', "Carte d'identité", '50x70'), C('BE', 'Belgique', 'EUR', 'a4', "Carte d'identité", '35x45'), C('CH', 'Suisse', 'CHF', 'a4', "Carte d'identité", '35x45'),
            C('SN', 'Sénégal', 'XOF', 'a4', "Carte d'identité", '35x45'), C('CI', "Côte d'Ivoire", 'XOF', 'a4', "Carte d'identité", '35x45'), C('MA', 'Maroc', 'MAD', 'a4', 'CNIE', '35x45'), C('CM', 'Cameroun', 'XAF', 'a4', "Carte d'identité", '35x45'), C('HT', 'Haïti', 'HTG', 'carta', 'CIN', '2x2')
        ] },
    { code: 'de', name: 'Deutsch', hello: 'Hallo', cont: 'Weiter', ocr: 'deu', countries: [
            C('DE', 'Deutschland', 'EUR', 'a4', 'Personalausweis', '35x45'), C('AT', 'Österreich', 'EUR', 'a4', 'Personalausweis', '35x45'), C('CH', 'Schweiz', 'CHF', 'a4', 'Identitätskarte', '35x45')
        ] },
    { code: 'it', name: 'Italiano', hello: 'Ciao', cont: 'Continua', ocr: 'ita', countries: [C('IT', 'Italia', 'EUR', 'a4', "Carta d'identità", '35x45'), C('CH', 'Svizzera', 'CHF', 'a4', "Carta d'identità", '35x45')] },
    { code: 'zh', name: '中文', hello: '你好', cont: '继续', ocr: 'chi_sim', countries: [C('CN', '中国大陆', 'CNY', 'a4', '身份证', '33x48'), C('TW', '台灣', 'TWD', 'a4', '身分證', '35x45'), C('HK', '香港', 'HKD', 'a4', '身份證', '40x50'), C('SG', '新加坡', 'SGD', 'a4', 'NRIC', '35x45')] },
    { code: 'hi', name: 'हिन्दी', hello: 'नमस्ते', cont: 'जारी रखें', ocr: 'hin', countries: [C('IN', 'भारत', 'INR', 'a4', 'आधार', '35x45')] },
    { code: 'id', name: 'Bahasa Indonesia', hello: 'Halo', cont: 'Lanjutkan', ocr: 'ind', countries: [C('ID', 'Indonesia', 'IDR', 'a4', 'KTP', '3x4')] },
    { code: 'ru', name: 'Русский', hello: 'Привет', cont: 'Продолжить', ocr: 'rus', countries: [C('RU', 'Россия', 'RUB', 'a4', 'Паспорт', '35x45'), C('KZ', 'Казахстан', 'KZT', 'a4', 'Удостоверение', '35x45'), C('BY', 'Беларусь', 'BYN', 'a4', 'Паспорт', '35x45')] },
    { code: 'tr', name: 'Türkçe', hello: 'Merhaba', cont: 'Devam', ocr: 'tur', countries: [C('TR', 'Türkiye', 'TRY', 'a4', 'Kimlik Kartı', '50x60')] },
    { code: 'vi', name: 'Tiếng Việt', hello: 'Xin chào', cont: 'Tiếp tục', ocr: 'vie', countries: [C('VN', 'Việt Nam', 'VND', 'a4', 'CCCD', '3x4')] },
    { code: 'ja', name: '日本語', hello: 'こんにちは', cont: '続ける', ocr: 'jpn', countries: [C('JP', '日本', 'JPY', 'a4', 'マイナンバーカード', '35x45')] },
    { code: 'ko', name: '한국어', hello: '안녕하세요', cont: '계속', ocr: 'kor', countries: [C('KR', '대한민국', 'KRW', 'a4', '주민등록증', '35x45')] },
    { code: 'ar', name: 'العربية', hello: 'مرحبا', cont: 'متابعة', ocr: 'ara', rtl: true, countries: [
            C('SA', 'السعودية', 'SAR', 'a4', 'الهوية الوطنية', '4x6'), C('EG', 'مصر', 'EGP', 'a4', 'بطاقة الرقم القومي', '4x6'), C('AE', 'الإمارات', 'AED', 'a4', 'الهوية الإماراتية', '35x45'), C('MA', 'المغرب', 'MAD', 'a4', 'البطاقة الوطنية', '35x45'),
            C('DZ', 'الجزائر', 'DZD', 'a4', 'بطاقة التعريف', '35x45'), C('IQ', 'العراق', 'IQD', 'a4', 'البطاقة الوطنية', '35x45'), C('JO', 'الأردن', 'JOD', 'a4', 'الهوية', '35x45'), C('TN', 'تونس', 'TND', 'a4', 'بطاقة التعريف', '35x45')
        ] },
];
/** Tamaños de foto tipo documento: id, ancho y alto en cm. */
export const PHOTO_SIZES = [
    ['3x4', '3 × 4 cm', 3, 4], ['2x2', '2 × 2 in (5,1 × 5,1 cm)', 5.08, 5.08], ['35x45', '3,5 × 4,5 cm', 3.5, 4.5], ['infantil', '2,5 × 3 cm', 2.5, 3], ['32x26', '3,2 × 2,6 cm', 2.6, 3.2],
    ['4x4', '4 × 4 cm', 4, 4], ['50x70', '5 × 7 cm', 5, 7], ['33x48', '3,3 × 4,8 cm', 3.3, 4.8], ['40x50', '4 × 5 cm', 4, 5], ['50x60', '5 × 6 cm', 5, 6], ['4x6', '4 × 6 cm', 4, 6],
];
export function detectLang() {
    const n = (navigator.language || 'es').slice(0, 2).toLowerCase();
    return (LANGS.find(l => l.code === n)?.code ?? 'en');
}
export function curLang() { const l = getSettings().lang; return (l && l !== 'auto' && LANGS.some(x => x.code === l) ? l : detectLang()); }
export function langInfo(l = curLang()) { return LANGS.find(x => x.code === l) ?? LANGS[0]; }
export function curCountry() {
    const c = getSettings().country, info = langInfo();
    return info.countries.find(x => x.code === c) ?? LANGS.flatMap(x => x.countries).find(x => x.code === c) ?? info.countries[0];
}
/** Etiqueta BCP 47 para fechas y números, p. ej. «es-CO», «pt-BR». */
export const loc = () => `${curLang()}-${curCountry().code}`;
export function fmtMoney(n) {
    const cur = curCountry().currency, dec = ['COP', 'CLP', 'PYG', 'JPY', 'KRW', 'VND', 'IDR', 'HUF', 'ISK', 'XOF', 'XAF', 'UGX'].includes(cur) ? 0 : 2;
    try {
        return new Intl.NumberFormat(loc(), { style: 'currency', currency: cur, maximumFractionDigits: dec, minimumFractionDigits: dec && n % 1 ? 2 : 0 }).format(n);
    }
    catch {
        return '$ ' + Math.round(n).toLocaleString();
    }
}
export const fmtDay = (t, o = { day: 'numeric', month: 'long', year: 'numeric' }) => new Date(t).toLocaleDateString(loc(), o);
export const fmtShort = (t) => new Date(t).toLocaleDateString(loc());
export const fmtStamp = (t) => new Date(t).toLocaleString(loc(), { dateStyle: 'medium', timeStyle: 'short' });
export const monthYear = (t) => new Date(t).toLocaleDateString(loc(), { month: 'long', year: 'numeric' });
export const paperDefault = () => curCountry().paper;
export const pdfPaper = () => curCountry().paper === 'carta' ? 'letter' : 'a4';
/** Idiomas de OCR: el del usuario + inglés (y el español si el país es hispano y el idioma es inglés). */
export function ocrLangFor(l = curLang()) { const o = langInfo(l).ocr; return o === 'eng' ? 'eng' : `${o}+eng`; }
export const isRtl = () => !!langInfo().rtl;
export const ttsLang = () => loc();
