// Busca actualizaciones en GitHub Releases y las instala (solo en el APK).
// El cuadro de «Novedades» al iniciar vive aquí también (ver changelog.js).
import { h } from '../ui/dom.js';
import { infoDialog, toast } from '../ui/components.js';
import { isNative } from './native.js';
import { getSettings, setSettings, APP_VERSION } from './settings.js';
import { CHANGELOG } from './changelog.js';

const CHECK_KEY = 'scanpro.update.lastCheck';
const bridge = globalThis.ScanProAndroid;

/** Cuadro con la lista de cambios cuando la app arranca tras una actualización. */
export function showChangelogIfUpdated() {
    const s = getSettings();
    if (!s.helloDone)
        return; // instalación nueva: todavía no pasó por la bienvenida
    if (s.lastSeenVersion === APP_VERSION)
        return;
    setSettings({ lastSeenVersion: APP_VERSION });
    const items = CHANGELOG[APP_VERSION];
    if (!items || !items.length)
        return;
    setTimeout(() => infoDialog(`Novedades en ScanPro ${APP_VERSION}`, h('div', { class: 'changelog', style: 'text-align:left' }, ...items.map(t => h('p', { style: 'margin:0 0 10px', class: 'small' }, '• ', t))), 'zap'), 1500);
}

async function checkUpdateFlow(interactive) {
    if (!isNative || !bridge?.checkUpdate) {
        if (interactive)
            infoDialog('Actualizaciones', 'La búsqueda de actualizaciones funciona en la app instalada. En el navegador, la PWA se actualiza sola al recargar', 'download');
        return;
    }
    let r = null;
    try {
        r = JSON.parse(bridge.checkUpdate());
    }
    catch { r = null; }
    if (!r) {
        if (interactive)
            toast('No se pudo comprobar actualizaciones', 'error');
        return;
    }
    if (r.error && interactive)
        toast('Sin conexión con el repositorio de actualizaciones', 'error');
    if (!r.available) {
        if (interactive)
            infoDialog('ScanPro', `Ya tienes la versión más reciente (${r.current}).`, 'checkCircle');
        return;
    }
    showUpdateDialog(r);
}

/** Cuadro de nueva versión con las notas del release y el botón de actualizar. */
function showUpdateDialog(r) {
    const notes = String(r.notes || '')
        .split('\n')
        .map(l => l.replace(/^#+\s*/, '').replace(/^[-*]\s+/, '').trim())
        .filter(l => l && !/^ScanPro\s+\d/.test(l))
        .slice(0, 8);
    infoDialog(`Nueva versión: ScanPro ${r.version}`, h('div', { style: 'text-align:left' },
        h('p', { class: 'small muted', style: 'margin-top:0' }, `Versión instalada: ${r.current}`),
        ...notes.map(l => h('p', { class: 'small', style: 'margin:0 0 8px' }, '• ', l)),
        h('button', {
            class: 'btn primary block', style: 'margin-top:14px', onclick: () => {
                void startUpdate(r.url, r.version);
            }
        }, 'Actualizar ahora')
    ), 'download');
}

function startUpdate(url, version) {
    if (!url) {
        toast('No se encontró el archivo de la nueva versión', 'error');
        return;
    }
    try {
        bridge.startUpdateDownload(url);
        toast(`Descargando ScanPro ${version}… al terminar se abrirá la instalación`, 'ok', 5000);
    }
    catch {
        toast('No se pudo iniciar la descarga', 'error');
    }
}

/** Comprobación automática al iniciar: como mucho una vez cada 24 h. */
export function maybeCheckUpdate() {
    if (!isNative || !bridge?.checkUpdate)
        return;
    const last = Number(localStorage.getItem(CHECK_KEY) || 0);
    if (Date.now() - last < 24 * 3600e3)
        return;
    try {
        localStorage.setItem(CHECK_KEY, String(Date.now()));
    }
    catch { /* modo privado */ }
    void checkUpdateFlow(false);
}

/** Comprobación manual desde Ajustes. */
export function checkUpdateNow() {
    return checkUpdateFlow(true);
}
