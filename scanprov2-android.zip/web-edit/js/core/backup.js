// Copia de seguridad completa en un ZIP (documentos, carpetas e imágenes) y restauración.
import { listDocs, listFolders, allPages, importRecords } from './db.js';
import { loadVendor } from './exporter.js';
const Z = () => window.JSZip;
const FORMAT = 'scanpro-backup';
export async function makeBackup(onProgress) {
    await loadVendor('vendor/jszip.min.js');
    const [docs, folders, pages] = await Promise.all([listDocs(true), listFolders(), allPages()]);
    const z = new (Z())();
    const meta = pages.map(({ image, original, thumb, ...rest }) => { void image; void original; void thumb; return rest; });
    z.file('manifest.json', JSON.stringify({ format: FORMAT, version: 1, created: Date.now(), docs, folders, pages: meta }, null, 1));
    pages.forEach((p, i) => {
        z.file(`img/${p.id}.jpg`, p.image);
        z.file(`orig/${p.id}`, p.original);
        z.file(`thumb/${p.id}.jpg`, p.thumb);
        onProgress(i / Math.max(1, pages.length) * 0.5);
    });
    const blob = await z.generateAsync({ type: 'blob', compression: 'STORE' });
    onProgress(1);
    const d = new Date();
    return new File([blob], `ScanPro-copia-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.zip`, { type: 'application/zip' });
}
export async function restoreBackup(file, onProgress) {
    await loadVendor('vendor/jszip.min.js');
    let z;
    try {
        z = await Z().loadAsync(file);
    }
    catch {
        throw new Error('El archivo no es una copia de seguridad válida (ZIP dañado).');
    }
    const mf = z.file('manifest.json');
    if (!mf)
        throw new Error('El ZIP no contiene una copia de ScanPro.');
    let m;
    try {
        m = JSON.parse(await mf.async('string'));
    }
    catch {
        throw new Error('El índice de la copia está dañado.');
    }
    if (m.format !== FORMAT)
        throw new Error('Formato de copia no reconocido.');
    const pages = [];
    for (let i = 0; i < m.pages.length; i++) {
        const p = m.pages[i];
        const img = z.file(`img/${p.id}.jpg`), orig = z.file(`orig/${p.id}`), th = z.file(`thumb/${p.id}.jpg`);
        if (!img || !orig || !th)
            throw new Error('A la copia le faltan imágenes; no se ha restaurado nada.');
        const [image, original, thumb] = await Promise.all([img.async('blob'), orig.async('blob'), th.async('blob')]);
        pages.push({ ...p, image: new Blob([image], { type: 'image/jpeg' }), original: new Blob([original], { type: 'image/jpeg' }), thumb: new Blob([thumb], { type: 'image/jpeg' }) });
        onProgress(i / Math.max(1, m.pages.length));
    }
    const byId = new Set(pages.map(p => p.id));
    for (const d of m.docs)
        if (!d.pageIds.every(id => byId.has(id)))
            throw new Error(`El documento «${d.name}» está incompleto en la copia; no se ha restaurado nada.`);
    return importRecords(m.docs, pages, m.folders);
}
