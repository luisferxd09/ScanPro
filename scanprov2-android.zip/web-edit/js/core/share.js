// Compartir con el sistema (Web Share API nivel 2) y descarga como alternativa.
import { isNative, nativeSave, nativeShare, nativeShareText } from './native.js';
export function canShareFiles(files) {
    if (isNative)
        return true;
    try {
        return typeof navigator.share === 'function' && typeof navigator.canShare === 'function' && navigator.canShare({ files });
    }
    catch {
        return false;
    }
}
export function canShareText() { return isNative || typeof navigator.share === 'function'; }
/** Abre el menú de compartir de Android (WhatsApp, Gmail, Drive…). Debe llamarse desde un toque. */
export async function shareFiles(files, title) {
    if (isNative) {
        try {
            return { outcome: (await nativeShare(files, title)) ? 'shared' : 'error' };
        }
        catch (e) {
            return { outcome: 'error', message: e.message };
        }
    }
    if (!canShareFiles(files))
        return { outcome: 'unsupported' };
    try {
        await navigator.share({ files, title });
        return { outcome: 'shared' };
    }
    catch (e) {
        const name = e.name;
        if (name === 'AbortError')
            return { outcome: 'cancelled' };
        if (name === 'NotAllowedError')
            return { outcome: 'error', message: 'El navegador bloqueó el menú de compartir. Toca «Compartir» de nuevo.' };
        if (name === 'DataError' || name === 'TypeError')
            return { outcome: 'unsupported' };
        return { outcome: 'error', message: e.message };
    }
}
export async function shareText(text, title) {
    if (isNative)
        return nativeShareText(text, title) ? 'shared' : 'error';
    if (!canShareText())
        return 'unsupported';
    try {
        await navigator.share({ text, title });
        return 'shared';
    }
    catch (e) {
        return e.name === 'AbortError' ? 'cancelled' : 'error';
    }
}
/** Descarga los archivos (en Android quedan en la carpeta Descargas). En el APK devuelve la carpeta. */
export async function downloadFiles(files) {
    if (isNative)
        return nativeSave(files);
    for (const f of files) {
        const url = URL.createObjectURL(f);
        const a = document.createElement('a');
        a.href = url;
        a.download = f.name;
        a.rel = 'noopener';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 60_000);
        if (files.length > 1)
            await new Promise(r => setTimeout(r, 350)); // los navegadores limitan descargas simultáneas
    }
    return undefined;
}
export async function copyText(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    }
    catch {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        let ok = false;
        try {
            ok = document.execCommand('copy');
        }
        catch {
            ok = false;
        }
        ta.remove();
        return ok;
    }
}
