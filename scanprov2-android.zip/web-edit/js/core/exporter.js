import { QUALITY } from './settings.js';
import { buildPdf } from '../imaging/pdf.js';
import { decode, scaledCanvas, encodeAs } from '../imaging/process.js';
import { fileSafe } from './names.js';
const MIME = {
    pdf: 'application/pdf', jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', txt: 'text/plain',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', zip: 'application/zip',
};
const vendor = new Map();
export function loadVendor(path) {
    let p = vendor.get(path);
    if (!p) {
        p = new Promise((res, rej) => {
            const s = document.createElement('script');
            s.src = path;
            s.onload = () => res();
            s.onerror = () => { vendor.delete(path); rej(new Error('No se pudo cargar un componente de exportación. Recarga la aplicación.')); };
            document.head.appendChild(s);
        });
        vendor.set(path, p);
    }
    return p;
}
async function bytes(b) { return new Uint8Array(await b.arrayBuffer()); }
/** Imagen de la página a la calidad elegida. En «alta» se reutiliza el JPEG guardado sin recomprimir. */
async function pageImage(p, type, q) {
    const preset = QUALITY[q];
    if (type === 'image/jpeg' && q === 'alta')
        return p.image;
    const dec = await decode(p.image);
    const c = Math.max(dec.width, dec.height) > preset.maxSide ? scaledCanvas(dec.canvas, preset.maxSide) : dec.canvas;
    return encodeAs(c, type, type === 'image/png' ? undefined : type === 'image/webp' ? Math.min(0.92, preset.jpeg + 0.04) : preset.jpeg);
}
const SHRINK = [[2200, 0.8], [1900, 0.72], [1650, 0.66], [1400, 0.6], [1200, 0.54], [1000, 0.48], [850, 0.42]];
async function shrunk(p, side, q) {
    const dec = await decode(p.image);
    const c = Math.max(dec.width, dec.height) > side ? scaledCanvas(dec.canvas, side) : dec.canvas;
    return encodeAs(c, 'image/jpeg', q);
}
function pad(i, n) { return String(i + 1).padStart(String(n).length, '0'); }
export async function generate(doc, pages, fmt, o, onProgress) {
    if (!pages.length)
        throw new Error('El documento no tiene páginas.');
    if (pages.length !== doc.pageIds.length)
        throw new Error('Faltan páginas en el documento (posible daño en el almacenamiento). Exportación detenida para no perder páginas.');
    const base = fileSafe(o.fileName || doc.name);
    const n = pages.length;
    let files = [];
    if (fmt === 'pdf') {
        const opts = { size: o.pdfSize, orientation: o.pdfOrientation, margin: o.pdfMargin, title: doc.name, password: o.password || undefined };
        const withText = (jpegs) => jpegs.map((jpeg, i) => ({ jpeg, lines: pages[i].ocrLines, srcW: pages[i].width, srcH: pages[i].height }));
        const jpegs = [];
        for (let i = 0; i < n; i++) {
            onProgress(`Preparando página ${i + 1} de ${n}…`, i / n * 0.8);
            jpegs.push(await bytes(await pageImage(pages[i], 'image/jpeg', o.quality)));
        }
        onProgress('Creando PDF…', 0.85);
        let pdf = buildPdf(withText(jpegs), opts);
        // tamaño máximo: se reduce resolución y calidad por pasos hasta que quepa
        if (o.maxBytes && pdf.length > o.maxBytes) {
            for (const [side, q] of SHRINK) {
                onProgress(`Ajustando al tamaño máximo (${Math.round(pdf.length / 1024)} KB)…`, 0.9);
                const small = [];
                for (const p of pages)
                    small.push(await bytes(await shrunk(p, side, q)));
                pdf = buildPdf(withText(small), opts);
                if (pdf.length <= o.maxBytes)
                    break;
            }
            if (pdf.length > o.maxBytes)
                throw new Error(`No se pudo bajar de ${Math.round(o.maxBytes / 1024 / 1024 * 10) / 10} MB sin que el texto quede ilegible. Divide el documento o elige un límite mayor.`);
        }
        files = [new File([pdf], `${base}.pdf`, { type: MIME.pdf })];
    }
    else if (fmt === 'jpg' || fmt === 'png' || fmt === 'webp') {
        const type = MIME[fmt];
        for (let i = 0; i < n; i++) {
            onProgress(`Convirtiendo página ${i + 1} de ${n}…`, i / n * 0.9);
            const b = await pageImage(pages[i], type, o.quality);
            files.push(new File([b], n === 1 ? `${base}.${fmt}` : `${base}_${pad(i, n)}.${fmt}`, { type }));
        }
    }
    else if (fmt === 'txt') {
        const parts = pages.map((p, i) => (n > 1 ? `— Página ${i + 1} —\n` : '') + (p.ocrText ?? '').trim());
        if (!pages.some(p => p.ocrText?.trim()))
            throw new Error('Este documento todavía no tiene texto reconocido. Ejecuta el OCR primero.');
        files = [new File(['﻿' + parts.join('\n\n')], `${base}.txt`, { type: 'text/plain;charset=utf-8' })];
    }
    else if (fmt === 'docx') {
        await loadVendor('vendor/docx.iife.js');
        const D = window.docx; // eslint-disable-line @typescript-eslint/no-explicit-any
        const children = [];
        const maxW = 680, maxH = 960; // píxeles a 96 ppp dentro de A4 con márgenes de 1,5 cm
        for (let i = 0; i < n; i++) {
            onProgress(`Añadiendo página ${i + 1} de ${n}…`, i / n * 0.85);
            const p = pages[i];
            const img = await bytes(await pageImage(p, 'image/jpeg', o.quality));
            const s = Math.min(maxW / p.width, maxH / p.height);
            children.push(new D.Paragraph({
                pageBreakBefore: i > 0, alignment: D.AlignmentType.CENTER,
                children: [new D.ImageRun({ type: 'jpg', data: img, transformation: { width: Math.round(p.width * s), height: Math.round(p.height * s) }, altText: { title: `Página ${i + 1}`, description: `Página ${i + 1} de ${doc.name}`, name: `pagina${i + 1}` } })],
            }));
            if (o.docxText && p.ocrText?.trim()) {
                children.push(new D.Paragraph({ pageBreakBefore: true, children: [new D.TextRun({ text: `Texto de la página ${i + 1}`, bold: true, size: 26 })] }));
                for (const line of p.ocrText.split('\n'))
                    children.push(new D.Paragraph({ children: [new D.TextRun({ text: line, size: 22 })] }));
            }
        }
        onProgress('Creando documento Word…', 0.92);
        const m = 850; // ~1,5 cm en twips
        const wdoc = new D.Document({ creator: 'ScanPro', title: doc.name, sections: [{ properties: { page: { margin: { top: m, bottom: m, left: m, right: m } } }, children }] });
        const blob = await D.Packer.toBlob(wdoc);
        files = [new File([blob], `${base}.docx`, { type: MIME.docx })];
    }
    for (const f of files)
        if (!f.size)
            throw new Error(`El archivo ${f.name} se generó vacío. Vuelve a intentarlo.`);
    let kind = fmt;
    if (files.length > 1 && o.multi === 'zip') {
        onProgress('Comprimiendo en ZIP…', 0.96);
        files = [await zipFiles(files, `${base}.zip`)];
        kind = 'zip';
    }
    await validate(files, kind);
    onProgress('Listo', 1);
    return { files, size: files.reduce((a, f) => a + f.size, 0), kind };
}
export async function zipFiles(files, name) {
    await loadVendor('vendor/jszip.min.js');
    const JSZip = window.JSZip;
    const z = new JSZip();
    for (const f of files)
        z.file(f.name, f);
    // las imágenes ya están comprimidas: STORE evita gastar batería sin reducir tamaño
    const blob = await z.generateAsync({ type: 'blob', compression: 'STORE', mimeType: MIME.zip });
    return new File([blob], name, { type: MIME.zip });
}
/** Comprueba la firma binaria de cada archivo generado. */
export async function validate(files, kind) {
    for (const f of files) {
        const h = new Uint8Array(await f.slice(0, 8).arrayBuffer());
        const ok = kind === 'pdf' ? h[0] === 0x25 && h[1] === 0x50 && h[2] === 0x44 && h[3] === 0x46 :
            kind === 'jpg' ? h[0] === 0xff && h[1] === 0xd8 :
                kind === 'png' ? h[0] === 0x89 && h[1] === 0x50 && h[2] === 0x4e && h[3] === 0x47 :
                    kind === 'webp' ? h[0] === 0x52 && h[1] === 0x49 && h[2] === 0x46 && h[3] === 0x46 :
                        kind === 'docx' || kind === 'zip' ? h[0] === 0x50 && h[1] === 0x4b :
                            true;
        if (!ok)
            throw new Error(`El archivo ${f.name} no se generó correctamente.`);
    }
}
/** Tamaño aproximado antes de generar (a partir de las páginas guardadas). */
export function estimateSize(pages, fmt, q) {
    const base = pages.reduce((a, p) => a + p.image.size, 0);
    const k = q === 'alta' ? 1 : q === 'equilibrada' ? 0.5 : 0.28;
    if (fmt === 'png')
        return base * 4.5 * (q === 'alta' ? 1 : q === 'equilibrada' ? 0.5 : 0.25);
    if (fmt === 'webp')
        return base * k * 0.75;
    if (fmt === 'docx')
        return base * k * 1.01;
    if (fmt === 'txt')
        return pages.reduce((a, p) => a + (p.ocrText?.length ?? 0), 0);
    return base * k;
}
