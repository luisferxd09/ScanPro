import { isNative } from './native.js';
export function cameraSupported() {
    return !!navigator.mediaDevices?.getUserMedia;
}
export async function cameraState() {
    if (!window.isSecureContext)
        return 'insecure';
    if (!cameraSupported())
        return 'unsupported';
    try {
        const st = await navigator.permissions?.query({ name: 'camera' });
        if (st)
            return st.state;
    }
    catch { /* Firefox/Safari antiguos no permiten consultar 'camera' */ }
    return 'unknown';
}
/** Solicita la cámara (muestra el diálogo del sistema) y la libera inmediatamente. */
export async function requestCamera() {
    if (!window.isSecureContext)
        return { ok: false, state: 'insecure', message: 'La cámara solo funciona con HTTPS o en localhost.' };
    if (!cameraSupported())
        return { ok: false, state: 'unsupported', message: 'Este navegador no permite usar la cámara desde la web.' };
    try {
        const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
        s.getTracks().forEach(t => t.stop());
        return { ok: true, state: 'granted' };
    }
    catch (e) {
        return { ok: false, ...describeCamError(e) };
    }
}
export function describeCamError(e) {
    const name = e?.name;
    if (name === 'NotAllowedError' || name === 'SecurityError')
        return { state: 'denied', message: 'Permiso de cámara denegado.' };
    if (name === 'NotFoundError' || name === 'OverconstrainedError')
        return { state: 'unsupported', message: 'No se encontró ninguna cámara en este dispositivo.' };
    if (name === 'NotSupportedError')
        return { state: 'unsupported', message: 'Este navegador no permite usar la cámara en vivo aquí.' };
    if (name === 'NotReadableError' || name === 'AbortError')
        return { state: 'unknown', message: 'La cámara está ocupada por otra aplicación. Ciérrala y vuelve a intentarlo.' };
    return { state: 'unknown', message: 'No se pudo iniciar la cámara.' };
}
export const CAMERA_HELP = isNative ? 'Para activarla: Ajustes de Android › Aplicaciones › ScanPro › Permisos › Cámara › Permitir.' : 'Para activarla: toca el icono junto a la dirección (candado o ajustes) › Permisos › Cámara › Permitir. Si instalaste la app: Ajustes de Android › Aplicaciones › ScanPro (o Chrome) › Permisos › Cámara.';
export async function persistState() {
    if (isNative)
        return 'granted'; // los datos de una app instalada no se borran solos
    if (!navigator.storage?.persisted)
        return 'unsupported';
    try {
        return (await navigator.storage.persisted()) ? 'granted' : 'not-granted';
    }
    catch {
        return 'unsupported';
    }
}
export async function requestPersist() {
    if (isNative)
        return 'granted';
    if (!navigator.storage?.persist)
        return 'unsupported';
    try {
        return (await navigator.storage.persist()) ? 'granted' : 'not-granted';
    }
    catch {
        return 'not-granted';
    }
}
export async function storageEstimate() {
    try {
        const e = await navigator.storage?.estimate?.();
        if (e && typeof e.usage === 'number' && typeof e.quota === 'number')
            return { usage: e.usage, quota: e.quota };
    }
    catch { /* sin soporte */ }
    return null;
}
