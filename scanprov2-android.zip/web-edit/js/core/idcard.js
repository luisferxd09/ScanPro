export const DPI = 300;
const mm = (v) => Math.round(v / 25.4 * DPI);
export const PAPER_PX = { carta: [2550, 3300], a4: [2480, 3508] };
export const CARD_PX = [mm(85.6), mm(53.98)]; // 1011 × 638
const SCALE = { real: 1, grande: 1.5 };
/** Dónde va cada cara en la hoja (en píxeles). Exportado para las pruebas. */
export function idLayout(o) {
    const [pw, ph] = PAPER_PX[o.paper], s = SCALE[o.scale];
    const cw = Math.round(CARD_PX[0] * s), ch = Math.round(CARD_PX[1] * s), gap = mm(o.scale === 'real' ? 15 : 12);
    const x = Math.round((pw - cw) / 2), top = Math.round((ph - (ch * 2 + gap)) / 2 - mm(o.scale === 'real' ? 25 : 12));
    return { page: [pw, ph], card: [cw, ch], front: [x, top], back: [x, top + ch + gap] };
}
function canvas(w, h) {
    const c = typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(w, h) : Object.assign(document.createElement('canvas'), { width: w, height: h });
    return { c, g: c.getContext('2d') };
}
async function toJpeg(c, q) {
    if ('convertToBlob' in c)
        return c.convertToBlob({ type: 'image/jpeg', quality: q });
    return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('No se pudo crear la imagen.')), 'image/jpeg', q));
}
function drawCard(g, img, x, y, w, h) {
    const r = Math.round(w * 3.18 / 85.6); // esquinas redondeadas como la tarjeta real
    g.save();
    g.beginPath();
    g.roundRect(x, y, w, h, r);
    g.clip();
    // la foto se pone en horizontal (las tarjetas son apaisadas)
    if (img.height > img.width) {
        g.translate(x + w, y);
        g.rotate(Math.PI / 2);
        g.drawImage(img, 0, 0, h, w);
    }
    else
        g.drawImage(img, x, y, w, h);
    g.restore();
    g.strokeStyle = 'rgba(0,0,0,.18)';
    g.lineWidth = 3;
    g.beginPath();
    g.roundRect(x, y, w, h, r);
    g.stroke();
}
/** Compone la hoja con las dos caras. Devuelve la imagen final y su miniatura. */
export async function composeIdPage(front, back, o) {
    const L = idLayout(o), [pw, ph] = L.page, [cw, ch] = L.card;
    const { c, g } = canvas(pw, ph);
    g.fillStyle = '#ffffff';
    g.fillRect(0, 0, pw, ph);
    g.imageSmoothingQuality = 'high';
    const fb = await createImageBitmap(front);
    try {
        drawCard(g, fb, L.front[0], L.front[1], cw, ch);
    }
    finally {
        fb.close();
    }
    if (back) {
        const bb = await createImageBitmap(back);
        try {
            drawCard(g, bb, L.back[0], L.back[1], cw, ch);
        }
        finally {
            bb.close();
        }
    }
    const image = await toJpeg(c, 0.92);
    const tw = 420, th = Math.round(ph * tw / pw), t = canvas(tw, th);
    t.g.imageSmoothingQuality = 'high';
    t.g.drawImage(c, 0, 0, tw, th);
    const thumb = await toJpeg(t.c, 0.8);
    return { image, thumb, width: pw, height: ph };
}
/** Si una página es una copia de documento de identidad, devuelve su hoja (para el PDF a tamaño real). */
export function idPaperOf(width, height) {
    if (width === PAPER_PX.carta[0] && height === PAPER_PX.carta[1])
        return 'letter';
    if (width === PAPER_PX.a4[0] && height === PAPER_PX.a4[1])
        return 'a4';
    return null;
}
