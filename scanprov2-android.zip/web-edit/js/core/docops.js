// Operaciones que crean páginas o documentos nuevos a partir de lienzos.
import { uid } from '../ui/dom.js';
import { createDoc, getPages, NO_ADJUST } from './db.js';
import { decode, encodeAs, thumbBlob, makeCanvas } from '../imaging/process.js';
export async function pageCanvas(p, maxSide = 3508) { return (await decode(p.image, maxSide)).canvas; }
export async function canvasToPage(c, ocrText) {
    const image = await encodeAs(c, 'image/jpeg', 0.9);
    return { id: uid(), image, original: image, thumb: await thumbBlob(c), width: c.width, height: c.height, corners: null, filter: 'original', adjust: { ...NO_ADJUST }, rotation: 0, ocrText, createdAt: Date.now() };
}
export async function copyPage(p) { const { docId: _d, ...rest } = p; void _d; return { ...rest, id: uid(), createdAt: Date.now() }; }
export async function newDoc(name, pages, folderId = null) { return createDoc(name, pages, folderId); }
/** Dibuja algo encima de cada página (marca de agua, números, sello) y crea un documento nuevo. */
export async function overlayDoc(doc, suffix, draw) {
    const pages = await getPages(doc), out = [];
    for (let i = 0; i < pages.length; i++) {
        const c = await pageCanvas(pages[i]), g = c.getContext('2d');
        draw(g, c.width, c.height, i, pages.length);
        out.push({ ...(await canvasToPage(c, pages[i].ocrText)), ocrLines: pages[i].ocrLines });
    }
    return newDoc(`${doc.name} ${suffix}`, out, doc.folderId);
}
/** Página de texto (portada, índice, nota…) en A4 a 150 ppp. */
export function textPage(lines, bg = '#ffffff') {
    const W = 1240, H = 1754, M = 120, c = makeCanvas(W, H), g = c.getContext('2d');
    g.fillStyle = bg;
    g.fillRect(0, 0, W, H);
    let y = M;
    for (const l of lines) {
        g.font = `${l.bold ? 700 : 400} ${l.size}px Helvetica, Arial, sans-serif`;
        g.fillStyle = l.color ?? '#1b1a2a';
        g.textAlign = l.align ?? 'left';
        const x = l.align === 'center' ? W / 2 : l.align === 'right' ? W - M : M;
        let line = '';
        for (const w of l.t.split(' ')) {
            const t = line ? line + ' ' + w : w;
            if (g.measureText(t).width > W - 2 * M && line) {
                g.fillText(line, x, y + l.size);
                y += l.size * 1.35;
                line = w;
            }
            else
                line = t;
        }
        g.fillText(line, x, y + l.size);
        y += l.size * 1.35 + (l.gap ?? 0);
    }
    return c;
}
/** Corta una página en dos mitades (libro abierto). Busca el lomo cerca del centro. */
export async function splitBookPage(p) {
    const c = await pageCanvas(p), g = c.getContext('2d'), w = c.width, h = c.height;
    const vertical = w >= h; // dos páginas lado a lado
    const n = vertical ? w : h, from = Math.round(n * 0.4), to = Math.round(n * 0.6);
    const small = makeCanvas(vertical ? 400 : 100, vertical ? 100 : 400);
    small.getContext('2d').drawImage(c, 0, 0, small.width, small.height);
    const d = small.getContext('2d').getImageData(0, 0, small.width, small.height).data;
    let best = Math.round(n / 2), bestV = Infinity;
    const len = vertical ? small.width : small.height, other = vertical ? small.height : small.width;
    for (let k = Math.round(len * 0.4); k <= Math.round(len * 0.6); k++) {
        let s = 0;
        for (let j = 0; j < other; j++) {
            const i = (vertical ? j * small.width + k : k * small.width + j) * 4;
            s += d[i] + d[i + 1] + d[i + 2];
        }
        if (s < bestV) {
            bestV = s;
            best = Math.round(k / len * n);
        }
    }
    void from;
    void to;
    const a = makeCanvas(vertical ? best : w, vertical ? h : best), b = makeCanvas(vertical ? w - best : w, vertical ? h : h - best);
    a.getContext('2d').drawImage(c, 0, 0);
    b.getContext('2d').drawImage(c, vertical ? -best : 0, vertical ? 0 : -best);
    void g;
    return [a, b];
}
export async function sha256(b) {
    const d = await crypto.subtle.digest('SHA-256', await b.arrayBuffer());
    return [...new Uint8Array(d)].map(x => x.toString(16).padStart(2, '0')).join('');
}
