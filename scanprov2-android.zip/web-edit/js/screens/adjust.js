// Filtros, ajustes manuales, rotación y comparación con el original.
// Las vistas previas se calculan en segundo plano y solo se pide la más reciente,
// así los deslizadores responden con fluidez incluso en móviles lentos.
import { h, ic } from '../ui/dom.js';
import { btn, toast, busy, slider, textBtn, confirmDialog } from '../ui/components.js';
import { go, setGuard, onLeave } from '../core/router.js';
import { getSession, viewOf, scheduleRender, saveEditedPage, withSource } from '../core/session.js';
import { engine } from '../imaging/engine.js';
import { FILTERS } from '../imaging/filters.js';
import { NO_ADJUST } from '../core/db.js';
export async function adjustScreen(params) {
    const s = getSession();
    const dp = s?.pages.find(p => p.id === params.page);
    if (!s || !dp) {
        setTimeout(() => go('home', {}, { replace: true }));
        return h('div');
    }
    const stored = params.mode === 'stored';
    const snapshot = { filter: dp.filter, adjust: { ...dp.adjust }, rotation: dp.rotation };
    let alive = true;
    const preview = h('canvas', { class: 'preview-canvas', 'aria-label': 'Vista previa del resultado' });
    preview.style.opacity = '0';
    const photo = h('canvas', { class: 'preview-photo', 'aria-label': 'Foto original' });
    const compareTag = h('div', { class: 'compare-tag' }, 'Original');
    compareTag.style.display = 'none';
    const wrap = h('div', { class: 'preview-wrap' }, photo, preview);
    const stage = h('div', { class: 'stage' }, wrap, compareTag);
    let comparing = false;
    const fit = (c, w, hh) => {
        const r = stage.getBoundingClientRect();
        const k = Math.min((r.width - 32) / w, (r.height - 32) / hh);
        c.style.width = `${Math.max(10, w * k)}px`;
        c.style.height = `${Math.max(10, hh * k)}px`;
    };
    // Foto original (se muestra al instante mientras se prepara el resultado, y al comparar)
    let viewBmp = null;
    const paintPhoto = () => {
        if (!viewBmp)
            return;
        const r = ((dp.rotation % 360) + 360) % 360, sw = r % 180 ? viewBmp.height : viewBmp.width, sh = r % 180 ? viewBmp.width : viewBmp.height;
        const k = Math.min(1, 1000 / Math.max(sw, sh));
        photo.width = Math.round(sw * k);
        photo.height = Math.round(sh * k);
        const x = photo.getContext('2d');
        x.translate(photo.width / 2, photo.height / 2);
        x.rotate(r * Math.PI / 180);
        x.drawImage(viewBmp, -viewBmp.width * k / 2, -viewBmp.height * k / 2, viewBmp.width * k, viewBmp.height * k);
        fit(photo, photo.width, photo.height);
    };
    // ---------- vista previa coalescente ----------
    let inflight = false, pending = false, firstShown = false;
    const requestPreview = async () => {
        if (inflight) {
            pending = true;
            return;
        }
        inflight = true;
        try {
            do {
                pending = false;
                const bmp = await engine.preview(dp.id, dp.rotation, dp.filter, dp.adjust);
                if (!alive) {
                    bmp.close();
                    return;
                }
                preview.width = bmp.width;
                preview.height = bmp.height;
                preview.getContext('2d').drawImage(bmp, 0, 0);
                bmp.close();
                preview.style.transition = 'none';
                preview.style.transform = '';
                fit(preview, preview.width, preview.height);
                if (!firstShown) {
                    firstShown = true;
                    requestAnimationFrame(() => { preview.style.transition = ''; preview.style.opacity = comparing ? '0' : '1'; photo.classList.add('gone'); });
                }
            } while (pending && alive);
        }
        catch (e) {
            if (alive)
                toast(e.message, 'error');
        }
        finally {
            inflight = false;
        }
    };
    // ---------- tira de filtros ----------
    const strip = h('div', { class: 'filter-strip', role: 'radiogroup', 'aria-label': 'Filtros' });
    const thumbCanvases = FILTERS.map(() => h('canvas', { width: '60', height: '78' }));
    const items = FILTERS.map((f, i) => h('button', { class: 'filter-item', role: 'radio', onclick: () => { if (dp.filter !== f.id) {
            dp.filter = f.id;
            paintStrip();
            void requestPreview();
        } } }, thumbCanvases[i], f.label));
    strip.append(...items);
    const paintStrip = () => items.forEach((b, i) => { b.classList.toggle('active', dp.filter === FILTERS[i].id); b.setAttribute('aria-checked', String(dp.filter === FILTERS[i].id)); });
    paintStrip();
    const loadThumbs = async () => {
        try {
            const bmps = await engine.thumbs(dp.id, dp.rotation, FILTERS.map(f => f.id));
            bmps.forEach((b, i) => { const c = thumbCanvases[i]; c.width = b.width; c.height = b.height; c.getContext('2d').drawImage(b, 0, 0); b.close(); });
        }
        catch { /* las miniaturas son opcionales */ }
    };
    // ---------- ajustes ----------
    const sliders = [
        slider('Brillo', dp.adjust.brightness, -100, 100, v => { dp.adjust.brightness = v; void requestPreview(); }),
        slider('Contraste', dp.adjust.contrast, -100, 100, v => { dp.adjust.contrast = v; void requestPreview(); }),
        slider('Saturación', dp.adjust.saturation, -100, 100, v => { dp.adjust.saturation = v; void requestPreview(); }),
        slider('Nitidez', dp.adjust.sharpness, 0, 100, v => { dp.adjust.sharpness = v; void requestPreview(); }),
    ];
    const adjustPanel = h('div', { class: 'stack', style: 'gap:2px;display:none' }, ...sliders.map(x => x.el), h('button', { class: 'xs accent', style: 'align-self:flex-end;font-weight:600;padding:6px', onclick: () => { dp.adjust = { ...NO_ADJUST }; sliders.forEach(x => x.set(0)); void requestPreview(); } }, 'Restablecer ajustes'));
    const tool = (icon, label, run) => h('button', { class: 'tool-btn', onclick: run }, ic(icon), label);
    const fBtn = tool('filters', 'Filtros', () => showPanel('filters'));
    const aBtn = tool('sliders', 'Ajustes', () => showPanel('adjust'));
    const showPanel = (which) => {
        const [show, hide] = which === 'filters' ? [strip, adjustPanel] : [adjustPanel, strip];
        if (show.style.display !== 'none')
            return;
        hide.style.display = 'none';
        show.style.display = '';
        show.classList.remove('panel-swap');
        void show.offsetWidth;
        show.classList.add('panel-swap');
        fBtn.classList.toggle('active', which === 'filters');
        aBtn.classList.toggle('active', which === 'adjust');
    };
    fBtn.classList.add('active');
    // Giro animado: la imagen gira con CSS y luego se sustituye por el resultado real
    const rotate = (d) => {
        dp.rotation = (dp.rotation + d + 360) % 360;
        preview.style.transition = 'transform .32s var(--ease-ios)';
        preview.style.transform = `rotate(${d}deg)`;
        paintPhoto();
        void requestPreview();
        void loadThumbs();
    };
    const cmpBtn = tool('eye', 'Comparar', () => { });
    const startCmp = (e) => { e.preventDefault(); comparing = true; compareTag.style.display = ''; cmpBtn.classList.add('active'); preview.style.opacity = '0'; photo.classList.remove('gone'); };
    const endCmp = () => { if (!comparing)
        return; comparing = false; compareTag.style.display = 'none'; cmpBtn.classList.remove('active'); preview.style.opacity = '1'; photo.classList.add('gone'); };
    cmpBtn.addEventListener('pointerdown', startCmp);
    cmpBtn.addEventListener('pointerup', endCmp);
    cmpBtn.addEventListener('pointerleave', endCmp);
    cmpBtn.addEventListener('pointercancel', endCmp);
    cmpBtn.addEventListener('contextmenu', e => e.preventDefault());
    cmpBtn.title = 'Mantén pulsado para ver el original';
    const changed = () => dp.filter !== snapshot.filter || dp.rotation !== snapshot.rotation || JSON.stringify(dp.adjust) !== JSON.stringify(snapshot.adjust);
    const applyAll = s.pages.length > 1 && !stored ? btn('Aplicar a todas las páginas', () => {
        for (const p of s.pages)
            if (p !== dp) {
                p.filter = dp.filter;
                p.adjust = { ...dp.adjust };
                void scheduleRender(p).catch(() => { });
            }
        toast(`Filtro aplicado a ${s.pages.length} páginas`);
    }, 'ghost', { sm: true, icon: 'layers' }) : null;
    const done = async () => {
        if (stored) {
            const b = busy('Guardando página…');
            try {
                await saveEditedPage(dp);
                setGuard(null);
                b.done();
                toast('Página actualizada');
                history.back();
            }
            catch (e) {
                b.done();
                toast(e.message, 'error', 4500);
            }
            return;
        }
        // el resultado final se calcula en segundo plano: volver es instantáneo
        void scheduleRender(dp).catch(e => toast(e.message, 'error'));
        if (params.from === 'review' || params.from === 'scan')
            history.back();
        else
            go('review', {}, { replace: true });
    };
    const cancel = () => {
        if (!stored) {
            dp.filter = snapshot.filter;
            dp.adjust = snapshot.adjust;
            dp.rotation = snapshot.rotation;
        }
        history.back();
    };
    if (stored)
        setGuard(() => (changed() ? confirmDialog({ title: '¿Salir sin guardar?', icon: 'alert', danger: true, confirm: 'Salir', cancel: 'Seguir editando', text: 'Los cambios en esta página se perderán.' }) : Promise.resolve(true)));
    const ro = new ResizeObserver(() => { fit(preview, preview.width || 1, preview.height || 1); if (viewBmp)
        fit(photo, photo.width, photo.height); });
    onLeave(() => { alive = false; ro.disconnect(); });
    // Carga: foto al instante → base recortada en segundo plano → resultado con fundido
    setTimeout(async () => {
        ro.observe(stage);
        try {
            await dp.ready;
            viewBmp = await viewOf(dp);
            if (!alive)
                return;
            paintPhoto();
            await withSource(dp, fb => engine.setBase(dp.id, fb, dp.corners));
            if (!alive)
                return;
            await requestPreview();
            void loadThumbs();
        }
        catch (e) {
            if (alive)
                toast(e.message, 'error');
        }
    });
    const idx = s.pages.indexOf(dp);
    return h('div', { class: 'editor' }, h('header', { class: 'topbar solid' }, textBtn('Cancelar', cancel), h('h1', { style: 'text-align:center' }, stored ? 'Editar página' : `Página ${idx + 1}${s.pages.length > 1 ? ` de ${s.pages.length}` : ''}`), textBtn(stored ? 'Guardar' : 'Listo', () => void done(), true)), stage, h('div', { class: 'editor-bar' }, strip, adjustPanel, h('div', { class: 'tool-row' }, fBtn, aBtn, tool('crop', 'Recortar', () => go('crop', { page: dp.id, from: 'adjust', mode: params.mode ?? '' })), tool('rotateCcw', 'Izquierda', () => rotate(-90)), tool('rotateCw', 'Derecha', () => rotate(90)), cmpBtn), applyAll, btn(stored ? 'Guardar cambios' : 'Listo', () => void done(), 'primary', { block: true, icon: 'check' })));
}
