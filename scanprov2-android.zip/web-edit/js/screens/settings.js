import { h, fmtSize, pickFiles } from '../ui/dom.js';
import { largeHeader, listItem, segmented, toggle, confirmDialog, toast, busy, infoDialog, revokeAll, tile } from '../ui/components.js';
import { go } from '../core/router.js';
import { getSettings, setSettings, QUALITY, APP_VERSION, isLowEnd } from '../core/settings.js';
import { FILTERS } from '../imaging/filters.js';
import { ocrOptions } from '../core/ocr.js';
import { langInfo, curCountry } from '../core/locale.js';
import { pickLanguage, showHelloAgain } from './hello.js';
import { resetTours } from '../ui/tour.js';
import { clearAll, listDocs } from '../core/db.js';
import { storageEstimate, persistState, requestPersist, cameraState, requestCamera, CAMERA_HELP } from '../core/permissions.js';
import { makeBackup, restoreBackup } from '../core/backup.js';
import { canShareFiles, shareFiles, downloadFiles } from '../core/share.js';
import { canInstall, isInstalled, promptInstall } from '../core/install.js';
import { isNative, nativeTestAds, nativeShareTo, nativeAdStatus, hasNativeScanner } from '../core/native.js';
import { checkUpdateNow } from '../core/update.js';
import { play } from '../core/sounds.js';
import { isPro } from '../core/pro.js';
import { openVipPanel } from './vip.js';
import { CONTACT_EMAIL } from '../core/settings.js';
import { settingsX, setSettingsX } from '../core/meta.js';
import { myEmail } from '../tools/kit.js';
import { openPrivate } from '../tools/life.js';
import { profileItem } from '../tools/ai.js';
function sendFeedback() {
    const subject = `ScanPro ${APP_VERSION} · comentarios`, body = `\n\n—\nScanPro ${APP_VERSION} · ${navigator.userAgent}`;
    const b = globalThis.ScanProAndroid;
    if (b?.email)
        b.email(CONTACT_EMAIL, subject, body);
    else
        location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
let taps = 0, tapAt = 0;
/** 7 toques seguidos en el título «Ajustes» activan o quitan los anuncios de prueba (para quien desarrolla). */
function devTap() {
    const now = Date.now();
    taps = now - tapAt < 800 ? taps + 1 : 1;
    tapAt = now;
    if (taps < 7 || !isNative)
        return false;
    taps = 0;
    let on = false;
    try {
        on = localStorage.getItem('scanpro.testads') !== '1';
        localStorage.setItem('scanpro.testads', on ? '1' : '0');
    }
    catch { /* */ }
    nativeTestAds(on);
    toast(on ? 'Anuncios de prueba activados' : 'Anuncios reales activados', 'ok', 2500);
    setTimeout(() => infoDialog('Estado de los anuncios', nativeAdStatus() + '\n\nCódigo 3 = Google aún no tiene anuncios para esta app (normal mientras AdMob la revisa o antes de publicarla en Google Play).', 'info'), 9000);
    return true;
}
export async function settingsScreen(params) {
    const st = getSettings();
    const docs = await listDocs(true);
    const docsSize = docs.reduce((a, d) => a + d.size, 0);
    const group = (title, ...items) => h('div', null, h('div', { class: 'section-title' }, title), h('div', { class: 'list' }, ...items));
    const block = (icon, tint, title, control, sub) => h('div', { class: 'list-item', style: 'flex-wrap:wrap' }, tile(icon, tint), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, title), sub ? h('div', { class: 'li-sub' }, sub) : null), h('div', { style: 'flex-basis:100%;margin:8px 0 2px' }, control));
    const motionDesc = h('span', null);
    const paintMotion = () => {
        const m = getSettings().motion;
        motionDesc.textContent = m === 'auto' ? (isLowEnd() ? 'Automático: modo ligero (teléfono de gama baja detectado)' : 'Automático: animaciones completas') : m === 'full' ? 'Transiciones completas estilo iPhone' : m === 'lite' ? 'Más cortas y sin desenfoques: ideal para gama baja' : 'Sin animaciones';
    };
    paintMotion();
    const capDesc = h('span', null);
    const paintCap = () => {
        const q = getSettings().captureQuality;
        capDesc.textContent = q === 'rapida' ? 'Mejor fotograma del vídeo: instantánea, algo menos nítida' : 'Foto del sensor con enfoque: texto nítido (recomendada para documentos)';
    };
    paintCap();
    // Almacenamiento
    const usage = h('span', { class: 'li-sub' }, 'Calculando…');
    void storageEstimate().then(e => { usage.textContent = e ? `${fmtSize(e.usage)} usados de ${fmtSize(e.quota)} disponibles para la app · documentos: ${fmtSize(docsSize)}` : `Documentos: ${fmtSize(docsSize)} (el navegador no informa del espacio total)`; });
    const persistBadge = h('span', { class: 'badge' }, '…');
    const paintPersist = (s) => { persistBadge.textContent = s === 'granted' ? 'Activo' : s === 'unsupported' ? 'No disponible' : 'Desactivado'; persistBadge.className = 'badge ' + (s === 'granted' ? 'ok' : 'warn'); };
    void persistState().then(paintPersist);
    const camBadge = h('span', { class: 'badge' }, '…');
    const paintCam = (s) => { camBadge.textContent = { granted: 'Concedido', denied: 'Denegado', prompt: 'Sin solicitar', unknown: 'Sin comprobar', unsupported: 'No disponible', insecure: 'Requiere HTTPS' }[s] ?? s; camBadge.className = 'badge ' + (s === 'granted' ? 'ok' : s === 'denied' ? 'bad' : ''); };
    void cameraState().then(paintCam);
    const driveBackup = async () => {
        if (!docs.length) {
            toast('No hay documentos que copiar.', 'error');
            return;
        }
        const b = busy('Preparando la copia…', true);
        try {
            const f = await makeBackup(p => b.set('Preparando la copia…', p));
            b.done();
            await nativeShareTo([f], f.name, 'com.google.android.apps.docs');
            setSettings({ lastBackup: Date.now() });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 4500);
        }
    };
    const backup = async () => {
        if (!docs.length) {
            toast('No hay documentos que copiar.', 'error');
            return;
        }
        const b = busy('Creando copia de seguridad…', true);
        try {
            const f = await makeBackup(p => b.set('Creando copia de seguridad…', p));
            b.done();
            const where = await downloadFiles([f]);
            setSettings({ lastBackup: Date.now() });
            toast(where ? `Copia guardada en ${where} (${fmtSize(f.size)})` : `Copia descargada (${fmtSize(f.size)})`, 'ok', 4000);
            if (canShareFiles([f]))
                void shareFiles([f], f.name);
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 4500);
        }
    };
    const restore = async () => {
        const [f] = await pickFiles({ accept: '.zip,application/zip' });
        if (!f)
            return;
        const b = busy('Restaurando…', true);
        try {
            const n = await restoreBackup(f, p => b.set('Restaurando…', p));
            b.done();
            toast(`Copia restaurada: ${n} documento(s) nuevo(s)`);
            go('docs');
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 5000);
        }
    };
    const qd = h('div', { class: 'xs faint', style: 'margin-top:8px' }, QUALITY[st.quality].desc);
    const [bar, big] = largeHeader('Ajustes');
    big.addEventListener('click', () => void devTap());
    const root = h('div', { class: 'screen with-nav' }, bar, big, h('div', { class: 'content' }, group('Apariencia', block('moon', 'peri', 'Tema', segmented([['light', 'Claro'], ['dark', 'Oscuro'], ['system', 'Sistema']], st.theme, v => setSettings({ theme: v }))), block('motion', 'rose', 'Animaciones', segmented([['auto', 'Auto'], ['full', 'Completas'], ['lite', 'Ligeras'], ['off', 'No']], st.motion, v => { setSettings({ motion: v }); paintMotion(); }), motionDesc)), group('Sonido e idioma', listItem({ icon: 'zap', tint: 'peach', title: 'Sonidos', sub: 'Obturador, guardado y avisos (se silencian con el teléfono en silencio)', right: toggle(st.sounds, v => { setSettings({ sounds: v }); if (v)
            play('success'); }, 'Sonidos') }), listItem({ icon: 'hand', tint: 'lilac', title: 'Vibración al tocar', sub: 'Una vibración suave con cada toque', right: toggle(st.haptics !== false, v => setSettings({ haptics: v }), 'Vibración al tocar') }), listItem({ icon: 'language', tint: 'sky', title: 'Idioma y país', sub: `${langInfo().name} · ${curCountry().name}`, onclick: () => void pickLanguage(true) })), group('Accesibilidad', listItem({ icon: 'contrast', tint: 'peri', title: 'Alto contraste', sub: 'Colores más marcados en toda la app', right: toggle(!!settingsX().contrast, v => { setSettingsX({ contrast: v }); document.documentElement.classList.toggle('hi-contrast', v); }, 'Alto contraste') }), listItem({ icon: 'type', tint: 'sky', title: 'Letra grande', sub: 'Aumenta el tamaño del texto de la app', right: toggle(!!settingsX().bigText, v => { setSettingsX({ bigText: v }); document.documentElement.classList.toggle('big-text', v); }, 'Letra grande') }), listItem({ icon: 'book', tint: 'butter', title: 'Lectura fácil', sub: 'Más espacio entre letras y líneas al leer texto (dislexia)', right: toggle(!!settingsX().dyslexia, v => { setSettingsX({ dyslexia: v }); document.documentElement.classList.toggle('easy-read', v); }, 'Lectura fácil') })), group('Mis herramientas', listItem({ icon: 'wand', tint: 'peach', title: 'Organizar automáticamente', sub: 'Al guardar: lee el texto, pone nombre, carpeta y vencimiento', right: toggle(settingsX().autoOrganize !== false, v => setSettingsX({ autoOrganize: v }), 'Organizar automáticamente') }), profileItem(), listItem({ icon: 'share', tint: 'lilac', title: 'Correo de destino', sub: settingsX().email ?? 'Para «Enviar a mi correo» con un toque', onclick: () => void myEmail(true).then(() => go('settings', {}, { replace: true })) }), listItem({ icon: 'lock', tint: 'rose', title: 'Carpeta privada', sub: 'Documentos protegidos con huella o PIN', onclick: () => void openPrivate() }), listItem({ icon: 'bell', tint: 'peach', title: 'Avisos', sub: 'Medicamentos, pagos y vencimientos', onclick: () => go('avisos', {}) })), group('Escaneo', ...(hasNativeScanner ? [block('scan', 'lilac', 'Escáner de la cámara', segmented([['google', 'Google (recomendado)'], ['scanpro', 'ScanPro']], st.scanner === 'scanpro' ? 'scanpro' : 'google', v => setSettings({ scanner: v })), h('div', { class: 'xs faint', style: 'margin-top:6px' }, 'El de Google enfoca mejor y detecta los bordes con IA, sin internet. El de ScanPro tiene captura automática y modo cédula.'))] : []), listItem({ icon: 'zap', tint: 'butter', title: 'Captura automática', sub: 'Dispara sola cuando la hoja está quieta', right: toggle(st.autoCapture, v => setSettings({ autoCapture: v }), 'Captura automática') }), listItem({ icon: 'scan', tint: 'lilac', title: 'Encuadre automático', sub: 'Detecta y endereza la hoja; si se desactiva se usa la foto completa', right: toggle(st.autoDetect, v => setSettings({ autoDetect: v }), 'Encuadre automático') }), block('camera', 'sky', 'Captura', segmented([['nitida', 'Nítida'], ['rapida', 'Rápida']], st.captureQuality === 'rapida' ? 'rapida' : 'nitida', v => { setSettings({ captureQuality: v }); paintCap(); }), capDesc), listItem({ icon: 'rotateCw', tint: 'peri', title: 'Girar el texto automáticamente', sub: 'Endereza las páginas fotografiadas de lado', right: toggle(st.autoRotate, v => setSettings({ autoRotate: v }), 'Girar el texto automáticamente') }), listItem({ icon: 'camera', tint: 'coral', title: 'Volver a elegir el lente', sub: 'Prueba de nuevo las cámaras traseras del teléfono', onclick: () => { try {
            localStorage.removeItem('scanpro.camera.v1');
        }
        catch { /* */ } toast('Se elegirá el mejor lente la próxima vez que abras la cámara'); } }), block('filters', 'peach', 'Filtro predeterminado', h('div', { class: 'chips wrap' }, FILTERS.map(f => {
        const b = h('button', { class: 'chip' + (st.defaultFilter === f.id ? ' active' : ''), onclick: () => { setSettings({ defaultFilter: f.id }); b.parentElement.querySelectorAll('.chip').forEach(c => c.classList.remove('active')); b.classList.add('active'); } }, f.label);
        return b;
    })))), group('Exportación', block('download', 'sky', 'Calidad predeterminada', h('div', null, segmented([['alta', 'Alta'], ['equilibrada', 'Equilibrada'], ['compacta', 'Compacta']], st.quality, v => { setSettings({ quality: v }); qd.textContent = QUALITY[v].desc; }), qd))), group('Reconocimiento de texto', block('language', 'lilac', 'Idioma OCR', segmented(ocrOptions(langInfo().ocr).map(([k, l]) => [k, l]), st.ocrLang, v => setSettings({ ocrLang: v })), 'Se descarga una vez y queda guardado en el dispositivo')), group('Almacenamiento', h('div', { class: 'list-item' }, tile('hardDrive', 'sand'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Espacio utilizado'), usage)), listItem({ icon: 'lock', tint: 'peri', title: 'Almacenamiento persistente', sub: 'Evita que el navegador borre tus documentos si falta espacio', right: persistBadge, onclick: async () => { const s = await requestPersist(); paintPersist(s); toast(s === 'granted' ? 'Almacenamiento persistente activado' : s === 'unsupported' ? 'Este navegador no lo admite' : 'El navegador no lo concedió. Instalar la app suele ayudar.', s === 'granted' ? 'ok' : 'error', 4000); } }), listItem({ icon: 'archive', tint: 'peach', title: 'Crear copia de seguridad', sub: 'Descarga un ZIP con todos tus documentos', onclick: backup }), ...(isNative ? [listItem({ icon: 'upload', tint: 'lilac', title: 'Copia en Google Drive', sub: 'Guarda todos tus documentos en tu Drive', onclick: () => void driveBackup() })] : []), listItem({ icon: 'upload', tint: 'sky', title: 'Restaurar copia de seguridad', sub: 'Importa un ZIP creado con ScanPro', onclick: restore }), listItem({ icon: 'info', tint: 'sand', title: 'Límites del navegador', sub: 'Qué pasa con tus datos', onclick: () => infoDialog('Dónde se guardan tus documentos', h('div', { class: 'small muted', style: 'text-align:left;margin-bottom:16px' }, h('p', { style: 'text-align:left' }, 'Todo se guarda en este dispositivo, dentro del almacenamiento del navegador (IndexedDB). No se sube nada a ningún servidor.'), h('p', { style: 'text-align:left' }, 'Si borras los datos del sitio en Chrome, desinstalas la app o usas modo incógnito, los documentos se eliminan. Sin almacenamiento persistente, el navegador podría borrarlos si el teléfono se queda sin espacio.'), h('p', { style: 'text-align:left;margin:0' }, 'Por eso conviene crear copias de seguridad de vez en cuando.'))) })), group('Privacidad y permisos', listItem({ icon: 'camera', tint: 'sky', title: 'Cámara', sub: 'Solo se activa al pulsar «Tomar foto»', right: camBadge, onclick: async () => { const r = await requestCamera(); paintCam(r.state); if (!r.ok)
            infoDialog('Permiso de cámara', `${r.message ?? ''} ${r.state === 'denied' ? CAMERA_HELP : ''}`, 'camera');
        else
            toast('Cámara disponible'); } }), listItem({ icon: 'shield', tint: 'lilac', title: 'Privacidad', sub: 'Procesamiento local, sin cuentas', onclick: () => infoDialog('Tu privacidad', `ScanPro procesa las fotos, los filtros, el PDF y el OCR en tu teléfono. No hay cuentas, analítica ni servidores propios. ${isNative ? 'La app instalada funciona sin Internet: el OCR viene incluido. Al exportar puede mostrarse un anuncio de Google (AdMob), que usa el identificador de publicidad del teléfono; tus documentos nunca se envían.' : 'La única conexión externa es la descarga del motor y del idioma de OCR (jsDelivr) la primera vez que lo usas; tus imágenes no se envían.'}`, 'shield') })), group('ScanPro VIP', isPro() ? listItem({ icon: 'crown', tint: 'butter', title: 'ScanPro VIP activo', sub: 'Sin anuncios. ¡Gracias por apoyar la app!' })
        : listItem({ icon: 'crown', tint: 'butter', title: 'ScanPro VIP', sub: 'Ruleta, anuncios de apoyo y desbloqueo temporal', onclick: () => void openVipPanel() })), group('Ayuda', ...(isNative ? [listItem({ icon: 'refresh', tint: 'sky', title: 'Buscar actualizaciones', sub: `La app revisa sola una vez al día · versión ${APP_VERSION}`, onclick: () => void checkUpdateNow() })] : []), listItem({ icon: 'send', tint: 'rose', title: 'Enviar comentarios', sub: 'Cuéntanos un fallo o una idea', onclick: () => sendFeedback() }), isInstalled() ? listItem({ icon: 'checkCircle', tint: 'lilac', title: 'Aplicación instalada', sub: 'Se abre a pantalla completa y funciona sin conexión' })
        : listItem({ icon: 'download', tint: 'peach', title: 'Instalar en el teléfono', sub: canInstall() ? 'Añade ScanPro a la pantalla de inicio' : 'En Chrome: menú ⋮ › «Instalar aplicación» o «Añadir a pantalla de inicio»', onclick: async () => {
                if (canInstall()) {
                    if (await promptInstall())
                        toast('ScanPro instalada');
                }
                else
                    infoDialog('Instalar ScanPro', 'Abre la app en Chrome para Android con una dirección https://, toca el menú ⋮ y elige «Instalar aplicación» (o «Añadir a pantalla de inicio»). Quedará como una app más, a pantalla completa y con funcionamiento sin conexión.', 'download');
            } }), listItem({ icon: 'book', tint: 'rose', title: 'Ver tutorial inicial', onclick: () => go('onboarding', { again: '1' }) }), listItem({ icon: 'book', tint: 'butter', title: 'Volver a ver las guías', sub: 'Los consejos paso a paso de cada pantalla', onclick: () => { resetTours(); toast('Las guías aparecerán de nuevo'); } }), listItem({ icon: 'language', tint: 'sky', title: 'Pantalla de bienvenida', sub: '«Hola» en todos los idiomas', onclick: () => showHelloAgain() }), listItem({ icon: 'info', tint: 'peri', title: 'Acerca de ScanPro', sub: `Versión ${APP_VERSION}`, onclick: () => infoDialog('ScanPro', `Versión ${APP_VERSION}. Escáner de documentos para Android ${isNative ? '(app instalada, funciona sin conexión)' : 'como aplicación web instalable (PWA)'}: cámara, encuadre automático, corrección de perspectiva, filtros, OCR (Tesseract.js), PDF, Word (docx), ZIP (JSZip).`, 'fileText') })), group('Zona de peligro', listItem({ icon: 'trash', title: 'Borrar todos los documentos', sub: `${docs.length} documento(s) · ${fmtSize(docsSize)}`, danger: true, onclick: async () => {
            if (!docs.length) {
                toast('No hay documentos.');
                return;
            }
            if (!(await confirmDialog({ title: 'Borrar todo', icon: 'trash', danger: true, confirm: 'Borrar todo', text: `Se eliminarán ${docs.length} documento(s), sus páginas y carpetas de este dispositivo. No se puede deshacer. Si quieres conservarlos, crea antes una copia de seguridad.` })))
                return;
            await clearAll();
            revokeAll();
            toast('Todos los documentos se han eliminado');
            go('settings', {}, { replace: true });
        } })), h('p', { class: 'center xs faint', style: 'margin-top:24px' }, `ScanPro · versión ${APP_VERSION}`)));
    if (params.section === 'storage')
        setTimeout(() => root.querySelectorAll('.section-title')[5]?.scrollIntoView({ behavior: 'smooth' }), 100);
    return root;
}
