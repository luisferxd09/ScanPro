import { play } from '../core/sounds.js';
// Cámara en vivo pensada para documentos:
//  · elige el lente trasero adecuado (enfoque automático, buena resolución; evita gran angular y tele)
//  · pide la máxima resolución que admite ese lente y enfoca en el centro del documento
//  · dispara cuando la hoja está quieta Y nítida (vigila el enfoque en vivo)
//  · captura «nítida»: foto del sensor en segundo plano; si no es posible, el fotograma más nítido de una ráfaga
//  · la cámara sigue abierta para la siguiente página
import { h, ic, pickFiles, vibrate } from '../ui/dom.js';
import { btn, blobUrl, busy, toast, confirmDialog, actionSheet } from '../ui/components.js';
import { go, onLeave, setGuard } from '../core/router.js';
import { getSession, startSession, addCapture, addFile, hasUnsaved, endSession, scheduleRender, onPageReady } from '../core/session.js';
import { describeCamError, CAMERA_HELP } from '../core/permissions.js';
import { getSettings, setSettings, captureQuality, isLowEnd } from '../core/settings.js';
import { savedChoice, probeCameras, rememberChoice, backCameras, lensName, videoTarget } from '../core/camera.js';
import { engine } from '../imaging/engine.js';
import { BLURRY } from '../imaging/quality.js';
import { importImages } from './common.js';
export function discardGuard() {
    if (!hasUnsaved()) {
        endSession();
        return Promise.resolve(true);
    }
    return confirmDialog({ title: '¿Descartar el escaneo?', icon: 'trash', danger: true, confirm: 'Descartar', cancel: 'Seguir', text: `Tienes ${getSession().pages.length} página(s) sin guardar. Si sales, se perderán.` })
        .then(ok => { if (ok)
        endSession(); return ok; });
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
export function scannerScreen() {
    const session = getSession() ?? startSession();
    session.viaScan = true;
    let stream = null;
    let track = null;
    let caps = {};
    let imageCapture = null;
    let photoMax = 0; // píxeles de la foto del sensor (0 = no disponible)
    let photoW = 0, photoH = 0;
    let lenses = [];
    let currentId = '';
    let alive = true, detecting = false, capturing = false, torch = false;
    let autoOn = getSettings().autoCapture;
    let photoChain = Promise.resolve(); // las fotos del sensor, de una en una
    // --- estado del encuadre ---
    let target = null;
    let shown = null;
    let lastSeen = 0, misses = 0, stableSince = 0;
    let armed = true;
    let capturedQuad = null;
    // --- nitidez en vivo (relativa: el enfoque continuo oscila y se dispara en el pico) ---
    let sharpNow = 0, sharpPeak = 0, sharpPeakAt = 0;
    let lastFocusAt = 0;
    let zoom = 1;
    const video = h('video', { playsinline: true, muted: true, autoplay: true, 'aria-label': 'Vista previa de la cámara' });
    video.muted = true;
    video.setAttribute('playsinline', '');
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('class', 'overlay-svg');
    const poly = document.createElementNS(svgNS, 'polygon');
    poly.setAttribute('class', 'quad');
    poly.style.opacity = '0';
    svg.appendChild(poly);
    const hint = h('div', { class: 'cam-hint' }, 'Iniciando cámara…');
    const flash = h('div', { class: 'flash' });
    const focusRing = h('div', { class: 'focus-ring' });
    const zoomPill = h('button', { class: 'zoom-pill', 'aria-label': 'Zoom', onclick: () => cycleZoom() }, '1×');
    zoomPill.style.display = 'none';
    // modo documento de identidad: guía con la forma de la tarjeta y paso (frente / reverso)
    const idMode = session.mode === 'id';
    const idGuide = h('div', { class: 'id-guide', 'aria-hidden': 'true' });
    const idStep = h('div', { class: 'id-step' });
    const paintIdStep = () => {
        const n = session.pages.length;
        idStep.replaceChildren(ic('idCard', 'sm'), h('span', null, n === 0 ? 'Frente · 1 de 2' : 'Reverso · 2 de 2'));
    };
    if (idMode)
        paintIdStep();
    if (idMode && session.idPending && session.pages.length >= 2) {
        session.idPending = false;
        setTimeout(() => go('review'), 60);
    }
    const stage = h('div', { class: 'stage' + (idMode ? ' id-mode' : '') }, video, ...(idMode ? [idGuide] : []), svg, hint, ...(idMode ? [idStep] : []), focusRing, zoomPill, flash);
    const word = idMode ? 'el documento' : 'la hoja';
    /** Esquinas del recuadro guía en coordenadas 0…1 de la imagen (vídeo con object-fit: contain). */
    const guideQuad = () => {
        const vw = video.videoWidth, vh = video.videoHeight, sw = stage.clientWidth, sh = stage.clientHeight;
        if (!vw || !vh || !sw || !sh)
            return null;
        const k = Math.min(sw / vw, sh / vh), ox = (sw - vw * k) / 2, oy = (sh - vh * k) / 2;
        const gw = sw * .82, gh = gw / 1.586, cx = sw / 2, cy = sh * .46;
        const u = (x) => Math.min(1, Math.max(0, (x - ox) / (vw * k))), v = (y) => Math.min(1, Math.max(0, (y - oy) / (vh * k)));
        const x0 = u(cx - gw / 2), x1 = u(cx + gw / 2), y0 = v(cy - gh / 2), y1 = v(cy + gh / 2);
        return [x0, y0, x1, y0, x1, y1, x0, y1];
    };
    const ringSvg = document.createElementNS(svgNS, 'svg');
    ringSvg.setAttribute('class', 'ring');
    ringSvg.setAttribute('viewBox', '0 0 76 76');
    const ringC = document.createElementNS(svgNS, 'circle');
    ringC.setAttribute('cx', '38');
    ringC.setAttribute('cy', '38');
    ringC.setAttribute('r', '36');
    ringSvg.appendChild(ringC);
    const shutter = h('button', { class: 'shutter', 'aria-label': 'Capturar', disabled: true, onclick: () => void capture(false) }, h('i'), ringSvg);
    const torchBtn = h('button', { class: 'cam-round', 'aria-label': 'Linterna', onclick: () => void toggleTorch() }, ic('zap', 'sm'));
    torchBtn.style.visibility = 'hidden';
    const lensBtn = h('button', { class: 'cam-round', 'aria-label': 'Cambiar de lente', onclick: () => chooseLens() }, ic('camera', 'sm'));
    lensBtn.style.visibility = 'hidden';
    const autoBtn = h('button', { class: 'auto-pill' + (autoOn ? ' on' : ''), 'aria-pressed': String(autoOn), 'aria-label': 'Captura automática', onclick: () => {
            autoOn = !autoOn;
            setSettings({ autoCapture: autoOn });
            autoBtn.classList.toggle('on', autoOn);
            autoBtn.setAttribute('aria-pressed', String(autoOn));
            toast(autoOn ? 'Captura automática activada' : 'Captura manual', 'ok', 1400);
            stableSince = 0;
            shutter.classList.remove('arming');
        } }, 'AUTO');
    const lastBtn = h('button', { class: 'cs-btn', 'aria-label': 'Revisar páginas', onclick: () => { if (session.pages.length)
            go('review'); } });
    const lastLabel = h('span', null, 'Revisar');
    const paintLast = (bump = false) => {
        const p = session.pages[session.pages.length - 1];
        const count = session.pages.length;
        lastBtn.replaceChildren(p?.out ? h('img', { src: blobUrl(p.out.thumb), alt: '' }) : ic('stack'), ...(count ? [h('span', { class: 'count' + (bump ? ' bump' : '') }, String(count))] : []));
        lastLabel.textContent = count ? 'Listo' : 'Revisar';
    };
    paintLast();
    const offReady = onPageReady(() => paintLast());
    // ---------- encuadre en pantalla ----------
    const videoBox = () => {
        const vw = video.videoWidth || 1, vh = video.videoHeight || 1;
        const r = stage.getBoundingClientRect();
        const s = Math.min(r.width / vw, r.height / vh);
        return { r, s, ox: (r.width - vw * s) / 2, oy: (r.height - vh * s) / 2, vw, vh };
    };
    const toScreen = (n) => {
        const { r, s, ox, oy, vw, vh } = videoBox();
        svg.setAttribute('viewBox', `0 0 ${r.width} ${r.height}`);
        return [0, 1, 2, 3].map(i => `${(ox + n[i * 2] * vw * s).toFixed(1)},${(oy + n[i * 2 + 1] * vh * s).toFixed(1)}`).join(' ');
    };
    let raf = 0;
    const animate = () => {
        raf = 0;
        if (!target || !shown)
            return;
        let moving = false;
        for (let i = 0; i < 8; i++) {
            const d = target[i] - shown[i];
            if (Math.abs(d) > 0.0008) {
                shown[i] += d * 0.35;
                moving = true;
            }
            else
                shown[i] = target[i];
        }
        poly.setAttribute('points', toScreen(shown));
        if (moving)
            raf = requestAnimationFrame(animate);
    };
    const quadDelta = (a, b) => Math.max(...a.map((v, i) => Math.abs(v - b[i])));
    /** Tamaño de la hoja respecto al fotograma (0–1): si es pequeño, conviene acercarse. */
    const quadArea = (q) => {
        let a = 0;
        for (let i = 0; i < 4; i++) {
            const j = (i + 1) % 4;
            a += q[i * 2] * q[j * 2 + 1] - q[j * 2] * q[i * 2 + 1];
        }
        return Math.abs(a) / 2;
    };
    // ---------- enfoque ----------
    /** Enfoca en un punto (normalizado 0–1 del vídeo). Las cámaras sin esta función lo ignoran. */
    async function focusAt(x, y, show) {
        if (!track)
            return;
        lastFocusAt = performance.now();
        if (show) {
            const { ox, oy, s, vw, vh } = videoBox();
            focusRing.style.left = `${ox + x * vw * s}px`;
            focusRing.style.top = `${oy + y * vh * s}px`;
            focusRing.classList.remove('on');
            void focusRing.offsetWidth;
            focusRing.classList.add('on');
        }
        const fm = caps.focusMode ?? [];
        try {
            await track.applyConstraints({ advanced: [{ pointsOfInterest: [{ x, y }], ...(fm.includes('single-shot') && show ? { focusMode: 'single-shot' } : {}) }] });
            if (show && fm.includes('continuous'))
                setTimeout(() => { void track?.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => { }); }, 1800);
        }
        catch { /* sin soporte de punto de enfoque */ }
    }
    stage.addEventListener('click', e => {
        if (e.target !== video && e.target !== svg && e.target !== stage)
            return;
        const { r, s, ox, oy, vw, vh } = videoBox();
        const x = (e.clientX - r.left - ox) / (vw * s), y = (e.clientY - r.top - oy) / (vh * s);
        if (x < 0 || y < 0 || x > 1 || y > 1)
            return;
        vibrate(5);
        void focusAt(x, y, true);
    });
    // ---------- zoom (pellizcar o botón) ----------
    const zmin = () => caps.zoom?.min ?? 1, zmax = () => Math.min(caps.zoom?.max ?? 1, 4);
    async function setZoom(z) {
        if (!track || !caps.zoom)
            return;
        zoom = Math.min(zmax(), Math.max(zmin(), z));
        zoomPill.textContent = `${zoom.toFixed(zoom < 2 && zoom % 1 ? 1 : 0).replace('.', ',')}×`;
        try {
            await track.applyConstraints({ advanced: [{ zoom }] });
        }
        catch { /* */ }
    }
    const cycleZoom = () => { const steps = [1, 1.5, 2].filter(v => v >= zmin() && v <= zmax()); const i = steps.findIndex(v => v > zoom + 0.05); void setZoom(steps[i < 0 ? 0 : i]); };
    let pinch0 = 0, zoom0 = 1;
    const touches = new Map();
    stage.addEventListener('pointerdown', e => { touches.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (touches.size === 2) {
        const [a, b] = [...touches.values()];
        pinch0 = Math.hypot(a.x - b.x, a.y - b.y);
        zoom0 = zoom;
    } });
    stage.addEventListener('pointermove', e => {
        if (!touches.has(e.pointerId))
            return;
        touches.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (touches.size === 2 && pinch0 && caps.zoom) {
            const [a, b] = [...touches.values()];
            void setZoom(zoom0 * Math.hypot(a.x - b.x, a.y - b.y) / pinch0);
        }
    });
    const up = (e) => { touches.delete(e.pointerId); if (touches.size < 2)
        pinch0 = 0; };
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
    // ---------- detección continua ----------
    function onDetection(q, sharp) {
        const now = performance.now();
        if (sharp !== null) {
            sharpNow = sharp;
            if (sharp > sharpPeak || now - sharpPeakAt > 2500) {
                sharpPeak = sharp;
                sharpPeakAt = now;
            }
        }
        if (q) {
            misses = 0;
            if (target && quadDelta(q, target) < 0.08)
                q = q.map((v, i) => target[i] * 0.45 + v * 0.55);
            const still = target ? quadDelta(q, target) < 0.012 : false;
            if (!target || !shown)
                shown = [...q];
            target = q;
            lastSeen = now;
            poly.style.opacity = '1';
            if (!raf)
                raf = requestAnimationFrame(animate);
            if (!armed && capturedQuad && quadDelta(q, capturedQuad) > 0.12)
                armed = true;
            if (still) {
                if (!stableSince)
                    stableSince = now;
            }
            else
                stableSince = 0;
            // enfoca en el centro de la hoja (como mucho cada 1,5 s)
            if (now - lastFocusAt > 1500) {
                const cx = (q[0] + q[2] + q[4] + q[6]) / 4, cy = (q[1] + q[3] + q[5] + q[7]) / 4;
                void focusAt(cx, cy, false);
            }
            const steady = stableSince ? now - stableSince : 0;
            // nítida = cerca del mejor enfoque visto en los últimos segundos
            const focused = sharp === null || sharpNow >= sharpPeak * 0.85;
            const small = quadArea(q) < (idMode ? 0.08 : 0.22);
            idGuide.classList.add('hide');
            poly.classList.toggle('locked', steady > 350 && focused);
            if (autoOn && armed && !capturing) {
                hint.classList.add('go');
                hint.textContent = small ? `Acércate a ${word}` : !focused ? 'Enfocando…' : steady ? 'Mantén quieto…' : idMode ? 'Documento detectado' : 'Hoja detectada';
                shutter.classList.toggle('arming', !!stableSince && focused && !small);
                if (steady > 1000 && focused && !small)
                    void capture(true);
            }
            else {
                hint.classList.remove('go');
                shutter.classList.remove('arming');
                hint.textContent = !armed && autoOn ? (idMode ? 'Voltea el documento' : 'Coloca la siguiente página') : small ? `Acércate a ${word} para más nitidez` : `${idMode ? 'Documento detectado' : 'Hoja detectada'} · toca para capturar`;
            }
        }
        else {
            misses++;
            stableSince = 0;
            shutter.classList.remove('arming');
            if (misses >= 2) {
                poly.style.opacity = '0';
                target = null;
                shown = null;
                poly.classList.remove('locked');
            }
            if (misses >= 3)
                armed = true;
            hint.classList.remove('go');
            hint.textContent = idMode ? 'Pon el documento dentro del recuadro, sobre un fondo oscuro' : 'Encuadra la hoja sobre un fondo que contraste';
            idGuide.classList.remove('hide');
        }
    }
    async function detectLoop() {
        if (!alive || detecting)
            return;
        detecting = true;
        try {
            while (alive && stream) {
                if (document.hidden || capturing || !video.videoWidth) {
                    await sleep(200);
                    continue;
                }
                const vw = video.videoWidth, vh = video.videoHeight, s = 360 / Math.max(vw, vh);
                let small, crop = null;
                try {
                    small = await createImageBitmap(video, { resizeWidth: Math.round(vw * s), resizeHeight: Math.round(vh * s), resizeQuality: 'low' });
                    // recorte del centro del documento a resolución nativa para medir el enfoque
                    if (target) {
                        const xs = [target[0], target[2], target[4], target[6]], ys = [target[1], target[3], target[5], target[7]];
                        const cx = (Math.min(...xs) + Math.max(...xs)) / 2 * vw, cy = (Math.min(...ys) + Math.max(...ys)) / 2 * vh;
                        const side = Math.round(Math.min(vw, vh) * 0.3);
                        const sx = Math.max(0, Math.min(vw - side, Math.round(cx - side / 2))), sy = Math.max(0, Math.min(vh - side, Math.round(cy - side / 2)));
                        crop = await createImageBitmap(video, sx, sy, side, side);
                    }
                }
                catch {
                    await sleep(300);
                    continue;
                }
                const t0 = performance.now();
                const info = await engine.frameInfo(small, crop).catch(() => ({ quad: null, sharp: null }));
                if (!alive)
                    break;
                onDetection(info.quad, info.sharp);
                await sleep(Math.max(60, 140 - (performance.now() - t0)));
            }
        }
        finally {
            detecting = false;
        }
    }
    // ---------- captura ----------
    async function grabFrame() {
        try {
            return await createImageBitmap(video);
        }
        catch {
            const c = document.createElement('canvas');
            c.width = video.videoWidth;
            c.height = video.videoHeight;
            c.getContext('2d').drawImage(video, 0, 0);
            return createImageBitmap(c);
        }
    }
    /** Ráfaga: 3 fotogramas en ~170 ms y se queda el más nítido (el temblor y el enfoque varían entre ellos). */
    async function bestFrame(first) {
        const frames = [first];
        for (let i = 0; i < 2; i++) {
            await sleep(85);
            try {
                frames.push(await grabFrame());
            }
            catch {
                break;
            }
        }
        if (frames.length === 1)
            return first;
        const scores = await Promise.all(frames.map(async (f) => {
            // se mide el centro a resolución nativa
            const side = Math.round(Math.min(f.width, f.height) * 0.4);
            const c = await createImageBitmap(f, Math.round((f.width - side) / 2), Math.round((f.height - side) / 2), side, side);
            return engine.sharpOf(c).catch(() => 0);
        }));
        let best = 0;
        scores.forEach((s, i) => { if (s > scores[best])
            best = i; });
        frames.forEach((f, i) => { if (i !== best)
            f.close(); });
        return frames[best];
    }
    /** Foto del sensor con su enfoque y procesado; si tarda o falla, el mejor fotograma. */
    function sensorPhoto(fallbackFrame) {
        const job = photoChain.then(async () => {
            if (!imageCapture)
                return bestFrame(fallbackFrame);
            // resolución completa del sensor; si el teléfono no acepta el ajuste, la predeterminada
            const ic = imageCapture;
            const shot = (photoW ? ic.takePhoto({ imageWidth: photoW, imageHeight: photoH }) : ic.takePhoto()).catch(() => ic.takePhoto());
            const res = await Promise.race([shot, sleep(4500).then(() => null)]);
            if (res && res.size > 0) {
                fallbackFrame.close();
                return res;
            }
            return bestFrame(fallbackFrame);
        });
        photoChain = job.catch(() => { });
        return job;
    }
    function flyToStack() {
        const sr = stage.getBoundingClientRect(), tr = lastBtn.getBoundingClientRect();
        const vw = video.videoWidth, vh = video.videoHeight;
        const s = Math.min(sr.width / vw, sr.height / vh);
        const w = vw * s, hgt = vh * s;
        const c = document.createElement('canvas');
        const k = Math.min(1, 280 / Math.max(w, hgt));
        c.width = Math.round(w * k);
        c.height = Math.round(hgt * k);
        c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
        c.className = 'fly';
        c.style.cssText = `left:${sr.left + (sr.width - w) / 2}px;top:${sr.top + (sr.height - hgt) / 2}px;width:${w}px;height:${hgt}px`;
        document.body.appendChild(c);
        requestAnimationFrame(() => requestAnimationFrame(() => {
            const sc = Math.min(tr.width / w, tr.height / hgt);
            const dx = tr.left + (tr.width - w * sc) / 2 - (sr.left + (sr.width - w) / 2);
            const dy = tr.top + (tr.height - hgt * sc) / 2 - (sr.top + (sr.height - hgt) / 2);
            c.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${sc})`;
            c.style.opacity = '0.2';
        }));
        setTimeout(() => c.remove(), 600);
    }
    async function capture(auto) {
        if (capturing || !stream || !video.videoWidth)
            return;
        capturing = true;
        shutter.classList.remove('arming');
        vibrate(auto ? 25 : 15);
        flash.classList.remove('go');
        void flash.offsetWidth;
        flash.classList.add('go');
        const hintQuad = target && performance.now() - lastSeen < 700 ? [...target] : null;
        try {
            const frame = await grabFrame();
            flyToStack();
            play('shutter');
            const nitida = captureQuality() === 'nitida';
            const forceSensor = globalThis.__scanproForceSensor === true; // solo pruebas
            const src = nitida && imageCapture && (forceSensor || photoMax > video.videoWidth * video.videoHeight * 1.2)
                ? sensorPhoto(frame)
                : bestFrame(frame);
            const dp = addCapture(src, hintQuad);
            armed = !auto && armed;
            capturedQuad = hintQuad;
            paintLast(true);
            void afterCapture(dp, auto);
        }
        catch (e) {
            toast(e.message || 'No se pudo capturar la imagen', 'error');
        }
        finally {
            // evita disparos dobles por un toque tembloroso, sin frenar al que escanea rápido
            setTimeout(() => { capturing = false; stableSince = 0; }, 150);
        }
    }
    async function afterCapture(dp, auto) {
        try {
            await dp.ready;
        }
        catch (e) {
            paintLast();
            toast(e.message || 'No se pudo procesar la foto', 'error');
            return;
        }
        if (dp.sharp && dp.sharp < BLURRY && alive)
            toast('La foto salió poco nítida: acércate, sujeta firme o enciende la linterna y repítela', 'error', 4200);
        // cédula sin borde detectado: se usa el recuadro guía como recorte (se puede ajustar luego)
        if (idMode && !dp.detected) {
            const g = guideQuad();
            if (g)
                dp.corners = g;
        }
        if (!dp.detected && !dp.corners && !auto && getSettings().autoDetect && alive) {
            if (idMode && session.pages.length >= 2)
                session.idPending = true;
            go('crop', { page: dp.id, from: 'scan' });
            return;
        }
        void scheduleRender(dp).catch(e => toast(e.message, 'error'));
        if (idMode && alive) {
            if (session.pages.length === 1) {
                paintIdStep();
                toast('Frente listo. Ahora voltea el documento y toma el reverso', 'ok', 3200);
            }
            else if (session.pages.length >= 2)
                go('review');
        }
    }
    // ---------- cámara y lentes ----------
    const systemCamera = async () => {
        const files = await pickFiles({ accept: 'image/*', capture: 'environment' });
        if (!files.length)
            return;
        const b = busy('Procesando foto…');
        try {
            const dp = await addFile(files[0]);
            b.done();
            go(dp.detected ? 'adjust' : 'crop', { page: dp.id, from: 'scan' });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error');
        }
    };
    const showMessage = (title, text) => {
        stage.replaceChildren(h('div', { class: 'cam-msg' }, h('div', { style: 'width:72px;height:72px;border-radius:22px;display:grid;place-items:center;background:rgba(255,255,255,.12)' }, ic('camera', 'lg')), h('h3', { style: 'margin:0' }, title), h('p', null, text), btn('Usar la cámara del sistema', () => void systemCamera(), 'primary', { block: true, icon: 'camera' }), btn('Importar de la galería', () => void importImages(session.targetDocId, true, true), 'secondary', { block: true, icon: 'images' }), btn('Reintentar', () => void startCamera(), 'ghost', { block: true, icon: 'refresh' })));
        shutter.disabled = true;
    };
    /** Abre una cámara concreta (o la trasera por defecto) a la máxima resolución útil. */
    async function open(deviceId) {
        stopCamera();
        const base = deviceId ? { deviceId: { exact: deviceId } } : { facingMode: { ideal: 'environment' } };
        stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { ...base, width: { ideal: 1920 }, height: { ideal: 1440 } } });
        track = stream.getVideoTracks()[0] ?? null;
        caps = (track?.getCapabilities?.() ?? {});
        currentId = track?.getSettings().deviceId ?? deviceId ?? '';
        // máxima resolución del lente (limitada en gama baja para que la vista previa vaya fluida)
        const want = videoTarget(caps, isLowEnd());
        const adv = [];
        if ((caps.focusMode ?? []).includes('continuous'))
            adv.push({ focusMode: 'continuous' });
        try {
            await track?.applyConstraints({ width: { ideal: want.width }, height: { ideal: want.height }, advanced: adv });
        }
        catch { /* se queda la resolución actual */ }
        // zoom inicial 1× si el lente arranca con otro valor
        zoom = 1;
        if (caps.zoom && (caps.zoom.max ?? 1) > 1) {
            zoomPill.style.display = '';
            void setZoom(Math.max(zmin(), 1));
        }
        else
            zoomPill.style.display = 'none';
        // foto del sensor
        const ICls = window.ImageCapture;
        imageCapture = null;
        photoMax = 0;
        photoW = 0;
        photoH = 0;
        if (ICls && track) {
            try {
                imageCapture = new ICls(track);
                const pc = await imageCapture.getPhotoCapabilities?.();
                photoW = pc?.imageWidth?.max ?? 0;
                photoH = pc?.imageHeight?.max ?? 0;
                photoMax = photoW * photoH;
            }
            catch {
                imageCapture = null;
            }
        }
        video.srcObject = stream;
        try {
            await video.play();
        }
        catch { /* el usuario ya tocó */ }
        torchBtn.style.visibility = caps.torch ? 'visible' : 'hidden';
    }
    /** Primera vez: prueba los lentes traseros y se queda con el mejor para documentos. */
    async function pickBestLens() {
        const saved = await savedChoice();
        if (saved) {
            lenses = saved.list ?? [];
            return saved.deviceId;
        }
        const devs = await backCameras().catch(() => []);
        if (devs.length < 2)
            return null; // un solo lente trasero: nada que elegir
        hint.textContent = 'Eligiendo el mejor lente para documentos…';
        stopCamera(); // en muchos Android solo puede haber una cámara abierta
        const { list, pool } = await probeCameras((i, n) => { hint.textContent = `Probando lentes (${i + 1} de ${n})…`; });
        if (!list.length)
            return null;
        lenses = list;
        rememberChoice(list[0].deviceId, list, false, pool);
        return list[0].deviceId;
    }
    function chooseLens() {
        if (lenses.length < 2) {
            toast('Este teléfono solo ofrece un lente trasero al navegador', 'ok', 2500);
            return;
        }
        actionSheet('Lente', lenses.map((c, i) => ({
            icon: c.deviceId === currentId ? 'checkCircle' : 'camera',
            label: `${lensName(c, i, i === 0)}${i === 0 ? ' (recomendado)' : ''}`,
            sub: [c.megapixels ? `${c.megapixels.toFixed(0)} MP` : '', c.autofocus ? 'enfoque automático' : 'enfoque fijo'].filter(Boolean).join(' · '),
            run: async () => {
                try {
                    await open(c.deviceId);
                    const s = await savedChoice();
                    rememberChoice(c.deviceId, lenses, true, s?.pool ?? (await backCameras()).map(d => d.deviceId).sort().join('|'));
                    void detectLoop();
                }
                catch (e) {
                    toast(describeCamError(e).message, 'error');
                }
            },
        })));
    }
    async function startCamera() {
        stopCamera();
        if (!stage.contains(video))
            stage.replaceChildren(video, svg, hint, focusRing, zoomPill, flash);
        if (!window.isSecureContext) {
            showMessage('La cámara en vivo necesita HTTPS', 'El navegador solo permite la cámara en páginas seguras (https:// o localhost). Puedes usar la cámara del sistema o importar fotos.');
            return;
        }
        if (!navigator.mediaDevices?.getUserMedia) {
            showMessage('Cámara no disponible', 'Este navegador no ofrece cámara en vivo. Usa la cámara del sistema o importa una foto.');
            return;
        }
        try {
            // 1) abrir la trasera por defecto (también concede el permiso y da nombres a las cámaras)
            await open((await savedChoice())?.deviceId ?? null);
            if (!alive) {
                stopCamera();
                return;
            }
            // 2) la primera vez, comprobar si hay un lente mejor
            if (!(await savedChoice())) {
                const best = await pickBestLens();
                if (!alive) {
                    stopCamera();
                    return;
                }
                if (best && best !== currentId)
                    await open(best);
                else if (!stream)
                    await open(best);
            }
            else
                lenses = (await savedChoice())?.list ?? [];
        }
        catch (e) {
            const d = describeCamError(e);
            showMessage(d.state === 'denied' ? 'Permiso de cámara denegado' : 'No se pudo abrir la cámara', d.state === 'denied' ? `Puedes seguir importando imágenes. ${CAMERA_HELP}` : d.message);
            return;
        }
        if (!alive) {
            stopCamera();
            return;
        }
        lensBtn.style.visibility = lenses.length > 1 ? 'visible' : 'hidden';
        shutter.disabled = false;
        hint.textContent = 'Encuadra la hoja';
        void detectLoop();
    }
    function stopCamera() {
        stream?.getTracks().forEach(t => t.stop());
        stream = null;
        track = null;
        imageCapture = null;
    }
    async function toggleTorch() {
        if (!track)
            return;
        torch = !torch;
        try {
            await track.applyConstraints({ advanced: [{ torch }] });
            torchBtn.classList.toggle('on', torch);
            torchBtn.replaceChildren(ic(torch ? 'zapOff' : 'zap', 'sm'));
        }
        catch {
            toast('La linterna no está disponible', 'error');
        }
    }
    const onVis = () => { if (document.hidden)
        stopCamera();
    else if (!stream && alive)
        void startCamera(); };
    document.addEventListener('visibilitychange', onVis);
    onLeave(() => { alive = false; cancelAnimationFrame(raf); stopCamera(); offReady(); document.removeEventListener('visibilitychange', onVis); document.querySelectorAll('.fly').forEach(f => f.remove()); });
    setGuard(discardGuard);
    setTimeout(() => { if (alive)
        void startCamera(); }, 120);
    return h('div', { class: 'scanner' }, h('div', { class: 'cam-top' }, h('button', { class: 'cam-round', 'aria-label': 'Cerrar', onclick: () => history.back() }, ic('x', 'sm')), autoBtn, h('div', { class: 'row', style: 'gap:8px' }, lensBtn, torchBtn)), stage, h('div', { class: 'cam-bottom' }, h('div', { class: 'cam-side left' }, h('button', { class: 'cs-btn', 'aria-label': 'Importar de la galería', onclick: () => void importImages(session.targetDocId, true, true) }, ic('images')), 'Galería'), shutter, h('div', { class: 'cam-side right' }, lastBtn, lastLabel)));
}
