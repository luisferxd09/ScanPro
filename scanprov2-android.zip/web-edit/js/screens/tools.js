import { curCountry } from '../core/locale.js';
// Herramientas agrupadas por uso: escaneo, PDF, texto, vida diaria, estudio, trabajo, negocio, imagen y seguridad.
import { h, ic } from '../ui/dom.js';
import { largeHeader, tile, stagger } from '../ui/components.js';
import { go } from '../core/router.js';
import { pickDocument, importImages, scanIdCard, scanWithCamera } from './common.js';
import { splitTool, compressTool, protectTool, watermarkTool, numberTool, pdfToImagesTool, redactTool, verifyTool, rotateReorderTool, signOthersTool } from '../tools/pdf.js';
import { qrTool, bookTool, batchTool, cardTool, copyTextTool, translateTool, readAloudTool, tableTool, compareTool, studyTool, dictateTool, notebookTool } from '../tools/smart.js';
import { openPrivate, expenseFromPhoto } from '../tools/life.js';
import { tipOnce } from '../ui/tour.js';
import { reviewTool, fillFormTool, organize, editProfile } from '../tools/ai.js';
import { toast } from '../ui/components.js';
import { removeBgTool, idPhotoTool, presentTool, pptxTool, templatesTool } from '../tools/media.js';
const SECTIONS = [
    ['Inteligencia', [
            ['search', 'lilac', 'Pregúntale a tus documentos', '«¿Cuándo vence mi SOAT?», «¿Cuánto pagué de luz?»', () => go('preguntar', {})],
            ['alert', 'rose', 'Revisar contrato', 'Resumen y alertas: permanencia, multas, renovación…', () => reviewTool()],
            ['pencil', 'sky', 'Llenar formulario', 'Escribe tus datos en los campos del formulario.', fillFormTool],
            ['wand', 'peach', 'Organizar documento', 'Le pone nombre, tipo, carpeta y vencimiento.', () => void pickDocument('Organizar…', async (d) => { const k = await organize(d.id, false); toast(k ? `Es un(a) ${k}. Listo.` : 'No reconocí el tipo de documento.', k ? 'ok' : 'error'); go('doc', { id: d.id }); })],
            ['person', 'butter', 'Mis datos', 'Para llenar formularios automáticamente.', () => void editProfile()],
        ]],
    ['Escanear', [
            ['camera', 'lilac', 'Escáner', 'Enfoque y bordes automáticos.', () => void scanWithCamera()],
            ['idCard', 'peach', curCountry().idName, 'Frente y reverso en una hoja, a tamaño real.', () => scanIdCard()],
            ['qr', 'sky', 'QR y códigos', 'Lee QR, códigos de barras y facturas DIAN.', () => void qrTool()],
            ['book', 'butter', 'Libro', 'Dos páginas por foto, separadas solas.', bookTool],
            ['layers', 'rose', 'Por lotes', 'Muchas hojas seguidas, en uno o varios documentos.', batchTool],
            ['person', 'peri', 'Tarjeta a contacto', 'Guarda una tarjeta de presentación en tus contactos.', () => void cardTool()],
            ['copy', 'coral', 'Copiar texto', 'Apunta, toma la foto y el texto queda copiado.', () => void copyTextTool()],
            ['images', 'sand', 'Importar', 'Fotos, PDF, Word, Excel, PowerPoint, EPUB o ZIP en documentos.', () => void importImages()],
        ]],
    ['PDF', [
            ['scissors', 'rose', 'Dividir', 'Saca páginas o parte un documento en varios.', splitTool],
            ['archive', 'sky', 'Comprimir', 'A 500 KB, 1, 2 o 5 MB para trámites.', compressTool],
            ['lock', 'lilac', 'Contraseña', 'Protege un PDF o quítale la contraseña.', protectTool],
            ['type', 'peach', 'Marca de agua', '«COPIA» o «SOLO PARA TRÁMITE X».', watermarkTool],
            ['list', 'butter', 'Numerar páginas', '1, 2, 3… o «1 de 10».', numberTool],
            ['rotateCw', 'peri', 'Rotar y ordenar', 'Gira, mueve o quita páginas.', rotateReorderTool],
            ['fileImage', 'coral', 'PDF a imágenes', 'Cada página de un PDF en JPG.', () => void pdfToImagesTool()],
            ['filePdf', 'sand', 'Crear PDF', 'A4, carta u original, con márgenes y calidad.', () => void pickDocument('Crear PDF de…', d => go('share', { id: d.id, fmt: 'pdf', mode: 'export' }))],
            ['merge', 'rose', 'Combinar', 'Une dos o más documentos en uno nuevo.', () => void pickDocument('Empezar a combinar con…', d => go('merge', { id: d.id }))],
        ]],
    ['Firmar y editar', [
            ['pencil', 'rose', 'Firmar', 'Firma, escribe, resalta o tacha una página.', () => void pickDocument('Firmar o anotar…', d => go('pages', { id: d.id, hint: 'annotate' }))],
            ['share', 'lilac', 'Firmar PDF recibido', 'Abre el PDF que te enviaron, fírmalo y devuélvelo.', signOthersTool],
            ['stamp', 'peach', 'Sello de recibido', 'Sello rojo con fecha y hora sobre el documento.', () => void pickDocument('Sellar…', d => go('pages', { id: d.id, hint: 'annotate' }))],
            ['eye', 'coral', 'Tachar datos', 'Tapa cédula, cuentas, correos y direcciones.', redactTool],
            ['fileWord', 'sky', 'Editor de texto', 'Escribe o abre un Word y guárdalo como Word o PDF.', () => go('textedit', {})],
            ['filters', 'butter', 'Filtros', 'Aclara, quita sombras, pizarra o B/N.', () => void pickDocument('Aplicar filtros a…', d => go('pages', { id: d.id, hint: 'filters' }))],
        ]],
    ['Texto e idiomas', [
            ['ocr', 'peri', 'OCR', 'Extrae el texto de un documento.', () => void pickDocument('Extraer texto de…', d => go('ocr', { id: d.id }))],
            ['translate', 'sky', 'Traducir', '15 idiomas, sin internet tras la primera vez.', translateTool],
            ['volume', 'lilac', 'Leer en voz alta', 'Escucha cualquier documento.', readAloudTool],
            ['mic', 'rose', 'Dictar', 'Habla y se convierte en texto o documento.', () => void dictateTool()],
            ['calculator', 'butter', 'Tabla a Excel', 'Una tabla en papel convertida en .xlsx.', tableTool],
            ['check', 'peach', 'Lista con casillas', 'Una nota o lista escrita, para ir marcando.', () => go('listas', {})],
            ['compare', 'coral', 'Comparar', 'Qué cambió entre dos versiones.', compareTool],
        ]],
    ['Mi vida en orden', [
            ['wallet', 'lilac', 'Carpetas de vida', 'Identidad, salud, vehículo, hogar, garantías…', () => go('vida', {})],
            ['bell', 'peach', 'Avisos', 'Medicamentos, pagos y vencimientos.', () => go('avisos', {})],
            ['cart', 'butter', 'Gastos', 'Fotografía recibos y mira tus gastos del mes.', () => go('gastos', {})],
            ['lock', 'rose', 'Carpeta privada', 'Documentos protegidos con tu huella.', () => void openPrivate()],
        ]],
    ['Estudio', [
            ['graduation', 'sky', 'Resumen y tarjetas', 'Resume tus apuntes y crea tarjetas de estudio.', studyTool],
            ['book', 'lilac', 'Libro de apuntes', 'Portada, índice y todos tus apuntes en un PDF.', notebookTool],
            ['presentation', 'peach', 'Presentar', 'Muestra las páginas a pantalla completa.', () => presentTool()],
            ['fileImage', 'rose', 'A PowerPoint', 'Cada página como diapositiva (.pptx).', pptxTool],
        ]],
    ['Trabajo y negocio', [
            ['briefcase', 'peri', 'Plantillas de trámites', 'Derecho de petición, cuenta de cobro, poder…', templatesTool],
            ['fileText', 'butter', 'Recibo a gasto', 'Lee el total y la fecha de un recibo.', () => void expenseFromPhoto()],
            ['archive', 'sky', 'Inventario', 'Productos con foto y código de barras; a Excel.', () => go('inventario', {})],
            ['fileWord', 'coral', 'Exportar a Word', 'DOCX con imágenes y texto.', () => void pickDocument('Exportar a Word…', d => go('share', { id: d.id, fmt: 'docx', mode: 'export' }))],
        ]],
    ['Imagen', [
            ['wand', 'lilac', 'Quitar el fondo', 'Productos o personas con fondo transparente o blanco.', () => void removeBgTool()],
            ['person', 'peach', 'Foto tipo documento', '3×4, pasaporte o visa, lista para imprimir.', () => void idPhotoTool()],
            ['magnifier', 'sky', 'Lupa', 'Lee letra pequeña con zoom y contraste.', () => go('lupa', {})],
        ]],
    ['Seguridad y respaldo', [
            ['shield', 'peri', 'Verificar PDF', 'Comprueba si un PDF fue modificado.', () => void verifyTool()],
            ['archive', 'sand', 'Copia de seguridad', 'Guarda o restaura todos tus documentos.', () => go('settings', { section: 'storage' })],
            ['folder', 'lilac', 'Carpetas', 'Organiza tus escaneos en paquetes.', () => go('docs', { tab: 'folders' })],
        ]],
];
const HOW = {
    'Escáner': 'Apunta a la hoja: se encuadra y endereza sola.', 'Cédula / DNI': 'Escanea el frente y luego el reverso; salen juntos en una hoja.', 'QR y códigos': 'Apunta al código y se lee al instante.',
    'Libro': 'Toma la foto con el libro abierto; cada foto se parte en dos páginas.', 'Dividir': 'Elige un documento y luego las páginas.', 'Comprimir': 'Elige el tamaño máximo y comparte el archivo.',
    'Firmar': 'Elige la página, toca «Firma», dibújala y arrástrala a su lugar.', 'Traducir': 'Elige un documento o toma una foto, y el idioma.', 'Gastos': 'Toca «Escanear recibo».',
    'Pregúntale a tus documentos': 'Escribe tu pregunta como se la harías a una persona.', 'Llenar formulario': 'Primero guarda «Mis datos» una vez.', 'Revisar contrato': 'Elige el contrato y lee las alertas.',
};
export function toolsScreen() {
    const card = ([icon, tint, title, desc, run]) => h('button', { class: 'tool-card tap', onclick: async () => { await tipOnce('tool:' + title, [{ icon, title, text: desc + ' ' + (HOW[title] ?? '') }]); run(); } }, tile(icon, tint, true), h('div', null, h('h4', null, title), h('p', null, desc)));
    const [bar, big] = largeHeader('Herramientas');
    const search = h('input', { type: 'search', placeholder: 'Buscar herramienta…', 'aria-label': 'Buscar herramienta' });
    const body = h('div');
    const paint = () => {
        const q = search.value.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
        const m = (t) => !q || (t[2] + ' ' + t[3]).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(q);
        body.replaceChildren(...SECTIONS.filter(([, ts]) => ts.some(m)).map(([name, ts]) => h('section', { class: 'tool-section' }, h('h3', { class: 'section-title' }, name), h('div', { class: 'tools-grid' }, ...ts.filter(m).map(card)))));
    };
    search.oninput = paint;
    paint();
    return h('div', { class: 'screen with-nav' }, bar, big, h('div', { class: 'content' }, h('div', { class: 'input-wrap tool-search' }, ic('search', 'sm faint'), search), stagger(body)));
}
