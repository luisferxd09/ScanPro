// Editor de texto: edita el texto reconocido (OCR) o un Word y guárdalo como Word (.docx) o PDF con texto.
import { h, pickFiles } from '../ui/dom.js';
import { btn, toast, busy, topbar, actionSheet, note } from '../ui/components.js';
import { go } from '../core/router.js';
import { getDoc, getPages } from '../core/db.js';
import { loadVendor } from '../core/exporter.js';
import { downloadFiles, shareFiles } from '../core/share.js';
import { fileSafe } from '../core/names.js';
import { buildPdf } from '../imaging/pdf.js';
import { play } from '../core/sounds.js';
import { canvasToPage, newDoc } from '../core/docops.js';
import { blobToCanvas } from '../imaging/process.js';
import { nativeHas, nativeDictate } from '../core/native.js';
const esc = (s) => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
/** Lee el contenido del editor como bloques con formato. */
export function blocks(root) {
    const out = [];
    const runsOf = (el, st = { b: false, i: false, u: false }, acc = []) => {
        el.childNodes.forEach(n => {
            if (n.nodeType === 3) {
                if (n.textContent)
                    acc.push({ t: n.textContent, ...st });
                return;
            }
            const t = n.tagName;
            if (t === 'BR') {
                acc.push({ t: '\n', ...st });
                return;
            }
            runsOf(n, { b: st.b || t === 'B' || t === 'STRONG', i: st.i || t === 'I' || t === 'EM', u: st.u || t === 'U' }, acc);
        });
        return acc;
    };
    root.childNodes.forEach(n => {
        if (n.nodeType === 3) {
            if (n.textContent?.trim())
                out.push({ kind: 'p', runs: [{ t: n.textContent, b: false, i: false, u: false }] });
            return;
        }
        const el = n, t = el.tagName;
        if (t === 'UL' || t === 'OL')
            el.querySelectorAll(':scope > li').forEach((li, k) => out.push({ kind: t === 'UL' ? 'ul' : 'ol', runs: runsOf(li), n: k + 1 }));
        else
            out.push({ kind: t === 'H1' ? 'h1' : t === 'H2' ? 'h2' : 'p', runs: runsOf(el) });
    });
    return out;
}
async function toDocx(bl, title) {
    await loadVendor('vendor/docx.iife.js');
    const D = window.docx; // eslint-disable-line @typescript-eslint/no-explicit-any
    const paras = bl.map(b => new D.Paragraph({
        heading: b.kind === 'h1' ? D.HeadingLevel.HEADING_1 : b.kind === 'h2' ? D.HeadingLevel.HEADING_2 : undefined,
        bullet: b.kind === 'ul' ? { level: 0 } : undefined,
        children: (b.kind === 'ol' ? [new D.TextRun({ text: `${b.n}. ` })] : []).concat(b.runs.map(r => r.t === '\n' ? new D.TextRun({ break: 1 }) : new D.TextRun({ text: r.t, bold: r.b, italics: r.i, underline: r.u ? {} : undefined, size: 24 }))),
    }));
    const blob = await D.Packer.toBlob(new D.Document({ creator: 'ScanPro', title, sections: [{ children: paras.length ? paras : [new D.Paragraph('')] }] }));
    return new File([blob], `${fileSafe(title)}.docx`, { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
}
/** Dibuja los bloques en páginas A4 a 150 ppp (JPEG) con la posición de cada línea de texto. */
export async function renderBlocks(bl) {
    const W = 1240, H = 1754, M = 110, pages = [];
    let c, g, y = M, lines = [];
    const flush = async () => { if (!c)
        return; const b = await new Promise(r => c.toBlob(x => r(x), 'image/jpeg', .9)); pages.push({ jpeg: new Uint8Array(await b.arrayBuffer()), lines, srcW: W, srcH: H }); };
    const newPage = async () => { await flush(); c = document.createElement('canvas'); c.width = W; c.height = H; g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.fillStyle = '#1b1a2a'; g.textBaseline = 'alphabetic'; y = M; lines = []; };
    await newPage();
    const fontOf = (r, size, heading) => `${r.i ? 'italic ' : ''}${r.b || heading ? 700 : 400} ${size}px Helvetica, Arial, sans-serif`;
    for (const b of bl) {
        const size = b.kind === 'h1' ? 48 : b.kind === 'h2' ? 38 : 30, lh = size * 1.4, heading = b.kind === 'h1' || b.kind === 'h2';
        const indent = b.kind === 'ul' || b.kind === 'ol' ? 50 : 0;
        if (heading)
            y += size * .5;
        // palabras con su estilo
        const words = [];
        for (const r of b.runs)
            r.t.split(/(\s+|\n)/).forEach(t => { if (t)
                words.push({ t, r }); });
        let line = [], lw = 0;
        const emit = async (first) => {
            if (y + lh > H - M)
                await newPage();
            let x = M + indent, text = '';
            if (first && b.kind !== 'p' && !heading) {
                g.font = fontOf(b.runs[0] ?? { t: '', b: false, i: false, u: false }, size, false);
                g.fillText(b.kind === 'ul' ? '•' : `${b.n}.`, M + 8, y + size);
            }
            for (const w of line) {
                g.font = fontOf(w.r, size, heading);
                g.fillText(w.t, x, y + size);
                if (w.r.u && w.t.trim())
                    g.fillRect(x, y + size + 4, w.w, 2);
                x += w.w;
                text += w.t;
            }
            if (text.trim())
                lines.push({ t: text.trim(), x0: M + indent, y0: y + size * .15, x1: x, y1: y + size * 1.2 });
            y += lh;
            line = [];
            lw = 0;
        };
        let first = true;
        for (const w of words) {
            if (w.t === '\n') {
                await emit(first);
                first = false;
                continue;
            }
            g.font = fontOf(w.r, size, heading);
            const ww = g.measureText(w.t).width;
            if (lw + ww > W - 2 * M - indent && line.length && w.t.trim()) {
                await emit(first);
                first = false;
            }
            if (!line.length && !w.t.trim())
                continue;
            line.push({ ...w, w: ww });
            lw += ww;
        }
        if (line.length || first)
            await emit(first);
        y += size * .35;
    }
    await flush();
    return pages;
}
/** PDF con texto real (se puede buscar y copiar). */
async function toPdf(bl, title) {
    const pages = await renderBlocks(bl);
    const pdf = buildPdf(pages, { size: 'a4', orientation: 'portrait', margin: 0, title });
    return new File([pdf], `${fileSafe(title)}.pdf`, { type: 'application/pdf' });
}
const isZip = async (f) => { const b = new Uint8Array(await f.slice(0, 4).arrayBuffer()); return b[0] === 0x50 && b[1] === 0x4b; };
/** OpenDocument (.odt) → HTML: párrafos, títulos y listas. */
async function odtToHtml(f) {
    await loadVendor('vendor/jszip.min.js');
    const JSZip = window.JSZip;
    const x = await (await JSZip.loadAsync(f)).file('content.xml')?.async('string');
    if (!x)
        throw new Error('El archivo no es un documento ODT válido.');
    const d = new DOMParser().parseFromString(x, 'application/xml'), T = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
    const body = d.getElementsByTagNameNS('urn:oasis:names:tc:opendocument:xmlns:office:1.0', 'text')[0];
    if (!body)
        return '';
    const txt = (el) => Array.from(el.childNodes).map(n => n.nodeType === 3 ? esc(n.textContent ?? '') : n.localName === 'line-break' ? '<br>' : n.localName === 's' || n.localName === 'tab' ? ' ' : txt(n)).join('');
    let html = '';
    const walk = (el) => Array.from(el.children).forEach(c => {
        if (c.namespaceURI !== T) {
            walk(c);
            return;
        }
        if (c.localName === 'h')
            html += `<${c.getAttributeNS(T, 'outline-level') === '1' ? 'h1' : 'h2'}>${txt(c)}</${c.getAttributeNS(T, 'outline-level') === '1' ? 'h1' : 'h2'}>`;
        else if (c.localName === 'p')
            html += `<p>${txt(c) || '<br>'}</p>`;
        else if (c.localName === 'list') {
            html += '<ul>';
            Array.from(c.getElementsByTagNameNS(T, 'p')).forEach(p => html += `<li>${txt(p)}</li>`);
            html += '</ul>';
        }
        else
            walk(c);
    });
    walk(body);
    return html;
}
/** RTF → texto plano (quita los códigos de control). */
function rtfToText(s) {
    return s.replace(/\\par[d]?/g, '\n').replace(/\\'([0-9a-f]{2})/gi, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\u(-?\d+)\??/g, (_, n) => String.fromCharCode(Number(n) < 0 ? Number(n) + 65536 : Number(n)))
        .replace(/\{\\\*[^{}]*\}/g, '').replace(/\{\\(fonttbl|colortbl|stylesheet|info)[\s\S]*?\}\s*\}/g, '').replace(/\\[a-z]+-?\d* ?/gi, '').replace(/[{}]/g, '').replace(/\n{3,}/g, '\n\n').trim();
}
const textToHtml = (t) => t.replace(/\r\n?/g, '\n').split(/\n{2,}/).map(p => `<p>${esc(p).replace(/\n/g, '<br>') || '<br>'}</p>`).join('');
/** Extensiones de documento de texto que se convierten en páginas. */
export const TEXT_DOC_RX = /\.(docx|docm|dotx|odt|ott|txt|text|md|markdown|rtf|html?|xhtml|log|json|xml|yaml|yml|ini|pptx|ppsx|odp|epub|eml|srt|vtt|tex)$/i;
/** Cualquier documento de texto compatible → HTML del editor. */
export async function anyDocToHtml(f) {
    const n = f.name.toLowerCase();
    if (/\.docx$/.test(n) || /wordprocessingml/.test(f.type))
        return docxToHtml(f);
    if (/\.odt$/.test(n) || /opendocument\.text/.test(f.type))
        return odtToHtml(f);
    if (/\.(pptx|ppsx)$/.test(n) || /presentationml/.test(f.type))
        return slidesToHtml(f, 'pptx');
    if (/\.odp$/.test(n) || /opendocument\.presentation/.test(f.type))
        return slidesToHtml(f, 'odp');
    if (/\.epub$/.test(n) || /epub/.test(f.type))
        return epubToHtml(f);
    if (/\.eml$/.test(n) || f.type === 'message/rfc822')
        return emlToHtml(await f.text());
    if (await isZip(f)) {
        try {
            return await docxToHtml(f);
        }
        catch {
            return odtToHtml(f);
        }
    }
    const raw = await f.text();
    if (/\.rtf$/.test(n) || raw.startsWith('{\\rtf'))
        return textToHtml(rtfToText(raw));
    if (/\.html?$/.test(n) || /text\/html/.test(f.type)) {
        const d = new DOMParser().parseFromString(raw, 'text/html');
        d.querySelectorAll('script,style,noscript').forEach(e => e.remove());
        return textToHtml(d.body.innerText || d.body.textContent || '');
    }
    return textToHtml(raw);
}
async function zipOf(f) { await loadVendor('vendor/jszip.min.js'); return window.JSZip.loadAsync(f); }
/** PowerPoint u OpenDocument de presentación → una sección por diapositiva. */
async function slidesToHtml(f, kind) {
    const z = await zipOf(f);
    let html = '';
    if (kind === 'pptx') {
        const names = Object.keys(z.files).filter(k => /^ppt\/slides\/slide\d+\.xml$/.test(k)).sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]));
        for (const [i, n] of names.entries()) {
            const d = new DOMParser().parseFromString(await z.file(n).async('string'), 'application/xml');
            const paras = Array.from(d.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/main', 'p')).map(p => Array.from(p.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/main', 't')).map(t => t.textContent).join('')).filter(Boolean);
            html += `<h2>${i + 1}. ${esc(paras[0] ?? '')}</h2>` + (paras.length > 1 ? `<ul>${paras.slice(1).map(p => `<li>${esc(p)}</li>`).join('')}</ul>` : '');
        }
    }
    else {
        const d = new DOMParser().parseFromString(await z.file('content.xml').async('string'), 'application/xml');
        Array.from(d.getElementsByTagNameNS('urn:oasis:names:tc:opendocument:xmlns:drawing:1.0', 'page')).forEach((pg, i) => {
            const paras = Array.from(pg.getElementsByTagNameNS('urn:oasis:names:tc:opendocument:xmlns:text:1.0', 'p')).map(p => p.textContent ?? '').filter(Boolean);
            html += `<h2>${i + 1}. ${esc(paras[0] ?? '')}</h2>` + (paras.length > 1 ? `<ul>${paras.slice(1).map(p => `<li>${esc(p)}</li>`).join('')}</ul>` : '');
        });
    }
    return html || '<p><br></p>';
}
/** Libro EPUB → texto de sus capítulos (máx. 400 párrafos). */
async function epubToHtml(f) {
    const z = await zipOf(f);
    const cont = new DOMParser().parseFromString(await z.file('META-INF/container.xml').async('string'), 'application/xml');
    const opfPath = cont.querySelector('rootfile')?.getAttribute('full-path') ?? '';
    const opf = new DOMParser().parseFromString(await z.file(opfPath).async('string'), 'application/xml'), base = opfPath.replace(/[^/]*$/, '');
    const man = new Map(Array.from(opf.querySelectorAll('manifest > item')).map(i => [i.getAttribute('id'), i.getAttribute('href')]));
    let html = '', n = 0;
    for (const it of Array.from(opf.querySelectorAll('spine > itemref'))) {
        const href = man.get(it.getAttribute('idref'));
        if (!href)
            continue;
        const file = z.file(base + decodeURIComponent(href));
        if (!file)
            continue;
        const doc = new DOMParser().parseFromString(await file.async('string'), 'text/html');
        for (const el of Array.from(doc.body.querySelectorAll('h1,h2,h3,p,li'))) {
            const t = (el.textContent ?? '').trim();
            if (!t)
                continue;
            html += /^H/.test(el.tagName) ? `<h2>${esc(t)}</h2>` : `<p>${esc(t)}</p>`;
            if (++n > 400)
                return html;
        }
    }
    return html;
}
/** Correo .eml → encabezados y cuerpo de texto. */
function emlToHtml(raw) {
    const [head, ...rest] = raw.replace(/\r\n/g, '\n').split(/\n\n/);
    let body = rest.join('\n\n');
    const hdr = (k) => head.match(new RegExp(`^${k}:\\s*(.*(?:\\n[ \\t].*)*)`, 'im'))?.[1].replace(/\n[ \t]/g, ' ').replace(/=\?[^?]+\?[BQ]\?([^?]*)\?=/gi, (_, x) => { try {
        return decodeURIComponent(x.replace(/_/g, ' ').replace(/=([0-9A-F]{2})/gi, '%$1'));
    }
    catch {
        return x;
    } }) ?? '';
    const plain = body.match(/content-type:\s*text\/plain[\s\S]*?\n\n([\s\S]*?)(\n--|$)/i);
    if (plain)
        body = plain[1];
    if (/quoted-printable/i.test(raw))
        body = body.replace(/=\n/g, '').replace(/=([0-9A-F]{2})/gi, (_, x) => String.fromCharCode(parseInt(x, 16)));
    try {
        if (/content-transfer-encoding:\s*base64/i.test(raw) && /^[A-Za-z0-9+/=\s]+$/.test(body.trim()))
            body = decodeURIComponent(escape(atob(body.replace(/\s/g, ''))));
    }
    catch { /* */ }
    body = body.replace(/<[^>]+>/g, ' ');
    return `<h1>${esc(hdr('Subject'))}</h1><p><b>${esc(hdr('From'))}</b><br>${esc(hdr('To'))}<br>${esc(hdr('Date'))}</p>` + textToHtml(body);
}
/** Word → HTML del editor (párrafos, títulos, listas, negrita, cursiva, subrayado). */
export async function docxToHtml(f) {
    await loadVendor('vendor/jszip.min.js');
    const JSZip = window.JSZip;
    const z = await JSZip.loadAsync(f), x = await z.file('word/document.xml')?.async('string');
    if (!x)
        throw new Error('El archivo no es un Word (.docx) válido.');
    const doc = new DOMParser().parseFromString(x, 'application/xml'), W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    let html = '', list = '';
    doc.getElementsByTagNameNS(W, 'p') && Array.from(doc.getElementsByTagNameNS(W, 'p')).forEach(p => {
        const style = p.getElementsByTagNameNS(W, 'pStyle')[0]?.getAttributeNS(W, 'val') ?? p.getElementsByTagNameNS(W, 'pStyle')[0]?.getAttribute('w:val') ?? '';
        const isList = p.getElementsByTagNameNS(W, 'numPr').length > 0;
        let inner = '';
        Array.from(p.getElementsByTagNameNS(W, 'r')).forEach(r => {
            const pr = r.getElementsByTagNameNS(W, 'rPr')[0];
            let t = Array.from(r.childNodes).map(n => n.localName === 't' ? esc(n.textContent ?? '') : n.localName === 'br' ? '<br>' : n.localName === 'tab' ? ' ' : '').join('');
            if (!t)
                return;
            if (pr?.getElementsByTagNameNS(W, 'b').length)
                t = `<b>${t}</b>`;
            if (pr?.getElementsByTagNameNS(W, 'i').length)
                t = `<i>${t}</i>`;
            if (pr?.getElementsByTagNameNS(W, 'u').length)
                t = `<u>${t}</u>`;
            inner += t;
        });
        if (isList) {
            if (!list) {
                html += '<ul>';
                list = 'ul';
            }
            html += `<li>${inner}</li>`;
            return;
        }
        if (list) {
            html += '</ul>';
            list = '';
        }
        const tag = /heading1|ttulo1|title/i.test(style) ? 'h1' : /heading[2-9]|ttulo[2-9]|subtitle/i.test(style) ? 'h2' : 'p';
        html += `<${tag}>${inner || '<br>'}</${tag}>`;
    });
    if (list)
        html += '</ul>';
    return html;
}
export async function textEditScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    const key = `scanpro.texto.${doc?.id ?? 'nuevo'}`;
    let title = doc?.name ?? 'Documento';
    const ed = h('div', { class: 'te-page', contenteditable: 'true', spellcheck: 'true', 'aria-label': 'Texto del documento' });
    let draft = null;
    try {
        draft = localStorage.getItem(key);
    }
    catch { /* */ }
    if (params.tpl) {
        try {
            draft = localStorage.getItem('scanpro.textedit.draft');
            title = localStorage.getItem('scanpro.textedit.title') ?? title;
            localStorage.removeItem('scanpro.textedit.draft');
            if (draft)
                localStorage.setItem(key, draft);
        }
        catch { /* */ }
    }
    if (draft)
        ed.innerHTML = draft;
    else if (doc) {
        const pages = await getPages(doc);
        const text = pages.map(p => p.ocrText ?? '').filter(Boolean).join('\n\n');
        ed.innerHTML = text ? text.split(/\n{2,}/).map(par => `<p>${esc(par).replace(/\n/g, '<br>')}</p>`).join('') : '<p><br></p>';
    }
    else
        ed.innerHTML = '<h1>Título</h1><p>Escribe aquí…</p>';
    const hasText = !!ed.textContent?.trim();
    let timer = 0;
    ed.addEventListener('input', () => { clearTimeout(timer); timer = window.setTimeout(() => { try {
        localStorage.setItem(key, ed.innerHTML);
    }
    catch { /* */ } }, 600); });
    const cmd = (c, v) => { ed.focus(); document.execCommand(c, false, v); };
    const tb = (label, title2, run, style = '') => h('button', { 'aria-label': title2, title: title2, style, onmousedown: (e) => e.preventDefault(), onclick: run }, label);
    const save = (kind) => actionSheet(kind === 'docx' ? 'Guardar como Word' : 'Guardar como PDF', [
        { icon: 'download', label: 'Guardar en el teléfono', run: () => void out(kind, false) },
        { icon: 'share', label: 'Compartir', run: () => void out(kind, true) },
    ]);
    const out = async (kind, share) => {
        const b = busy(kind === 'docx' ? 'Creando Word…' : 'Creando PDF…');
        try {
            const bl = blocks(ed), f = kind === 'docx' ? await toDocx(bl, title) : await toPdf(bl, title);
            b.done();
            if (share)
                await shareFiles([f], title);
            else {
                const where = await downloadFiles([f]);
                toast(where ? `Guardado en ${where}` : 'Descarga iniciada');
            }
            play('success');
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 4500);
        }
    };
    const openWord = async () => {
        const [f] = await pickFiles({ accept: '.docx,.odt,.rtf,.txt,.md,.html,.htm,.csv,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.oasis.opendocument.text,text/*' });
        if (!f)
            return;
        try {
            ed.innerHTML = await anyDocToHtml(f);
            title = f.name.replace(/\.[a-z0-9]+$/i, '');
            try {
                localStorage.setItem(key, ed.innerHTML);
            }
            catch { /* */ }
            toast('Word abierto');
        }
        catch (e) {
            toast(e.message, 'error');
        }
    };
    return h('div', { class: 'screen' }, topbar(doc ? doc.name : 'Editor de texto', { back: true, solid: true }), h('div', { class: 'content stack' }, doc && !hasText ? note(h('span', null, 'Este documento aún no tiene texto. ', h('button', { class: 'accent', style: 'font-weight:700', onclick: () => go('ocr', { id: doc.id }) }, 'Reconocer texto (OCR)'))) : null, h('div', { class: 'te-tools' }, tb('B', 'Negrita', () => cmd('bold')), tb('I', 'Cursiva', () => cmd('italic'), 'font-style:italic'), tb('U', 'Subrayado', () => cmd('underline'), 'text-decoration:underline'), tb('H1', 'Título', () => cmd('formatBlock', 'H1')), tb('H2', 'Subtítulo', () => cmd('formatBlock', 'H2')), tb('¶', 'Párrafo', () => cmd('formatBlock', 'P')), tb('•', 'Lista', () => cmd('insertUnorderedList')), tb('1.', 'Lista numerada', () => cmd('insertOrderedList')), tb('↶', 'Deshacer', () => cmd('undo')), tb('↷', 'Rehacer', () => cmd('redo'))), ed, h('div', { class: 'btn-row' }, btn('Word', () => save('docx'), 'secondary', { icon: 'fileWord' }), btn('PDF', () => save('pdf'), 'primary', { icon: 'filePdf' })), h('div', { class: 'btn-row' }, btn('Guardar en ScanPro', async () => { const b = busy('Guardando…'); try {
        const pages = await renderBlocks(blocks(ed));
        const np = [];
        for (const pg of pages) {
            const c = await blobToCanvas(new Blob([pg.jpeg], { type: 'image/jpeg' }));
            np.push({ ...(await canvasToPage(c, pg.lines.map(l => l.t).join('\n'))), ocrLines: pg.lines });
        }
        const d = await newDoc(title, np);
        b.done();
        toast('Guardado en tus documentos');
        go('doc', { id: d.id });
    }
    catch (e) {
        b.done();
        toast(e.message, 'error');
    } }, 'secondary', { icon: 'download' }), nativeHas('dictate') ? btn('Dictar', async () => { const r = await nativeDictate(); if (r.startsWith('ok:')) {
        ed.focus();
        document.execCommand('insertText', false, ' ' + r.slice(3));
    } }, 'secondary', { icon: 'mic' }) : null), btn('Abrir un documento (Word, ODT, RTF, TXT)', () => void openWord(), 'ghost', { block: true, icon: 'upload' })));
}
