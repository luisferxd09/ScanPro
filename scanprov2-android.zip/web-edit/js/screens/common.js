import { play } from '../core/sounds.js';
// Piezas compartidas entre pantallas: elementos de documento, menús, selector e importación.
import { h, ic, fmtDate, pagesLabel, pickFiles, uid } from '../ui/dom.js';
import { actionSheet, confirmDialog, thumbEl, toast, busy, sheet, btn, emptyState } from '../ui/components.js';
import { go } from '../core/router.js';
import { listDocs, getPages, deleteDoc, patchDoc, listFolders, putFolder } from '../core/db.js';
import { startSession, addFile, addCapture, getSession, scheduleRender } from '../core/session.js';
import { validateName } from '../core/names.js';
import { pdfToImages } from '../core/pdfimport.js';
import { toDecodableImages, IMAGE_RX, SHEET_RX, sheetToPages, unzipFiles } from '../core/formats.js';
import { hasNativeScanner, nativeScan } from '../core/native.js';
import { getSettings } from '../core/settings.js';
import { tipOnce } from '../ui/tour.js';
import { tagMenu, tagDots, setExpiry, togglePrivate, LIFE } from '../tools/life.js';
import { metaOf, setMeta, isPrivate } from '../core/meta.js';
import { anyDocToHtml, blocks, renderBlocks, TEXT_DOC_RX } from './textedit.js';
/** Miniatura de la primera página de un documento (se carga en segundo plano). */
export function docThumb(doc, cls = 'thumb') {
    const el = thumbEl(null, cls + ' loading');
    void getPages({ ...doc, pageIds: doc.pageIds.slice(0, 1) }).then(([p]) => {
        if (p)
            el.replaceWith(thumbEl(p.thumb, cls, `Primera página de ${doc.name}`));
    }).catch(() => { });
    return el;
}
export function docSub(doc) {
    return `${fmtDate(doc.updatedAt)}  ·  ${pagesLabel(doc.pageIds.length)}`;
}
export function docItem(doc, refresh, highlight) {
    const item = h('div', { class: 'doc-item', role: 'button', tabindex: '0', onclick: () => go('doc', { id: doc.id }), onkeydown: (e) => { if (e.key === 'Enter')
            go('doc', { id: doc.id }); } }, docThumb(doc), h('div', { class: 'meta' }, h('div', { class: 'name' }, doc.name, doc.favorite ? ic('star', 'sm filled star') : null, tagDots(doc.id)), h('div', { class: 'sub' }, docSub(doc)), highlight ? h('div', { class: 'sub ellipsis' }, highlight) : null), h('button', { class: 'icon-btn', 'aria-label': `Acciones de ${doc.name}`, onclick: (e) => { e.stopPropagation(); docMenu(doc, refresh); } }, ic('moreV')));
    return item;
}
export function docTile(doc, refresh) {
    return h('div', { class: 'doc-tile tap', role: 'button', tabindex: '0', onclick: () => go('doc', { id: doc.id }) }, docThumb(doc, 'tile-img'), h('div', { class: 'tile-meta' }, h('div', { class: 'ellipsis', style: 'font-weight:500' }, doc.name), h('div', { class: 'xs faint' }, pagesLabel(doc.pageIds.length))), h('button', { class: 'icon-btn tile-menu', 'aria-label': `Acciones de ${doc.name}`, onclick: (e) => { e.stopPropagation(); docMenu(doc, refresh); } }, ic('moreV')));
}
export function docMenu(doc, refresh) {
    actionSheet(null, [
        { icon: 'eye', label: 'Abrir', run: () => go('doc', { id: doc.id }) },
        { icon: 'pencil', label: 'Cambiar nombre', run: () => go('rename', { id: doc.id }) },
        { icon: 'star', label: doc.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos', run: async () => { await patchDoc(doc.id, { favorite: !doc.favorite }); refresh(); } },
        { icon: 'folderMove', label: 'Mover a carpeta', run: () => moveToFolder(doc, refresh) },
        { icon: 'share', label: 'Compartir', run: () => go('share', { id: doc.id }) },
        { icon: 'merge', label: 'Combinar con otro documento', run: () => go('merge', { id: doc.id }) },
        { icon: 'tag', label: 'Etiquetas', run: () => tagMenu(doc, refresh) },
        { icon: 'clock', label: metaOf(doc.id).expires ? 'Cambiar vencimiento' : 'Poner fecha de vencimiento', sub: 'Te avisamos 7 días antes', run: () => void setExpiry(doc, refresh) },
        { icon: 'wallet', label: 'Mover a una carpeta de vida', run: () => actionSheet('Carpeta de vida', LIFE.map(l => ({ icon: l.icon, label: l.name, run: () => { setMeta(doc.id, { life: l.id }); toast(`En «${l.name}»`); } }))) },
        { icon: 'lock', label: isPrivate(doc.id) ? 'Sacar de la carpeta privada' : 'Mover a la carpeta privada', run: () => togglePrivate(doc, refresh) },
        { icon: 'trash', label: 'Eliminar', danger: true, run: async () => { if (await confirmDelete(doc))
                refresh(); } },
    ], h('div', { class: 'row', style: 'margin-bottom:8px' }, docThumb(doc), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:600' }, doc.name), h('div', { class: 'xs faint' }, docSub(doc)))));
}
/** Confirmación de borrado con nombre y miniatura. Devuelve true si se eliminó. */
export async function confirmDelete(doc) {
    const ok = await confirmDialog({
        title: 'Eliminar documento', icon: 'trash', danger: true, confirm: 'Eliminar',
        text: '¿Seguro que quieres eliminar este documento? Se borrarán todas sus páginas y no podrá recuperarse.',
        body: h('div', { class: 'file-card' }, docThumb(doc), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:600' }, doc.name), h('div', { class: 'xs faint' }, pagesLabel(doc.pageIds.length)))),
    });
    if (!ok)
        return false;
    try {
        await deleteDoc(doc.id);
        play('delete');
        toast(`«${doc.name}» eliminado`);
        return true;
    }
    catch (e) {
        toast(e.message, 'error');
        return false;
    }
}
export async function moveToFolder(doc, refresh) {
    const folders = (await listFolders()).sort((a, b) => a.name.localeCompare(b.name, 'es'));
    actionSheet('Mover a carpeta', [
        { icon: 'files', label: 'Sin carpeta', sub: doc.folderId === null ? 'Ubicación actual' : undefined, run: async () => { await patchDoc(doc.id, { folderId: null }); toast('Documento movido'); refresh(); } },
        ...folders.map(f => ({ icon: 'folder', label: f.name, sub: doc.folderId === f.id ? 'Ubicación actual' : undefined, run: async () => { await patchDoc(doc.id, { folderId: f.id }); toast(`Movido a «${f.name}»`); refresh(); } })),
        { icon: 'folderPlus', label: 'Nueva carpeta…', run: async () => { const f = await newFolderDialog(); if (f) {
                await patchDoc(doc.id, { folderId: f });
                toast('Documento movido');
                refresh();
            } } },
    ]);
}
/** Diálogo para crear una carpeta (paquete). Devuelve su id. */
export function newFolderDialog() {
    return new Promise(async (resolve) => {
        const existing = (await listFolders()).map(f => f.name);
        let result = null;
        const input = h('input', { type: 'text', maxlength: '80', placeholder: 'Ej.: Facturas 2026', 'aria-label': 'Nombre de la carpeta' });
        const wrap = h('div', { class: 'input-wrap' }, ic('folder', 'sm faint'), input);
        const err = h('div', { class: 'error', role: 'alert' });
        const save = async (close) => {
            const v = validateName(input.value, existing);
            if (!v.ok) {
                wrap.classList.add('invalid');
                err.textContent = v.error.replace('documento', 'carpeta');
                return;
            }
            const id = uid();
            await putFolder({ id, name: v.name, createdAt: Date.now() });
            result = id;
            toast(`Carpeta «${v.name}» creada`);
            await close();
        };
        sheet(close => [
            h('h2', null, 'Nueva carpeta'),
            h('div', { class: 'field' }, wrap, err),
            h('div', { class: 'btn-row', style: 'margin-top:16px' }, btn('Cancelar', () => void close(), 'secondary'), btn('Crear', () => void save(close))),
        ], () => resolve(result));
        input.addEventListener('keydown', e => { if (e.key === 'Enter')
            input.closest('.sheet')?.querySelector('.btn.primary')?.click(); });
        setTimeout(() => input.focus(), 250);
    });
}
/** Selector de documento para herramientas (OCR, PDF, filtros…). */
export async function pickDocument(title, onPick) {
    const docs = (await listDocs()).sort((a, b) => b.updatedAt - a.updatedAt);
    if (!docs.length) {
        sheet(close => [emptyState('fileText', 'Aún no tienes documentos', 'Escanea o importa un documento para usar esta herramienta.', btn('Escanear ahora', async () => { await close(); newScanSheet(); }, 'primary'))]);
        return;
    }
    sheet(close => [
        h('h2', null, title),
        h('div', { class: 'doc-list' }, docs.map(d => h('button', { class: 'doc-item', onclick: async () => { await close(); onPick(d); } }, docThumb(d), h('div', { class: 'meta' }, h('div', { class: 'name' }, d.name), h('div', { class: 'sub' }, docSub(d))), ic('chevRight', 'sm faint')))),
    ]);
}
/** Hoja del botón «+»: escanear con cámara o importar. */
export function newScanSheet(targetDocId = null) {
    actionSheet(targetDocId ? 'Agregar páginas' : 'Nuevo documento', [
        { icon: 'camera', label: 'Escanear con la cámara', sub: 'Detecta bordes y endereza la hoja', run: () => scanWithCamera(targetDocId) },
        { icon: 'images', label: 'Importar fotos o documentos', sub: 'Fotos, PDF, Word, Excel, PowerPoint, EPUB, ZIP…', run: () => importImages(targetDocId) },
        { icon: 'idCard', label: 'Documento de identidad', sub: 'Cédula, DNI o licencia: ambos lados en una hoja', run: () => scanIdCard(targetDocId) },
    ]);
}
/** Escáner con cámara: el de Google (enfoque y bordes nativos) si está disponible; si no, el de ScanPro. */
let scanTarget = { target: null };
export function takeScanTarget() { const t = scanTarget; scanTarget = { target: null }; return t; }
export async function scanWithCamera(targetDocId = null, mode) {
    if (hasNativeScanner && getSettings().scanner !== 'scanpro') {
        await tipOnce('scan-google', [
            { icon: 'camera', title: 'Apunta a la hoja', text: 'Pon el documento sobre una superficie que contraste. La cámara lo detecta sola y toma la foto.' },
            { icon: 'crop', title: 'Ajusta si hace falta', text: 'Puedes mover las esquinas, girar o aplicar un filtro antes de terminar.' },
            { icon: 'layers', title: 'Varias páginas', text: 'Toca «+» para seguir escaneando hojas. Al final toca «Guardar» y vuelves a ScanPro.' },
        ]);
        scanTarget = { target: targetDocId, mode };
        const r = await nativeScan(mode === 'id' ? 2 : 0);
        if (r.startsWith('error:')) {
            scanTarget = { target: null };
            toast('El escáner de Google no está disponible en este teléfono; se usa el de ScanPro.', 'ok', 3500);
            startSession(targetDocId, mode);
            go('scan');
        }
        return;
    }
    startSession(targetDocId, mode);
    go('scan');
}
/** Foto(s) para una herramienta (QR, tarjeta, recibo…): escáner de Google o cámara del sistema. No crea documentos. */
let toolHook = null;
export function takeToolHook() { const h2 = toolHook; toolHook = null; return h2; }
export async function captureForTool(limit = 1) {
    if (hasNativeScanner && getSettings().scanner !== 'scanpro') {
        const p = new Promise(res => { toolHook = res; });
        const r = await nativeScan(limit);
        if (r.startsWith('ok'))
            return p;
        toolHook = null;
        if (r === 'cancel')
            return [];
    }
    return pickFiles({ accept: 'image/*', capture: 'environment', multiple: limit !== 1 });
}
/** Copia de documento de identidad: frente y reverso en una sola hoja a tamaño real. */
export function scanIdCard(targetDocId = null) {
    if (hasNativeScanner && getSettings().scanner !== 'scanpro')
        toast('Escanea primero el frente y luego el reverso', 'ok', 2600);
    void scanWithCamera(targetDocId, 'id');
}
/** Importa imágenes o PDF con el selector del sistema (no requiere permisos). */
export async function importImages(targetDocId = null, keepSession = false, fromScanner = false) {
    const files = await pickFiles({ accept: 'image/*,application/pdf,.pdf,.tif,.tiff,.heic,.heif,.avif,.dng,.svg,.docx,.odt,.rtf,.txt,.md,.html,.htm,.csv,.tsv,.xlsx,.ods,.pptx,.odp,.epub,.eml,.zip,.json,.xml,.jfif,.ico,.bmp,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.oasis.opendocument.text,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/epub+zip,application/zip,message/rfc822,text/*', multiple: true });
    if (files.length)
        await importFiles(files, targetDocId, keepSession, fromScanner);
}
const isPdf = (f) => f.type === 'application/pdf' || /\.pdf$/i.test(f.name);
/** Añade fotos y PDF a una sesión y abre la revisión (también para «Abrir con ScanPro»). */
export async function importFiles(files, targetDocId = null, keepSession = false, fromScanner = false, scanned = false, mode) {
    // los ZIP (que no sean Word, Excel ni presentaciones) se abren y se importa lo que traen
    const expanded = [];
    for (const f of files) {
        if (/\.zip$/i.test(f.name) || f.type === 'application/zip') {
            try {
                expanded.push(...await unzipFiles(f));
            }
            catch {
                expanded.push(f);
            }
        }
        else
            expanded.push(f);
    }
    files = expanded;
    if (!keepSession || !getSession())
        startSession(targetDocId, mode);
    const b = busy('Procesando…', true);
    let fails = 0, total = 0;
    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        try {
            if (isPdf(f)) {
                let imgs;
                try {
                    imgs = await pdfToImages(f, (k, n) => b.set(`PDF: página ${k + 1} de ${n}…`, (i + k / n) / files.length));
                }
                catch (e) {
                    if (e.message !== 'PDF_PASSWORD')
                        throw e;
                    b.done();
                    const pw = prompt(`«${f.name}» tiene contraseña. Escríbela para importarlo:`) ?? '';
                    if (!pw) {
                        fails++;
                        continue;
                    }
                    imgs = await pdfToImages(f, () => { }, pw).catch(() => { throw new Error('Contraseña incorrecta.'); });
                }
                for (const im of imgs) {
                    const dp = addCapture(im, null, false);
                    dp.filter = 'original';
                    dp.source = 'doc';
                    await dp.ready;
                    void scheduleRender(dp).catch(() => { });
                    total++;
                }
                continue;
            }
            b.set(`Procesando ${i + 1} de ${files.length}…`, i / files.length);
            // páginas que ya vienen recortadas y enderezadas por el escáner de Google
            if (scanned) {
                const dp = addCapture(f, null, false);
                dp.filter = 'original';
                dp.source = 'scan';
                await dp.ready;
                void scheduleRender(dp).catch(() => { });
                total++;
                continue;
            }
            // hojas de cálculo → páginas con tabla
            if (SHEET_RX.test(f.name) || /spreadsheetml|opendocument\.spreadsheet|text\/csv/.test(f.type)) {
                for (const pg of await sheetToPages(f)) {
                    const dp = addCapture(pg.img, null, false);
                    dp.filter = 'original';
                    dp.source = 'doc';
                    dp.ocrText = pg.text;
                    await dp.ready;
                    void scheduleRender(dp).catch(() => { });
                    total++;
                }
                continue;
            }
            // Word, ODT, RTF, TXT… → páginas A4
            if (TEXT_DOC_RX.test(f.name) || /wordprocessingml|opendocument\.text|^text\//.test(f.type)) {
                const div = document.createElement('div');
                div.innerHTML = await anyDocToHtml(f);
                const pages = await renderBlocks(blocks(div));
                for (const pg of pages) {
                    const dp = addCapture(new Blob([pg.jpeg], { type: 'image/jpeg' }), null, false);
                    dp.filter = 'original';
                    dp.source = 'doc';
                    dp.ocrText = pg.lines.map(l => l.t).join('\n');
                    dp.ocrLines = pg.lines;
                    await dp.ready;
                    void scheduleRender(dp).catch(() => { });
                    total++;
                }
                continue;
            }
            if (!f.type.startsWith('image/') && !IMAGE_RX.test(f.name) && f.type)
                throw new Error('tipo');
            for (const im of await toDecodableImages(f)) {
                const dp = await addFile(im);
                void scheduleRender(dp).catch(() => { });
                total++;
            }
        }
        catch (e) {
            fails++;
            const m = e.message;
            if (m !== 'tipo' && m !== 'formato')
                toast(m, 'error', 4000);
        }
    }
    b.done();
    if (fails)
        toast(fails === files.length ? 'No se pudo leer ningún archivo: formato no compatible o archivo dañado. Prueba con PDF, JPG, PNG, HEIC, TIFF o Word.' : `${fails} archivo(s) no se pudieron leer y se omitieron.`, 'error', 4200);
    if (fromScanner) {
        if (total)
            toast(`${total} página(s) añadida(s)`, 'ok', 1600);
        return;
    }
    if (getSession()?.pages.length)
        go('review', {}, { replace: keepSession });
}
