import { organizeLater } from '../tools/ai.js';
import { takeLifeAfterScan } from '../tools/life.js';
import { play } from '../core/sounds.js';
// Revisión del documento de identidad: frente, reverso, hoja y tamaño, con vista previa de la copia.
import { h, ic } from '../ui/dom.js';
import { btn, blobUrl, toast, busy, segmented, topbar, note, fadeImg, actionSheet } from '../ui/components.js';
import { go, setGuard, replaceBack, onLeave } from '../core/router.js';
import { saveSession, onPageReady, ensureRendered } from '../core/session.js';
import { listDocs, getDoc } from '../core/db.js';
import { validateName, uniqueName } from '../core/names.js';
import { composeIdPage } from '../core/idcard.js';
import { discardGuard } from './scanner.js';
import { importImages } from './common.js';
export async function idReviewScreen(s) {
    const names = (await listDocs(true)).map(d => d.name);
    const target = s.targetDocId ? await getDoc(s.targetDocId) : undefined;
    const opts = s.idOptions ?? (s.idOptions = { paper: 'carta', scale: 'real' });
    const input = h('input', { type: 'text', 'aria-label': 'Nombre del documento', maxlength: '100' });
    input.value = uniqueName('Documento de identidad', names);
    const wrap = h('div', { class: 'input-wrap' }, ic('idCard', 'sm faint'), input);
    const err = h('div', { class: 'error', role: 'alert' });
    input.addEventListener('input', () => { wrap.classList.remove('invalid'); err.textContent = ''; });
    const front = () => s.pages[0], back = () => s.pages[1];
    const takeBack = () => actionSheet('Tomar el reverso', [
        { icon: 'camera', label: 'Con la cámara', run: () => { if (s.viaScan)
                history.back();
            else
                go('scan', {}, { replace: true }); } },
        { icon: 'images', label: 'De la galería', run: () => importImages(s.targetDocId, true, false) },
    ]);
    const side = (label, p) => h('button', { class: 'id-side tap', 'aria-label': p ? `Editar ${label.toLowerCase()}` : `Tomar ${label.toLowerCase()}`, onclick: () => p ? go('adjust', { page: p.id, from: 'review' }) : takeBack() }, h('div', { class: 'id-img' }, p?.out ? fadeImg(blobUrl(p.out.thumb), label) : p ? ic('image') : ic('plus')), h('div', { class: 'row', style: 'justify-content:space-between' }, h('b', null, label), h('span', { class: 'xs faint' }, p ? 'Editar' : 'Falta')));
    const sides = h('div', { class: 'id-sides' });
    const preview = h('div', { style: 'display:grid;place-items:center;min-height:200px' }, ic('image'));
    let gen = 0;
    const paintPreview = async () => {
        const my = ++gen, f = front();
        if (!f)
            return;
        try {
            await ensureRendered(f);
            const b = back();
            if (b)
                await ensureRendered(b);
            if (my !== gen)
                return;
            const out = await composeIdPage(f.out.image, b?.out?.image ?? null, opts);
            if (my !== gen)
                return;
            preview.replaceChildren(h('img', { class: 'id-sheet', src: blobUrl(out.thumb), alt: 'Vista previa de la hoja con las dos caras' }));
        }
        catch (e) {
            toast(e.message, 'error');
        }
    };
    const paint = () => { sides.replaceChildren(side('Frente', front()), side('Reverso', back())); void paintPreview(); };
    const off = onPageReady(() => paint());
    onLeave(off);
    paint();
    const save = async () => {
        if (!back() && !(await new Promise(res => actionSheet('Falta el reverso', [
            { icon: 'camera', label: 'Tomar el reverso', run: () => { takeBack(); res(false); } },
            { icon: 'check', label: 'Guardar solo el frente', run: () => res(true) },
        ]))))
            return;
        let name = target?.name ?? '';
        if (!target) {
            const v = validateName(input.value, names);
            if (!v.ok) {
                wrap.classList.add('invalid');
                err.textContent = v.error;
                input.focus();
                return;
            }
            name = v.name;
        }
        const b = busy('Creando la copia…', true);
        try {
            const viaScan = !!s.viaScan;
            const id = await saveSession(name, null, (d, t) => b.set(d < t ? `Procesando ${d === 0 ? 'el frente' : 'el reverso'}…` : 'Uniendo en una hoja…', d / t));
            takeLifeAfterScan(id);
            organizeLater(id);
            setGuard(null);
            b.done();
            play('success');
            toast(target ? `Copia añadida a «${target.name}»` : `«${name}» guardado: ambas caras en una hoja`);
            if (target)
                replaceBack(viaScan ? 2 : 1, null);
            else
                replaceBack(viaScan ? 1 : 0, { name: 'doc', params: { id } });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 5000);
        }
    };
    setGuard(discardGuard);
    return h('div', { class: 'screen' }, topbar('Documento de identidad', { back: () => history.back(), solid: true }), h('div', { class: 'content stack' }, target ? note(h('span', null, 'Se añadirá como una página al final de ', h('b', null, target.name), '.')) : h('div', { class: 'field' }, h('label', null, 'Nombre'), wrap, err), sides, h('div', { class: 'field' }, h('label', null, 'Hoja'), segmented([['carta', 'Carta'], ['a4', 'A4']], opts.paper, (v) => { opts.paper = v; void paintPreview(); })), h('div', { class: 'field' }, h('label', null, 'Tamaño de la tarjeta'), segmented([['real', 'Real (como fotocopia)'], ['grande', 'Ampliado ×1,5']], opts.scale, (v) => { opts.scale = v; void paintPreview(); })), h('div', { class: 'card pad' }, preview), note('Para que se imprima a tamaño real, exporta en PDF con la misma hoja y «Sin márgenes», e imprime al 100 %.'), btn(target ? 'Añadir la copia' : 'Guardar copia en una hoja', () => void save(), 'primary', { block: true, icon: 'check' })));
}
