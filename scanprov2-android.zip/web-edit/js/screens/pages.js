import { h, ic, pagesLabel } from '../ui/dom.js';
import { topbar, iconBtn, blobUrl, confirmDialog, toast, emptyState, note, busy, fadeImg, stagger } from '../ui/components.js';
import { go } from '../core/router.js';
import { getDoc, getPages, setPageOrder, deletePage } from '../core/db.js';
import { editStoredPage } from '../core/session.js';
import { newScanSheet } from './common.js';
export async function pagesScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Páginas', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    let pages = await getPages(doc);
    const grid = h('div', { class: 'page-grid' });
    const title = h('h1', null, `${pagesLabel(pages.length)}`);
    const move = async (i, d) => {
        const j = i + d;
        if (j < 0 || j >= pages.length)
            return;
        const order = pages.map(p => p.id);
        [order[i], order[j]] = [order[j], order[i]];
        await setPageOrder(doc.id, order);
        [pages[i], pages[j]] = [pages[j], pages[i]];
        render();
    };
    const remove = async (p, i) => {
        if (pages.length <= 1) {
            toast('Un documento necesita al menos una página. Elimina el documento si ya no lo necesitas.', 'error', 4000);
            return;
        }
        const ok = await confirmDialog({ title: `Eliminar página ${i + 1}`, icon: 'trash', danger: true, confirm: 'Eliminar', text: 'La página se borrará de este documento y no podrá recuperarse.',
            body: h('div', { style: 'display:grid;place-items:center;margin-bottom:8px' }, h('img', { src: blobUrl(p.thumb), alt: '', style: 'max-height:140px;border-radius:6px' })) });
        if (!ok)
            return;
        try {
            await deletePage(doc.id, p.id);
            pages = pages.filter(x => x.id !== p.id);
            render();
            toast('Página eliminada');
        }
        catch (e) {
            toast(e.message, 'error');
        }
    };
    const edit = async (p) => {
        const b = busy('Abriendo página…');
        try {
            const dp = await editStoredPage(p.id);
            b.done();
            go('adjust', { page: dp.id, mode: 'stored' });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error');
        }
    };
    const render = () => {
        title.textContent = pagesLabel(pages.length);
        grid.replaceChildren(...pages.map((p, i) => h('div', { class: 'page-cell' }, h('div', { class: 'pc-img tap', onclick: () => edit(p) }, fadeImg(blobUrl(p.thumb), `Página ${i + 1}`), h('span', { class: 'pc-num' }, String(i + 1)), p.ocrText ? h('span', { class: 'badge ok', style: 'position:absolute;top:8px;right:8px' }, 'OCR') : null), h('div', { class: 'pc-actions' }, iconBtn('arrowLeft', 'Mover antes', () => move(i, -1)), iconBtn('pencil', 'Editar: recorte y filtros', () => edit(p)), iconBtn('type', 'Firmar o anotar', () => go('annotate', { page: p.id })), iconBtn('trash', 'Eliminar página', () => remove(p, i)), iconBtn('arrowRight', 'Mover después', () => move(i, 1))))));
        grid.querySelectorAll('.pc-actions').forEach((el, i) => {
            el.firstElementChild.disabled = i === 0;
            el.lastElementChild.disabled = i === pages.length - 1;
        });
    };
    render();
    stagger(grid);
    return h('div', { class: 'screen' }, h('header', { class: 'topbar solid' }, h('button', { class: 'back-btn', 'aria-label': 'Atrás', onclick: () => history.back() }, ic('chevLeft')), title, iconBtn('imagePlus', 'Agregar páginas', () => newScanSheet(doc.id))), h('div', { class: 'content stack' }, params.hint === 'annotate' ? note('Elige la página y toca «Firmar o anotar» (icono T).') : params.hint === 'filters' ? note('Toca una página para recortarla, rotarla o aplicarle filtros y ajustes.') : h('div', { class: 'small faint' }, `${doc.name} · usa las flechas para cambiar el orden`), grid, h('button', { class: 'btn secondary block', onclick: () => history.back() }, ic('check', 'sm'), 'Listo')));
}
