import { loc } from '../core/locale.js';
// Firmar y anotar una página: firma, texto, resaltador y lápiz. Se «imprime» sobre la imagen al guardar.
import { h, ic } from '../ui/dom.js';
import { btn, toast, busy, sheet, iconBtn, emptyState, topbar } from '../ui/components.js';
import { getPage, updatePage } from '../core/db.js';
import { decode, scaledCanvas, encodeAs } from '../imaging/process.js';
import { play } from '../core/sounds.js';
const SIG_KEY = 'scanpro.firma.v1';
let pending = null;
/** Textos que se colocan al abrir el editor (formularios llenados automáticamente), en píxeles de la página guardada. */
export function setPendingText(items, pageWidth) { pending = { items, w: pageWidth }; }
/** Hoja para dibujar la firma con el dedo. Devuelve un lienzo recortado (fondo transparente). */
function signaturePad() {
    return new Promise(resolve => {
        let result = null;
        const c = h('canvas', { class: 'sig-pad', width: 900, height: 360 }), g = c.getContext('2d');
        g.lineWidth = 6;
        g.lineCap = 'round';
        g.lineJoin = 'round';
        g.strokeStyle = '#1b1a3a';
        let drawing = false, any = false, last = [0, 0];
        const pt = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
        c.addEventListener('pointerdown', e => { drawing = true; any = true; last = pt(e); c.setPointerCapture(e.pointerId); });
        c.addEventListener('pointermove', e => { if (!drawing)
            return; const p = pt(e); g.beginPath(); g.moveTo(...last); g.lineTo(...p); g.stroke(); last = p; });
        c.addEventListener('pointerup', () => { drawing = false; });
        const trim = () => {
            const d = g.getImageData(0, 0, c.width, c.height).data;
            let x0 = c.width, y0 = c.height, x1 = 0, y1 = 0;
            for (let y = 0; y < c.height; y++)
                for (let x = 0; x < c.width; x++)
                    if (d[(y * c.width + x) * 4 + 3] > 10) {
                        x0 = Math.min(x0, x);
                        y0 = Math.min(y0, y);
                        x1 = Math.max(x1, x);
                        y1 = Math.max(y1, y);
                    }
            if (x1 <= x0)
                return null;
            const o = document.createElement('canvas');
            o.width = x1 - x0 + 16;
            o.height = y1 - y0 + 16;
            o.getContext('2d').drawImage(c, x0 - 8, y0 - 8, o.width, o.height, 0, 0, o.width, o.height);
            return o;
        };
        const saved = (() => { try {
            return localStorage.getItem(SIG_KEY);
        }
        catch {
            return null;
        } })();
        sheet(close => [
            h('h2', null, 'Tu firma'),
            h('div', { class: 'xs faint', style: 'margin-bottom:8px' }, 'Firma con el dedo dentro del recuadro.'),
            c,
            h('div', { class: 'btn-row', style: 'margin-top:12px' }, btn('Borrar', () => { g.clearRect(0, 0, c.width, c.height); any = false; }, 'secondary', { icon: 'trash' }), btn('Usar firma', async () => {
                const t = any ? trim() : null;
                if (!t) {
                    toast('Dibuja tu firma primero.', 'error');
                    return;
                }
                try {
                    localStorage.setItem(SIG_KEY, t.toDataURL('image/png'));
                }
                catch { /* */ }
                result = t;
                await close();
            }, 'primary', { icon: 'check' })),
            saved ? btn('Usar mi firma guardada', async () => { const im = new Image(); im.src = saved; await im.decode(); const o = document.createElement('canvas'); o.width = im.width; o.height = im.height; o.getContext('2d').drawImage(im, 0, 0); result = o; await close(); }, 'ghost', { block: true }) : null,
        ], () => resolve(result));
    });
}
function askText() {
    return new Promise(resolve => {
        let r = null;
        const input = h('textarea', { rows: '3', placeholder: 'Escribe el texto…', style: 'width:100%;font:inherit;padding:10px;border-radius:12px' });
        sheet(close => [h('h2', null, 'Añadir texto'), input, h('div', { class: 'btn-row', style: 'margin-top:12px' }, btn('Cancelar', () => void close(), 'secondary'), btn('Añadir', async () => { r = input.value.trim() || null; await close(); }))], () => resolve(r));
        setTimeout(() => input.focus(), 250);
    });
}
export async function annotateScreen(params) {
    const page = params.page ? await getPage(params.page) : undefined;
    if (!page)
        return h('div', { class: 'screen' }, topbar('Firmar y anotar', { back: true }), emptyState('alert', 'Página no encontrada', ''));
    const src = await decode(page.image, 1600);
    const view = h('canvas', { class: 'annot-canvas', width: src.width, height: src.height }), vg = view.getContext('2d');
    const sx = page.width / src.width; // vista → imagen completa
    vg.drawImage(src.canvas, 0, 0);
    const objs = [];
    const paper = (() => { const d = vg.getImageData(0, 0, view.width, view.height).data, W = view.width, pts = [[8, 8], [W - 9, 8], [8, view.height - 9], [W - 9, view.height - 9]]; let r = 0, g2 = 0, b = 0; for (const [x, y] of pts) {
        const i = (y * W + x) * 4;
        r += d[i];
        g2 += d[i + 1];
        b += d[i + 2];
    } return `rgb(${r / 4 | 0},${g2 / 4 | 0},${b / 4 | 0})`; })();
    let tool = 'move', color = '#1b1a3a', sel = null;
    const drawObj = (g, o, k) => {
        g.save();
        if (o.k === 'stroke') {
            g.globalAlpha = o.a;
            g.strokeStyle = o.color;
            g.lineWidth = o.w * k;
            g.lineCap = 'round';
            g.lineJoin = 'round';
            g.beginPath();
            for (let i = 0; i < o.pts.length; i += 2)
                i ? g.lineTo(o.pts[i] * k, o.pts[i + 1] * k) : g.moveTo(o.pts[i] * k, o.pts[i + 1] * k);
            g.stroke();
        }
        else if (o.k === 'img')
            g.drawImage(o.c, o.x * k, o.y * k, o.w * k, o.h * k);
        else if (o.k === 'rect') {
            g.fillStyle = '#000';
            g.fillRect(Math.min(o.x, o.x + o.w) * k, Math.min(o.y, o.y + o.h) * k, Math.abs(o.w) * k, Math.abs(o.h) * k);
        }
        else {
            g.fillStyle = o.color;
            g.font = `600 ${o.s * k}px Inter, sans-serif`;
            g.textBaseline = 'top';
            o.t.split('\n').forEach((l, i) => g.fillText(l, o.x * k, (o.y + i * o.s * 1.25) * k));
        }
        g.restore();
    };
    const bounds = (o) => {
        if (o.k === 'img')
            return [o.x, o.y, o.w, o.h];
        if (o.k === 'text') {
            vg.font = `600 ${o.s}px Inter, sans-serif`;
            const ls = o.t.split('\n');
            return [o.x, o.y, Math.max(...ls.map(l => vg.measureText(l).width)), ls.length * o.s * 1.25];
        }
        return null;
    };
    const paint = () => {
        vg.drawImage(src.canvas, 0, 0);
        for (const o of objs)
            drawObj(vg, o, 1);
        const b = sel && bounds(sel);
        if (b) {
            vg.save();
            vg.setLineDash([10, 8]);
            vg.strokeStyle = '#8c7cf7';
            vg.lineWidth = 3;
            vg.strokeRect(b[0] - 6, b[1] - 6, b[2] + 12, b[3] + 12);
            vg.restore();
        }
    };
    if (pending) {
        const k = view.width / pending.w;
        for (const it of pending.items)
            objs.push({ k: 'text', t: it.t, x: it.x * k, y: it.y * k, s: Math.max(14, it.s * k), color: '#1b1a6a' });
        pending = null;
    }
    paint();
    // gestos: dibujar con lápiz/resaltador o mover el elemento seleccionado
    let cur = null, drag = null;
    const pt = (e) => { const r = view.getBoundingClientRect(); return [(e.clientX - r.left) * view.width / r.width, (e.clientY - r.top) * view.height / r.height]; };
    view.addEventListener('pointerdown', e => {
        const p = pt(e);
        view.setPointerCapture(e.pointerId);
        if (tool === 'move') {
            sel = [...objs].reverse().find(o => { const b = bounds(o); return b && p[0] >= b[0] - 20 && p[0] <= b[0] + b[2] + 20 && p[1] >= b[1] - 20 && p[1] <= b[1] + b[3] + 20; }) ?? null;
            drag = sel ? p : null;
            paint();
            return;
        }
        cur = tool === 'redact' ? { k: 'rect', x: p[0], y: p[1], w: 0, h: 0 } : tool === 'erase' ? { k: 'stroke', color: paper, w: 34, a: 1, pts: [...p] } : tool === 'pen' ? { k: 'stroke', color, w: 4, a: 1, pts: [...p] } : { k: 'stroke', color: '#ffe14d', w: 26, a: .38, pts: [...p] };
        objs.push(cur);
        paint();
    });
    view.addEventListener('pointermove', e => {
        const p = pt(e);
        if (cur && cur.k === 'stroke') {
            cur.pts.push(...p);
            paint();
        }
        else if (cur && cur.k === 'rect') {
            cur.w = p[0] - cur.x;
            cur.h = p[1] - cur.y;
            paint();
        }
        else if (drag && sel && (sel.k === 'img' || sel.k === 'text')) {
            sel.x += p[0] - drag[0];
            sel.y += p[1] - drag[1];
            drag = p;
            paint();
        }
    });
    view.addEventListener('pointerup', () => { cur = null; drag = null; });
    const resize = (f) => { if (!sel) {
        toast('Toca primero la firma o el texto para seleccionarlo.', 'error');
        return;
    } if (sel.k === 'img') {
        sel.w *= f;
        sel.h *= f;
    }
    else if (sel.k === 'text')
        sel.s *= f; paint(); };
    const toolBtns = new Map();
    const setTool = (t) => { tool = t; toolBtns.forEach((b, k) => b.classList.toggle('active', k === t)); };
    const tb = (t, icon, label) => { const b = h('button', { class: 'tool-btn', onclick: () => setTool(t) }, ic(icon), label); toolBtns.set(t, b); return b; };
    const addStamp = (word) => {
        const w = 640, hh = 260, c = document.createElement('canvas');
        c.width = w;
        c.height = hh;
        const g = c.getContext('2d');
        g.strokeStyle = '#c4161c';
        g.fillStyle = '#c4161c';
        g.lineWidth = 12;
        g.beginPath();
        g.roundRect(10, 10, w - 20, hh - 20, 26);
        g.stroke();
        g.textAlign = 'center';
        g.font = '800 92px Helvetica, Arial';
        g.fillText(word, w / 2, 125);
        g.font = '600 46px Helvetica, Arial';
        g.fillText(new Date().toLocaleString(loc(), { dateStyle: 'medium', timeStyle: 'short' }), w / 2, 200);
        const ww = view.width * .4, o = { k: 'img', c, x: view.width * .55, y: view.height * .08, w: ww, h: ww * hh / w };
        objs.push(o);
        sel = o;
        setTool('move');
        paint();
    };
    const save = async () => {
        if (!objs.length) {
            history.back();
            return;
        }
        const b = busy('Guardando…');
        try {
            const full = await decode(page.image, 99999), g = full.canvas.getContext('2d');
            for (const o of objs)
                drawObj(g, o, sx);
            const image = await encodeAs(full.canvas, 'image/jpeg', .92), thumb = await encodeAs(scaledCanvas(full.canvas, 360), 'image/jpeg', .8);
            await updatePage({ ...page, image, thumb });
            b.done();
            play('success');
            toast('Página guardada');
            history.back();
        }
        catch (e) {
            b.done();
            toast(e.message, 'error');
        }
    };
    const root = h('div', { class: 'editor' }, h('header', { class: 'topbar solid' }, h('button', { class: 'back-btn', 'aria-label': 'Cancelar', onclick: () => history.back() }, ic('x')), h('h1', { style: 'text-align:center' }, 'Firmar y anotar'), btn('Guardar', () => void save(), 'primary', { sm: true, icon: 'check' })), h('div', { class: 'stage annot-stage' }, view), h('div', { class: 'editor-bar' }, h('div', { class: 'tool-row' }, h('button', { class: 'tool-btn', onclick: async () => { const s = await signaturePad(); if (!s)
            return; const w = view.width * .38, hh = w * s.height / s.width; const o = { k: 'img', c: s, x: view.width * .5, y: view.height * .78, w, h: hh }; objs.push(o); sel = o; setTool('move'); paint(); toast('Arrastra la firma a su lugar', 'ok', 2000); } }, ic('pencil'), 'Firma'), h('button', { class: 'tool-btn', onclick: async () => { const t = await askText(); if (!t)
            return; const o = { k: 'text', t, x: view.width * .1, y: view.height * .1, s: view.width * .035, color }; objs.push(o); sel = o; setTool('move'); paint(); } }, ic('type'), 'Texto'), tb('mark', 'droplet', 'Resaltar'), tb('pen', 'wand', 'Dibujar'), tb('move', 'hand', 'Mover')), h('div', { class: 'tool-row' }, tb('redact', 'eye', 'Tachar'), tb('erase', 'eraser', 'Corrector'), h('button', { class: 'tool-btn', onclick: () => addStamp('RECIBIDO') }, ic('stamp'), 'Recibido'), h('button', { class: 'tool-btn', onclick: () => { const o = { k: 'text', t: new Date().toLocaleDateString(loc()), x: view.width * .6, y: view.height * .85, s: view.width * .03, color }; objs.push(o); sel = o; setTool('move'); paint(); } }, ic('clock'), 'Fecha'), h('button', { class: 'tool-btn', onclick: () => { const o = { k: 'text', t: '✓', x: view.width * .45, y: view.height * .45, s: view.width * .06, color }; objs.push(o); sel = o; setTool('move'); paint(); } }, ic('check'), 'Marca')), h('div', { class: 'tool-row' }, ...['#1b1a3a', '#2f5bd8', '#d83a3a', '#2a9d5b'].map(c => h('button', { class: 'color-dot', style: `background:${c}`, 'aria-label': 'Color', onclick: () => { color = c; if (sel?.k === 'text') {
            sel.color = c;
            paint();
        } } })), iconBtn('minus', 'Más pequeño', () => resize(1 / 1.15)), iconBtn('plus', 'Más grande', () => resize(1.15)), iconBtn('rotateCcw', 'Deshacer', () => { objs.pop(); sel = null; paint(); }), iconBtn('trash', 'Quitar seleccionado', () => { if (sel) {
        objs.splice(objs.indexOf(sel), 1);
        sel = null;
        paint();
    } }))));
    setTool('move');
    return root;
}
