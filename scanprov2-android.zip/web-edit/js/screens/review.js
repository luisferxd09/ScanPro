import { organizeLater } from '../tools/ai.js';
import { takeLifeAfterScan } from '../tools/life.js';
import { play } from '../core/sounds.js';
// Revisión antes de guardar: orden, eliminación, edición, nombre y carpeta.
import { h, ic } from '../ui/dom.js';
import { btn, blobUrl, toast, busy, iconBtn, actionSheet, confirmDialog, sheet, topbar, fadeImg, stagger } from '../ui/components.js';
import { go, setGuard, replaceBack, onLeave } from '../core/router.js';
import { getSession, saveSession, removePage, onPageReady, ensureRendered } from '../core/session.js';
import { listDocs, listFolders, getDoc } from '../core/db.js';
import { validateName, defaultDocName, uniqueName } from '../core/names.js';
import { FILTERS } from '../imaging/filters.js';
import { BLURRY } from '../imaging/quality.js';
import { discardGuard } from './scanner.js';
import { importImages, newFolderDialog } from './common.js';
import { idReviewScreen } from './idreview.js';
export async function reviewScreen() {
    const s = getSession();
    if (!s || !s.pages.length) {
        setTimeout(() => go('home', {}, { replace: true }));
        return h('div');
    }
    // la detección de la última foto puede estar terminando: se espera (dura décimas de segundo)
    await Promise.allSettled(s.pages.map(p => p.ready));
    if (!s.pages.length) {
        setTimeout(() => go('home', {}, { replace: true }));
        return h('div');
    }
    if (s.mode === 'id')
        return idReviewScreen(s);
    const names = (await listDocs(true)).map(d => d.name);
    let folders = await listFolders();
    const target = s.targetDocId ? await getDoc(s.targetDocId) : undefined;
    let folderId = null;
    const input = h('input', { type: 'text', 'aria-label': 'Nombre del documento', maxlength: '100' });
    input.value = uniqueName(defaultDocName(), names);
    const wrap = h('div', { class: 'input-wrap' }, ic('fileText', 'sm faint'), input);
    const err = h('div', { class: 'error', role: 'alert' });
    input.addEventListener('input', () => { wrap.classList.remove('invalid'); err.textContent = ''; });
    const folderChip = h('button', { class: 'chip' });
    const paintFolder = () => folderChip.replaceChildren(ic('folder', 'sm'), folderId ? folders.find(f => f.id === folderId)?.name ?? 'Carpeta' : 'Sin carpeta', ic('chevDown', 'sm'));
    folderChip.addEventListener('click', () => actionSheet('Guardar en', [
        { icon: 'files', label: 'Sin carpeta', run: () => { folderId = null; paintFolder(); } },
        ...folders.map(f => ({ icon: 'folder', label: f.name, run: () => { folderId = f.id; paintFolder(); } })),
        { icon: 'folderPlus', label: 'Nueva carpeta…', run: async () => { const id = await newFolderDialog(); if (id) {
                folders = await listFolders();
                folderId = id;
                paintFolder();
            } } },
    ]));
    paintFolder();
    const list = h('div', { class: 'review-strip' });
    const title = h('h1');
    const thumbFor = (p) => p.out ? fadeImg(blobUrl(p.out.thumb), '') : ic('image');
    const thumbs = new Map();
    const off = onPageReady(p => {
        const t = thumbs.get(p.id);
        if (!t)
            return;
        // si cambió el encuadre (p. ej. tras recortar), se repinta la fila completa
        if (t.dataset.corners !== String(p.corners)) {
            render();
            return;
        }
        t.classList.remove('loading');
        t.replaceChildren(thumbFor(p));
    });
    onLeave(off);
    // si alguna página aún no tiene resultado (p. ej. importada), se calcula en segundo plano
    for (const p of s.pages)
        if (!p.out && !p.outP)
            void ensureRendered(p).catch(() => { });
    const render = () => {
        title.textContent = `${s.pages.length} página(s)`;
        list.replaceChildren(...s.pages.map((p, i) => {
            const up = iconBtn('arrowUp', 'Subir', () => { [s.pages[i - 1], s.pages[i]] = [s.pages[i], s.pages[i - 1]]; render(); });
            const down = iconBtn('arrowDown', 'Bajar', () => { [s.pages[i + 1], s.pages[i]] = [s.pages[i], s.pages[i + 1]]; render(); });
            up.disabled = i === 0;
            down.disabled = i === s.pages.length - 1;
            const th = h('button', { class: 'thumb' + (p.out ? '' : ' loading'), 'aria-label': `Editar página ${i + 1}`, onclick: () => go('adjust', { page: p.id, from: 'review' }) }, thumbFor(p));
            th.dataset.corners = String(p.corners);
            thumbs.set(p.id, th);
            const row = h('div', { class: 'review-item' }, th, h('div', { class: 'ri-main' }, h('div', { style: 'font-weight:600' }, `Página ${i + 1}`), h('div', { class: 'xs faint' }, `${FILTERS.find(f => f.id === p.filter)?.label ?? ''}${p.rotation ? ` · ${p.rotation}°` : ''}`), h('div', { class: 'row', style: 'gap:6px;margin-top:6px;flex-wrap:wrap' }, p.source === 'scan' ? h('span', { class: 'badge ok' }, 'Escáner de Google') : p.source === 'doc' ? h('span', { class: 'badge ok' }, 'Documento') : p.detected ? h('span', { class: 'badge ok' }, 'Encuadre automático') : p.corners ? h('span', { class: 'badge' }, 'Recorte manual') : h('button', { class: 'badge warn', onclick: () => go('crop', { page: p.id, from: 'review' }) }, 'Sin recorte · ajustar'), p.sharp && p.sharp < BLURRY ? h('button', { class: 'badge bad', title: 'Tócala para repetirla con la cámara', onclick: () => retake(p) }, 'Poco nítida · repetir') : null)), h('div', { class: 'stack', style: 'gap:0' }, up, down), h('div', { class: 'stack', style: 'gap:0' }, iconBtn('pencil', 'Editar', () => go('adjust', { page: p.id, from: 'review' })), iconBtn('trash', 'Eliminar página', async () => {
                if (!(await confirmDialog({ title: `Eliminar página ${i + 1}`, icon: 'trash', danger: true, confirm: 'Eliminar', text: 'Esta página todavía no se ha guardado y se descartará.' })))
                    return;
                row.classList.add('removing');
                setTimeout(() => {
                    removePage(p);
                    if (!s.pages.length) {
                        history.back();
                        return;
                    }
                    render();
                }, 300);
            })));
            return row;
        }));
    };
    render();
    stagger(list);
    /** Repite una página borrosa: la descarta y vuelve a la cámara. */
    const retake = async (p) => {
        if (!(await confirmDialog({ title: 'Repetir la foto', icon: 'camera', confirm: 'Repetir', text: 'Se descartará esta página y se abrirá la cámara. Consejo: acércate hasta que la hoja llene la pantalla, sujeta firme y, si hay poca luz, enciende la linterna.' })))
            return;
        removePage(p);
        if (s.viaScan)
            history.back();
        else
            go('scan', {}, { replace: true });
    };
    const addMore = () => actionSheet('Agregar página', [
        { icon: 'camera', label: 'Con la cámara', run: () => { if (s.viaScan)
                history.back();
            else
                go('scan', {}, { replace: true }); } },
        { icon: 'images', label: 'De la galería', run: () => importImages(s.targetDocId, true, false) },
    ]);
    const save = async () => {
        let name = target?.name ?? '';
        if (!target) {
            const v = validateName(input.value, names);
            if (!v.ok) {
                wrap.classList.add('invalid');
                err.textContent = v.error + (v.suggestion ? ` Prueba «${v.suggestion}».` : '');
                input.focus();
                return;
            }
            name = v.name;
        }
        const b = busy('Guardando…', s.pages.length > 1);
        try {
            const n = s.pages.length;
            const viaScan = !!s.viaScan;
            const id = await saveSession(name, folderId, (d, t) => b.set(d < t ? `Procesando página ${d + 1} de ${t}…` : 'Guardando…', d / t));
            takeLifeAfterScan(id);
            if (!target)
                organizeLater(id);
            setGuard(null);
            b.done();
            play('success');
            toast(target ? `${n} página(s) añadida(s) a «${target.name}»` : `«${name}» guardado`);
            if (target)
                replaceBack(viaScan ? 2 : 1, null);
            else
                replaceBack(viaScan ? 1 : 0, { name: 'doc', params: { id } });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 5000);
        }
    };
    setGuard(discardGuard);
    return h('div', { class: 'screen' }, topbar(title, { back: () => history.back(), actions: [iconBtn('eye', 'Vista previa', async () => {
                const b = busy('Preparando vista previa…');
                try {
                    await Promise.all(s.pages.map(p => ensureRendered(p)));
                }
                catch (e) {
                    b.done();
                    toast(e.message, 'error');
                    return;
                }
                b.done();
                sheet(close => [h('h2', null, 'Vista previa'), h('div', { class: 'stack' }, s.pages.map((p, i) => p.out ? h('img', { src: blobUrl(p.out.image), alt: `Página ${i + 1}`, style: 'width:100%;border-radius:8px;background:#fff' }) : null)), h('div', { style: 'height:12px' }), btn('Cerrar', () => void close(), 'secondary', { block: true })]);
            })], solid: true }), h('div', { class: 'content stack' }, target ? h('div', { class: 'note' }, ic('info', 'sm'), h('div', null, 'Se añadirán al final de ', h('b', null, target.name), '.'))
        : h('div', { class: 'field' }, h('label', null, 'Nombre del documento'), wrap, err, h('div', { class: 'row', style: 'margin-top:10px' }, folderChip)), list, btn('Agregar página', addMore, 'secondary', { block: true, icon: 'plus' }), btn(target ? 'Añadir al documento' : 'Guardar documento', () => void save(), 'primary', { block: true, icon: 'check' })));
}
