import { isNative } from '../core/native.js';
import { h, ic, escapeHtml, debounce } from '../ui/dom.js';
import { topbar, btn, toast, emptyState, segmented, note, iconBtn, confirmDialog, tile } from '../ui/components.js';
import { go } from '../core/router.js';
import { getDoc, getPages, updatePage } from '../core/db.js';
import { getSettings, setSettings } from '../core/settings.js';
import { recognize, ocrOptions } from '../core/ocr.js';
import { langInfo } from '../core/locale.js';
import { copyText, shareText, canShareText, downloadFiles } from '../core/share.js';
import { fileSafe } from '../core/names.js';
/** Ejecuta OCR sobre las páginas indicadas mostrando progreso; guarda el texto en cada página. */
export async function runOcr(doc, pages, lang = getSettings().ocrLang) {
    const ctrl = new AbortController();
    const lbl = h('div', { class: 'center muted small' }, 'Preparando OCR…');
    const sub = h('div', { class: 'center xs faint' }, 'La primera vez se descarga el idioma (≈ 2–4 MB).');
    const bar = h('i');
    const el = h('div', { class: 'busy', role: 'alert', 'aria-busy': 'true' }, h('div', { class: 'card' }, h('div', { class: 'spinner' }), lbl, h('div', { class: 'progress' }, bar), sub, btn('Cancelar', () => ctrl.abort(), 'ghost', { sm: true })));
    document.body.appendChild(el);
    try {
        const { texts, lines } = await recognize(pages.map(p => p.image), lang, p => {
            lbl.textContent = p.total > 1 ? `${p.status} Página ${p.page + 1} de ${p.total}` : p.status;
            const frac = p.status.startsWith('Reconociendo') ? (p.page + p.progress) / p.total : 0.02;
            bar.style.width = `${Math.round(frac * 100)}%`;
        }, ctrl.signal);
        for (let i = 0; i < pages.length; i++) {
            pages[i] = { ...pages[i], ocrText: texts[i], ocrLang: lang, ocrLines: lines[i] };
            await updatePage(pages[i]);
        }
        const chars = texts.reduce((a, t) => a + t.length, 0);
        toast(chars ? `Texto reconocido en ${pages.length} página(s)` : 'No se encontró texto legible', chars ? 'ok' : 'error');
        void doc.id;
        return true;
    }
    catch (e) {
        toast(e.message, 'error', 5000);
        return false;
    }
    finally {
        el.remove();
    }
}
export async function ocrScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Texto OCR', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    let pages = await getPages(doc);
    let pageIdx = -1; // -1 = todo el documento
    let editing = false;
    let query = '';
    const body = h('div', { class: 'stack' });
    const search = h('input', { type: 'search', placeholder: 'Buscar en el texto…', 'aria-label': 'Buscar palabras' });
    const count = h('span', { class: 'xs faint' });
    search.addEventListener('input', debounce(() => { query = search.value.trim(); render(); }, 120));
    const fullText = () => (pageIdx < 0 ? pages : [pages[pageIdx]]).map((p, i) => (pageIdx < 0 && pages.length > 1 ? `— Página ${i + 1} —\n` : '') + (p.ocrText ?? '')).join('\n\n').trim();
    const hasAny = () => pages.some(p => p.ocrText?.trim());
    const run = async (scope) => {
        const target = scope === 'all' ? pages : [pages[Math.max(0, pageIdx)]];
        if (target.some(p => p.ocrText) && !(await confirmDialog({ title: 'Repetir OCR', icon: 'refresh', confirm: 'Repetir', text: 'Se reemplazará el texto reconocido (y tus correcciones) de ' + (scope === 'all' ? 'todo el documento.' : 'esta página.') })))
            return;
        const copy = [...target];
        if (await runOcr(doc, copy)) {
            pages = await getPages(doc);
            render();
        }
    };
    const render = () => {
        const pageSel = pages.length > 1 ? h('div', { class: 'chips' }, h('button', { class: 'chip' + (pageIdx < 0 ? ' active' : ''), onclick: () => { pageIdx = -1; render(); } }, 'Todo'), ...pages.map((p, i) => h('button', { class: 'chip' + (pageIdx === i ? ' active' : ''), onclick: () => { pageIdx = i; render(); } }, `Pág. ${i + 1}`, p.ocrText ? ic('check', 'sm') : null))) : null;
        const lang = h('div', null, h('div', { class: 'opt-label' }, 'Idioma del documento'), segmented(ocrOptions(langInfo().ocr).map(([k, l]) => [k, l]), getSettings().ocrLang, v => setSettings({ ocrLang: v })));
        if (!hasAny()) {
            body.replaceChildren(h('div', { class: 'card pad stack' }, h('div', { class: 'row' }, tile('ocr', 'lilac', true), h('div', { class: 'grow' }, h('div', { style: 'font-weight:600' }, 'Reconocer texto'), h('div', { class: 'xs faint' }, `${pages.length} página(s) · se procesa en tu teléfono`))), lang, note(isNative ? 'Las imágenes no salen del dispositivo. El motor y el idioma vienen dentro de la app: funciona sin conexión.' : 'Las imágenes no salen del dispositivo. La primera vez se descarga el motor y el idioma desde jsDelivr (requiere conexión); después funciona sin conexión.'), btn(pages.length > 1 ? 'Reconocer todo el documento' : 'Reconocer texto', () => void run('all'), 'primary', { block: true, icon: 'type' })));
            return;
        }
        const text = fullText();
        let viewer;
        if (editing && pageIdx >= 0) {
            const ta = h('textarea', { class: 'textbox', 'aria-label': 'Corregir texto' });
            ta.value = pages[pageIdx].ocrText ?? '';
            viewer = h('div', { class: 'stack' }, ta, h('div', { class: 'btn-row' }, btn('Cancelar', () => { editing = false; render(); }, 'secondary'), btn('Guardar texto', async () => { pages[pageIdx] = { ...pages[pageIdx], ocrText: ta.value, ocrLines: undefined }; await updatePage(pages[pageIdx]); editing = false; toast('Texto guardado'); render(); })));
        }
        else {
            let html = escapeHtml(text || '(Sin texto en esta página)');
            let n = 0;
            if (query) {
                const re = new RegExp(escapeHtml(query).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
                html = html.replace(re, m => { n++; return `<mark>${m}</mark>`; });
            }
            count.textContent = query ? `${n} coincidencia(s)` : '';
            viewer = h('div', { class: 'ocr-view', html });
        }
        body.replaceChildren(pageSel ?? h('span'), h('label', { class: 'search' }, ic('search', 'sm'), search, count), viewer, h('div', { class: 'btn-row' }, btn('Copiar todo', async () => { const ok = await copyText(text); toast(ok ? 'Texto copiado' : 'No se pudo copiar', ok ? 'ok' : 'error'); }, 'secondary', { icon: 'copy', sm: true }), canShareText() ? btn('Compartir', async () => { const r = await shareText(text, doc.name); if (r === 'shared')
            toast('Compartido'); }, 'secondary', { icon: 'share', sm: true }) : null, btn('TXT', () => downloadFiles([new File(['﻿' + text], `${fileSafe(doc.name)}.txt`, { type: 'text/plain;charset=utf-8' })]), 'secondary', { icon: 'download', sm: true })), h('div', { class: 'btn-row' }, pageIdx >= 0 ? btn('Corregir', () => { editing = true; render(); }, 'ghost', { icon: 'pencil', sm: true }) : null, btn(pageIdx >= 0 ? 'Repetir en esta página' : 'Repetir OCR', () => void run(pageIdx >= 0 ? 'page' : 'all'), 'ghost', { icon: 'refresh', sm: true })), lang, pages.some(p => !p.ocrText) ? note(`${pages.filter(p => !p.ocrText).length} página(s) sin reconocer. Usa «Repetir OCR» para procesar todo.`, 'warn') : h('span'));
    };
    render();
    return h('div', { class: 'screen' }, topbar(`Texto · ${doc.name}`, { back: true, actions: [iconBtn('share', 'Compartir en otro formato', () => go('share', { id: doc.id, fmt: 'txt' }))] }), h('div', { class: 'content' }, body));
}
