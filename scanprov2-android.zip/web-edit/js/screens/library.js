import { h, ic, clear, debounce } from '../ui/dom.js';
import { iconBtn, emptyState, btn, actionSheet, confirmDialog, toast, sheet, largeHeader, stagger, tile, topbar } from '../ui/components.js';
import { go } from '../core/router.js';
import { listDocs, listFolders, deleteFolder, putFolder } from '../core/db.js';
import { getSettings, setSettings } from '../core/settings.js';
import { validateName } from '../core/names.js';
import { metaOf, TAGS } from '../core/meta.js';
import { docItem, docTile, newScanSheet, newFolderDialog } from './common.js';
function snippet(text, q) {
    const i = text.toLocaleLowerCase('es').indexOf(q);
    if (i < 0)
        return undefined;
    const s = Math.max(0, i - 24);
    return (s > 0 ? '…' : '') + text.slice(s, i + q.length + 40).replace(/\s+/g, ' ') + '…';
}
export async function libraryScreen(params) {
    let tab = params.tab ?? 'all';
    const folderId = params.folder ?? null;
    let query = '';
    let tagF = null;
    let docs = [];
    let folders = [];
    const listEl = h('div');
    const chipsEl = h('div', { class: 'chips', role: 'tablist' });
    let firstPaint = true;
    const load = async () => { [docs, folders] = await Promise.all([listDocs(), listFolders()]); render(); };
    const sorted = (arr) => {
        const s = getSettings().sort;
        return [...arr].sort((a, b) => s === 'name' ? a.name.localeCompare(b.name, 'es', { numeric: true }) : s === 'created' ? b.createdAt - a.createdAt : b.updatedAt - a.updatedAt);
    };
    const renderDocs = (arr, emptyNode) => {
        if (!arr.length)
            return emptyNode;
        const q = query.toLocaleLowerCase('es');
        const el = getSettings().view === 'grid' && !q
            ? h('div', { class: 'doc-grid' }, sorted(arr).map(d => docTile(d, load)))
            : h('div', { class: 'doc-list' }, sorted(arr).map(d => docItem(d, load, q && !d.name.toLocaleLowerCase('es').includes(q) ? snippet(d.ocrText, q) : undefined)));
        return firstPaint ? stagger(el) : el;
    };
    const render = () => {
        clear(chipsEl);
        if (!folderId) {
            [['all', 'Todos'], ['folders', 'Carpetas'], ['favs', 'Favoritos']].forEach(([k, l]) => chipsEl.appendChild(h('button', { class: 'chip' + (tab === k ? ' active' : ''), role: 'tab', 'aria-selected': String(tab === k), onclick: () => { tab = k; history.replaceState({ ...history.state, route: { name: 'docs', params: { tab: k } } }, '', `#/docs?tab=${k}`); firstPaint = true; render(); } }, l)));
        }
        clear(listEl);
        const q = query.trim().toLocaleLowerCase('es');
        queueMicrotask(() => { firstPaint = false; });
        const match = (d) => (!tagF || (metaOf(d.id).tags ?? []).includes(tagF)) && (!q || d.name.toLocaleLowerCase('es').includes(q) || d.ocrText.toLocaleLowerCase('es').includes(q));
        const used = new Set(docs.flatMap(d => metaOf(d.id).tags ?? []));
        if (used.size && !folderId)
            chipsEl.appendChild(h('span', { class: 'chip-sep' }));
        if (!folderId)
            TAGS.filter(t => used.has(t.id)).forEach(t => chipsEl.appendChild(h('button', { class: 'chip tag-chip' + (tagF === t.id ? ' active' : ''), style: `--tag:${t.color}`, onclick: () => { tagF = tagF === t.id ? null : t.id; if (tagF)
                    tab = 'all'; render(); } }, h('i', { class: 'tag-dot' }), t.label)));
        if (folderId) {
            const arr = docs.filter(d => d.folderId === folderId && match(d));
            listEl.appendChild(renderDocs(arr, emptyState('folder', q ? 'Sin resultados' : 'Carpeta vacía', q ? `Nada coincide con «${query}».` : 'Mueve documentos aquí desde su menú «⋮ › Mover a carpeta» o escanea uno nuevo.')));
            return;
        }
        if (tab === 'folders' && !q) {
            const counts = new Map();
            docs.forEach(d => d.folderId && counts.set(d.folderId, (counts.get(d.folderId) ?? 0) + 1));
            const fl = [...folders].sort((a, b) => a.name.localeCompare(b.name, 'es'));
            listEl.append(btn('Nueva carpeta', async () => { if (await newFolderDialog())
                void load(); }, 'secondary', { block: true, icon: 'folderPlus' }), h('div', { style: 'height:12px' }), fl.length ? (firstPaint ? stagger : (x) => x)(h('div', { class: 'doc-list' }, fl.map((f, i) => h('div', { class: 'doc-item', role: 'button', tabindex: '0', onclick: () => go('folder', { folder: f.id }) }, tile('folder', ['lilac', 'peach', 'sky', 'rose', 'butter', 'peri'][i % 6], true), h('div', { class: 'meta' }, h('div', { class: 'name' }, f.name), h('div', { class: 'sub' }, `${counts.get(f.id) ?? 0} documento(s)`)), h('button', { class: 'icon-btn', 'aria-label': `Acciones de la carpeta ${f.name}`, onclick: (e) => { e.stopPropagation(); folderMenu(f); } }, ic('moreV')))))) : emptyState('folder', 'Sin carpetas', 'Crea carpetas (paquetes) para agrupar tus escaneos: facturas, apuntes, trámites…'));
            return;
        }
        const arr = docs.filter(d => match(d) && (tab !== 'favs' || d.favorite));
        const empty = q ? emptyState('search', 'Sin resultados', `Ningún documento coincide con «${query}» en el nombre ni en el texto reconocido.`)
            : tab === 'favs' ? emptyState('star', 'Sin favoritos', 'Marca documentos como favoritos desde su menú para encontrarlos rápido.')
                : emptyState('files', 'Todavía no hay documentos', 'Escanea tu primera hoja con la cámara o importa fotos de la galería.', btn('Escanear documento', () => newScanSheet(), 'primary', { icon: 'camera' }));
        listEl.appendChild(renderDocs(arr, empty));
    };
    const folderMenu = (f) => actionSheet(f.name, [
        { icon: 'eye', label: 'Abrir', run: () => go('folder', { folder: f.id }) },
        { icon: 'pencil', label: 'Cambiar nombre', run: () => renameFolder(f) },
        { icon: 'trash', label: 'Eliminar carpeta', sub: 'Los documentos se conservan', danger: true, run: async () => {
                if (await confirmDialog({ title: 'Eliminar carpeta', icon: 'folder', danger: true, confirm: 'Eliminar', text: `Se eliminará «${f.name}». Sus documentos NO se borran: pasarán a «Todos».` })) {
                    await deleteFolder(f.id);
                    toast('Carpeta eliminada');
                    void load();
                }
            } },
    ]);
    const renameFolder = (f) => {
        const input = h('input', { type: 'text', maxlength: '80', value: f.name, 'aria-label': 'Nombre de la carpeta' });
        const wrap = h('div', { class: 'input-wrap' }, input);
        const err = h('div', { class: 'error', role: 'alert' });
        sheet(close => [h('h2', null, 'Cambiar nombre de la carpeta'), h('div', { class: 'field' }, wrap, err),
            h('div', { class: 'btn-row', style: 'margin-top:16px' }, btn('Cancelar', () => void close(), 'secondary'), btn('Guardar', async () => {
                const v = validateName(input.value, folders.map(x => x.name), f.name);
                if (!v.ok) {
                    wrap.classList.add('invalid');
                    err.textContent = v.error.replace('documento', 'carpeta');
                    return;
                }
                await putFolder({ ...f, name: v.name });
                await close();
                toast('Carpeta renombrada');
                void load();
            }))]);
        setTimeout(() => { input.focus(); input.select(); }, 250);
    };
    const sortMenu = () => actionSheet('Ordenar y ver', [
        { icon: 'sort', label: 'Modificación reciente', sub: getSettings().sort === 'updated' ? 'Seleccionado' : undefined, run: () => { setSettings({ sort: 'updated' }); render(); } },
        { icon: 'sort', label: 'Fecha de creación', sub: getSettings().sort === 'created' ? 'Seleccionado' : undefined, run: () => { setSettings({ sort: 'created' }); render(); } },
        { icon: 'sort', label: 'Nombre (A–Z)', sub: getSettings().sort === 'name' ? 'Seleccionado' : undefined, run: () => { setSettings({ sort: 'name' }); render(); } },
        { icon: getSettings().view === 'list' ? 'grid' : 'list', label: getSettings().view === 'list' ? 'Ver en cuadrícula' : 'Ver en lista', run: () => { setSettings({ view: getSettings().view === 'list' ? 'grid' : 'list' }); render(); } },
    ]);
    const search = h('input', { type: 'search', placeholder: 'Buscar por nombre o texto…', 'aria-label': 'Buscar documentos', enterkeyhint: 'search' });
    search.addEventListener('input', debounce(() => { query = search.value; render(); }, 150));
    const clearBtn = iconBtn('xCircle', 'Borrar búsqueda', () => { search.value = ''; query = ''; clearBtn.style.visibility = 'hidden'; render(); search.focus(); });
    clearBtn.style.cssText = 'width:32px;height:32px;color:var(--text-3);visibility:hidden';
    search.addEventListener('input', () => { clearBtn.style.visibility = search.value ? 'visible' : 'hidden'; });
    const folderName = folderId ? (await listFolders()).find(f => f.id === folderId)?.name ?? 'Carpeta' : null;
    const sortBtn = iconBtn('sort', 'Ordenar y vista', sortMenu);
    const [bar, big] = folderId
        ? [topbar(folderName, { back: true, actions: [sortBtn], solid: true }), h('span')]
        : largeHeader('Mis documentos', { actions: [sortBtn] });
    const root = h('div', { class: 'screen ' + (folderId ? '' : 'with-nav') }, bar, big, h('div', { class: 'content stack' }, h('label', { class: 'search' }, ic('search', 'sm'), search, clearBtn), chipsEl, listEl));
    await load();
    return root;
}
