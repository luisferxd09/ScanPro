import { h, ic, clear } from '../ui/dom.js';
import { btn, tile, textBtn } from '../ui/components.js';
import { logoSvg, scanArtSvg } from '../ui/icons.js';
import { go } from '../core/router.js';
import { setSettings } from '../core/settings.js';
import { cameraState, requestCamera, persistState, requestPersist, CAMERA_HELP } from '../core/permissions.js';
export function onboardingScreen(params) {
    const root = h('div', { class: 'screen' });
    let step = Number(params.step ?? 0);
    const finish = () => { setSettings({ onboardingDone: true }); go('home', {}, { replace: true }); };
    const dots = () => h('div', { class: 'dots', 'aria-label': `Paso ${step + 1} de 3` }, [0, 1, 2].map(i => h('i', { class: i === step ? 'on' : '' })));
    // cada paso entra deslizando (adelante o atrás) y sus elementos aparecen escalonados
    const render = (dir = '') => {
        clear(root);
        const el = step === 0 ? welcome() : step === 1 ? about() : permissions();
        if (dir)
            el.classList.add('onb-step', dir);
        else
            el.classList.add('onb-step');
        root.appendChild(el);
    };
    const goStep = (n) => { const dir = n > step ? 'fwd' : 'bwd'; step = n; render(dir); };
    const nav = (back) => h('div', { class: 'row', style: 'height:48px;margin:0 -12px' }, back ? h('button', { class: 'back-btn', 'aria-label': 'Atrás', onclick: () => goStep(step - 1) }, ic('chevLeft'), 'Atrás') : h('span'), h('span', { class: 'grow' }), params.again ? textBtn('Cerrar', () => go('settings', {}, { replace: true })) : step < 2 ? textBtn('Omitir', () => goStep(2)) : null);
    function welcome() {
        return h('div', { class: 'onb' }, nav(false), h('div', { class: 'onb-hero enter' }, h('div', { class: 'scan-art logo-float', html: scanArtSvg() + '<div class="beam"></div>' }), h('div', { class: 'row', style: 'gap:12px;justify-content:center;margin-top:12px' }, h('span', { html: logoSvg(48) }), h('h1', { class: 'brand', style: 'margin:0;font-size:40px' }, 'Scan', h('b', null, 'Pro'))), h('div', { class: 'tag' }, 'Escanea · Organiza · Avanza'), h('p', { class: 'lead' }, 'Tus documentos, digitalizados.'), h('p', { class: 'lead2', style: 'margin:0' }, 'Escanea, organiza y comparte tus documentos en segundos.')), btn('Comenzar', () => goStep(1), 'primary', { block: true }), dots());
    }
    function about() {
        const feats = [
            ['camera', 'lilac', 'Escanea documentos con la cámara o importa imágenes de la galería.'],
            ['scan', 'peach', 'Encuadra la hoja y corrige la perspectiva automáticamente.'],
            ['filters', 'sky', 'Mejora la legibilidad con filtros y ajustes manuales.'],
            ['filePdf', 'rose', 'Convierte varias páginas a PDF, Word, JPG, PNG o WEBP.'],
            ['ocr', 'butter', 'Extrae el texto con OCR en español (e inglés).'],
            ['folder', 'peri', 'Guarda y organiza tus archivos en carpetas.'],
        ];
        return h('div', { class: 'onb' }, nav(true), h('div', { class: 'onb-body enter' }, h('h2', null, '¿Qué es Scan', h('span', { class: 'accent' }, 'Pro'), '?'), h('p', { class: 'muted center small', style: 'margin:0 0 16px' }, 'Una aplicación para digitalizar papel: mejora tus fotos para que parezcan escaneadas, reconoce el texto y lo organiza todo en tu teléfono, sin subir nada a Internet.'), h('div', { class: 'card pad', style: 'padding-top:6px;padding-bottom:6px' }, feats.map(([i, c, t]) => h('div', { class: 'feature' }, tile(i, c, true), h('span', null, t))))), h('div', { style: 'margin-top:20px' }, btn('Siguiente', () => goStep(2), 'primary', { block: true })), dots());
    }
    function permissions() {
        const camBadge = h('span', { class: 'badge' }, 'Comprobando…');
        const camHelp = h('div', { class: 'p-help' });
        const camBtn = btn('Permitir cámara', async () => {
            camBtn.disabled = true;
            const r = await requestCamera();
            paintCam(r.state, r.message);
            camBtn.disabled = false;
        }, 'secondary', { sm: true, icon: 'camera' });
        const paintCam = (s, msg) => {
            const map = {
                granted: ['Concedido', 'ok'], denied: ['Denegado', 'bad'], prompt: ['Sin solicitar', ''], unknown: ['Sin comprobar', ''],
                unsupported: ['No disponible', 'warn'], insecure: ['Requiere HTTPS', 'warn'],
            };
            const [t, c] = map[s];
            camBadge.textContent = t;
            camBadge.className = 'badge ' + c;
            camBtn.style.display = s === 'granted' || s === 'unsupported' || s === 'insecure' ? 'none' : '';
            camHelp.textContent = s === 'denied' ? `${msg ?? ''} Puedes seguir importando fotos. ${CAMERA_HELP}` :
                s === 'insecure' ? 'Abre la app desde una dirección https:// para usar la cámara en vivo. Mientras tanto puedes importar fotos o usar la cámara del sistema.' :
                    s === 'unsupported' ? (msg ?? 'Puedes importar imágenes o usar la cámara del sistema.') : msg ?? '';
        };
        void cameraState().then(s => paintCam(s));
        const stBadge = h('span', { class: 'badge' }, 'Comprobando…');
        const stHelp = h('div', { class: 'p-help' });
        const stBtn = btn('Activar', async () => {
            const s = await requestPersist();
            paintSt(s, true);
        }, 'secondary', { sm: true, icon: 'hardDrive' });
        const paintSt = (s, asked = false) => {
            if (s === 'granted') {
                stBadge.textContent = 'Concedido';
                stBadge.className = 'badge ok';
                stBtn.style.display = 'none';
                stHelp.textContent = 'El navegador no borrará tus documentos aunque falte espacio.';
            }
            else if (s === 'unsupported') {
                stBadge.textContent = 'No disponible';
                stBadge.className = 'badge warn';
                stBtn.style.display = 'none';
                stHelp.textContent = 'Tus documentos se guardan igualmente en el dispositivo. Haz copias de seguridad desde Ajustes.';
            }
            else {
                stBadge.textContent = asked ? 'No concedido' : 'Sin solicitar';
                stBadge.className = 'badge' + (asked ? ' warn' : '');
                stHelp.textContent = asked ? 'El navegador decide según el uso; instalar la app suele concederlo. Tus documentos se guardan igualmente.' : '';
            }
        };
        void persistState().then(s => paintSt(s));
        return h('div', { class: 'onb' }, nav(true), h('div', { class: 'onb-body enter' }, h('h2', null, 'Permisos necesarios'), h('p', { class: 'muted center small', style: 'margin:0 0 16px' }, 'Solo se piden cuando los activas. Puedes saltarte cualquiera y seguir usando el resto de funciones.'), h('div', { class: 'stack' }, h('div', { class: 'card perm-card' }, tile('camera', 'lilac', true), h('div', { class: 'grow' }, h('div', { class: 'row', style: 'justify-content:space-between' }, h('h4', null, 'Cámara'), camBadge), h('p', null, 'Para fotografiar y escanear documentos.'), camBtn, camHelp)), h('div', { class: 'card perm-card' }, tile('images', 'sky', true), h('div', { class: 'grow' }, h('div', { class: 'row', style: 'justify-content:space-between' }, h('h4', null, 'Fotos y archivos'), h('span', { class: 'badge' }, 'Sin permiso')), h('p', { style: 'margin-bottom:0' }, 'Para importar imágenes y documentos existentes. Se usa el selector del sistema: solo verás y compartirás lo que tú elijas.'))), h('div', { class: 'card perm-card' }, tile('hardDrive', 'peach', true), h('div', { class: 'grow' }, h('div', { class: 'row', style: 'justify-content:space-between' }, h('h4', null, 'Almacenamiento'), stBadge), h('p', null, 'Para guardar y exportar tus documentos. Activa el almacenamiento persistente para que el navegador no los borre.'), stBtn, stHelp)))), h('div', { style: 'margin-top:20px' }, btn('Entrar a ScanPro', finish, 'primary', { block: true, icon: 'arrowRight' })), dots());
    }
    render();
    return root;
}
