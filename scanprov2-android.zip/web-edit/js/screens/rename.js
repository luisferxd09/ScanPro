import { h, ic } from '../ui/dom.js';
import { topbar, btn, toast, emptyState, thumbEl } from '../ui/components.js';
import { getDoc, listDocs, patchDoc, getPages } from '../core/db.js';
import { validateName, MAX_NAME } from '../core/names.js';
import { pagesLabel } from '../ui/dom.js';
export async function renameScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Cambiar nombre', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    const others = (await listDocs(true)).filter(d => d.id !== doc.id).map(d => d.name);
    const [first] = await getPages({ ...doc, pageIds: doc.pageIds.slice(0, 1) });
    const input = h('input', { type: 'text', value: doc.name, maxlength: String(MAX_NAME + 20), autocomplete: 'off', 'aria-label': 'Nuevo nombre del documento', 'aria-describedby': 'rn-err', enterkeyhint: 'done' });
    const wrap = h('div', { class: 'input-wrap' }, input, h('button', { class: 'icon-btn', style: 'width:34px;height:34px;color:var(--text-3)', 'aria-label': 'Borrar texto', onclick: () => { input.value = ''; input.focus(); validate(false); } }, ic('xCircle', 'sm')));
    const err = h('div', { id: 'rn-err', class: 'error', role: 'alert' });
    const counter = h('div', { class: 'hint' });
    const saveBtn = btn('Guardar', () => void save(), 'primary');
    const validate = (show) => {
        const v = validateName(input.value, others);
        counter.textContent = `${input.value.trim().length} / ${MAX_NAME}`;
        err.replaceChildren();
        wrap.classList.toggle('invalid', !v.ok && show);
        if (!v.ok && show) {
            err.append(ic('alert', 'sm'), h('span', null, v.error, v.suggestion ? h('span', null, ' ', h('button', { class: 'accent', style: 'font-weight:600;text-decoration:underline', onclick: () => { input.value = v.suggestion; validate(true); input.focus(); } }, `Usar «${v.suggestion}»`)) : null));
        }
        return v;
    };
    const save = async () => {
        const v = validate(true);
        if (!v.ok) {
            input.focus();
            return;
        } // el texto introducido se conserva
        if (v.name === doc.name) {
            history.back();
            return;
        }
        saveBtn.disabled = true;
        try {
            await patchDoc(doc.id, { name: v.name });
            toast('Nombre actualizado');
            history.back();
        }
        catch (e) {
            saveBtn.disabled = false;
            toast(e.message, 'error');
        }
    };
    input.addEventListener('input', () => validate(true));
    input.addEventListener('keydown', e => { if (e.key === 'Enter')
        void save(); });
    validate(false);
    // seleccionar todo el texto para sustituirlo con facilidad
    setTimeout(() => { input.focus(); input.select(); }, 320);
    return h('div', { class: 'screen' }, topbar('Cambiar nombre', { back: true }), h('div', { class: 'content' }, h('div', { class: 'card pad stack', style: 'gap:16px' }, h('div', { class: 'row' }, thumbEl(first?.thumb), h('div', { class: 'grow' }, h('div', { class: 'xs faint' }, 'Nombre actual'), h('div', { class: 'ellipsis', style: 'font-weight:600' }, doc.name), h('div', { class: 'xs faint' }, pagesLabel(doc.pageIds.length)))), h('div', { class: 'field' }, h('label', null, 'Nuevo nombre del documento'), wrap, err, counter), h('div', { class: 'btn-row' }, btn('Cancelar', () => history.back(), 'secondary'), saveBtn))));
}
