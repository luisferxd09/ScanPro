// Primera apertura: «Hola» en muchos idiomas (como en el iPhone), luego idioma y país.
import { h, ic } from '../ui/dom.js';
import { sheet } from '../ui/components.js';
import { go } from '../core/router.js';
import { setSettings, getSettings } from '../core/settings.js';
import { LANGS, detectLang, langInfo } from '../core/locale.js';
import { play, haptic } from '../core/sounds.js';
import { logoSvg } from '../ui/icons.js';
const ORDER = ['es', 'en', 'pt', 'fr', 'zh', 'it', 'de', 'ja', 'hi', 'ko', 'ar', 'ru', 'id', 'tr', 'vi'];
export function helloScreen() {
    const first = detectLang();
    let i = Math.max(0, ORDER.indexOf(first));
    const word = h('div', { class: 'hello-word', 'data-notr': '' }, langInfo(ORDER[i]).hello);
    const btnLbl = h('span', { 'data-notr': '' }, langInfo(ORDER[i]).cont);
    const btn = h('button', { class: 'hello-btn', onclick: () => { haptic('medium'); play('pop'); void pickLanguage(false); } }, btnLbl, ic('chevRight'));
    const tick = () => {
        if (!document.body.contains(word)) {
            clearInterval(iv);
            return;
        }
        i = (i + 1) % ORDER.length;
        const L = langInfo(ORDER[i]);
        word.classList.remove('in');
        btnLbl.classList.remove('in');
        void word.offsetWidth;
        word.textContent = L.hello;
        btnLbl.textContent = L.cont;
        word.dir = btnLbl.dir = L.rtl ? 'rtl' : 'ltr';
        word.classList.add('in');
        btnLbl.classList.add('in');
    };
    const iv = setInterval(tick, 1300);
    setTimeout(() => play('chime'), 400);
    return h('div', { class: 'hello', 'data-notr': '' }, h('div', { class: 'hello-bg' }, h('i'), h('i'), h('i')), h('div', { class: 'hello-logo', html: logoSvg(64) }), word, h('div', { class: 'hello-sub' }, 'ScanPro'), btn);
}
/** Elige idioma y luego país. after: true = desde Ajustes (recarga en el sitio). */
export function pickLanguage(fromSettings) {
    return new Promise(resolve => {
        const cur = getSettings().lang === 'auto' ? detectLang() : getSettings().lang;
        sheet(close => [
            h('h2', { 'data-notr': '' }, '🌍 Idioma · Language'),
            h('div', { class: 'lang-list', 'data-notr': '' }, ...ORDER.map(code => { const L = langInfo(code); return h('button', { class: 'lang-item' + (code === cur ? ' on' : ''), dir: L.rtl ? 'rtl' : 'ltr', onclick: async () => { haptic('light'); play('tap'); await close(); await pickCountry(code, fromSettings); resolve(); } }, h('b', null, L.name), h('span', null, L.hello), code === cur ? ic('check', 'sm') : null); })),
        ], () => resolve());
    });
}
function pickCountry(lang, fromSettings) {
    const L = LANGS.find(x => x.code === lang);
    const done = (country) => {
        play('success');
        haptic('success');
        setSettings({ lang, country, ocrLang: L.ocr === 'eng' ? 'eng' : L.ocr, helloDone: true });
        if (fromSettings) {
            location.reload();
            return;
        }
        // se recarga para aplicar el idioma en toda la app y sigue con la bienvenida
        location.hash = '#/onboarding';
        location.reload();
    };
    if (L.countries.length === 1) {
        done(L.countries[0].code);
        return Promise.resolve();
    }
    const guess = (navigator.language.split('-')[1] ?? '').toUpperCase();
    return new Promise(resolve => {
        sheet(() => [
            h('h2', { 'data-notr': '' }, `${L.name} · ${{ es: 'País', en: 'Country', pt: 'País', fr: 'Pays', de: 'Land', it: 'Paese', zh: '国家/地区', ru: 'Страна', ar: 'البلد', hi: 'देश', id: 'Negara', tr: 'Ülke', vi: 'Quốc gia', ja: '国・地域', ko: '국가' }[lang] ?? 'Country'}`),
            h('div', { class: 'lang-list', 'data-notr': '', dir: L.rtl ? 'rtl' : 'ltr' }, ...[...L.countries].sort((a, b) => (b.code === guess ? 1 : 0) - (a.code === guess ? 1 : 0)).map(c => h('button', { class: 'lang-item' + (c.code === guess ? ' on' : ''), onclick: () => { haptic('light'); done(c.code); } }, h('b', null, `${flag(c.code)}  ${c.name}`), h('span', null, c.currency)))),
        ], () => resolve());
    });
}
export const flag = (cc) => String.fromCodePoint(...[...cc].map(c => 0x1f1e6 + c.charCodeAt(0) - 65));
export function showHelloAgain() { setSettings({ helloDone: false }); go('hola', {}); }
