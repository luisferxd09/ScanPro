import { pdfPaper } from '../core/locale.js';
import { play } from '../core/sounds.js';
import { nativeAd } from '../core/native.js';
import { isPro } from '../core/pro.js';
import { maybeInterstitial, houseAd } from '../core/ads.js';
import { idPaperOf } from '../core/idcard.js';
import { h, ic, fmtSize, pagesLabel } from '../ui/dom.js';
import { topbar, btn, toast, emptyState, segmented, sheet, busy, note, thumbEl, toggle } from '../ui/components.js';
import { getDoc, getPages } from '../core/db.js';
import { getSettings, QUALITY } from '../core/settings.js';
import { generate, estimateSize } from '../core/exporter.js';
import { canShareFiles, shareFiles, downloadFiles, copyText, shareText, canShareText } from '../core/share.js';
import { fileSafe } from '../core/names.js';
import { runOcr } from './ocr.js';
const FORMATS = [
    { id: 'pdf', title: 'PDF', desc: 'Todas las páginas en un único documento.', icon: 'filePdf', color: 'coral' },
    { id: 'docx', title: 'Word (DOCX)', desc: 'Documento editable con las páginas y el texto OCR.', icon: 'fileWord', color: 'sky' },
    { id: 'jpg', title: 'JPG', desc: 'Imágenes de alta calidad, ligeras.', icon: 'image', color: 'peri' },
    { id: 'png', title: 'PNG', desc: 'Imágenes sin pérdida de calidad.', icon: 'fileImage', color: 'lilac' },
    { id: 'webp', title: 'WEBP', desc: 'Imágenes modernas, máxima compresión.', icon: 'images', color: 'rose' },
    { id: 'txt', title: 'Texto (OCR)', desc: 'Compartir únicamente el texto reconocido.', icon: 'type', color: 'butter' },
];
export async function shareScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Compartir', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    let pages = await getPages(doc);
    const exportMode = params.mode === 'export';
    const st = getSettings();
    let fmt = (FORMATS.find(f => f.id === params.fmt)?.id) ?? 'pdf';
    // una copia de documento de identidad se exporta en su misma hoja para que quede a tamaño real
    const idPaper = pages.length ? idPaperOf(pages[0].width, pages[0].height) : null;
    const o = { quality: st.quality, multi: pages.length > 1 ? 'zip' : 'files', pdfSize: idPaper ?? pdfPaper(), pdfOrientation: idPaper ? 'portrait' : 'auto', pdfMargin: 0, docxText: true, fileName: doc.name };
    const list = h('div', { class: 'fmt-list', role: 'radiogroup', 'aria-label': 'Formato' });
    const optsEl = h('div', { class: 'card pad opts' });
    const estimate = h('div', { class: 'small muted' });
    const renderList = () => list.replaceChildren(...FORMATS.map(f => h('button', {
        class: 'option' + (fmt === f.id ? ' selected' : ''), role: 'radio', 'aria-checked': String(fmt === f.id),
        onclick: (e) => { fmt = f.id; list.querySelectorAll('.option').forEach(o => { const on = o === e.currentTarget; o.classList.toggle('selected', on); o.setAttribute('aria-checked', String(on)); }); renderOpts(); },
    }, h('span', { class: `o-ico c-${f.color}` }, ic(f.icon)), h('span', { class: 'grow' }, h('div', { class: 'o-title' }, f.title), h('div', { class: 'o-desc' }, f.desc)), ic('check', 'tick'))));
    const label = (t) => h('div', { class: 'opt-label' }, t);
    const nameInput = h('input', { type: 'text', value: doc.name, 'aria-label': 'Nombre del archivo' });
    const pwInput = h('input', { type: 'password', autocomplete: 'new-password', placeholder: 'Sin contraseña', 'aria-label': 'Contraseña del PDF', maxlength: '32' });
    pwInput.addEventListener('input', () => { o.password = pwInput.value || undefined; });
    nameInput.addEventListener('input', () => { o.fileName = nameInput.value; });
    const paintEstimate = () => {
        const hasText = pages.some(p => p.ocrText?.trim());
        estimate.textContent = fmt === 'txt' ? (hasText ? `${pages.filter(p => p.ocrText?.trim()).length} de ${pages.length} página(s) con texto reconocido.` : 'Aún no hay texto: se reconocerá ahora con OCR (en el dispositivo).')
            : `Tamaño aproximado: ${fmtSize(estimateSize(pages, fmt, o.quality))} · ${pagesLabel(pages.length)}`;
    };
    const renderOpts = () => {
        const parts = [h('div', { class: 'field' }, label('Nombre del archivo'), h('div', { class: 'input-wrap' }, nameInput))];
        if (fmt !== 'txt') {
            parts.push(h('div', null, label('Calidad'), segmented([['alta', 'Alta'], ['equilibrada', 'Equilibrada'], ['compacta', 'Compacta']], o.quality, v => { o.quality = v; paintEstimate(); qDesc.textContent = QUALITY[v].desc + (fmt === 'png' && v === 'alta' ? ' (PNG sin pérdida a resolución completa)' : ''); }), qDesc));
            qDesc.textContent = QUALITY[o.quality].desc;
        }
        if (fmt === 'pdf') {
            parts.push(h('div', null, label('Tamaño de página'), segmented([['a4', 'A4'], ['letter', 'Carta'], ['original', 'Original']], o.pdfSize, v => { o.pdfSize = v; })), h('div', null, label('Orientación'), segmented([['auto', 'Automática'], ['portrait', 'Vertical'], ['landscape', 'Horizontal']], o.pdfOrientation, v => { o.pdfOrientation = v; })), h('div', null, label('Márgenes'), segmented([['0', 'Sin márgenes'], ['18', 'Pequeños'], ['36', 'Normales']], String(o.pdfMargin), v => { o.pdfMargin = Number(v); })), h('div', null, label('Tamaño máximo del archivo'), segmented([['0', 'Sin límite'], ['1', '1 MB'], ['2', '2 MB'], ['5', '5 MB']], String((o.maxBytes ?? 0) / 1048576), v => { o.maxBytes = Number(v) * 1048576 || undefined; }), h('div', { class: 'xs faint', style: 'margin-top:6px' }, 'Para portales de trámites que limitan el peso. Se baja la calidad solo lo necesario.')), h('div', { class: 'field' }, label('Contraseña para abrir (opcional)'), h('div', { class: 'input-wrap' }, ic('lock', 'sm faint'), pwInput)), h('div', { class: 'xs faint' }, pages.some(p => p.ocrLines?.length) ? `PDF con búsqueda: ${pages.filter(p => p.ocrLines?.length).length} de ${pages.length} página(s) llevan su texto (se puede buscar y copiar).` : 'Consejo: usa «Texto (OCR)» antes y el PDF se podrá buscar y copiar.'));
        }
        if ((fmt === 'jpg' || fmt === 'png' || fmt === 'webp') && pages.length > 1) {
            parts.push(h('div', null, label(`Varias páginas (${pages.length})`), segmented([['zip', 'Un ZIP con todas'], ['files', 'Un archivo por página']], o.multi, v => { o.multi = v; })));
        }
        if (fmt === 'docx') {
            parts.push(h('div', { class: 'row' }, h('div', { class: 'grow' }, h('div', { style: 'font-weight:500' }, 'Incluir texto editable'), h('div', { class: 'xs faint' }, 'Añade el texto OCR de cada página (si existe) tras su imagen.')), toggle(o.docxText, v => { o.docxText = v; }, 'Incluir texto editable')));
        }
        parts.push(estimate);
        optsEl.replaceChildren(...parts);
        paintEstimate();
    };
    const qDesc = h('div', { class: 'xs faint', style: 'margin-top:6px' });
    const run = async () => {
        // PDF con contraseña: se desbloquea con un anuncio con recompensa (si hay internet y anuncio disponible)
        if (fmt === 'pdf' && o.password && !isPro()) {
            const r = await nativeAd('rewarded');
            if (r === 'closed') {
                toast('Mira el anuncio completo para proteger el PDF con contraseña.', 'error', 3500);
                return;
            }
            if (r === 'none')
                await houseAd();
        }
        else
            await maybeInterstitial();
        if (fmt === 'txt' && !pages.some(p => p.ocrText?.trim())) {
            const ok = await runOcr(doc, pages);
            if (!ok)
                return;
            pages = await getPages(doc);
            paintEstimate();
            if (!pages.some(p => p.ocrText?.trim())) {
                toast('No se reconoció texto en este documento.', 'error');
                return;
            }
        }
        const b = busy('Generando archivo…', true);
        let res;
        try {
            res = await generate(doc, pages, fmt, { ...o, fileName: fileSafe(nameInput.value || doc.name) }, (l, f) => b.set(l, f));
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 5000);
            return;
        }
        b.done();
        showResult(res);
    };
    const showResult = (res) => {
        const shareable = canShareFiles(res.files);
        const main = res.files[0];
        const kindLabel = res.kind === 'zip' ? 'ZIP' : FORMATS.find(f => f.id === res.kind).title;
        const desc = res.files.length > 1 ? `${res.files.length} archivos · ${fmtSize(res.size)}` : `${kindLabel} · ${fmtSize(res.size)}`;
        const status = h('div');
        const txt = fmt === 'txt' ? pages.map((p, i) => (pages.length > 1 ? `— Página ${i + 1} —\n` : '') + (p.ocrText ?? '')).join('\n\n') : '';
        const doShare = async () => {
            const r = await shareFiles(res.files, doc.name);
            if (r.outcome === 'shared') {
                status.replaceChildren(note('Enviado a la aplicación que elegiste.'));
                toast('Compartido');
                play('success');
            }
            else if (r.outcome === 'cancelled')
                status.replaceChildren(note('Compartir cancelado. El archivo sigue listo.'));
            else if (r.outcome === 'unsupported')
                status.replaceChildren(note('Este navegador no puede compartir este tipo de archivo. Usa «Descargar» y compártelo desde Archivos o Descargas.', 'warn'));
            else
                status.replaceChildren(note(r.message ?? 'No se pudo compartir.', 'err'));
        };
        const doDownload = async () => {
            let where;
            try {
                where = await downloadFiles(res.files);
            }
            catch (e) {
                status.replaceChildren(note(e.message, 'err'));
                return;
            }
            if (where) {
                status.replaceChildren(note(`Guardado en ${where}.`));
                toast('Archivo guardado');
                play('success');
                return;
            }
            status.replaceChildren(note(res.files.length > 1 ? `Se iniciaron ${res.files.length} descargas. Si el navegador pregunta, permite descargas múltiples.` : 'Descarga iniciada. En Android lo encontrarás en Archivos › Descargas.'));
        };
        sheet(close => [
            h('h2', null, exportMode ? 'Archivo listo' : 'Listo para compartir'),
            h('div', { class: 'file-card' }, h('div', { class: 'fc-ico' }, pages[0] && res.kind !== 'txt' ? thumbEl(pages[0].thumb, 'fc-ico') : ic(res.kind === 'txt' ? 'type' : 'fileText', 'lg')), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:600' }, main.name + (res.files.length > 1 ? ` y ${res.files.length - 1} más` : '')), h('div', { class: 'xs faint' }, desc))),
            fmt === 'txt' ? h('div', { class: 'ocr-view', style: 'max-height:180px;overflow:auto;margin-top:12px;font-size:13px' }, txt.slice(0, 3000) + (txt.length > 3000 ? '…' : '')) : null,
            h('div', { style: 'height:14px' }),
            shareable && !exportMode ? null : h('div', { style: 'margin-bottom:12px' }, shareable ? null : note(res.kind === 'zip' || res.kind === 'docx'
                ? 'Android no permite compartir archivos ZIP o Word directamente desde el navegador. Descárgalo y compártelo desde la app Archivos, o elige PDF / imágenes por separado.'
                : 'Tu navegador no admite compartir archivos (Web Share API). Puedes descargarlo y enviarlo desde Archivos.', 'warn')),
            h('div', { class: 'stack' }, shareable ? btn('Compartir', () => void doShare(), exportMode ? 'secondary' : 'primary', { block: true, icon: 'share' }) : null, btn('Descargar', () => void doDownload(), shareable && !exportMode ? 'secondary' : 'primary', { block: true, icon: 'download' }), fmt === 'txt' ? h('div', { class: 'btn-row' }, btn('Copiar texto', async () => { const ok = await copyText(txt); toast(ok ? 'Texto copiado' : 'No se pudo copiar', ok ? 'ok' : 'error'); }, 'secondary', { icon: 'copy', sm: true }), canShareText() ? btn('Como mensaje', async () => { const r = await shareText(txt, doc.name); if (r === 'shared')
                toast('Compartido'); }, 'secondary', { icon: 'share', sm: true }) : null) : null, btn('Cerrar', () => void close(), 'ghost', { block: true })),
            status,
        ]);
    };
    renderList();
    renderOpts();
    return h('div', { class: 'screen' }, topbar(exportMode ? 'Exportar documento' : 'Compartir documento', { back: true }), h('div', { class: 'content stack' }, h('div', { class: 'row card pad', style: 'padding:10px 12px' }, thumbEl(pages[0]?.thumb), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:600' }, doc.name), h('div', { class: 'xs faint' }, pagesLabel(pages.length)))), h('h2', { style: 'font-size:var(--fs-lg);margin:8px 0 0' }, exportMode ? '¿En qué formato quieres exportar?' : '¿En qué formato quieres compartir?'), h('div', { class: 'small muted', style: 'margin-top:-6px' }, 'Elige el formato; el archivo se genera en tu teléfono.'), list, optsEl, h('div', { class: 'btn-row', style: 'margin-top:4px' }, btn('Cancelar', () => history.back(), 'secondary'), btn(exportMode ? 'Continuar' : 'Compartir', () => void run(), 'primary')), exportMode ? null : h('div', { class: 'xs faint center' }, 'Tras generar el archivo se abrirá el menú de Android para elegir WhatsApp, Gmail, Drive u otra app.')));
}
