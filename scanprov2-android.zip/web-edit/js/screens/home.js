import { curCountry } from '../core/locale.js';
import { loc } from '../core/locale.js';
import { h, ic } from '../ui/dom.js';
import { tile, stagger } from '../ui/components.js';
import { go } from '../core/router.js';
import { getSettings } from '../core/settings.js';
import { listDocs } from '../core/db.js';
import { allMeta } from '../core/meta.js';
import { qrTool } from '../tools/smart.js';
import { docItem, pickDocument, scanIdCard, scanWithCamera } from './common.js';
import { openVipAdsPanel, openVipPanel } from './vip.js';
export async function homeScreen() {
    const recentWrap = h('div');
    let first = true;
    const renderRecent = async () => {
        const list = (await listDocs()).sort((a, b) => b.updatedAt - a.updatedAt);
        const ul = h('div', { class: 'doc-list' }, list.slice(0, 4).map(d => docItem(d, renderRecent)));
        recentWrap.replaceChildren(h('div', { class: 'section-title big row' }, h('span', null, 'Recientes'), list.length ? h('button', { class: 'small accent', style: 'font-weight:600;letter-spacing:0', onclick: () => go('docs') }, 'Ver todo') : null), list.length ? (first ? stagger(ul) : ul)
            : h('div', { class: 'card pad row' }, tile('stack', 'peri', true), h('div', { class: 'grow small muted' }, 'Aquí aparecerán tus últimos escaneos. Toca «Tomar foto» para empezar.')));
        first = false;
    };
    await renderRecent();
    // recordatorio de copia de seguridad: todo vive en el teléfono
    const all = await listDocs(), lb = getSettings().lastBackup;
    const remind = all.length >= 5 && Date.now() - lb > 14 * 86400000
        ? h('button', { class: 'card pad row tap', style: 'width:100%;text-align:left;margin-bottom:14px;gap:12px', onclick: () => go('settings', { section: 'storage' }) }, tile('archive', 'peach', true), h('div', { class: 'grow' }, h('div', { style: 'font-weight:700' }, 'Haz una copia de seguridad'), h('div', { class: 'xs faint' }, lb ? 'Hace más de 2 semanas de la última copia.' : `Tienes ${all.length} documentos sin copia. Si borras la app, se pierden.`)), ic('chevRight', 'sm faint'))
        : null;
    const meta = allMeta(), soon = all.filter(d => { const e = meta[d.id]?.expires; return e && e - Date.now() < 30 * 86400000; }).sort((a, b) => meta[a.id].expires - meta[b.id].expires);
    const expiring = soon.length ? h('button', { class: 'card pad row tap', style: 'width:100%;text-align:left;margin-bottom:14px;gap:12px', onclick: () => go('vida', {}) }, tile('clock', 'rose', true), h('div', { class: 'grow' }, h('div', { style: 'font-weight:700' }, soon.length === 1 ? `«${soon[0].name}» vence pronto` : `${soon.length} documentos vencen pronto`), h('div', { class: 'xs faint' }, `${new Date(meta[soon[0].id].expires).toLocaleDateString(loc(), { day: 'numeric', month: 'long' })} · renuévalo a tiempo`)), ic('chevRight', 'sm faint')) : null;
    const quick = (icon, tint, label, run) => h('button', { class: 'quick', onclick: run }, h('span', { class: `q-ico c-${tint}` }, ic(icon)), label);
    return h('div', { class: 'screen with-nav' }, h('div', { style: 'height:calc(env(safe-area-inset-top) + 12px)' }), h('div', { class: 'content' }, h('div', { class: 'home-vip-bar' }, h('button', { class: 'home-vip-btn', 'aria-label': 'Abrir ScanPro VIP', title: 'ScanPro VIP', onclick: () => void openVipPanel() }, ic('crown'), h('span', null, 'VIP')), h('button', { class: 'home-ad-btn', 'aria-label': 'Anuncios y recompensas', title: 'Anuncios y recompensas', onclick: () => void openVipAdsPanel() }, ic('play'))), expiring, remind, stagger(h('div', { class: 'stack', style: 'gap:12px' }, h('button', { class: 'hero-card tap', onclick: () => void scanWithCamera() }, h('span', { class: 'hero-icon' }, ic('camera', 'lg')), h('span', null, h('h3', null, 'Tomar foto'), h('p', null, 'Escanea un documento en segundos')), ic('chevRight', 'chev')), h('button', { class: 'big-card tap', onclick: () => go('docs') }, h('span', { class: 'hero-icon' }, ic('docs', 'lg')), h('span', null, h('h3', null, 'Ver documentos'), h('p', null, 'Accede a tus archivos escaneados')), ic('chevRight', 'chev')))), h('div', { class: 'section-title big' }, 'Herramientas rápidas'), stagger(h('div', { class: 'quick-grid' }, quick('ocr', 'lilac', 'OCR', () => void pickDocument('Extraer texto de…', d => go('ocr', { id: d.id }))), quick('filePdf', 'peach', 'Crear PDF', () => void pickDocument('Crear PDF de…', d => go('share', { id: d.id, fmt: 'pdf', mode: 'export' }))), quick('idCard', 'sky', curCountry().idName, () => scanIdCard()), quick('qr', 'butter', 'QR', () => void qrTool()), quick('pencil', 'coral', 'Firmar', () => void pickDocument('Firmar o anotar…', d => go('pages', { id: d.id, hint: 'annotate' }))), quick('wallet', 'peri', 'Mi vida', () => go('vida', {})), quick('cart', 'sand', 'Gastos', () => go('gastos', {})), quick('gridOut', 'rose', 'Más', () => go('tools')))), recentWrap));
}
