import { h, ic, fmtDateTime, fmtSize, pagesLabel } from '../ui/dom.js';
import { topbar, iconBtn, actionSheet, blobUrl, emptyState, toast, tile, listItem, stagger } from '../ui/components.js';
import { go } from '../core/router.js';
import { getDoc, getPages, patchDoc } from '../core/db.js';
import { confirmDelete, moveToFolder, newScanSheet } from './common.js';
import { presentTool } from '../tools/media.js';
import { reviewTool, organize } from '../tools/ai.js';
import { showText, translateText } from '../tools/smart.js';
import { docText, exportDoc, myEmail } from '../tools/kit.js';
import { isNative, nativePrint, nativeShareEmail } from '../core/native.js';
import { settingsX } from '../core/meta.js';
export async function detailScreen(params) {
    const doc = params.id ? await getDoc(params.id) : undefined;
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Documento', { back: true }), emptyState('alert', 'Documento no encontrado', 'Puede que se haya eliminado.'));
    const pages = await getPages(doc);
    const missing = doc.pageIds.length - pages.length;
    const pill = h('div', { class: 'page-pill' }, `1 / ${pages.length}`);
    const track = h('div', { class: 'viewer-track', 'aria-label': 'Páginas del documento' }, pages.map((p, i) => h('div', { class: 'viewer-page' }, h('img', { src: blobUrl(p.image), alt: `Página ${i + 1}`, decoding: 'async', onclick: () => go('pages', { id: doc.id }) }))));
    track.addEventListener('scroll', () => {
        const i = Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
        pill.textContent = `${Math.min(pages.length, i + 1)} / ${pages.length}`;
    }, { passive: true });
    const strip = (icon, tint, label, run) => h('button', { class: 'tap', onclick: run }, tile(icon, tint), label);
    const more = () => actionSheet('Más opciones', [
        { icon: 'download', label: 'Exportar / descargar', sub: 'PDF, Word, JPG, PNG, WEBP, TXT', run: () => go('share', { id: doc.id, mode: 'export' }) },
        { icon: 'ocr', label: doc.ocrText ? 'Ver texto reconocido (OCR)' : 'Reconocer texto (OCR)', run: () => go('ocr', { id: doc.id }) },
        { icon: 'type', label: 'Firmar o anotar', sub: 'Firma, texto, resaltador y lápiz', run: () => pages.length === 1 ? go('annotate', { page: pages[0].id }) : go('pages', { id: doc.id, hint: 'annotate' }) },
        { icon: 'fileWord', label: 'Editar como texto (Word)', sub: 'Edita el texto reconocido y guárdalo como Word o PDF', run: () => go('textedit', { id: doc.id }) },
        { icon: 'alert', label: 'Revisar (resumen y alertas)', sub: 'Permanencia, multas, renovación, fechas y valores', run: () => reviewTool(doc.id) },
        { icon: 'wand', label: 'Organizar automáticamente', sub: 'Nombre, tipo, carpeta y vencimiento', run: async () => { const k = await organize(doc.id, false); toast(k ? `Es un(a) ${k}. Organizado.` : 'No reconocí el tipo de documento.', k ? 'ok' : 'error'); go('doc', { id: doc.id }, { replace: true }); } },
        { icon: 'presentation', label: 'Presentar', sub: 'Pantalla completa, desliza para pasar', run: () => presentTool(doc.id) },
        { icon: 'volume', label: 'Leer en voz alta', run: async () => { const t = await docText(doc); if (t)
                showText(doc.name, t.text, doc.id); } },
        { icon: 'translate', label: 'Traducir', run: async () => { const t = await docText(doc); if (t)
                await translateText(t.text, doc.name); } },
        ...(isNative ? [{ icon: 'printer', label: 'Imprimir', run: async () => { const f = await exportDoc(doc, 'pdf', {}, pages); if (f && !(await nativePrint(f[0])))
                    toast('No se pudo abrir la impresión.', 'error'); } },
            { icon: 'share', label: 'Enviar a mi correo', sub: settingsX().email ?? 'Configúralo la primera vez', run: async () => { const to = await myEmail(); if (!to)
                    return; const f = await exportDoc(doc, 'pdf', {}, pages); if (f)
                    await nativeShareEmail(f, doc.name, to); } }] : []),
        { icon: 'imagePlus', label: 'Agregar páginas', run: () => newScanSheet(doc.id) },
        { icon: 'pages', label: 'Ver y ordenar páginas', run: () => go('pages', { id: doc.id }) },
        { icon: 'star', label: doc.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos', run: async () => { await patchDoc(doc.id, { favorite: !doc.favorite }); toast(doc.favorite ? 'Quitado de favoritos' : 'Añadido a favoritos'); go('doc', { id: doc.id }, { replace: true }); } },
        { icon: 'folderMove', label: 'Mover a carpeta', run: () => moveToFolder(doc, () => { }) },
        { icon: 'info', label: 'Información', sub: `${pagesLabel(pages.length)} · ${fmtSize(doc.size)} · modificado ${fmtDateTime(doc.updatedAt)}`, run: () => { } },
    ]);
    return h('div', { class: 'screen' }, topbar(doc.name, { back: true, actions: [iconBtn('moreH', 'Más opciones', more)] }), missing ? h('div', { style: 'margin:0 16px 12px' }, h('div', { class: 'note err' }, ic('alert', 'sm'), `Faltan ${missing} página(s) de este documento en el almacenamiento.`)) : null, h('div', { class: 'viewer' }, track, pages.length > 0 ? pill : null), h('div', { class: 'action-strip' }, strip('imagePlus', 'lilac', 'Agregar', () => newScanSheet(doc.id)), strip('pages', 'peach', 'Páginas', () => go('pages', { id: doc.id })), strip('ocr', 'sky', 'Texto', () => go('ocr', { id: doc.id })), strip('download', 'rose', 'Exportar', () => go('share', { id: doc.id, mode: 'export' }))), h('div', { class: 'action-list' }, stagger(h('div', { class: 'list' }, listItem({ icon: 'pencil', tint: 'lilac', title: 'Cambiar nombre', onclick: () => go('rename', { id: doc.id }) }), listItem({ icon: 'merge', tint: 'peach', title: 'Combinar con otro documento', onclick: () => go('merge', { id: doc.id }) }), listItem({ icon: 'share', tint: 'sky', title: 'Compartir', onclick: () => go('share', { id: doc.id }) }), listItem({ icon: 'moreH', tint: 'sand', title: 'Más opciones', onclick: more }), listItem({ icon: 'trash', title: 'Eliminar', danger: true, onclick: async () => { if (await confirmDelete(doc))
            history.back(); } })))));
}
