// Panel VIP: ruleta, anuncios de apoyo y desbloqueo temporal.
import { h, ic } from '../ui/dom.js';
import { sheet, infoDialog, toast, busy, confirmDialog } from '../ui/components.js';
import { play, haptic } from '../core/sounds.js';
import { isNative } from '../core/native.js';
import { tier, isVip, vipStatusText, formatVipExpiry, buyVip, spinRoulette, watchAdForRoulette, watchAdToSupport, watchAdForFullProgress, adsForFullProgress } from '../core/vip.js';

const FEATURE_LABELS = {
    ocr: 'OCR',
    password: 'PDF con contraseña',
    export: 'Exportación premium',
    qr: 'QR y códigos',
    sign: 'Firmar y anotar',
    translate: 'Traducir',
    removebg: 'Quitar fondo',
    dictate: 'Dictado por voz'
};

function statusBlock() {
    const t = tier();
    const active = isVip();
    return h('div', { class: 'vip-status' },
        h('div', { class: 'vip-badge' + (active ? ' active' : '') }, ic(active ? 'crown' : 'star')),
        h('div', { class: 'vip-title' }, active ? 'VIP activo' : 'Gratuito'),
        h('div', { class: 'vip-sub' }, vipStatusText()),
        formatVipExpiry() ? h('div', { class: 'vip-expiry' }, `Vence: ${formatVipExpiry()}`) : null
    );
}

function rewardLabel(reward) {
    if (reward.type === 'none') return 'Sin premio';
    if (reward.type === 'full') return 'VIP completo temporal';
    if (reward.type === 'feature') return `Desbloqueo: ${FEATURE_LABELS[reward.feature] ?? reward.feature}`;
    return '';
}

const ROULETTE_LABELS = ['15 min VIP', '1 h VIP', '30 min función', 'Sin premio', '15 min VIP', 'Sin premio'];

function rewardSegment(reward) {
    if (reward.type === 'none') return Math.random() < 0.5 ? 3 : 5;
    if (reward.type === 'feature') return 2;
    if (reward.duration === 60 * 60 * 1000) return 1;
    return Math.random() < 0.5 ? 0 : 4;
}

async function openRoulette(close) {
    if (!isNative) { toast('Disponible en la app instalada', 'error'); return; }
    await close();
    const labels = ROULETTE_LABELS.map((label, i) => {
        const angle = i * 60 + 30;
        return h('span', { class: 'roulette-label', style: `transform:translate(-50%,-50%) rotate(${angle}deg) translateY(-73px) rotate(${-angle}deg)` }, label);
    });
    // Cada etiqueta contra-rota con el mismo tiempo y curva que la ruleta: el texto queda siempre horizontal.
    const placeLabels = () => labels.forEach((l, i) => {
        const angle = i * 60 + 30;
        l.style.transform = `translate(-50%,-50%) rotate(${angle}deg) translateY(-73px) rotate(${-(angle + rotation)}deg)`;
    });
    const wheel = h('div', { class: 'roulette-wheel' }, ...labels, h('span', { class: 'roulette-hub' }, ic('crown')));
    const resultEl = h('div', { class: 'roulette-result' }, 'Un anuncio = un giro');
    let rotation = 0;
    const spinBtn = h('button', { class: 'btn primary block', onclick: async () => {
        spinBtn.disabled = true;
        resultEl.textContent = 'Cargando anuncio…';
        const b = busy('Cargando anuncio…');
        let adResult;
        try {
            adResult = await watchAdForRoulette();
        }
        finally {
            b.done();
        }
        if (adResult !== 'rewarded') {
            resultEl.textContent = 'Debes ver el anuncio completo para girar.';
            toast('No se completó el anuncio', 'error');
            spinBtn.disabled = false;
            return;
        }
        resultEl.textContent = 'Girando…';
        play('pop');
        const reward = await spinRoulette();
        const selectedAngle = rewardSegment(reward) * 60 + 30;
        const targetAngle = (360 - selectedAngle + 360) % 360;
        const currentAngle = (rotation % 360 + 360) % 360;
        rotation += 5 * 360 + (targetAngle - currentAngle + 360) % 360;
        wheel.style.transform = `rotate(${rotation}deg)`;
        placeLabels();
        await new Promise(r => setTimeout(r, 2400));
        haptic(reward.type === 'none' ? 'light' : 'success');
        resultEl.textContent = reward.type === 'none' ? 'Sin premio. ¡Inténtalo de nuevo!' : `¡Ganaste: ${rewardLabel(reward)}!`;
        if (reward.type !== 'none') {
            toast('Recompensa VIP activada', 'ok', 3500);
        }
        spinBtn.disabled = false;
    } }, 'Ver anuncio y girar');
    sheet(() => [
        h('h2', null, 'Ruleta VIP'),
        h('p', { class: 'small muted' }, 'Ve un anuncio completo para girar y conseguir VIP temporal o desbloquear una función.'),
        h('div', { class: 'roulette-stage' }, h('span', { class: 'roulette-pointer' }), wheel),
        resultEl,
        spinBtn
    ]);
}

async function openAdsProgress(close) {
    if (!isNative) { toast('Disponible en la app instalada', 'error'); return; }
    await close();
    const { current, total } = adsForFullProgress();
    const countEl = h('div', { class: 'vip-counter' }, `${current}/${total} anuncios`);
    const bar = h('div', { class: 'vip-progress' }, h('div', { class: 'vip-progress-bar', style: `width:${(current / total) * 100}%` }));
    const watchBtn = h('button', { class: 'btn primary block', onclick: async () => {
        watchBtn.disabled = true;
        const b = busy('Cargando anuncio…');
        const res = await watchAdForFullProgress();
        b.done();
        if (res.ok) {
            const { current: c, total: t } = adsForFullProgress();
            countEl.textContent = `${c}/${t} anuncios`;
            bar.querySelector('.vip-progress-bar').style.width = `${(c / t) * 100}%`;
            if (res.reward) {
                toast('¡VIP completo desbloqueado por 1 hora!', 'ok', 4000);
                watchBtn.textContent = 'VIP desbloqueado';
                watchBtn.disabled = true;
            }
            else {
                toast(`Anuncio visto: ${c} de ${t}`, 'ok', 2500);
                watchBtn.disabled = false;
            }
        }
        else {
            toast('No se pudo cargar el anuncio', 'error');
            watchBtn.disabled = false;
        }
    } }, current >= total ? 'VIP desbloqueado' : 'Ver anuncio');
    sheet(() => [
        h('h2', null, 'Desbloquear VIP'),
        h('p', { class: 'small muted' }, `Ve ${total} anuncios para obtener VIP completo durante 1 hora.`),
        countEl,
        bar,
        watchBtn
    ]);
}

async function supportCreator(close) {
    if (!isNative) { toast('Disponible en la app instalada', 'error'); return; }
    await close();
    const b = busy('Cargando anuncio…');
    const r = await watchAdToSupport();
    b.done();
    if (r === 'rewarded') {
        toast('¡Gracias por apoyar a ScanPro! 💜', 'ok', 4000);
    }
    else {
        toast('No se pudo cargar el anuncio', 'error');
    }
}

async function buyVipInfo(close) {
    await close();
    const msg = buyVip();
    infoDialog('ScanPro VIP', msg ?? 'Las suscripciones VIP se activarán cuando ScanPro esté disponible en Google Play.', 'crown');
}

export function openVipAdsPanel() {
    sheet(close => [
        h('h2', null, 'Anuncios y recompensas'),
        h('p', { class: 'small muted' }, 'Elige si quieres ganar una recompensa o apoyar el desarrollo de ScanPro.'),
        h('div', { class: 'list' },
            h('button', { class: 'list-item', onclick: () => void openRoulette(close) }, ic('dice'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Ver anuncio para girar la ruleta'), h('div', { class: 'li-sub' }, 'Un anuncio completo = un giro'))),
            h('button', { class: 'list-item', onclick: () => void supportCreator(close) }, ic('heart'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Apoyar al creador'), h('div', { class: 'li-sub' }, 'Mira un anuncio como agradecimiento'))),
            h('button', { class: 'list-item', onclick: () => void openAdsProgress(close) }, ic('play'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Conseguir 1 hora de VIP'), h('div', { class: 'li-sub' }, 'Completa 5 anuncios para desbloquearla')))
        )
    ]);
}

export function openVipPanel() {
    sheet(close => [
        h('h2', null, 'ScanPro VIP'),
        statusBlock(),
        h('div', { class: 'list' },
            h('button', { class: 'list-item', onclick: () => void openRoulette(close) }, ic('dice'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Ruleta VIP'), h('div', { class: 'li-sub' }, 'Gira para ganar ventajas temporales'))),
            h('button', { class: 'list-item', onclick: () => void openAdsProgress(close) }, ic('play'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Ver anuncios'), h('div', { class: 'li-sub' }, '5 anuncios = 1 hora de VIP'))),
            h('button', { class: 'list-item', onclick: () => void supportCreator(close) }, ic('heart'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Apoyar al creador'), h('div', { class: 'li-sub' }, 'Mira un anuncio para apoyar el desarrollo'))),
            h('button', { class: 'list-item', onclick: () => void buyVipInfo(close) }, ic('crown'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, 'Comprar VIP'), h('div', { class: 'li-sub' }, 'Información sobre la suscripción')))
        )
    ]);
}
