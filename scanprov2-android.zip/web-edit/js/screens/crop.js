// Ajuste manual de las cuatro esquinas, con lupa y detección automática.
import { h, ic } from '../ui/dom.js';
import { btn, toast, busy } from '../ui/components.js';
import { go, onLeave } from '../core/router.js';
import { getSession, viewOf, removePage, scheduleRender, withSource } from '../core/session.js';
import { engine } from '../imaging/engine.js';
import { isConvexQuad } from '../imaging/detect.js';
const FULL_NORM = [0, 0, 1, 0, 1, 1, 0, 1];
export async function cropScreen(params) {
    const s = getSession();
    const dp = s?.pages.find(p => p.id === params.page);
    if (!s || !dp) {
        setTimeout(() => go('home', {}, { replace: true }));
        return h('div');
    }
    await dp.ready;
    const bmp = await viewOf(dp);
    const view = h('canvas', { width: String(bmp.width), height: String(bmp.height), 'aria-label': 'Foto original' });
    view.getContext('2d').drawImage(bmp, 0, 0);
    let pts = [...(dp.corners ?? (dp.sourcePageId ? FULL_NORM : insetNorm()))];
    function insetNorm() { return [0.06, 0.06, 0.94, 0.06, 0.94, 0.94, 0.06, 0.94]; }
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('class', 'crop-svg');
    svg.setAttribute('viewBox', '0 0 1000 1000');
    svg.setAttribute('preserveAspectRatio', 'none');
    const shade = document.createElementNS(svgNS, 'path');
    shade.setAttribute('fill', 'rgba(0,0,0,.45)');
    shade.setAttribute('fill-rule', 'evenodd');
    const quad = document.createElementNS(svgNS, 'polygon');
    quad.setAttribute('class', 'quad');
    quad.setAttribute('vector-effect', 'non-scaling-stroke');
    svg.append(shade, quad);
    const handles = [];
    for (let i = 0; i < 4; i++) {
        const g = document.createElementNS(svgNS, 'g');
        const hit = document.createElementNS(svgNS, 'ellipse');
        hit.setAttribute('class', 'hit');
        const c = document.createElementNS(svgNS, 'ellipse');
        c.setAttribute('class', 'handle');
        c.setAttribute('vector-effect', 'non-scaling-stroke');
        g.append(hit, c);
        g.dataset.i = String(i);
        g.setAttribute('role', 'slider');
        g.setAttribute('aria-label', ['Esquina superior izquierda', 'Esquina superior derecha', 'Esquina inferior derecha', 'Esquina inferior izquierda'][i]);
        svg.appendChild(g);
        handles.push(g);
    }
    const loupe = h('div', { class: 'loupe' });
    const loupeCanvas = h('canvas', { width: '110', height: '110' });
    loupe.appendChild(loupeCanvas);
    const box = h('div', { class: 'crop-box' }, view, svg, loupe);
    const stage = h('div', { class: 'stage' }, box);
    const status = h('div', { class: 'xs faint center' });
    const sizeBox = () => {
        const r = stage.getBoundingClientRect();
        const aw = Math.max(50, r.width - 32), ah = Math.max(50, r.height - 32);
        const k = Math.min(aw / view.width, ah / view.height);
        box.style.width = `${view.width * k}px`;
        box.style.height = `${view.height * k}px`;
        view.style.width = '100%';
        view.style.height = '100%';
        paint();
    };
    const paint = () => {
        const bw = box.clientWidth || 1, bh = box.clientHeight || 1;
        const P = [0, 1, 2, 3].map(i => [pts[i * 2] * 1000, pts[i * 2 + 1] * 1000]);
        quad.setAttribute('points', P.map(p => p.join(',')).join(' '));
        shade.setAttribute('d', `M0 0H1000V1000H0Z M${P.map(p => p.join(' ')).join(' L')} Z`);
        const rx = 11 * 1000 / bw, ry = 11 * 1000 / bh;
        handles.forEach((g, i) => {
            const [hit, c] = Array.from(g.children);
            for (const [el, k] of [[hit, 2.6], [c, 1]]) {
                el.setAttribute('cx', String(P[i][0]));
                el.setAttribute('cy', String(P[i][1]));
                el.setAttribute('rx', String(rx * k));
                el.setAttribute('ry', String(ry * k));
            }
        });
        const ok = isConvexQuad([0, 1, 2, 3].map(i => ({ x: pts[i * 2], y: pts[i * 2 + 1] })));
        quad.style.stroke = ok ? '' : 'var(--danger)';
        status.textContent = ok ? (dp.detected ? 'Hoja detectada automáticamente. Arrastra las esquinas para afinar.' : 'No se detectó la hoja con seguridad: arrastra las esquinas a sus bordes.') : 'Las esquinas se cruzan: corrige la forma.';
        nextBtn.disabled = !ok;
    };
    const drawLoupe = (nx, ny) => {
        const ctx = loupeCanvas.getContext('2d');
        // aumento ×2,5 respecto a lo que se ve en pantalla
        const sz = 110, disp = (box.clientWidth || 1) / view.width, src = sz / (2.5 * disp);
        const sx = nx * view.width - src / 2, sy = ny * view.height - src / 2;
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, sz, sz);
        ctx.drawImage(view, sx, sy, src, src, 0, 0, sz, sz);
        ctx.strokeStyle = '#b8acff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(sz / 2, sz / 2 - 14);
        ctx.lineTo(sz / 2, sz / 2 + 14);
        ctx.moveTo(sz / 2 - 14, sz / 2);
        ctx.lineTo(sz / 2 + 14, sz / 2);
        ctx.stroke();
        const bw = box.clientWidth, bh = box.clientHeight;
        const lx = nx * bw < bw / 2 ? bw - sz - 6 : 6;
        loupe.style.left = `${lx}px`;
        loupe.style.top = `${ny < 0.5 ? Math.max(6, bh - sz - 6) : 6}px`; // en la mitad opuesta: no tapa el dedo ni la esquina
    };
    let drag = -1;
    svg.addEventListener('pointerdown', e => {
        const r = box.getBoundingClientRect();
        const nx = (e.clientX - r.left) / r.width, ny = (e.clientY - r.top) / r.height;
        // esquina más cercana dentro de un radio táctil generoso
        let best = -1, bd = Infinity;
        for (let i = 0; i < 4; i++) {
            const d = Math.hypot((pts[i * 2] - nx) * r.width, (pts[i * 2 + 1] - ny) * r.height);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        if (bd > 48)
            return;
        drag = best;
        svg.setPointerCapture(e.pointerId);
        loupe.classList.add('on');
        drawLoupe(pts[best * 2], pts[best * 2 + 1]);
        e.preventDefault();
    });
    svg.addEventListener('pointermove', e => {
        if (drag < 0)
            return;
        const r = box.getBoundingClientRect();
        pts[drag * 2] = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
        pts[drag * 2 + 1] = Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
        paint();
        drawLoupe(pts[drag * 2], pts[drag * 2 + 1]);
    });
    const end = () => { drag = -1; loupe.classList.remove('on'); };
    svg.addEventListener('pointerup', end);
    svg.addEventListener('pointercancel', end);
    // transición suave de las esquinas (iOS anima los cambios de recorte)
    let tween = 0;
    const animateTo = (to) => {
        cancelAnimationFrame(tween);
        const from = [...pts], t0 = performance.now(), dur = document.documentElement.classList.contains('no-motion') ? 1 : 320;
        const step = (t) => {
            const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
            pts = from.map((v, i) => v + (to[i] - v) * e);
            paint();
            if (k < 1)
                tween = requestAnimationFrame(step);
        };
        tween = requestAnimationFrame(step);
    };
    const auto = async () => {
        const b = busy('Detectando bordes…');
        try {
            const q = await withSource(dp, fb => engine.detectAgain(dp.id, fb));
            b.done();
            if (q) {
                dp.detected = true;
                animateTo(q);
                toast('Bordes detectados', 'ok', 1500);
            }
            else
                toast('No se encontró la hoja. Ajusta las esquinas manualmente.', 'error');
        }
        catch (e) {
            b.done();
            toast(e.message, 'error');
        }
    };
    const tool = (icon, label, run) => h('button', { class: 'tool-btn', onclick: run }, ic(icon), label);
    const fromScan = params.from === 'scan';
    const nextBtn = btn(fromScan ? 'Usar' : 'Aplicar', () => {
        dp.corners = [...pts];
        dp.out = undefined;
        if (fromScan)
            void scheduleRender(dp).catch(e => toast(e.message, 'error'));
        history.back();
    }, 'primary', { icon: 'check' });
    const ro = new ResizeObserver(sizeBox);
    setTimeout(() => { ro.observe(stage); sizeBox(); });
    onLeave(() => { ro.disconnect(); cancelAnimationFrame(tween); });
    const leftBtn = fromScan
        ? btn('Repetir', () => { removePage(dp); history.back(); }, 'secondary', { icon: 'camera' })
        : btn('Cancelar', () => history.back(), 'secondary');
    return h('div', { class: 'editor' }, h('header', { class: 'topbar solid' }, h('span', { style: 'min-width:88px' }), h('h1', { style: 'text-align:center' }, 'Recortar'), h('span', { class: 'xs faint', style: 'min-width:88px;text-align:right;margin-right:12px' }, `Página ${s.pages.indexOf(dp) + 1}`)), stage, h('div', { class: 'editor-bar' }, status, h('div', { class: 'tool-row' }, tool('scan', 'Auto', () => void auto()), tool('maximize', 'Toda la foto', () => animateTo(FULL_NORM)), tool('crop', 'Margen', () => animateTo(insetNorm()))), h('div', { class: 'btn-row' }, leftBtn, nextBtn)));
}
