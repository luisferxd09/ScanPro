import { h, ic, pagesLabel, uid } from '../ui/dom.js';
import { topbar, btn, toast, emptyState, iconBtn, sheet, blobUrl, busy, fadeImg } from '../ui/components.js';
import { go } from '../core/router.js';
import { listDocs, getPages, mergeDocs } from '../core/db.js';
import { validateName, uniqueName } from '../core/names.js';
import { docThumb } from './common.js';
export async function mergeScreen(params) {
    const docs = (await listDocs()).sort((a, b) => b.updatedAt - a.updatedAt);
    const base = docs.find(d => d.id === params.id) ?? null;
    const order = base ? [base.id] : [];
    const byId = new Map(docs.map(d => [d.id, d]));
    const names = docs.map(d => d.name);
    if (docs.length < 2) {
        return h('div', { class: 'screen' }, topbar('Combinar documentos', { back: true }), emptyState('merge', 'Necesitas al menos dos documentos', 'Escanea o importa otro documento para poder unirlos en uno solo.'));
    }
    const pick = h('div', { class: 'list' });
    const orderEl = h('div', { class: 'list' });
    const summary = h('div', { class: 'small muted' });
    const input = h('input', { type: 'text', 'aria-label': 'Nombre del nuevo documento' });
    input.value = uniqueName(base ? `${base.name} (combinado)` : 'Documento combinado', names);
    const wrap = h('div', { class: 'input-wrap' }, ic('fileText', 'sm faint'), input);
    const err = h('div', { class: 'error', role: 'alert' });
    const previewBtn = btn('Vista previa', () => void preview(), 'secondary', { icon: 'eye', block: true });
    const mergeBtn = btn('Combinar documentos', () => void doMerge(), 'primary', { icon: 'merge', block: true });
    const total = () => order.reduce((a, id) => a + (byId.get(id)?.pageIds.length ?? 0), 0);
    const render = () => {
        pick.replaceChildren(...docs.map(d => {
            const sel = order.includes(d.id);
            return h('button', { class: 'merge-item' + (sel ? ' sel' : ''), 'aria-pressed': String(sel), onclick: () => {
                    if (sel)
                        order.splice(order.indexOf(d.id), 1);
                    else
                        order.push(d.id);
                    render();
                } }, h('span', { class: 'check' + (sel ? ' on' : '') }, sel ? ic('check', 'sm') : null), docThumb(d), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:500' }, d.name), h('div', { class: 'xs faint' }, pagesLabel(d.pageIds.length))));
        }));
        orderEl.replaceChildren(...(order.length ? order.map((id, i) => {
            const d = byId.get(id);
            const up = iconBtn('arrowUp', 'Subir', () => { [order[i - 1], order[i]] = [order[i], order[i - 1]]; render(); });
            const down = iconBtn('arrowDown', 'Bajar', () => { [order[i + 1], order[i]] = [order[i], order[i + 1]]; render(); });
            up.disabled = i === 0;
            down.disabled = i === order.length - 1;
            return h('div', { class: 'merge-item' }, h('span', { class: 'order-num' }, String(i + 1)), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:500' }, d.name), h('div', { class: 'xs faint' }, pagesLabel(d.pageIds.length))), up, down);
        }) : [h('div', { class: 'small faint' }, 'Selecciona documentos arriba.')]));
        summary.textContent = order.length >= 2 ? `El nuevo documento tendrá ${pagesLabel(total())} de ${order.length} documentos. Los originales no se modifican.` : 'Selecciona al menos dos documentos.';
        previewBtn.disabled = mergeBtn.disabled = order.length < 2;
    };
    const preview = async () => {
        const all = [];
        for (const id of order) {
            const d = byId.get(id);
            const ps = await getPages(d);
            ps.forEach((p, i) => all.push({ blob: p.thumb, label: `${d.name} · ${i + 1}` }));
        }
        sheet(close => [
            h('h2', null, `Vista previa · ${pagesLabel(all.length)}`),
            h('div', { class: 'preview-grid' }, all.map((p, i) => h('div', { class: 'pg', title: p.label }, fadeImg(blobUrl(p.blob), p.label), h('span', null, String(i + 1))))),
            h('div', { style: 'height:16px' }),
            btn('Cerrar', () => void close(), 'secondary', { block: true }),
        ]);
    };
    const doMerge = async () => {
        const v = validateName(input.value, names);
        if (!v.ok) {
            wrap.classList.add('invalid');
            err.textContent = v.error + (v.suggestion ? ` Prueba «${v.suggestion}».` : '');
            input.focus();
            return;
        }
        const expected = total();
        const b = busy('Combinando páginas…');
        try {
            const doc = await mergeDocs(order, v.name, uid);
            b.done();
            if (doc.pageIds.length !== expected)
                throw new Error('El número de páginas no coincide.');
            toast(`«${doc.name}» creado con ${pagesLabel(doc.pageIds.length)}`);
            go('doc', { id: doc.id }, { replace: true });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error', 4500);
        }
    };
    input.addEventListener('input', () => { wrap.classList.remove('invalid'); err.textContent = ''; });
    render();
    return h('div', { class: 'screen' }, topbar('Combinar documentos', { back: true }), h('div', { class: 'content stack' }, h('div', { class: 'section-title', style: 'margin-top:4px' }, '1. Elige los documentos'), pick, h('div', { class: 'section-title' }, '2. Orden de unión'), orderEl, h('div', { class: 'section-title' }, '3. Nombre del nuevo documento'), h('div', { class: 'field' }, wrap, err), summary, h('div', { class: 'stack', style: 'margin-top:8px' }, mergeBtn, previewBtn)));
}
