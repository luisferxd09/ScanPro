// Idiomas de la interfaz. El español es el original; para los demás se carga un diccionario
// (src/i18n/lang/xx.ts, alineado con KEYS) y se traduce el DOM al vuelo.
import { KEYS } from './keys.js';
import { curLang, isRtl, langInfo } from '../core/locale.js';
let dict = null;
let RX = [];
export const uiLang = () => curLang();
/** Traduce un texto escrito en español al idioma actual (o lo deja igual). */
export function t(s) { return (dict && tr(s)) ?? s; }
function tr(s) {
    if (!dict)
        return null;
    const k = s.trim();
    if (!k)
        return null;
    const d = dict.get(k);
    if (d)
        return s.replace(k, d);
    for (const [rx, rep] of RX)
        if (rx.test(k))
            return s.replace(k, k.replace(rx, rep));
    return null;
}
const ATTRS = ['aria-label', 'placeholder', 'title'];
function walk(n) {
    if (n.nodeType === 3) {
        const p = n.parentElement;
        if (p?.closest('[data-notr]'))
            return;
        const r = tr(n.nodeValue ?? '');
        if (r !== null && r !== n.nodeValue)
            n.nodeValue = r;
        return;
    }
    if (n.nodeType !== 1)
        return;
    const el = n;
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.tagName === 'TEXTAREA' || el.isContentEditable || el.hasAttribute('data-notr'))
        return;
    for (const a of ATTRS) {
        const v = el.getAttribute(a);
        if (v) {
            const r = tr(v);
            if (r !== null && r !== v)
                el.setAttribute(a, r);
        }
    }
    n.childNodes.forEach(walk);
}
export async function initI18n() {
    const lang = curLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = isRtl() ? 'rtl' : 'ltr';
    document.documentElement.classList.toggle('rtl', isRtl());
    if (lang === 'es')
        return;
    try {
        const m = await import(`./lang/${lang}.js`);
        dict = new Map();
        KEYS.forEach((k, i) => { const v = m.T[i]; if (v)
            dict.set(k, v); });
        RX = (m.RX ?? []).map(([a, b]) => [new RegExp(a), b]);
    }
    catch {
        dict = null;
        return;
    }
    walk(document.body);
    new MutationObserver(ms => { for (const m of ms) {
        if (m.type === 'characterData')
            walk(m.target);
        else
            m.addedNodes.forEach(walk);
        if (m.type === 'attributes')
            walk(m.target);
    } })
        .observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    void langInfo;
}
