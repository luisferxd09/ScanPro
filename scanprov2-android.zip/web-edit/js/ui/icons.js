// Iconografía de trazo uniforme (rejilla 24×24, trazo redondeado al estilo de iOS) dibujada para ScanPro.
const P = {
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
    qr: '<rect x="3.5" y="3.5" width="6.5" height="6.5" rx="1.2"/><rect x="14" y="3.5" width="6.5" height="6.5" rx="1.2"/><rect x="3.5" y="14" width="6.5" height="6.5" rx="1.2"/><path d="M14 14h2.5v2.5H14zM18 18h2.5v2.5H18zM18 14h2.5M14 18v2.5"/>',
    volume: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18.3 6.5a8 8 0 0 1 0 11"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>',
    printer: '<path d="M6.5 9V3.5h11V9"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6.5 14h11v6.5h-11z"/>',
    tag: '<path d="M3 12V4.5A1.5 1.5 0 0 1 4.5 3H12l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1.4"/>',
    scissors: '<circle cx="6" cy="6" r="2.8"/><circle cx="6" cy="18" r="2.8"/><path d="M8.2 7.8 20 18M8.2 16.2 20 6"/>',
    stamp: '<path d="M9 13V9.5a3 3 0 1 1 6 0V13"/><rect x="4" y="13" width="16" height="4" rx="1.2"/><path d="M5 20.5h14"/>',
    eraser: '<path d="m7 21-4-4 10.5-10.5a2 2 0 0 1 2.8 0l3.2 3.2a2 2 0 0 1 0 2.8L11 21z"/><path d="M7 21h13M8.5 11.5l6 6"/>',
    wallet: '<path d="M3.5 7.5A2 2 0 0 1 5.5 5.5h13v3"/><rect x="3.5" y="7.5" width="17" height="12" rx="2"/><path d="M16 13.5h4.5"/>',
    cart: '<circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/><path d="M2.5 3.5h3l2.4 11.5h10.6l2-8H6.6"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',
    car: '<path d="M5 16.5V12l2-5h10l2 5v4.5"/><rect x="3.5" y="11.5" width="17" height="5" rx="1.5"/><circle cx="7.5" cy="18" r="1.6"/><circle cx="16.5" cy="18" r="1.6"/>',
    paw: '<circle cx="7" cy="9" r="1.8"/><circle cx="11" cy="6" r="1.8"/><circle cx="15" cy="7" r="1.8"/><circle cx="18" cy="10.5" r="1.6"/><path d="M8.5 17.5c0-2.5 2-4.5 4.5-4.5s4 2 4 4c0 1.7-1.5 2.5-3 2.5-1 0-1.8-.5-3-.5s-2.5 1-3.5 0c-.6-.5 1-1.5 1-1.5z"/>',
    graduation: '<path d="M2 9l10-4.5L22 9l-10 4.5z"/><path d="M6 11v4.5c1.5 1.5 3.7 2.3 6 2.3s4.5-.8 6-2.3V11M22 9v5"/>',
    briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8.5 7V5a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v2M3 12.5h18"/>',
    play: '<path d="M7 4.5v15l12.5-7.5z"/>',
    calculator: '<rect x="5" y="2.5" width="14" height="19" rx="2"/><path d="M8 6.5h8M8 11h.01M12 11h.01M16 11h.01M8 14.5h.01M12 14.5h.01M16 14.5h.01M8 18h.01M12 18h4"/>',
    person: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c1-4 4-6 7.5-6s6.5 2 7.5 6"/>',
    bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    magnifier: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5M8 10.5h5M10.5 8v5"/>',
    compare: '<rect x="3" y="4" width="7.5" height="16" rx="1.5"/><rect x="13.5" y="4" width="7.5" height="16" rx="1.5"/><path d="M5.5 8.5h2.5M5.5 12h2.5M16 8.5h2.5M16 12h2.5M16 15.5h2.5"/>',
    translate: '<path d="M3 5.5h9M7.5 3.5v2M5 9.5c1.5 2.5 3.5 4.3 6 5.5M10.5 5.5c-1 4-3.5 7.5-7 9.5"/><path d="m13 20.5 3.8-9 3.7 9M14.3 17.5h5"/>',
    presentation: '<rect x="3" y="3.5" width="18" height="12" rx="1.5"/><path d="M12 15.5v3M8 21l4-2.5 4 2.5M9.5 7.5l5 2.5-5 2.5z"/>',
    camera: '<path d="M14.5 4h-5L7.5 6.5H4.5A2 2 0 0 0 2.5 8.5v9a2 2 0 0 0 2 2h15a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3.5"/>',
    idCard: '<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><circle cx="8.5" cy="11" r="2.2"/><path d="M5.2 16.2c.7-1.5 1.9-2.3 3.3-2.3s2.6.8 3.3 2.3M14.5 10h4M14.5 13.5h3"/>',
    files: '<path d="M15 2H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V6z"/><path d="M15 2v4h4"/><path d="M3 7v12a3 3 0 0 0 3 3h9"/>',
    fileText: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h8M8 9h2"/>',
    filePdf: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8.5 17.5c1.5-.6 4.6-3.6 4.8-6.1.1-1.4-1.6-1.5-1.6 0 0 2.2 2.3 4.7 4.3 5.1 1.2.2 1.2-1.2-.2-1.2-2.5 0-5.4 1.4-7.3 2.2z"/>',
    fileWord: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="m7.5 12 1.3 5.5L10.5 13l1.7 4.5L13.5 12"/>',
    ocr: '<path d="M4 7V5a1 1 0 0 1 1-1h2M17 4h2a1 1 0 0 1 1 1v2M20 17v2a1 1 0 0 1-1 1h-2M7 20H5a1 1 0 0 1-1-1v-2"/><path d="M8 8.5h8M12 8.5v8"/>',
    type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    filters: '<circle cx="9" cy="9" r="5.5"/><circle cx="15" cy="9" r="5.5"/><circle cx="12" cy="15" r="5.5"/>',
    grid: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    folderPlus: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v6M9 14h6"/>',
    folderMove: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 14h6M13 11.5l2.5 2.5-2.5 2.5"/>',
    tools: '<path d="M14.7 6.3a4 4 0 0 0 5 5L21 13l-2 2-1.3-1.3-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9L13.4 9.4l2-2z"/><path d="m3 3 4 4M7 3v4H3"/>',
    settings: '<path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-4.5-4.5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    xCircle: '<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6M9 9l6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    back: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
    chevRight: '<path d="m9 6 6 6-6 6"/>',
    chevDown: '<path d="m6 9 6 6 6-6"/>',
    moreV: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
    moreH: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    pencil: '<path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/><path d="m14.5 5.5 3 3"/>',
    trash: '<path d="M3.5 6h17M8.5 6V4.5a1.5 1.5 0 0 1 1.5-1.5h4a1.5 1.5 0 0 1 1.5 1.5V6M18.5 6l-.8 13a2 2 0 0 1-2 1.9H8.3a2 2 0 0 1-2-1.9L5.5 6"/><path d="M10 10.5v6M14 10.5v6"/>',
    merge: '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3"/><rect x="6" y="8" width="12" height="13" rx="2"/><path d="M12 11.5v6M9 14.5h6"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
    upload: '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
    crown: '<path d="m3 7 4 4 5-6 5 6 4-4-2 11H5L3 7z"/><path d="M5 21h14"/>',
    dice: '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M8 8h.01M16 8h.01M12 12h.01M8 16h.01M16 16h.01"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-4.5-4.5L6 21"/>',
    images: '<rect x="7" y="3" width="14" height="14" rx="2.5"/><circle cx="12" cy="8" r="1.6"/><path d="m21 13-3.5-3.5L10 17"/><path d="M3 7v11a3 3 0 0 0 3 3h11"/>',
    imagePlus: '<path d="M21 12v6a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h6"/><circle cx="9" cy="9" r="2"/><path d="m21 15-4.5-4.5L6 21M16 5h6M19 2v6"/>',
    rotateCw: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    rotateCcw: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
    scan: '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 12h10"/>',
    expand: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    monitor: '<rect x="2.5" y="3.5" width="19" height="13" rx="2"/><path d="M8 21h8M12 16.5V21"/>',
    contrast: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18a9 9 0 0 0 0-18z" fill="currentColor"/>',
    droplet: '<path d="M12 2.7 6.3 8.4a8 8 0 1 0 11.4 0z"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    arrowUp: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    arrowDown: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
    arrowLeft: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    arrowRight: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    sort: '<path d="m3 16 4 4 4-4M7 20V4M21 8l-4-4-4 4M17 4v16"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 16v-4.5M12 8h.01"/>',
    alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    hardDrive: '<path d="M22 12H2M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/><path d="M6 16h.01M10 16h.01"/>',
    archive: '<rect x="2" y="3.5" width="20" height="5" rx="1.5"/><path d="M4 8.5V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8.5M10 12.5h4"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 15.5-6.2L21 8M21 3v5h-5M21 12a9 9 0 0 1-15.5 6.2L3 16M3 21v-5h5"/>',
    zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    zapOff: '<path d="M12.4 7.3 13 2l-3.3 4.4M17 10.5h2l-2.3 3.1M9 9 4 14h7l-1 8 4.6-6.1M2 2l20 20"/>',
    language: '<path d="m5 8 6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6"/>',
    wand: '<path d="m15 4 .6 1.4L17 6l-1.4.6L15 8l-.6-1.4L13 6l1.4-.6zM19 10l.4.9.9.4-.9.4-.4.9-.4-.9-.9-.4.9-.4z"/><path d="m3 21 12-12 1.5 1.5-12 12z"/>',
    book: '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
    layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    pages: '<rect x="3" y="3" width="7.5" height="9" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="9" rx="1.5"/><rect x="3" y="14.5" width="7.5" height="6.5" rx="1.5"/><rect x="13.5" y="14.5" width="7.5" height="6.5" rx="1.5"/>',
    fileImage: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><circle cx="10" cy="13" r="1.6"/><path d="m20 17-3-3-7 7"/>',
    fileZip: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M10 4h1M10 7h1M10 10h1M9.5 13h2v4h-2z"/>',
    maximize: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    homeFill: '<path d="M11.3 2.6a1.2 1.2 0 0 1 1.4 0l8.6 6.7c.4.3.7.8.7 1.3V20a2 2 0 0 1-2 2h-4.2v-6.4h-3.6V22H4a2 2 0 0 1-2-2v-9.4c0-.5.3-1 .7-1.3z" fill="currentColor" stroke="none"/>',
    docsFill: '<path d="M8 2h6.6c.5 0 1 .2 1.4.6l3.4 3.4c.4.4.6.9.6 1.4V16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" fill="currentColor" stroke="none"/><path d="M3.5 7v12.5A2.5 2.5 0 0 0 6 22h9.5" stroke-width="2"/>',
    gridFill: '<rect x="3" y="3" width="8" height="8" rx="2.3" fill="currentColor" stroke="none"/><rect x="13" y="3" width="8" height="8" rx="2.3" fill="currentColor" stroke="none"/><rect x="3" y="13" width="8" height="8" rx="2.3" fill="currentColor" stroke="none"/><rect x="13" y="13" width="8" height="8" rx="2.3" fill="currentColor" stroke="none"/>',
    gearFill: '<path fill="currentColor" stroke="none" fill-rule="evenodd" d="M10.3 2.2a1.7 1.7 0 0 1 3.4 0l.2 1.2c.6.2 1.2.4 1.7.7l1-.7a1.7 1.7 0 0 1 2.4 2.4l-.7 1c.3.5.6 1.1.7 1.7l1.2.2a1.7 1.7 0 0 1 0 3.4l-1.2.2c-.2.6-.4 1.2-.7 1.7l.7 1a1.7 1.7 0 0 1-2.4 2.4l-1-.7c-.5.3-1.1.6-1.7.7l-.2 1.2a1.7 1.7 0 0 1-3.4 0l-.2-1.2c-.6-.2-1.2-.4-1.7-.7l-1 .7a1.7 1.7 0 0 1-2.4-2.4l.7-1c-.3-.5-.6-1.1-.7-1.7l-1.2-.2a1.7 1.7 0 0 1 0-3.4l1.2-.2c.2-.6.4-1.2.7-1.7l-.7-1a1.7 1.7 0 0 1 2.4-2.4l1 .7c.5-.3 1.1-.6 1.7-.7zM12 15.3a3.3 3.3 0 1 0 0-6.6 3.3 3.3 0 0 0 0 6.6z"/>',
    docs: '<path d="M8 2.8h6.3l4.9 4.9V16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4.8a2 2 0 0 1 2-2z"/><path d="M14 3v4.5h5M3.5 7v12.5A2.5 2.5 0 0 0 6 22h9.5"/>',
    gridOut: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
    motion: '<path d="M3 12c2.5-4 5-4 7.5 0s5 4 7.5 0M3 17c2.5-4 5-4 7.5 0s5 4 7.5 0M3 7c2.5-4 5-4 7.5 0s5 4 7.5 0" transform="translate(1.5 0)"/>',
    chevLeft: '<path d="m15 5-7 7 7 7"/>',
    stack: '<rect x="6" y="3" width="12" height="15" rx="2"/><path d="M4 7v12a2 2 0 0 0 2 2h10"/>',
    hand: '<path d="M18 11V6a2 2 0 0 0-4 0v5M14 10V4a2 2 0 0 0-4 0v6M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.9-6-2.4l-3.6-3.6a2 2 0 0 1 2.8-2.8L7 15"/>',
};
export function iconSvg(name, cls = '') {
    if (name === 'activity')
        return activitySvg();
    const body = P[name] ?? P.info;
    return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
}
export function icon(name, cls = '') {
    const t = document.createElement('template');
    t.innerHTML = iconSvg(name, cls);
    return t.content.firstElementChild;
}
/** Logotipo: «squircle» estilo icono de iOS con degradado pastel y hoja con marcas de escaneo. */
export function logoSvg(size = 40) {
    const id = 'lg' + size;
    return `<svg width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true">
  <defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c7bbff"/><stop offset=".55" stop-color="#f3c0dc"/><stop offset="1" stop-color="#ffd6bf"/></linearGradient></defs>
  <path d="M62.5 32.0 L62.5 43.5 L62.3 47.1 L62.1 49.8 L61.8 51.9 L61.3 53.6 L60.8 55.1 L60.2 56.4 L59.4 57.6 L58.6 58.6 L57.6 59.4 L56.4 60.2 L55.1 60.8 L53.6 61.3 L51.9 61.8 L49.8 62.1 L47.1 62.3 L43.5 62.5 L32.0 62.5 L20.5 62.5 L16.9 62.3 L14.2 62.1 L12.1 61.8 L10.4 61.3 L8.9 60.8 L7.6 60.2 L6.4 59.4 L5.4 58.6 L4.6 57.6 L3.8 56.4 L3.2 55.1 L2.7 53.6 L2.2 51.9 L1.9 49.8 L1.7 47.1 L1.5 43.5 L1.5 32.0 L1.5 20.5 L1.7 16.9 L1.9 14.2 L2.2 12.1 L2.7 10.4 L3.2 8.9 L3.8 7.6 L4.6 6.4 L5.4 5.4 L6.4 4.6 L7.6 3.8 L8.9 3.2 L10.4 2.7 L12.1 2.2 L14.2 1.9 L16.9 1.7 L20.5 1.5 L32.0 1.5 L43.5 1.5 L47.1 1.7 L49.8 1.9 L51.9 2.2 L53.6 2.7 L55.1 3.2 L56.4 3.8 L57.6 4.6 L58.6 5.4 L59.4 6.4 L60.2 7.6 L60.8 8.9 L61.3 10.4 L61.8 12.1 L62.1 14.2 L62.3 16.9 L62.5 20.5Z" fill="url(#${id})"/>
  <path d="M23 15.5h12.5l7.5 7.5v22.5a3 3 0 0 1-3 3H23a3 3 0 0 1-3-3v-27a3 3 0 0 1 3-3z" fill="#fff"/>
  <path d="M35.5 15.5V21a2 2 0 0 0 2 2H43" fill="#e6dfff"/>
  <rect x="24.5" y="29" width="14" height="2.4" rx="1.2" fill="#a497f5"/><rect x="24.5" y="34" width="14" height="2.4" rx="1.2" fill="#c3b9fa"/><rect x="24.5" y="39" width="9" height="2.4" rx="1.2" fill="#c3b9fa"/>
  <path d="M11 22v-5.5a5.5 5.5 0 0 1 5.5-5.5H22M53 42v5.5a5.5 5.5 0 0 1-5.5 5.5H42M42 11h5.5a5.5 5.5 0 0 1 5.5 5.5V22M22 53h-5.5a5.5 5.5 0 0 1-5.5-5.5V42" stroke="#5b4bc4" stroke-width="2.8" stroke-linecap="round" fill="none" opacity=".75"/>
</svg>`;
}
/** Ilustración de bienvenida (pocas formas: barata de pintar). */
export function scanArtSvg() {
    return `<svg viewBox="0 0 200 200" aria-hidden="true">
  <defs>
    <linearGradient id="sa1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d2c8ff"/><stop offset=".6" stop-color="#f6cde3"/><stop offset="1" stop-color="#ffdcc9"/></linearGradient>
  </defs>
  <circle cx="100" cy="100" r="90" fill="url(#sa1)" opacity=".55"/>
  <g transform="rotate(-6 100 100)">
    <rect x="58" y="38" width="86" height="114" rx="10" fill="#9b8de8" opacity=".25"/>
    <rect x="52" y="32" width="86" height="114" rx="10" fill="#fff"/>
    <rect x="64" y="50" width="44" height="7" rx="3.5" fill="#8c7cf7"/>
    <rect x="64" y="68" width="62" height="5" rx="2.5" fill="#ddd6fb"/><rect x="64" y="81" width="62" height="5" rx="2.5" fill="#ddd6fb"/>
    <rect x="64" y="94" width="52" height="5" rx="2.5" fill="#ddd6fb"/><rect x="64" y="107" width="62" height="5" rx="2.5" fill="#ddd6fb"/>
    <rect x="64" y="120" width="36" height="5" rx="2.5" fill="#ffc7b1"/>
  </g>
  <path d="M28 54V38a10 10 0 0 1 10-10h16M146 28h16a10 10 0 0 1 10 10v16M172 146v16a10 10 0 0 1-10 10h-16M54 172H38a10 10 0 0 1-10-10v-16" stroke="#8c7cf7" stroke-width="5" stroke-linecap="round" fill="none"/>
</svg>`;
}
/** Indicador de actividad de iOS: 8 radios con opacidad decreciente. */
export function activitySvg() {
    let r = '';
    for (let i = 0; i < 8; i++)
        r += `<rect x="13.5" y="2" width="3" height="8" rx="1.5" fill="currentColor" opacity="${(1 - i * 0.11).toFixed(2)}" transform="rotate(${-i * 45} 15 15)"/>`;
    return `<svg class="activity" viewBox="0 0 30 30" aria-hidden="true">${r}</svg>`;
}
