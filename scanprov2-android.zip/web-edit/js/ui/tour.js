// Tutorial paso a paso: resalta cada parte de la pantalla la primera vez que la abres.
import { h, ic } from './dom.js';
import { feedback } from './components.js';
import { getSettings } from '../core/settings.js';
const KEY = 'scanpro.tours.v1';
const seen = () => { try {
    return JSON.parse(localStorage.getItem(KEY) || '{}');
}
catch {
    return {};
} };
const mark = (id) => { try {
    const s = seen();
    s[id] = 1;
    localStorage.setItem(KEY, JSON.stringify(s));
}
catch { /* */ } };
export const resetTours = () => { try {
    localStorage.removeItem(KEY);
}
catch { /* */ } };
export const tourSeen = (id) => { const s = seen(); return !!(s[id] || s.all); };
const TOURS = {
    home: [
        { title: '¡Bienvenido a ScanPro! 👋', text: 'Te muestro en 30 segundos cómo usarla. Puedes saltarte esto cuando quieras.' },
        { sel: '.hero-card', title: '1. Escanea', text: 'Toca aquí, apunta a la hoja y ScanPro la encuadra, la endereza y la deja como escaneada.' },
        { sel: '.fab', title: '2. Botón +', text: 'Desde cualquier pantalla: escanear, importar fotos, PDF o Word, o copiar tu cédula.' },
        { sel: '.quick-grid', title: '3. Accesos rápidos', text: 'Las herramientas que más se usan: texto, PDF, cédula, QR, firmar…' },
        { sel: '.tabbar .tab:nth-child(2)', title: '4. Tus documentos', text: 'Aquí se guarda todo, ordenado. Puedes buscar por nombre o por lo que dice el documento.' },
        { sel: '.tabbar .tab:nth-child(3)', title: '5. Herramientas', text: 'Más de 50 herramientas: dividir PDF, firmar, traducir, gastos y mucho más.' },
        { sel: '.tabbar .tab:nth-child(4)', title: '6. Ajustes', text: 'Idioma, sonidos, copias de seguridad y más. ¡Listo, a escanear!' },
    ],
    review: [
        { sel: 'input[aria-label="Nombre del documento"]', title: 'Ponle nombre', text: 'O déjalo así: ScanPro lo nombra solo según lo que diga el documento.' },
        { sel: '.review-item', title: 'Revisa cada página', text: 'Tócala para recortar, girar o aplicar filtros. Con las flechas cambias el orden.' },
        { sel: '.btn.primary', title: 'Guarda', text: 'Toca «Guardar documento». Después podrás compartirlo como PDF, Word o imagen.' },
    ],
    doc: [
        { sel: '.viewer', title: 'Tu documento', text: 'Desliza para ver las páginas. Toca una para editarla.' },
        { sel: '.action-strip', title: 'Lo esencial', text: 'Agregar páginas, ordenarlas, sacar el texto o exportar en PDF, Word o imagen.' },
        { sel: '.topbar .icon-btn:last-child, .topbar button:last-child', title: 'Más opciones', text: 'Firmar, traducir, leer en voz alta, revisar un contrato, imprimir y más.' },
    ],
    share: [
        { sel: '.option', title: 'Elige el formato', text: 'PDF para enviar, Word para editar, JPG para fotos. ScanPro recuerda tu elección.' },
        { sel: '.btn-row .btn.primary', title: 'Continuar', text: 'Se crea el archivo y eliges si guardarlo en el teléfono o enviarlo por WhatsApp, correo…' },
    ],
    tools: [
        { sel: '.tool-search', title: 'Busca una herramienta', text: 'Escribe lo que necesitas: «firmar», «comprimir», «traducir»…' },
        { sel: '.tool-section', title: 'Por categorías', text: 'Están agrupadas por uso. Toca cualquiera: cada una te explica cómo funciona la primera vez.' },
    ],
    scan: [
        { sel: '.stage', title: 'Apunta a la hoja', text: 'Ponla sobre una mesa oscura. Cuando el marco se ponga verde, quédate quieto: dispara solo.' },
        { sel: '.shutter', title: 'O dispara tú', text: 'Toca el botón para tomar la foto cuando quieras. Puedes tomar varias páginas seguidas.' },
    ],
    annotate: [
        { sel: '.tool-row', title: 'Firma y escribe', text: 'Dibuja tu firma una vez y queda guardada. También puedes escribir, resaltar o tachar.' },
        { sel: '.topbar .btn.primary, .btn.primary', title: 'Guardar', text: 'Arrastra la firma o el texto a su lugar y toca Guardar.' },
    ],
    ocr: [{ sel: '.btn.primary', title: 'Sacar el texto', text: 'ScanPro lee el documento en tu teléfono, sin internet. Después puedes copiarlo, buscarlo o traducirlo.' }],
    gastos: [{ sel: '.btn.primary', title: 'Tus gastos', text: 'Fotografía un recibo o factura: ScanPro lee el total y la fecha y suma tus gastos del mes.' }],
    inventario: [{ sel: '.btn.primary', title: 'Inventario', text: 'Agrega productos con foto y código de barras. Al vender, lee el código y descuenta solo.' }],
    vida: [{ title: 'Carpetas de vida', text: 'Guarda aquí tus documentos importantes. Si tienen fecha de vencimiento, te avisamos 7 días antes.' }],
    avisos: [{ sel: '.btn.primary', title: 'Avisos', text: 'Crea recordatorios de medicamentos, pagos o citas. Te llegan aunque la app esté cerrada.' }],
    preguntar: [{ sel: 'input', title: 'Pregunta lo que quieras', text: 'Por ejemplo «¿Cuándo vence mi SOAT?» o «¿Cuánto gasté este mes?». ScanPro busca en tus documentos.' }],
    privado: [{ title: 'Carpeta privada', text: 'Lo que pongas aquí no aparece en ninguna otra parte y se abre con tu huella o PIN.' }],
};
let running = false;
export function runTours(route) {
    if (running || !getSettings().onboardingDone)
        return;
    const steps = TOURS[route];
    if (!steps || tourSeen(route))
        return;
    setTimeout(() => { if (!document.querySelector('.overlay, .busy, .tour'))
        startTour(route, steps); }, 650);
}
export function startTour(id, steps) {
    running = true;
    mark(id);
    let i = 0;
    const hole = h('div', { class: 'tour-hole' }), bubble = h('div', { class: 'tour-bubble', role: 'dialog' });
    const root = h('div', { class: 'tour' }, hole, bubble);
    const end = () => { running = false; root.classList.add('out'); setTimeout(() => root.remove(), 250); };
    const show = () => {
        const s = steps[i], el = s.sel ? [...document.querySelectorAll(s.sel)].find(x => x.offsetParent !== null || x.getClientRects().length) : null;
        if (el)
            el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        setTimeout(() => {
            const r = el?.getBoundingClientRect();
            if (r && r.width) {
                Object.assign(hole.style, { left: `${r.left - 8}px`, top: `${r.top - 8}px`, width: `${r.width + 16}px`, height: `${r.height + 16}px`, borderRadius: '18px', opacity: '1' });
            }
            else
                Object.assign(hole.style, { left: '50%', top: '40%', width: '0px', height: '0px', opacity: '1' });
            bubble.replaceChildren(h('div', { class: 'tour-count' }, `${i + 1} / ${steps.length}`), h('h3', null, s.title), h('p', null, s.text), h('div', { class: 'tour-btns' }, i < steps.length - 1 ? h('button', { class: 'tour-skip', onclick: end }, 'Omitir') : h('span'), h('button', { class: 'tour-next', onclick: () => { if (i < steps.length - 1) {
                    i++;
                    feedback('step');
                    show();
                }
                else {
                    feedback('success');
                    end();
                } } }, i < steps.length - 1 ? 'Siguiente' : '¡Entendido!', ic(i < steps.length - 1 ? 'chevRight' : 'check', 'sm'))));
            const below = !r || r.top + r.height / 2 < window.innerHeight / 2;
            bubble.style.top = r && r.width ? (below ? `${Math.min(window.innerHeight - 220, r.bottom + 16)}px` : '') : '50%';
            bubble.style.bottom = r && r.width && !below ? `${Math.max(16, window.innerHeight - r.top + 16)}px` : '';
            bubble.classList.toggle('center', !r || !r.width);
            bubble.classList.remove('in');
            void bubble.offsetWidth;
            bubble.classList.add('in');
        }, el ? 280 : 0);
    };
    document.body.appendChild(root);
    feedback('step');
    show();
}
/** Tarjetas de ayuda antes de una acción (por ejemplo, el primer escaneo con la cámara de Google). */
export function tipOnce(id, cards) {
    if (tourSeen(id))
        return Promise.resolve();
    mark(id);
    return new Promise(resolve => {
        let i = 0;
        const body = h('div', { class: 'tip-card' });
        const root = h('div', { class: 'tour tip' }, body);
        const paint = () => {
            const c = cards[i];
            body.replaceChildren(h('div', { class: 'tip-ico' }, ic(c.icon, 'lg')), h('div', { class: 'tour-count' }, `${i + 1} / ${cards.length}`), h('h3', null, c.title), h('p', null, c.text), h('div', { class: 'tip-dots' }, ...cards.map((_, k) => h('i', { class: k === i ? 'on' : '' }))), h('button', { class: 'tour-next block', onclick: () => { if (i < cards.length - 1) {
                    i++;
                    feedback('step');
                    paint();
                }
                else {
                    feedback('success');
                    root.remove();
                    resolve();
                } } }, i < cards.length - 1 ? 'Siguiente' : '¡Empezar!'));
            body.classList.remove('in');
            void body.offsetWidth;
            body.classList.add('in');
        };
        document.body.appendChild(root);
        feedback('step');
        paint();
    });
}
