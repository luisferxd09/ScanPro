// Componentes reutilizables del sistema de diseño (estilo iOS, tonos pastel).
import { play, haptic } from '../core/sounds.js';
import { h, ic, clear, vibrate } from './dom.js';
import { logoSvg, activitySvg } from './icons.js';
import { go, back, currentRoute, pushOverlay, popOverlay, TABS } from '../core/router.js';
// ---------- Estructura ----------
/** Barra superior. `back`: botón «‹ Atrás» de iOS (texto opcional). */
export function topbar(title, opts = {}) {
    const b = opts.back;
    return h('header', { class: 'topbar' + (opts.solid ? ' solid' : '') }, b ? h('button', { class: 'back-btn', 'aria-label': 'Atrás', onclick: () => (typeof b === 'function' ? b() : back()) }, ic('chevLeft'), opts.backLabel ?? null) : null, typeof title === 'string' ? h('h1', null, title) : title, ...(opts.actions ?? []));
}
/**
 * Cabecera con «título grande» de iOS: el título grande se desplaza con el contenido y,
 * al desaparecer, aparece uno pequeño centrado en la barra (IntersectionObserver: sin coste por scroll).
 */
export function largeHeader(title, opts = {}) {
    const mini = h('div', { class: 'mini-title' }, title);
    const bar = h('header', { class: 'topbar' }, ...(opts.left ?? []), mini, h('span', { class: 'grow' }), ...(opts.actions ?? []));
    const big = h('h1', { class: 'large-title' }, title);
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(([e]) => bar.classList.toggle('scrolled', !e.isIntersecting), { rootMargin: '-52px 0px 0px 0px' });
        io.observe(big);
    }
    return [bar, big];
}
export function iconBtn(name, label, onclick, cls = '') {
    return h('button', { class: 'icon-btn ' + cls, 'aria-label': label, title: label, onclick }, ic(name));
}
export function textBtn(label, onclick, bold = false) {
    return h('button', { class: 'text-btn' + (bold ? ' bold' : ''), onclick }, label);
}
export function btn(label, onclick, variant = 'primary', opts = {}) {
    const b = h('button', { class: `btn ${variant}${opts.block ? ' block' : ''}${opts.sm ? ' sm' : ''}`, onclick }, opts.icon ? ic(opts.icon, 'sm') : null, label);
    if (opts.disabled)
        b.disabled = true;
    return b;
}
export function tile(icon, tint, lg = false) {
    return h('span', { class: `tile c-${tint}${lg ? ' lg' : ''}` }, ic(icon));
}
export function brand(size = 34, fontSize = 26) {
    return h('div', { class: 'logo-row' }, h('span', { html: logoSvg(size) }), h('span', { class: 'brand', style: `font-size:${fontSize}px` }, 'Scan', h('b', null, 'Pro')));
}
export function emptyState(iconName, title, text, action) {
    return h('div', { class: 'empty' }, h('div', { class: 'e-art' }, ic(iconName, 'xl')), h('h3', null, title), h('p', null, text), action ?? null);
}
export function note(text, kind = 'info') {
    return h('div', { class: 'note ' + kind }, ic(kind === 'info' ? 'info' : 'alert', 'sm'), h('div', null, text));
}
/** Marca los hijos de `el` para entrar escalonados (solo al montar la pantalla). */
export function stagger(el) {
    el.classList.add('stagger');
    Array.from(el.children).forEach((c, i) => c.style.setProperty('--i', String(i)));
    setTimeout(() => el.classList.remove('stagger'), 1200);
    return el;
}
// ---------- Barra de pestañas y botón + (globales: no se mueven al cambiar de pestaña) ----------
let tabbar = null;
let fab = null;
const TAB_DEF = [
    ['home', 'home', 'homeFill', 'Inicio'], ['docs', 'docs', 'docsFill', 'Documentos'],
    ['tools', 'gridOut', 'gridFill', 'Herramientas'], ['settings', 'settings', 'gearFill', 'Ajustes'],
];
export function initChrome(onFab) {
    tabbar = h('nav', { class: 'tabbar hidden', 'aria-label': 'Navegación principal' });
    fab = h('button', { class: 'fab hidden', 'aria-label': 'Nuevo escaneo o importar', onclick: onFab }, ic('plus'));
    document.body.append(tabbar, fab);
}
export function updateChrome(route) {
    if (!tabbar || !fab)
        return;
    const isTab = TABS.includes(route);
    tabbar.classList.toggle('hidden', !isTab);
    fab.classList.toggle('hidden', !(route === 'home' || route === 'docs'));
    if (!isTab)
        return;
    tabbar.replaceChildren(...TAB_DEF.map(([r, i, f, l]) => h('button', {
        class: 'tab' + (route === r ? ' active' : ''), 'aria-current': route === r ? 'page' : undefined,
        onclick: () => { if (currentRoute().name !== r) {
            vibrate(6);
            go(r);
        }
        else
            window.scrollTo({ top: 0, behavior: 'smooth' }); },
    }, ic(route === r ? f : i), l)));
}
function overlay(build, centered, onClosed) {
    const wrap = h('div', { class: 'overlay' + (centered ? ' center' : '') });
    feedback('pop');
    let closed = false;
    let cleanup = () => { };
    const remove = () => {
        if (closed)
            return;
        closed = true;
        cleanup();
        wrap.classList.add('closing');
        setTimeout(() => wrap.remove(), 320);
        onClosed?.();
    };
    const id = pushOverlay(remove);
    const close = () => (closed ? Promise.resolve() : popOverlay(id));
    wrap.addEventListener('click', e => { if (e.target === wrap)
        void close(); });
    const inner = build(close);
    wrap.appendChild(inner);
    document.body.appendChild(wrap);
    if (!centered)
        cleanup = enableDragToClose(inner, close);
    return { el: wrap, close };
}
/** Arrastrar la hoja hacia abajo para cerrarla, como en iOS. */
function enableDragToClose(sheetEl, close) {
    let startY = 0, dy = 0, dragging = false, t0 = 0;
    sheetEl.addEventListener('pointerdown', e => {
        const fromTop = e.clientY - sheetEl.getBoundingClientRect().top;
        if (sheetEl.scrollTop > 0 || fromTop > 56)
            return; // solo desde la parte superior
        dragging = true;
        startY = e.clientY;
        dy = 0;
        t0 = performance.now();
        sheetEl.classList.remove('settle');
    });
    const move = (e) => {
        if (!dragging)
            return;
        dy = Math.max(0, e.clientY - startY);
        if (dy > 4) {
            sheetEl.classList.add('dragging');
            sheetEl.style.transform = `translate3d(0, ${dy}px, 0)`;
        }
    };
    window.addEventListener('pointermove', move, { passive: true });
    const end = () => {
        if (!dragging)
            return;
        dragging = false;
        sheetEl.classList.remove('dragging');
        const v = dy / Math.max(1, performance.now() - t0);
        if (dy > sheetEl.offsetHeight * 0.3 || v > 0.6) {
            sheetEl.classList.add('settle');
            sheetEl.style.transform = 'translate3d(0, 100%, 0)';
            void close();
        }
        else {
            sheetEl.classList.add('settle');
            sheetEl.style.transform = '';
        }
    };
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end); window.removeEventListener('pointercancel', end); };
}
/** Hoja de acciones iOS: grupo de opciones + «Cancelar» aparte. La acción se ejecuta tras cerrar. */
export function actionSheet(title, actions, header) {
    overlay(close => h('div', { class: 'sheet', role: 'dialog', 'aria-label': title ?? 'Acciones' }, h('div', { class: 'grabber' }), header ?? null, title ? h('h2', null, title) : null, h('div', { class: 'sheet-group' }, actions.map(a => h('button', {
        class: 'sheet-action' + (a.danger ? ' danger' : ''),
        onclick: async () => { await close(); await a.run(); },
    }, ic(a.icon), h('span', null, h('span', null, a.label), a.sub ? h('span', { class: 'sub' }, a.sub) : null)))), h('button', { class: 'sheet-cancel', onclick: () => void close() }, 'Cancelar')), false);
}
/** Hoja inferior con contenido libre. */
export function sheet(build, onClosed) {
    return overlay(close => h('div', { class: 'sheet', role: 'dialog' }, h('div', { class: 'grabber' }), ...build(close)), false, onClosed);
}
/** Alerta estilo iOS con dos botones de texto. */
export function confirmDialog(o) {
    return new Promise(resolve => {
        let answered = false;
        const done = (v) => { if (!answered) {
            answered = true;
            resolve(v);
        } };
        overlay(close => h('div', { class: 'dialog', role: 'alertdialog', 'aria-label': o.title }, h('div', { class: 'd-body' }, o.icon ? h('div', { class: 'd-icon ' + (o.danger ? 'c-danger' : 'c-lilac') }, ic(o.icon)) : null, h('h2', null, o.title), o.text ? h('p', null, o.text) : null, o.body ? h('div', { class: 'd-extra' }, o.body) : null), h('div', { class: 'd-actions' }, h('button', { class: 'd-btn', onclick: async () => { done(false); await close(); } }, o.cancel ?? 'Cancelar'), h('button', { class: 'd-btn ' + (o.danger ? 'danger' : 'bold'), onclick: async () => { done(true); await close(); } }, o.confirm))), true, () => done(false));
        if (o.danger)
            vibrate(8);
    });
}
export function infoDialog(title, body, iconName = 'info') {
    return new Promise(resolve => {
        overlay(close => h('div', { class: 'dialog', role: 'dialog' }, h('div', { class: 'd-body' }, h('div', { class: 'd-icon c-lilac' }, ic(iconName)), h('h2', null, title), typeof body === 'string' ? h('p', null, body) : h('div', { class: 'd-extra small muted' }, body)), h('div', { class: 'd-actions' }, h('button', { class: 'd-btn bold', onclick: () => void close() }, 'Entendido'))), true, () => resolve());
    });
}
// ---------- Avisos y carga ----------
let toastWrap = null;
let toastTimer = 0;
export function toast(msg, kind = 'ok', ms = 2800) {
    if (!toastWrap) {
        toastWrap = h('div', { class: 'toast-wrap', role: 'status', 'aria-live': 'polite' });
        document.body.appendChild(toastWrap);
    }
    clear(toastWrap);
    clearTimeout(toastTimer);
    const t = h('div', { class: 'toast' + (kind === 'error' ? ' error' : '') }, ic(kind === 'error' ? 'alert' : 'checkCircle', 'sm'), h('span', null, msg));
    toastWrap.appendChild(t);
    if (kind === 'error') {
        feedback('warn');
        void vibrate;
    }
    toastTimer = window.setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, ms);
}
/** HUD de iOS. Aparece con un pequeño retraso para que las operaciones rápidas no parpadeen. */
export function busy(label, withProgress = false, delay = 160) {
    const lbl = h('div', { class: 'small muted' }, label);
    const bar = h('i');
    const el = h('div', { class: 'busy', role: 'alert', 'aria-busy': 'true' }, h('div', { class: 'hud' }, h('span', { html: activitySvg() }), lbl, withProgress ? h('div', { class: 'progress' }, bar) : null));
    let shown = false, ended = false;
    document.body.dataset.busy = String(Number(document.body.dataset.busy ?? 0) + 1);
    const t = setTimeout(() => { if (!ended) {
        shown = true;
        document.body.appendChild(el);
    } }, delay);
    // bloquea toques aunque el HUD aún no se vea
    const shield = h('div', { style: 'position:fixed;inset:0;z-index:299' });
    document.body.appendChild(shield);
    return {
        set: (l, p) => { lbl.textContent = l; if (p !== undefined)
            bar.style.transform = `scaleX(${Math.max(0, Math.min(1, p))})`; },
        done: () => { if (ended)
            return; ended = true; const n = Number(document.body.dataset.busy ?? 1) - 1; if (n > 0)
            document.body.dataset.busy = String(n);
        else
            delete document.body.dataset.busy; clearTimeout(t); shield.remove(); if (shown) {
            el.style.transition = 'opacity .2s';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 200);
        } },
    };
}
// ---------- Controles ----------
/** Control segmentado iOS: el indicador se desliza entre opciones. */
export function segmented(options, value, onChange) {
    const thumb = h('span', { class: 'seg-thumb' });
    const el = h('div', { class: 'segmented', role: 'radiogroup' }, thumb);
    el.style.setProperty('--n', String(options.length));
    const buttons = options.map(([k, l], i) => h('button', {
        role: 'radio',
        onclick: () => { if (k !== cur) {
            cur = k;
            paint();
            vibrate(5);
            onChange(k);
        } },
        dataset: { i: String(i) },
    }, l));
    let cur = value;
    const paint = () => {
        const i = Math.max(0, options.findIndex(o => o[0] === cur));
        el.style.setProperty('--i', String(i));
        buttons.forEach((b, j) => { b.classList.toggle('active', j === i); b.setAttribute('aria-checked', String(j === i)); });
    };
    el.append(...buttons);
    paint();
    return el;
}
export function slider(label, value, min, max, onInput) {
    const out = h('output', null, String(value));
    const input = h('input', { type: 'range', min: String(min), max: String(max), step: '1', 'aria-label': label });
    input.value = String(value);
    const paint = () => {
        const v = Number(input.value);
        input.style.setProperty('--p', `${((v - min) / (max - min)) * 100}%`);
        out.textContent = (v > 0 && min < 0 ? '+' : '') + v;
    };
    input.addEventListener('input', () => { paint(); onInput(Number(input.value)); });
    input.addEventListener('dblclick', () => { input.value = String(min < 0 ? 0 : min); paint(); onInput(Number(input.value)); });
    paint();
    return { el: h('div', { class: 'slider-row' }, h('span', null, label), input, out), set: v => { input.value = String(v); paint(); } };
}
export function toggle(checked, onChange, label) {
    const input = h('input', { type: 'checkbox', role: 'switch', 'aria-label': label });
    input.checked = checked;
    input.addEventListener('change', () => { vibrate(5); onChange(input.checked); });
    return h('label', { class: 'switch' }, input, h('span'));
}
export function listItem(o) {
    const tag = o.onclick ? 'button' : 'div';
    return h(tag, { class: 'list-item' + (o.danger ? ' danger' : ''), onclick: o.onclick }, tile(o.icon, o.danger ? 'danger' : o.tint ?? 'lilac'), h('span', { class: 'li-main' }, h('div', { class: 'li-title' }, o.title), o.sub ? h('div', { class: 'li-sub' }, o.sub) : null), o.right ?? (o.onclick ? ic('chevRight', 'sm chev') : null));
}
// ---------- Miniaturas (URLs de objeto gestionadas por generación) ----------
// Al cambiar de pantalla se liberan las URLs que ya no usa nadie, pero tras la animación,
// para que la pantalla que sale no muestre imágenes rotas.
const urlCache = new Map();
let gen = 0;
export function blobUrl(b) {
    let e = urlCache.get(b);
    if (!e) {
        e = { url: URL.createObjectURL(b), gen };
        urlCache.set(b, e);
    }
    e.gen = gen;
    return e.url;
}
export function revokeAll() {
    const old = gen++;
    setTimeout(() => {
        for (const [b, e] of urlCache)
            if (e.gen <= old) {
                URL.revokeObjectURL(e.url);
                urlCache.delete(b);
            }
    }, 900);
}
/** Imagen que aparece con un fundido cuando termina de decodificarse. */
export function fadeImg(src, alt = '', cls = '') {
    const img = h('img', { src, alt, decoding: 'async', class: cls });
    const ok = () => img.classList.add('ok');
    if (img.complete && img.naturalWidth)
        ok();
    else
        img.addEventListener('load', ok, { once: true });
    return img;
}
export function thumbEl(b, cls = 'thumb', alt = '') {
    return h('div', { class: cls }, b ? fadeImg(blobUrl(b), alt) : ic('fileText'));
}
/** Sonido + vibración breves (respeta los ajustes de sonido y vibración). */
export function feedback(kind) {
    play(kind);
    haptic(kind === 'warn' ? 'error' : kind === 'success' ? 'success' : kind === 'pop' || kind === 'step' ? 'medium' : 'light');
}
