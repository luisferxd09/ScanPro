import { icon } from './icons.js';
/** Crea elementos DOM de forma declarativa. Las claves on* registran eventos. */
export function h(tag, props, ...children) {
    const el = document.createElement(tag);
    if (props) {
        for (const [k, v] of Object.entries(props)) {
            if (v === undefined || v === null || v === false)
                continue;
            if (k === 'class')
                el.className = String(v);
            else if (k === 'style') {
                if (typeof v === 'string')
                    el.setAttribute('style', v);
                else
                    Object.assign(el.style, v);
            }
            else if (k === 'dataset')
                Object.assign(el.dataset, v);
            else if (k.startsWith('on') && typeof v === 'function')
                el.addEventListener(k.slice(2).toLowerCase(), v);
            else if (k === 'html')
                el.innerHTML = String(v);
            else if (k in el && typeof v !== 'string')
                el[k] = v;
            else if (v === true)
                el.setAttribute(k, '');
            else
                el.setAttribute(k, String(v));
        }
    }
    append(el, children);
    return el;
}
export function append(parent, children) {
    for (const c of children) {
        if (c === null || c === undefined || c === false)
            continue;
        if (Array.isArray(c))
            append(parent, c);
        else if (c instanceof Node)
            parent.appendChild(c);
        else
            parent.appendChild(document.createTextNode(String(c)));
    }
}
export const ic = icon;
export function clear(el) {
    while (el.firstChild)
        el.removeChild(el.firstChild);
}
export function uid() {
    const a = new Uint8Array(10);
    crypto.getRandomValues(a);
    return Date.now().toString(36) + Array.from(a, b => b.toString(36).padStart(2, '0')).join('').slice(0, 10);
}
const MONTHS = ['ene.', 'feb.', 'mar.', 'abr.', 'may.', 'jun.', 'jul.', 'ago.', 'sept.', 'oct.', 'nov.', 'dic.'];
export function fmtDate(ts) {
    const d = new Date(ts);
    return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}
export function fmtDateTime(ts) {
    const d = new Date(ts);
    return `${fmtDate(ts)} · ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
export function fmtSize(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(0)} KB`;
    if (bytes < 1024 ** 3)
        return `${(bytes / 1024 / 1024).toFixed(1).replace('.', ',')} MB`;
    return `${(bytes / 1024 ** 3).toFixed(2).replace('.', ',')} GB`;
}
export function pagesLabel(n) {
    return n === 1 ? '1 página' : `${n} páginas`;
}
export function debounce(fn, ms) {
    let t;
    return ((...a) => {
        clearTimeout(t);
        t = window.setTimeout(() => fn(...a), ms);
    });
}
/** Cede el hilo principal para que la interfaz pueda pintar (spinners, progreso). */
export function nextFrame() {
    return new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));
}
export function vibrate(ms = 10) {
    try {
        navigator.vibrate?.(ms);
    }
    catch { /* sin soporte */ }
}
/** Abre el selector de archivos del sistema (no requiere permisos). */
export function pickFiles(opts) {
    return new Promise(resolve => {
        const input = h('input', { type: 'file', accept: opts.accept, class: 'sr-only' });
        if (opts.multiple)
            input.multiple = true;
        if (opts.capture)
            input.setAttribute('capture', opts.capture);
        let done = false;
        const finish = (files) => { if (done)
            return; done = true; input.remove(); resolve(files); };
        input.addEventListener('change', () => finish(Array.from(input.files ?? [])));
        input.addEventListener('cancel', () => finish([]));
        document.body.appendChild(input);
        input.click();
    });
}
export function escapeHtml(s) {
    return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
