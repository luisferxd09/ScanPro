import { pdfPaper } from '../core/locale.js';
import { fmtMoney } from '../core/locale.js';
// Piezas comunes de las herramientas: formularios, entrega de archivos y texto de documentos.
import { h, ic, fmtSize } from '../ui/dom.js';
import { btn, sheet, toast, busy } from '../ui/components.js';
import { getPages, getDoc } from '../core/db.js';
import { generate } from '../core/exporter.js';
import { getSettings } from '../core/settings.js';
import { downloadFiles, shareFiles } from '../core/share.js';
import { isNative, nativePrint, nativeShareEmail } from '../core/native.js';
import { maybeInterstitial } from '../core/ads.js';
import { runOcr } from '../screens/ocr.js';
import { settingsX, setSettingsX, rememberHash } from '../core/meta.js';
import { sha256 } from '../core/docops.js';
/** Formulario en una hoja. Devuelve los valores o null si se cancela. */
export function form(title, fields, ok = 'Aceptar', intro) {
    return new Promise(resolve => {
        let res = null;
        const inputs = new Map();
        const rows = fields.map(f => {
            const el = f.options ? h('select', { 'aria-label': f.label }, ...f.options.map(([v, l]) => h('option', { value: v, selected: v === f.value }, l)))
                : f.type === 'textarea' ? h('textarea', { rows: '4', placeholder: f.placeholder ?? '', 'aria-label': f.label }) : h('input', { type: f.type ?? 'text', placeholder: f.placeholder ?? '', 'aria-label': f.label });
            if (f.value !== undefined && !f.options)
                el.value = f.value;
            inputs.set(f.k, el);
            return h('div', { class: 'field' }, h('label', null, f.label), h('div', { class: 'input-wrap' }, el));
        });
        sheet(close => [
            h('h2', null, title), intro ? h('p', { class: 'small muted', style: 'margin:0 0 12px' }, intro) : null,
            h('div', { class: 'tool-form' }, ...rows),
            h('div', { class: 'btn-row', style: 'margin-top:16px' }, btn('Cancelar', () => void close(), 'secondary'), btn(ok, async () => { res = {}; inputs.forEach((el, k) => { res[k] = el.value.trim(); }); await close(); })),
        ], () => resolve(res));
        setTimeout(() => inputs.values().next().value?.focus(), 250);
    });
}
/** Entrega uno o varios archivos: guardar, compartir, imprimir o enviar al correo guardado. */
export async function deliver(files, title) {
    for (const f of files)
        if (f.type === 'application/pdf')
            rememberHash(await sha256(f), f.name);
    const pdf = files.length === 1 && files[0].type === 'application/pdf';
    sheet(close => [
        h('h2', null, 'Listo'),
        h('div', { class: 'file-card' }, ic('fileText'), h('div', { class: 'grow' }, h('div', { class: 'ellipsis', style: 'font-weight:600' }, files.length === 1 ? files[0].name : `${files.length} archivos`), h('div', { class: 'xs faint' }, fmtSize(files.reduce((a, f) => a + f.size, 0))))),
        h('div', { class: 'tool-actions' }, btn('Guardar', async () => { try {
            const w = await downloadFiles(files);
            toast(w ? `Guardado en ${w}` : 'Descarga iniciada');
        }
        catch (e) {
            toast(e.message, 'error');
        } }, 'primary', { icon: 'download' }), btn('Compartir', async () => { const r = await shareFiles(files, title); if (r.outcome === 'error')
            toast(r.message ?? 'No se pudo compartir.', 'error'); }, 'secondary', { icon: 'share' }), pdf && isNative ? btn('Imprimir', async () => { if (!(await nativePrint(files[0])))
            toast('No se pudo abrir la impresión.', 'error'); }, 'secondary', { icon: 'fileText' }) : null, isNative ? btn('Enviar a mi correo', async () => { const to = await myEmail(); if (to)
            await nativeShareEmail(files, title, to); }, 'secondary', { icon: 'share' }) : null, btn('Cerrar', () => void close(), 'ghost')),
    ]);
}
/** Correo guardado para «Escanear a correo» (se pide la primera vez). */
export async function myEmail(force = false) {
    const cur = settingsX().email;
    if (cur && !force)
        return cur;
    const r = await form('Tu correo de destino', [{ k: 'email', label: 'Correo', type: 'email', value: cur ?? '', placeholder: 'tu.correo@empresa.com' }], 'Guardar', 'Los documentos se enviarán a este correo con un toque (por ejemplo, el de tu trabajo o tu EPS).');
    if (!r?.email || !/^[^@\s]+@[^@\s]+\.\w+$/.test(r.email))
        return null;
    setSettingsX({ email: r.email });
    return r.email;
}
/** Exporta un documento con las opciones de ScanPro más los cambios indicados (con anuncio, como toda exportación). */
export async function exportDoc(doc, fmt, patch = {}, pages) {
    await maybeInterstitial();
    const ps = pages ?? await getPages(doc);
    const o = { quality: getSettings().quality, multi: 'files', pdfSize: pdfPaper(), pdfOrientation: 'auto', pdfMargin: 0, docxText: true, fileName: doc.name, ...patch };
    const b = busy('Generando archivo…', true);
    try {
        return (await generate(doc, ps, fmt, o, (l, f) => b.set(l, f))).files;
    }
    catch (e) {
        toast(e.message, 'error', 4500);
        return null;
    }
    finally {
        b.done();
    }
}
/** Texto de un documento; si no tiene OCR, lo reconoce primero. */
export async function docText(doc) {
    let pages = await getPages(doc);
    if (!pages.some(p => p.ocrText?.trim())) {
        if (!(await runOcr(doc, pages)))
            return null;
        const d2 = await getDoc(doc.id);
        if (d2)
            pages = await getPages(d2);
    }
    const text = pages.map(p => p.ocrText ?? '').filter(Boolean).join('\n\n').trim();
    if (!text) {
        toast('No se reconoció texto en este documento.', 'error');
        return null;
    }
    return { pages, text };
}
export const money = (n) => fmtMoney(n);
