import { PHOTO_SIZES, curCountry, curLang } from '../core/locale.js';
import { intlTemplates } from './templates-intl.js';
import { loc } from '../core/locale.js';
// Imagen, presentación, accesibilidad y plantillas: quitar fondo, foto documento, presentar, PowerPoint, lupa y trámites.
import { h, ic, pickFiles } from '../ui/dom.js';
import { sheet, btn, toast, busy, topbar, emptyState, note } from '../ui/components.js';
import { go, onLeave } from '../core/router.js';
import { getDoc, getPages } from '../core/db.js';
import { pickDocument } from '../screens/common.js';
import { isNative, nativeHas, nativeRemoveBg } from '../core/native.js';
import { loadVendor } from '../core/exporter.js';
import { canvasToPage, newDoc } from '../core/docops.js';
import { makeCanvas, blobToCanvas } from '../imaging/process.js';
import { fileSafe } from '../core/names.js';
import { maybeInterstitial } from '../core/ads.js';
import { form, deliver } from './kit.js';
// ---------- quitar el fondo ----------
export async function removeBgTool() {
    if (!nativeHas('removeBg')) {
        toast('Quitar el fondo funciona en la app instalada (Android).', 'error');
        return;
    }
    const [f] = await pickFiles({ accept: 'image/*' });
    if (!f)
        return;
    const b = busy('Quitando el fondo…');
    try {
        const png = await nativeRemoveBg(f);
        b.done();
        const r = await form('Fondo nuevo', [{ k: 'bg', label: 'Fondo', value: 'none', options: [['none', 'Transparente (PNG)'], ['#ffffff', 'Blanco'], ['#f2f2f2', 'Gris claro'], ['#000000', 'Negro'], ['#dbe8ff', 'Azul claro']] }], 'Listo');
        if (!r)
            return;
        let out = png;
        if (r.bg !== 'none') {
            const c = await blobToCanvas(png), o = makeCanvas(c.width, c.height), g = o.getContext('2d');
            g.fillStyle = r.bg;
            g.fillRect(0, 0, o.width, o.height);
            g.drawImage(c, 0, 0);
            out = await new Promise(res => o.toBlob(x => res(x), 'image/jpeg', 0.95));
        }
        await deliver([new File([out], `${fileSafe(f.name.replace(/\.[a-z0-9]+$/i, ''))}-sin-fondo.${r.bg === 'none' ? 'png' : 'jpg'}`, { type: out.type })], 'Sin fondo');
    }
    catch (e) {
        b.done();
        toast(e.message, 'error', 5000);
    }
}
// ---------- foto tipo documento ----------
const SIZES = PHOTO_SIZES;
export async function idPhotoTool() {
    const r = await form('Foto tipo documento', [{ k: 'size', label: 'Tamaño', value: curCountry().photo, options: SIZES.map(s => [s[0], s[1]]) }, { k: 'n', label: 'Copias en la hoja', value: '8', options: [['4', '4'], ['6', '6'], ['8', '8'], ['12', '12']] }], 'Tomar o elegir foto', 'Usa una foto de frente, con buena luz. Si el teléfono lo permite, el fondo se cambia a blanco.');
    if (!r)
        return;
    const [f] = await pickFiles({ accept: 'image/*' });
    if (!f)
        return;
    const b = busy('Preparando la foto…');
    try {
        let src = f;
        if (nativeHas('removeBg')) {
            try {
                src = await nativeRemoveBg(f);
            }
            catch { /* sin modelo: se usa la foto tal cual */ }
        }
        const c = await blobToCanvas(src), [, , wcm, hcm] = SIZES.find(s => s[0] === r.size);
        // recorte centrado arriba (cara) con la proporción pedida
        const ratio = wcm / hcm;
        let cw = c.width, ch = cw / ratio;
        if (ch > c.height) {
            ch = c.height;
            cw = ch * ratio;
        }
        const sx = (c.width - cw) / 2, sy = Math.max(0, (c.height - ch) * 0.25);
        const DPI = 300, pw = Math.round(wcm / 2.54 * DPI), ph = Math.round(hcm / 2.54 * DPI);
        const one = makeCanvas(pw, ph), g1 = one.getContext('2d');
        g1.fillStyle = '#fff';
        g1.fillRect(0, 0, pw, ph);
        g1.drawImage(c, sx, sy, cw, ch, 0, 0, pw, ph);
        // hoja carta a 300 ppp con las copias y líneas de corte
        const W = 2550, H = 3300, sheetC = makeCanvas(W, H), g = sheetC.getContext('2d');
        g.fillStyle = '#fff';
        g.fillRect(0, 0, W, H);
        const n = Number(r.n), cols = Math.max(1, Math.min(n, Math.floor((W - 200) / (pw + 40)))), gap = 40;
        for (let i = 0; i < n; i++) {
            const x = 100 + (i % cols) * (pw + gap), y = 100 + Math.floor(i / cols) * (ph + gap);
            if (y + ph > H - 100)
                break;
            g.drawImage(one, x, y);
            g.strokeStyle = '#bbb';
            g.lineWidth = 2;
            g.setLineDash([12, 10]);
            g.strokeRect(x - 1, y - 1, pw + 2, ph + 2);
        }
        g.setLineDash([]);
        g.fillStyle = '#888';
        g.font = '36px Helvetica, Arial';
        g.fillText(`Imprimir en carta al 100 % · ${SIZES.find(s => s[0] === r.size)[1]}`, 100, H - 60);
        const d = await newDoc(`Fotos ${SIZES.find(s => s[0] === r.size)[1]}`, [await canvasToPage(sheetC)]);
        b.done();
        toast('Hoja de fotos lista: imprímela al 100 %', 'ok', 3500);
        go('doc', { id: d.id });
    }
    catch (e) {
        b.done();
        toast(e.message, 'error');
    }
}
// ---------- presentar ----------
let presentId = '';
export function presentTool(id) { if (id) {
    presentId = id;
    go('presentar', {});
    return;
} void pickDocument('Presentar…', d => { presentId = d.id; go('presentar', {}); }); }
export async function presentScreen() {
    const doc = await getDoc(presentId);
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Presentar', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    const pages = await getPages(doc);
    let i = 0;
    const img = h('img', { class: 'present-img', alt: '' }), count = h('div', { class: 'present-count' });
    const urls = pages.map(p => URL.createObjectURL(p.image));
    onLeave(() => urls.forEach(u => URL.revokeObjectURL(u)));
    const show = () => { img.src = urls[i]; count.textContent = `${i + 1} / ${pages.length}`; };
    const root = h('div', { class: 'present', onclick: (e) => { const x = e.clientX / window.innerWidth; i = x < 0.33 ? Math.max(0, i - 1) : Math.min(pages.length - 1, i + 1); show(); } }, img, count, h('button', { class: 'present-close', 'aria-label': 'Cerrar', onclick: (e) => { e.stopPropagation(); void document.exitFullscreen?.().catch(() => { }); history.back(); } }, ic('x')));
    let sx = 0;
    root.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
    root.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) {
        i = dx < 0 ? Math.min(pages.length - 1, i + 1) : Math.max(0, i - 1);
        show();
    } }, { passive: true });
    show();
    setTimeout(() => void root.requestFullscreen?.().catch(() => { }), 50);
    return root;
}
// ---------- PowerPoint ----------
export function pptxTool() {
    void pickDocument('Exportar a PowerPoint…', async (doc) => {
        await maybeInterstitial();
        const b = busy('Creando presentación…');
        try {
            await loadVendor(isNative ? 'vendor/pptxgen.bundle.js' : 'https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js');
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const P = new window.PptxGenJS();
            P.layout = 'LAYOUT_16x9';
            P.title = doc.name;
            for (const p of await getPages(doc)) {
                const data = await new Promise(res => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(p.image); });
                const s = P.addSlide();
                s.background = { color: 'FFFFFF' };
                const W = 10, Hh = 5.625, k = Math.min(W / p.width, Hh / p.height), w = p.width * k, hh = p.height * k;
                s.addImage({ data, x: (W - w) / 2, y: (Hh - hh) / 2, w, h: hh });
                if (p.ocrText)
                    s.addNotes(p.ocrText.slice(0, 3000));
            }
            const blob = await P.write({ outputType: 'blob' });
            b.done();
            await deliver([new File([blob], `${fileSafe(doc.name)}.pptx`, { type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' })], doc.name);
        }
        catch (e) {
            b.done();
            toast('No se pudo crear el PowerPoint: ' + e.message, 'error', 5000);
        }
    });
}
// ---------- lupa ----------
export async function magnifierScreen() {
    const video = h('video', { class: 'lupa-video', autoplay: true, muted: true, playsinline: true });
    let stream = null, zoom = 2, mode = 0;
    const modes = ['none', 'contrast(1.6) grayscale(1)', 'invert(1) contrast(1.6) grayscale(1)', 'contrast(1.4) saturate(0) sepia(1) hue-rotate(10deg)'];
    const apply = () => { video.style.transform = `scale(${zoom})`; video.style.filter = modes[mode]; };
    try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 } }, audio: false });
        video.srcObject = stream;
    }
    catch {
        return h('div', { class: 'screen' }, topbar('Lupa', { back: true }), emptyState('camera', 'Cámara no disponible', 'Permite el uso de la cámara para usar la lupa.'));
    }
    onLeave(() => stream?.getTracks().forEach(t => t.stop()));
    const track = stream.getVideoTracks()[0];
    let torch = false;
    apply();
    return h('div', { class: 'lupa' }, video, h('div', { class: 'lupa-bar' }, btn('−', () => { zoom = Math.max(1, zoom - 0.5); apply(); }, 'secondary'), btn('+', () => { zoom = Math.min(6, zoom + 0.5); apply(); }, 'secondary'), btn('Contraste', () => { mode = (mode + 1) % modes.length; apply(); }, 'secondary', { icon: 'contrast' }), btn('Luz', async () => { torch = !torch; try {
        await track.applyConstraints({ advanced: [{ torch }] });
    }
    catch {
        toast('La linterna no está disponible', 'error');
    } }, 'secondary', { icon: 'zap' }), btn('Cerrar', () => history.back(), 'primary', { icon: 'x' })));
}
const today = () => new Date().toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' });
export const TEMPLATES = [
    { id: 'peticion', name: 'Derecho de petición', fields: [['ciudad', 'Ciudad'], ['entidad', 'Entidad a la que se dirige'], ['nombre', 'Tu nombre completo'], ['cc', 'Cédula'], ['hechos', 'Hechos (qué pasó)'], ['peticion', 'Qué solicitas'], ['correo', 'Correo para respuesta'], ['tel', 'Teléfono']],
        body: v => `<p>${v.ciudad}, ${today()}</p><p>Señores<br><b>${v.entidad}</b><br>Ciudad</p><p><b>Referencia: Derecho de petición (artículo 23 de la Constitución Política y Ley 1755 de 2015)</b></p><p>Yo, ${v.nombre}, identificado(a) con cédula de ciudadanía No. ${v.cc}, en ejercicio del derecho fundamental de petición, me permito presentar la siguiente solicitud:</p><h2>Hechos</h2><p>${v.hechos}</p><h2>Petición</h2><p>${v.peticion}</p><h2>Notificaciones</h2><p>Recibiré respuesta en el correo ${v.correo} o en el teléfono ${v.tel}. Recuerdo que el plazo legal para responder es de quince (15) días hábiles.</p><p>Atentamente,</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p>` },
    { id: 'certlaboral', name: 'Solicitud de certificado laboral', fields: [['ciudad', 'Ciudad'], ['empresa', 'Empresa'], ['nombre', 'Tu nombre'], ['cc', 'Cédula'], ['cargo', 'Cargo'], ['destino', 'Para qué lo necesitas']],
        body: v => `<p>${v.ciudad}, ${today()}</p><p>Señores<br><b>${v.empresa}</b><br>Área de Talento Humano</p><p><b>Asunto: Solicitud de certificado laboral</b></p><p>Yo, ${v.nombre}, identificado(a) con cédula No. ${v.cc}, en mi calidad de ${v.cargo}, solicito amablemente la expedición de un certificado laboral en el que conste mi cargo, fecha de ingreso, tipo de contrato y salario, con destino a ${v.destino}.</p><p>Agradezco su atención.</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p>` },
    { id: 'pazysalvo', name: 'Paz y salvo', fields: [['ciudad', 'Ciudad'], ['quien', 'Quien expide (persona o empresa)'], ['nit', 'NIT o cédula de quien expide'], ['beneficiario', 'A favor de'], ['ccb', 'Cédula del beneficiario'], ['concepto', 'Concepto (arriendo, deuda, curso…)']],
        body: v => `<h1>PAZ Y SALVO</h1><p>${v.quien}, identificado(a) con NIT/C.C. ${v.nit}, hace constar que <b>${v.beneficiario}</b>, identificado(a) con C.C. ${v.ccb}, se encuentra a paz y salvo por concepto de ${v.concepto} a la fecha.</p><p>Se expide en ${v.ciudad}, el ${today()}.</p><p><br><br>${v.quien}<br>NIT/C.C. ${v.nit}</p>` },
    { id: 'autorizacion', name: 'Autorización', fields: [['ciudad', 'Ciudad'], ['nombre', 'Quien autoriza'], ['cc', 'Su cédula'], ['autorizado', 'Persona autorizada'], ['cca', 'Cédula del autorizado'], ['tramite', 'Qué puede hacer (reclamar, firmar…)'], ['entidad', 'Ante qué entidad']],
        body: v => `<p>${v.ciudad}, ${today()}</p><h1>AUTORIZACIÓN</h1><p>Yo, ${v.nombre}, identificado(a) con cédula No. ${v.cc}, autorizo a <b>${v.autorizado}</b>, identificado(a) con cédula No. ${v.cca}, para que en mi nombre ${v.tramite} ante ${v.entidad}.</p><p>Anexo copia de ambas cédulas.</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p>` },
    { id: 'poder', name: 'Poder simple', fields: [['ciudad', 'Ciudad'], ['nombre', 'Poderdante (quien da el poder)'], ['cc', 'Su cédula'], ['apoderado', 'Apoderado'], ['ccap', 'Cédula del apoderado'], ['asunto', 'Para qué asunto'], ['entidad', 'Ante quién']],
        body: v => `<p>${v.ciudad}, ${today()}</p><p>Señores<br><b>${v.entidad}</b></p><p><b>Referencia: Poder especial</b></p><p>Yo, ${v.nombre}, mayor de edad, identificado(a) con cédula No. ${v.cc}, confiero poder especial, amplio y suficiente a ${v.apoderado}, identificado(a) con cédula No. ${v.ccap}, para que en mi nombre y representación adelante ${v.asunto}. Mi apoderado queda facultado para recibir, firmar, solicitar y realizar todas las gestiones necesarias para este fin.</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p><p>Acepto,<br><br>${v.apoderado}<br>C.C. ${v.ccap}</p>` },
    { id: 'cobro', name: 'Cuenta de cobro', fields: [['ciudad', 'Ciudad'], ['cliente', 'Cliente (empresa o persona)'], ['nitc', 'NIT o cédula del cliente'], ['nombre', 'Tu nombre'], ['cc', 'Tu cédula'], ['concepto', 'Concepto del servicio'], ['valor', 'Valor (solo números)'], ['cuenta', 'Banco y número de cuenta']],
        body: v => `<p>${v.ciudad}, ${today()}</p><h1>CUENTA DE COBRO</h1><p><b>${v.cliente}</b><br>NIT/C.C. ${v.nitc}</p><p>DEBE A:</p><p><b>${v.nombre}</b><br>C.C. ${v.cc}</p><p>LA SUMA DE: <b>$ ${Number(v.valor || 0).toLocaleString(loc())}</b></p><p>Por concepto de: ${v.concepto}.</p><p>Favor consignar en: ${v.cuenta}.</p><p>Declaro que no soy responsable de IVA.</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p>` },
    { id: 'cotizacion', name: 'Cotización', fields: [['negocio', 'Tu negocio'], ['cliente', 'Cliente'], ['items', 'Productos (uno por línea: nombre ; cantidad ; precio)'], ['validez', 'Validez (días)'], ['contacto', 'Teléfono o WhatsApp']],
        body: v => {
            const rows = (v.items || '').split('\n').map(l => l.split(';').map(x => x.trim())).filter(r => r[0]);
            const total = rows.reduce((a, r) => a + (Number(r[1]) || 1) * (Number(r[2]) || 0), 0);
            return `<h1>COTIZACIÓN · ${v.negocio}</h1><p>Fecha: ${today()}<br>Cliente: <b>${v.cliente}</b></p><ul>${rows.map(r => `<li>${r[0]} — ${Number(r[1]) || 1} × $ ${(Number(r[2]) || 0).toLocaleString(loc())} = <b>$ ${((Number(r[1]) || 1) * (Number(r[2]) || 0)).toLocaleString(loc())}</b></li>`).join('')}</ul><h2>Total: $ ${total.toLocaleString(loc())}</h2><p>Validez de la oferta: ${v.validez || 15} días. Contacto: ${v.contacto}</p>`;
        } },
    { id: 'renuncia', name: 'Carta de renuncia', fields: [['ciudad', 'Ciudad'], ['empresa', 'Empresa'], ['jefe', 'Dirigida a'], ['nombre', 'Tu nombre'], ['cc', 'Cédula'], ['cargo', 'Cargo'], ['fecha', 'Último día de trabajo']],
        body: v => `<p>${v.ciudad}, ${today()}</p><p>Señor(a)<br>${v.jefe}<br><b>${v.empresa}</b></p><p><b>Asunto: Renuncia voluntaria</b></p><p>Por medio de la presente, yo ${v.nombre}, identificado(a) con cédula No. ${v.cc}, presento mi renuncia voluntaria al cargo de ${v.cargo}, siendo mi último día de trabajo el ${v.fecha}.</p><p>Agradezco la oportunidad y el aprendizaje durante este tiempo.</p><p>Cordialmente,</p><p><br><br>${v.nombre}<br>C.C. ${v.cc}</p>` },
];
export function templatesTool() {
    const lang = curLang(), country = curCountry().code;
    // en español: todas (las de Colombia solo para Colombia); en otros idiomas: las internacionales en ese idioma
    const list = lang === 'es' ? TEMPLATES.filter(t => country === 'CO' || !['peticion', 'pazysalvo'].includes(t.id)) : intlTemplates(lang);
    sheet(close => [h('h2', null, 'Plantillas de trámites'), h('div', { class: 'tool-actions' }, ...list.map(t => btn(t.name, async () => {
            await close();
            const v = await form(t.name, t.fields.map(([k, l]) => ({ k, label: l, type: k === 'hechos' || k === 'peticion' || k === 'items' ? 'textarea' : 'text' })), 'Crear documento', 'Llena los datos; después puedes editar el texto y firmarlo.');
            if (!v)
                return;
            try {
                localStorage.setItem('scanpro.textedit.draft', t.body(v));
                localStorage.setItem('scanpro.textedit.title', t.name);
            }
            catch { /* */ }
            go('textedit', { tpl: '1' });
        }, 'secondary', { icon: 'fileText' })), btn('Cancelar', () => void close(), 'ghost'))]);
}
export const tplNote = () => note('Plantillas de referencia. Revisa que el texto se ajuste a tu caso.', 'info');
