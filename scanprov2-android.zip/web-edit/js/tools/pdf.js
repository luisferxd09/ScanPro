// Herramientas de PDF: dividir, comprimir, contraseña, marca de agua, numerar, PDF a imágenes, tachar datos y verificar.
import { h, ic, pickFiles, fmtDateTime } from '../ui/dom.js';
import { sheet, btn, toast, busy, thumbEl, infoDialog } from '../ui/components.js';
import { go } from '../core/router.js';
import { getPages } from '../core/db.js';
import { pickDocument } from '../screens/common.js';
import { pdfToImages } from '../core/pdfimport.js';
import { overlayDoc, newDoc, copyPage, canvasToPage, pageCanvas, sha256 } from '../core/docops.js';
import { sensitiveLines } from '../core/textintel.js';
import { exportHashes } from '../core/meta.js';
import { decode } from '../imaging/process.js';
import { zipFiles } from '../core/exporter.js';
import { form, deliver, exportDoc, docText } from './kit.js';
import { fileSafe } from '../core/names.js';
/** Selector de páginas con miniaturas. */
function pickPages(pages, title, ok) {
    return new Promise(resolve => {
        const sel = new Set();
        let res = null;
        const grid = h('div', { class: 'page-pick' }, ...pages.map((p, i) => {
            const b = h('button', { class: 'pp-item', onclick: () => { sel.has(i) ? sel.delete(i) : sel.add(i); b.classList.toggle('on', sel.has(i)); } }, thumbEl(p.thumb, 'pp-thumb'), h('span', null, String(i + 1)));
            return b;
        }));
        sheet(close => [h('h2', null, title), h('p', { class: 'small muted', style: 'margin:0 0 10px' }, 'Toca las páginas que quieres.'), grid,
            h('div', { class: 'btn-row', style: 'margin-top:14px' }, btn('Cancelar', () => void close(), 'secondary'), btn(ok, async () => { if (!sel.size) {
                toast('Elige al menos una página.', 'error');
                return;
            } res = [...sel].sort((a, b) => a - b); await close(); }))], () => resolve(res));
    });
}
export function splitTool() {
    void pickDocument('Dividir…', async (doc) => {
        const pages = await getPages(doc);
        if (pages.length < 2) {
            toast('El documento tiene una sola página.', 'error');
            return;
        }
        sheet(close => [h('h2', null, `Dividir «${doc.name}»`),
            h('div', { class: 'tool-actions' }, btn('Elegir páginas para un documento nuevo', async () => { await close(); const sel = await pickPages(pages, 'Páginas del nuevo documento', 'Crear'); if (!sel)
                return; const d = await newDoc(`${doc.name} (págs. ${sel.map(i => i + 1).join(', ')})`, await Promise.all(sel.map(i => copyPage(pages[i]))), doc.folderId); toast('Documento creado'); go('doc', { id: d.id }); }, 'primary', { icon: 'pages' }), btn('Una página por documento', async () => { await close(); const b = busy('Dividiendo…'); try {
                for (let i = 0; i < pages.length; i++)
                    await newDoc(`${doc.name} · pág. ${i + 1}`, [await copyPage(pages[i])], doc.folderId);
                toast(`${pages.length} documentos creados`);
                go('docs');
            }
            finally {
                b.done();
            } }, 'secondary', { icon: 'files' }), btn('Partir cada N páginas', async () => { await close(); const r = await form('Partir cada…', [{ k: 'n', label: 'Páginas por documento', type: 'number', value: '2' }], 'Partir'); const n = Math.max(1, Number(r?.n) || 0); if (!r || !n)
                return; let k = 0; for (let i = 0; i < pages.length; i += n)
                await newDoc(`${doc.name} · parte ${++k}`, await Promise.all(pages.slice(i, i + n).map(copyPage)), doc.folderId); toast(`${k} documentos creados`); go('docs'); }, 'secondary', { icon: 'layers' }), btn('Cancelar', () => void close(), 'ghost'))]);
    });
}
export function compressTool() {
    void pickDocument('Comprimir…', async (doc) => {
        const r = await form('Comprimir PDF', [{ k: 'mb', label: 'Tamaño máximo', value: '1', options: [['0.5', '500 KB'], ['1', '1 MB'], ['2', '2 MB'], ['5', '5 MB']] }], 'Comprimir', 'Ideal para portales de trámites, correos o WhatsApp. La calidad baja solo lo necesario.');
        if (!r)
            return;
        const f = await exportDoc(doc, 'pdf', { maxBytes: Number(r.mb) * 1024 * 1024, quality: 'equilibrada' });
        if (f)
            await deliver(f, doc.name);
    });
}
export function protectTool() {
    sheet(close => [h('h2', null, 'Contraseña de PDF'),
        h('div', { class: 'tool-actions' }, btn('Proteger un documento con contraseña', async () => {
            await close();
            void pickDocument('Proteger…', async (doc) => {
                const r = await form('Contraseña para abrir', [{ k: 'pw', label: 'Contraseña', type: 'password' }, { k: 'pw2', label: 'Repítela', type: 'password' }], 'Proteger');
                if (!r)
                    return;
                if (r.pw.length < 4 || r.pw !== r.pw2) {
                    toast('Las contraseñas no coinciden (mínimo 4 caracteres).', 'error');
                    return;
                }
                const f = await exportDoc(doc, 'pdf', { password: r.pw });
                if (f)
                    await deliver(f, doc.name);
            });
        }, 'primary', { icon: 'lock' }), btn('Quitar la contraseña de un PDF', async () => {
            await close();
            const [file] = await pickFiles({ accept: 'application/pdf,.pdf' });
            if (!file)
                return;
            const r = await form('Contraseña actual', [{ k: 'pw', label: 'Contraseña del PDF', type: 'password' }], 'Quitar');
            if (!r)
                return;
            const b = busy('Abriendo PDF…', true);
            try {
                const imgs = await pdfToImages(file, (k, n) => b.set(`Página ${k + 1} de ${n}…`, k / n), r.pw);
                const pages = [];
                for (const im of imgs)
                    pages.push(await canvasToPage((await decode(im, 3508)).canvas));
                const doc = await newDoc(file.name.replace(/\.pdf$/i, '') + ' (sin contraseña)', pages);
                b.done();
                const f = await exportDoc(doc, 'pdf');
                if (f)
                    await deliver(f, doc.name);
            }
            catch (e) {
                b.done();
                toast(e.message === 'PDF_PASSWORD' ? 'Contraseña incorrecta.' : e.message, 'error');
            }
        }, 'secondary', { icon: 'shield' }), btn('Cancelar', () => void close(), 'ghost'))]);
}
export function watermarkTool() {
    void pickDocument('Marca de agua en…', async (doc) => {
        const r = await form('Marca de agua', [{ k: 't', label: 'Texto', value: 'COPIA' }, { k: 'pos', label: 'Posición', value: 'diag', options: [['diag', 'Diagonal grande'], ['foot', 'Pie de página'], ['repeat', 'Repetida (más segura)']] }, { k: 'op', label: 'Intensidad', value: '0.18', options: [['0.1', 'Suave'], ['0.18', 'Media'], ['0.3', 'Fuerte']] }], 'Aplicar', 'Por ejemplo «SOLO PARA TRÁMITE EN BANCO X» sobre tu cédula, para que no la reutilicen.');
        if (!r?.t)
            return;
        const b = busy('Aplicando marca de agua…');
        try {
            const d = await overlayDoc(doc, '(marca de agua)', (g, w, hh) => {
                g.save();
                g.globalAlpha = Number(r.op);
                g.fillStyle = '#d0021b';
                g.textAlign = 'center';
                g.textBaseline = 'middle';
                if (r.pos === 'foot') {
                    g.globalAlpha = Math.min(1, Number(r.op) * 3);
                    g.font = `700 ${Math.round(w / 40)}px Helvetica, Arial`;
                    g.fillText(r.t, w / 2, hh - w / 30);
                }
                else if (r.pos === 'repeat') {
                    g.font = `700 ${Math.round(w / 22)}px Helvetica, Arial`;
                    g.translate(w / 2, hh / 2);
                    g.rotate(-Math.atan2(hh, w));
                    for (let y = -hh; y < hh; y += w / 6)
                        for (let x = -w; x < w; x += g.measureText(r.t).width + w / 10)
                            g.fillText(r.t, x + (y / (w / 6)) % 2 * w / 10, y);
                }
                else {
                    const fs = Math.min(w, hh) / Math.max(4, r.t.length * 0.55);
                    g.font = `800 ${Math.round(fs)}px Helvetica, Arial`;
                    g.translate(w / 2, hh / 2);
                    g.rotate(-Math.atan2(hh, w));
                    g.fillText(r.t, 0, 0);
                }
                g.restore();
            });
            toast('Marca de agua aplicada');
            go('doc', { id: d.id });
        }
        finally {
            b.done();
        }
    });
}
export function numberTool() {
    void pickDocument('Numerar páginas de…', async (doc) => {
        const r = await form('Numerar páginas', [{ k: 'fmt', label: 'Formato', value: 'n/t', options: [['n', '1, 2, 3…'], ['n/t', '1 de 10'], ['pag', 'Página 1']] }, { k: 'pos', label: 'Posición', value: 'bc', options: [['bc', 'Abajo al centro'], ['br', 'Abajo a la derecha'], ['tr', 'Arriba a la derecha']] }], 'Numerar');
        if (!r)
            return;
        const b = busy('Numerando…');
        try {
            const d = await overlayDoc(doc, '(numerado)', (g, w, hh, i, n) => {
                const t = r.fmt === 'n' ? String(i + 1) : r.fmt === 'pag' ? `Página ${i + 1}` : `${i + 1} de ${n}`;
                g.font = `600 ${Math.round(w / 55)}px Helvetica, Arial`;
                g.fillStyle = '#333';
                g.textAlign = r.pos === 'bc' ? 'center' : 'right';
                g.fillText(t, r.pos === 'bc' ? w / 2 : w - w / 25, r.pos === 'tr' ? w / 25 : hh - w / 30);
            });
            toast('Páginas numeradas');
            go('doc', { id: d.id });
        }
        finally {
            b.done();
        }
    });
}
export async function pdfToImagesTool() {
    const [file] = await pickFiles({ accept: 'application/pdf,.pdf' });
    if (!file)
        return;
    const b = busy('Extrayendo páginas…', true);
    try {
        let imgs;
        try {
            imgs = await pdfToImages(file, (k, n) => b.set(`Página ${k + 1} de ${n}…`, k / n));
        }
        catch (e) {
            if (e.message !== 'PDF_PASSWORD')
                throw e;
            b.done();
            const r = await form('PDF con contraseña', [{ k: 'pw', label: 'Contraseña', type: 'password' }]);
            if (!r)
                return;
            imgs = await pdfToImages(file, () => { }, r.pw);
        }
        const base = fileSafe(file.name.replace(/\.pdf$/i, ''));
        const files = imgs.map((im, i) => new File([im], `${base}-${i + 1}.${im.type === 'image/png' ? 'png' : 'jpg'}`, { type: im.type }));
        b.done();
        await deliver(files.length > 1 ? [await zipFiles(files, `${base}-imagenes`)] : files, base);
    }
    catch (e) {
        b.done();
        toast(e.message, 'error');
    }
}
/** Tacha datos sensibles: cédula, cuentas, correos, teléfonos y direcciones (con el texto OCR). */
export function redactTool() {
    void pickDocument('Tachar datos de…', async (doc) => {
        const t = await docText(doc);
        if (!t)
            return;
        const found = t.pages.map(p => sensitiveLines(p.ocrLines ?? []));
        const n = found.reduce((a, l) => a + l.length, 0);
        const ok = n ? await new Promise(res => {
            let r = false;
            sheet(close => [h('h2', null, `${n} dato(s) sensible(s)`), h('div', { class: 'redact-list' }, ...found.flat().slice(0, 30).map(l => h('div', { class: 'redact-item' }, ic('eye', 'sm'), l.t))),
                h('p', { class: 'xs faint' }, 'Se crea una copia con esas líneas tapadas en negro. El original no cambia. Para tapar otras zonas usa «Firmar o anotar › Tachar».'),
                h('div', { class: 'btn-row' }, btn('Cancelar', () => void close(), 'secondary'), btn('Tachar', async () => { r = true; await close(); }, 'danger'))], () => res(r));
        }) : false;
        if (!n) {
            toast('No se encontraron números largos, correos ni direcciones.', 'ok', 3500);
            go('pages', { id: doc.id, hint: 'annotate' });
            return;
        }
        if (!ok)
            return;
        const b = busy('Tachando…');
        try {
            const pages = t.pages, out = [];
            for (let i = 0; i < pages.length; i++) {
                const c = await pageCanvas(pages[i], 100000), g = c.getContext('2d'), k = c.width / (pages[i].width || c.width);
                g.fillStyle = '#000';
                for (const l of found[i])
                    g.fillRect(l.x0 * k - 6, l.y0 * k - 4, (l.x1 - l.x0) * k + 12, (l.y1 - l.y0) * k + 8);
                out.push(await canvasToPage(c));
            }
            const d = await newDoc(`${doc.name} (datos tachados)`, out, doc.folderId);
            toast('Copia con datos tachados creada');
            go('doc', { id: d.id });
        }
        finally {
            b.done();
        }
    });
}
export async function verifyTool() {
    const [file] = await pickFiles({ accept: 'application/pdf,.pdf' });
    if (!file)
        return;
    const hsh = await sha256(file), hit = exportHashes().find(x => x.h === hsh);
    void infoDialog(hit ? 'PDF original ✓' : 'No coincide', hit
        ? `Este PDF es idéntico, byte por byte, al «${hit.name}» que exportaste el ${fmtDateTime(hit.at)}. No ha sido modificado.`
        : `No coincide con ningún PDF exportado desde este teléfono: fue modificado o lo creó otra app.\n\nHuella SHA-256:\n${hsh.slice(0, 32)}\n${hsh.slice(32)}`, hit ? 'checkCircle' : 'alert');
}
export function rotateReorderTool() { void pickDocument('Rotar o reordenar…', d => go('pages', { id: d.id })); }
export function signOthersTool() {
    void (async () => {
        const [file] = await pickFiles({ accept: 'application/pdf,.pdf,image/*' });
        if (!file)
            return;
        const b = busy('Abriendo…', true);
        try {
            const imgs = /pdf$/i.test(file.type) || /\.pdf$/i.test(file.name) ? await pdfToImages(file, (k, n) => b.set(`Página ${k + 1} de ${n}…`, k / n)) : [file];
            const pages = [];
            for (const im of imgs)
                pages.push(await canvasToPage((await decode(im, 3508)).canvas));
            const d = await newDoc(file.name.replace(/\.[a-z0-9]+$/i, '') + ' (firmado)', pages);
            b.done();
            toast('Toca la página que vas a firmar', 'ok', 2500);
            go('pages', { id: d.id, hint: 'annotate' });
        }
        catch (e) {
            b.done();
            toast(e.message, 'error');
        }
    })();
}
