import { loc } from '../core/locale.js';
// Inteligencia en el teléfono: organizar solo (nombre, tipo, carpeta, vencimiento), preguntar a tus documentos,
// revisar contratos con alertas y llenar formularios con tus datos.
import { h, ic, fmtDate } from '../ui/dom.js';
import { btn, toast, topbar, emptyState, note, listItem, sheet } from '../ui/components.js';
import { go } from '../core/router.js';
import { getDoc, getPages, listDocs, patchDoc, updatePage } from '../core/db.js';
import { recognize, cleanText } from '../core/ocr.js';
import { getSettings } from '../core/settings.js';
import { analyze, reviewText, keyFacts, findDates, findAmounts, findExpiry, MONTHS, norm } from '../core/classify.js';
import { metaOf, setMeta, scheduleExpiry, expenses, settingsX, setSettingsX, allMeta } from '../core/meta.js';
import { summarize } from '../core/textintel.js';
import { pickDocument, captureForTool } from '../screens/common.js';
import { setPendingText } from '../screens/annotate.js';
import { canvasToPage, newDoc } from '../core/docops.js';
import { decode } from '../imaging/process.js';
import { LIFE } from './life.js';
import { runOcr } from '../screens/ocr.js';
import { form, docText, money } from './kit.js';
// ---------- organizar automáticamente ----------
let queue = Promise.resolve();
const isDefaultName = (n) => /^(Escaneo \d{4}-\d{2}-\d{2}|Lote \d|Documento combinado|Escaneo$)/.test(n);
export const autoOrganizeOn = () => settingsX().autoOrganize !== false;
/** Reconoce el texto en segundo plano y ordena el documento. No bloquea la app. */
export function organizeLater(docId) {
    if (!autoOrganizeOn())
        return;
    queue = queue.then(async () => { await organize(docId, true); }).catch(() => { });
}
export async function organize(docId, silent) {
    const doc = await getDoc(docId);
    if (!doc)
        return null;
    let pages = await getPages(doc);
    if (!pages.some(p => p.ocrText?.trim())) {
        try {
            const r = await recognize(pages.map(p => p.image), getSettings().ocrLang, () => { });
            for (let i = 0; i < pages.length; i++) {
                pages[i] = { ...pages[i], ocrText: cleanText(r.texts[i]), ocrLang: getSettings().ocrLang, ocrLines: r.lines[i] };
                await updatePage(pages[i]);
            }
        }
        catch {
            return null;
        }
    }
    const text = pages.map(p => p.ocrText ?? '').join('\n');
    if (!text.trim())
        return null;
    const a = analyze(text), m = metaOf(docId), done = [];
    if (a.name && isDefaultName(doc.name)) {
        const others = new Set((await listDocs(true)).map(d => d.name));
        let nm = a.name, k = 2;
        while (others.has(nm))
            nm = `${a.name} (${k++})`;
        await patchDoc(docId, { name: nm });
        done.push(`nombre «${nm}»`);
    }
    if (a.kind?.life && !m.life) {
        setMeta(docId, { life: a.kind.life });
        done.push(`carpeta ${LIFE.find(l => l.id === a.kind.life)?.name}`);
    }
    if (a.kind?.tags && !m.tags?.length)
        setMeta(docId, { tags: a.kind.tags });
    if (a.expires && !m.expires && a.expires > Date.now()) {
        setMeta(docId, { expires: a.expires });
        scheduleExpiry(docId, a.name ?? doc.name, a.expires);
        done.push(`vence ${fmtDate(a.expires)}`);
    }
    setMeta(docId, { kind: a.kind?.id });
    if (done.length && silent)
        toast(`Organizado: ${done.join(' · ')}`, 'ok', 3500);
    return a.kind?.label ?? null;
}
function search(docs, q) {
    const terms = norm(q).match(/[a-z0-9ñ]{3,}/g)?.filter(t => !['cuando', 'cuanto', 'cual', 'donde', 'esta', 'tengo', 'mis', 'que', 'para', 'del', 'los', 'las', 'pague', 'gaste', 'numero', 'vence', 'mostrar', 'muestrame'].includes(t)) ?? [];
    return docs.map(d => {
        const t = norm(d.name + ' ' + d.name + ' ' + d.ocrText);
        let score = 0, at = -1;
        for (const w of terms) {
            const c = t.split(w).length - 1;
            if (c) {
                score += 1 + Math.log(c);
                if (at < 0)
                    at = t.indexOf(w);
            }
            if (norm(d.name).includes(w))
                score += 3;
        }
        const src = d.ocrText.replace(/\s+/g, ' '), i = Math.max(0, at - d.name.length * 2 - 2 - 60);
        return { doc: d, score, snippet: at >= 0 ? (i > 0 ? '…' : '') + src.slice(i, i + 180) + '…' : src.slice(0, 140) };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
}
async function answer(q) {
    const docs = await listDocs(), nq = norm(q), hits = search(docs, q).slice(0, 5), meta = allMeta();
    const monthIdx = (() => { const m = MONTHS.findIndex(mn => nq.includes(mn)); if (m >= 0)
        return m; for (let k = 0; k < 12; k++) {
        const nm = norm(new Date(2026, k, 1).toLocaleDateString(loc(), { month: 'long' }));
        if (nm && nq.includes(nm))
            return k;
    } return -1; })();
    // ¿cuándo vence…?
    if (/vence|vencimiento|vigencia|caduca|expira|expire|due|vencer|validade|expir|ablauf|scad/.test(nq)) {
        for (const h2 of hits) {
            const e = meta[h2.doc.id]?.expires ?? findExpiry(h2.doc.ocrText);
            if (e) {
                const days = Math.ceil((e - Date.now()) / 86400000);
                return { text: `«${h2.doc.name}» vence el ${new Date(e).toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' })} (${days < 0 ? `venció hace ${-days} días` : `faltan ${days} días`}).`, hits: [h2] };
            }
        }
        const soon = docs.filter(d => meta[d.id]?.expires).sort((a, b) => meta[a.id].expires - meta[b.id].expires);
        if (soon.length)
            return { text: 'No encontré ese documento con fecha de vencimiento. Estos son los próximos vencimientos:\n' + soon.slice(0, 5).map(d => `• ${d.name}: ${fmtDate(meta[d.id].expires)}`).join('\n'), hits: [] };
    }
    // ¿cuánto pagué / gasté…?
    if (/cuanto|pague|gaste|valor|total|cost|how much|spent|paid|quanto|gastei|combien|depense|wie viel|ausgegeben|speso/.test(nq)) {
        const terms = nq.match(/[a-zñ]{3,}/g) ?? [];
        let ex = expenses().filter(e => terms.some(t => norm(e.merchant + ' ' + e.category).includes(t)) || /gaste|gastos|spent|spend|gastei|depense|ausgegeben|speso/.test(nq));
        if (monthIdx >= 0)
            ex = ex.filter(e => new Date(e.date).getMonth() === monthIdx);
        if (ex.length) {
            const tot = ex.reduce((a, e) => a + e.total, 0);
            return { text: `${monthIdx >= 0 ? `En ${MONTHS[monthIdx]}` : 'En total'} registraste ${ex.length} gasto(s) por ${money(tot)}:\n` + ex.slice(0, 8).map(e => `• ${e.merchant}: ${money(e.total)} (${fmtDate(e.date)})`).join('\n'), hits: [] };
        }
        const h0 = hits.find(x => findAmounts(x.doc.ocrText).length);
        if (h0) {
            const big = findAmounts(h0.doc.ocrText).sort((a, b) => b.v - a.v)[0];
            return { text: `En «${h0.doc.name}» el valor más alto es ${money(big.v)} (“${big.ctx.trim()}”).`, hits: [h0] };
        }
    }
    // ¿cuál es mi número de…?
    const idM = nq.match(/(cedula|nit|placa|cuenta|contrato|poliza|referencia|telefono|celular|correo|plate|account|contract|policy|phone|email|number|numero)/);
    if (idM && hits.length) {
        const t = hits[0].doc.ocrText, k = idM[1];
        const v = k === 'placa' ? t.match(/\b[A-Z]{3}[- ]?\d{2}[A-Z0-9]\b/)?.[0] : k === 'correo' ? t.match(/[\w.+-]+@[\w-]+\.[\w.]+/)?.[0] : k === 'telefono' || k === 'celular' ? t.match(/3\d{9}|\(?\d{3}\)?\s?\d{3}\s?\d{4}/)?.[0]
            : t.match(new RegExp(`${k === 'cedula' ? 'c[eé]dula|c\\.?c\\.?|documento' : k}[^\\d]{0,25}([\\d.\\- ]{5,})`, 'i'))?.[1]?.trim();
        if (v)
            return { text: `En «${hits[0].doc.name}» encontré: ${v}`, hits: [hits[0]] };
    }
    if (/cuando|fecha/.test(nq) && hits.length) {
        const d = findDates(hits[0].doc.ocrText)[0];
        if (d)
            return { text: `En «${hits[0].doc.name}» aparece la fecha ${new Date(d.at).toLocaleDateString(loc(), { day: 'numeric', month: 'long', year: 'numeric' })}.`, hits: [hits[0]] };
    }
    return { text: hits.length ? `Encontré ${hits.length} documento(s) relacionados:` : 'No encontré nada sobre eso en tus documentos. Prueba con otras palabras (por ejemplo, el nombre de la empresa o del documento).', hits };
}
export async function askScreen() {
    const input = h('input', { type: 'search', placeholder: 'Ej.: ¿Cuándo vence mi SOAT?', 'aria-label': 'Pregunta' });
    const out = h('div', { class: 'ask-out' });
    const run = async (q) => {
        if (!q.trim())
            return;
        input.value = q;
        out.replaceChildren(h('div', { class: 'spinner' }));
        const r = await answer(q);
        out.replaceChildren(h('div', { class: 'card ask-answer' }, ic('wand'), h('div', { style: 'white-space:pre-line' }, r.text)), ...r.hits.map(x => h('button', { class: 'card ask-hit tap', onclick: () => go('doc', { id: x.doc.id }) }, h('b', null, x.doc.name), h('div', { class: 'xs faint' }, x.snippet))));
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter')
        void run(input.value); });
    const ex = ['¿Cuándo vence mi SOAT?', '¿Cuánto pagué de luz en octubre?', '¿Cuál es el número de mi contrato?', '¿Cuánto gasté este mes?', '¿Dónde está mi certificado laboral?'];
    return h('div', { class: 'screen' }, topbar('Pregúntale a tus documentos', { back: true }), h('div', { class: 'content' }, h('div', { class: 'row', style: 'gap:8px' }, h('div', { class: 'input-wrap grow' }, ic('search', 'sm faint'), input), btn('Preguntar', () => void run(input.value), 'primary', { sm: true })), h('div', { class: 'chips wrap', style: 'margin:10px 0' }, ...ex.map(q => h('button', { class: 'chip', onclick: () => void run(q) }, q))), out, note('Las respuestas salen de tus documentos y gastos, buscando en el teléfono (sin internet). Si un documento no tiene texto, ábrelo y toca «Texto».', 'info')));
}
// ---------- revisar un contrato o documento largo ----------
let reviewId = '';
export function reviewTool(id) { if (id) {
    reviewId = id;
    go('revisar', {});
    return;
} void pickDocument('Revisar…', d => { reviewId = d.id; go('revisar', {}); }); }
export async function reviewScreen() {
    const doc = await getDoc(reviewId);
    if (!doc)
        return h('div', { class: 'screen' }, topbar('Revisar', { back: true }), emptyState('alert', 'Documento no encontrado', ''));
    const t = await docText(doc);
    if (!t)
        return h('div', { class: 'screen' }, topbar('Revisar', { back: true }), emptyState('fileText', 'Sin texto', 'No se pudo leer el documento.'));
    const alerts = reviewText(t.text), facts = keyFacts(t.text), sum = summarize(t.text, 0.25);
    const lv = { alta: 'Importante', media: 'Revisa', info: 'Para saber' };
    return h('div', { class: 'screen' }, topbar(`Revisar · ${doc.name}`, { back: true }), h('div', { class: 'content' }, h('div', { class: 'card review-facts' }, ...facts.map(f => h('div', { class: 'fact' }, h('span', { class: 'xs faint' }, f.label), h('b', null, f.value)))), h('h3', null, alerts.length ? `${alerts.length} punto(s) a revisar` : 'Sin alertas'), ...(alerts.length ? alerts.map(a => h('div', { class: `alert-card ${a.level}` }, h('div', { class: 'row', style: 'gap:6px' }, ic(a.level === 'alta' ? 'alert' : 'info', 'sm'), h('b', null, a.title), h('span', { class: 'badge' }, lv[a.level])), h('div', { class: 'small' }, `“${a.quote}”`)))
        : [note('No encontré cláusulas de permanencia, multas, renovación automática ni otras alertas comunes.', 'info')]), h('h3', { style: 'margin-top:16px' }, 'Resumen'), h('ul', { class: 'summary' }, ...sum.map(s => h('li', null, s))), note('Revisión automática hecha en el teléfono para ayudarte a leer. No reemplaza la asesoría de un abogado.', 'warn')));
}
// ---------- mis datos y llenar formularios ----------
const PROFILE = [
    ['nombre', 'Nombre completo', /^(nombres? y apellidos?|nombre completo|nombre del (solicitante|titular|paciente|trabajador|cliente)|nombres?)\b/],
    ['apellidos', 'Apellidos', /^apellidos?\b/],
    ['cedula', 'Cédula', /^(c\.?\s?c\.?|cedula( de ciudadania)?|documento( de identidad)?|no\.? de (documento|identificacion)|identificacion|n[uú]mero de documento)\b/],
    ['nacimiento', 'Fecha de nacimiento', /^fecha de nacimiento\b/],
    ['direccion', 'Dirección', /^(direccion( de (residencia|domicilio))?|domicilio)\b/],
    ['ciudad', 'Ciudad', /^(ciudad|municipio)\b/],
    ['telefono', 'Teléfono / celular', /^(telefono|celular|tel\.?|movil|numero de contacto)\b/],
    ['correo', 'Correo', /^(correo( electronico)?|e-?mail|email)\b/],
    ['eps', 'EPS', /^eps\b/],
    ['empresa', 'Empresa', /^(empresa|empleador|razon social)\b/],
    ['cargo', 'Cargo / ocupación', /^(cargo|ocupacion|profesion)\b/],
    ['fecha', '(fecha de hoy)', /^fecha\b(?! de nacimiento)/],
];
export const profile = () => settingsX().profile ?? {};
export async function editProfile() {
    const p = profile();
    const r = await form('Mis datos', PROFILE.filter(f => f[0] !== 'fecha').map(([k, l]) => ({ k, label: l, value: p[k] ?? '', type: k === 'nacimiento' ? 'date' : k === 'correo' ? 'email' : 'text' })), 'Guardar', 'Se guardan solo en tu teléfono y se usan para llenar formularios.');
    if (!r)
        return false;
    setSettingsX({ profile: r });
    toast('Datos guardados');
    return true;
}
export function fillFormTool() {
    sheet(close => [h('h2', null, 'Llenar formulario'), h('p', { class: 'small muted' }, 'ScanPro lee el formulario, encuentra campos como «Nombre», «Cédula», «Dirección» o «Teléfono» y escribe tus datos. Después puedes moverlos y firmar.'),
        h('div', { class: 'tool-actions' }, btn('Escanear un formulario', async () => { await close(); const f = await captureForTool(1); if (!f[0])
            return; const c = (await decode(f[0], 3508)).canvas; const d = await newDoc('Formulario', [await canvasToPage(c)]); await fillDoc(d.id); }, 'primary', { icon: 'camera' }), btn('Usar un documento guardado', async () => { await close(); void pickDocument('Llenar…', d => void fillDoc(d.id)); }, 'secondary', { icon: 'fileText' }), btn('Editar mis datos', async () => { await close(); await editProfile(); }, 'ghost', { icon: 'person' }))]);
}
async function fillDoc(docId) {
    if (!Object.values(profile()).some(Boolean) && !(await editProfile()))
        return;
    const p = profile();
    const doc = await getDoc(docId);
    if (!doc)
        return;
    const t = await docText(doc);
    if (!t)
        return;
    let page = t.pages[0];
    if (!page.ocrLines?.length) {
        if (!(await runOcr(doc, [page])))
            return;
        const d2 = await getDoc(docId);
        if (d2)
            page = (await getPages(d2))[0];
    }
    const lines = page.ocrLines ?? [];
    const items = [];
    const used = new Set();
    for (const l of lines) {
        const raw = l.t.trim(), n = norm(raw);
        for (const [k, , rx] of PROFILE) {
            if (used.has(k) || !rx.test(n))
                continue;
            const val = k === 'fecha' ? new Date().toLocaleDateString(loc()) : k === 'nombre' && p.apellidos && !lines.some(x => /^apellidos?\b/.test(norm(x.t))) ? `${p.nombre ?? ''}`.trim() : p[k];
            if (!val)
                continue;
            used.add(k);
            const hgt = l.y1 - l.y0, labelEnd = l.x0 + (l.x1 - l.x0) * Math.min(1, (raw.match(/^[^:_]*[:_]?/)?.[0].length ?? raw.length) / raw.length);
            const free = l.x1 - labelEnd > page.width * 0.15 || /[_.]{4,}|:\s*$/.test(raw);
            items.push({ t: val, x: free ? labelEnd + hgt * 0.6 : l.x0, y: free ? l.y0 : l.y1 + hgt * 0.2, s: hgt * 0.85 });
            break;
        }
    }
    if (!items.length) {
        toast('No encontré campos conocidos. Abro el editor para que escribas a mano.', 'ok', 3500);
        go('annotate', { page: page.id });
        return;
    }
    setPendingText(items, page.width);
    toast(`${items.length} campo(s) llenados. Revisa, muévelos si hace falta y firma.`, 'ok', 4000);
    go('annotate', { page: page.id });
}
export function profileItem() { return listItem({ icon: 'person', tint: 'sky', title: 'Mis datos', sub: 'Para llenar formularios automáticamente', onclick: () => void editProfile() }); }
