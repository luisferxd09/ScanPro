import { loc } from '../core/locale.js';
// Mis carpetas de vida, vencimientos, privados, avisos, etiquetas, gastos e inventario.
import { h, ic, uid, fmtDate } from '../ui/dom.js';
import { sheet, btn, toast, busy, topbar, emptyState, note, listItem, actionSheet, confirmDialog, tile } from '../ui/components.js';
import { go } from '../core/router.js';
import { listDocs } from '../core/db.js';
import { docItem, captureForTool, scanWithCamera } from '../screens/common.js';
import { TAGS, metaOf, setMeta, allMeta, scheduleExpiry, reminders, saveReminder, deleteReminder, expenses, saveExpenses, items, saveItems, setPrivateUnlocked, privateUnlocked } from '../core/meta.js';
import { isNative, nativeHas, nativeAuth, nativeScanCode } from '../core/native.js';
import { parseReceipt } from '../core/textintel.js';
import { makeXlsx, XLSX_MIME } from '../core/xlsx.js';
import { canvasToPage, newDoc } from '../core/docops.js';
import { makeCanvas } from '../imaging/process.js';
import { form, deliver, money } from './kit.js';
import { ocrBlobs } from './smart.js';
// ---------- carpetas de vida ----------
export const LIFE = [
    { id: 'identidad', name: 'Identidad', icon: 'idCard', hint: 'Cédula, pasaporte, licencia, libreta militar', expiry: true },
    { id: 'salud', name: 'Salud', icon: 'heart', hint: 'Órdenes, fórmulas, exámenes, incapacidades, vacunas', expiry: false },
    { id: 'vehiculo', name: 'Vehículo', icon: 'car', hint: 'SOAT, técnico-mecánica, tarjeta de propiedad', expiry: true },
    { id: 'hogar', name: 'Hogar', icon: 'home', hint: 'Arriendo, servicios, escrituras, manuales', expiry: false },
    { id: 'garantias', name: 'Garantías', icon: 'checkCircle', hint: 'Facturas de compra con fecha de fin de garantía', expiry: true },
    { id: 'estudios', name: 'Estudios', icon: 'graduation', hint: 'Diplomas, certificados, notas, carné', expiry: false },
    { id: 'trabajo', name: 'Trabajo', icon: 'briefcase', hint: 'Contratos, desprendibles, certificados laborales', expiry: false },
    { id: 'mascotas', name: 'Mascotas', icon: 'paw', hint: 'Vacunas, historia clínica, registro', expiry: true },
];
export async function lifeScreen(params) {
    const all = await listDocs(), meta = allMeta();
    if (!params.c) {
        const soon = all.filter(d => meta[d.id]?.expires).sort((a, b) => meta[a.id].expires - meta[b.id].expires).slice(0, 5);
        return h('div', { class: 'screen' }, topbar('Mis carpetas de vida', { back: true }), h('div', { class: 'content' }, soon.length ? h('div', { class: 'card' }, h('h3', null, 'Próximos vencimientos'), ...soon.map(d => expiryRow(d, meta[d.id].expires))) : null, h('div', { class: 'tools-grid' }, ...LIFE.map(l => h('button', { class: 'tool-card tap', onclick: () => go('vida', { c: l.id }) }, tile(l.icon, 'lilac', true), h('div', null, h('h4', null, l.name), h('p', null, `${all.filter(d => meta[d.id]?.life === l.id).length} · ${l.hint}`))))), note('Los documentos con fecha de vencimiento te avisan 7 días antes.', 'info')));
    }
    const L = LIFE.find(x => x.id === params.c) ?? LIFE[0];
    const docs = all.filter(d => meta[d.id]?.life === L.id);
    const refresh = () => go('vida', { c: L.id }, { replace: true });
    return h('div', { class: 'screen' }, topbar(L.name, { back: true }), h('div', { class: 'content' }, h('p', { class: 'small muted' }, L.hint), h('div', { class: 'btn-row' }, btn('Escanear', () => { lifeAfterScan = L.id; void scanWithCamera(); }, 'primary', { icon: 'camera' }), btn('Añadir existente', () => void addExisting(L.id, all, refresh), 'secondary', { icon: 'plus' })), docs.length ? h('div', { class: 'doc-list' }, ...docs.map(d => h('div', null, docItem(d, refresh), metaOf(d.id).expires ? expiryRow(d, metaOf(d.id).expires) : L.expiry ? btn('Poner fecha de vencimiento', () => void setExpiry(d, refresh), 'ghost', { sm: true, icon: 'clock' }) : null)))
        : emptyState(L.icon, 'Vacía', 'Escanea o añade documentos a esta carpeta.')));
}
/** Tras escanear desde una carpeta de vida, el documento nuevo queda en ella. */
export let lifeAfterScan = null;
export function takeLifeAfterScan(docId) { if (lifeAfterScan) {
    setMeta(docId, { life: lifeAfterScan });
    lifeAfterScan = null;
} }
function expiryRow(d, at) {
    const days = Math.ceil((at - Date.now()) / 86400000);
    return h('div', { class: 'expiry ' + (days < 0 ? 'late' : days <= 30 ? 'soon' : '') }, ic('clock', 'sm'), h('span', { class: 'grow' }, `${d.name}: ${days < 0 ? `venció hace ${-days} días` : days === 0 ? 'vence hoy' : `vence en ${days} días`} (${fmtDate(at)})`));
}
async function addExisting(life, all, done) {
    actionSheet('Añadir a la carpeta', all.filter(d => metaOf(d.id).life !== life).slice(0, 40).map(d => ({ icon: 'fileText', label: d.name, run: () => { setMeta(d.id, { life }); done(); } })));
}
export async function setExpiry(d, done) {
    const cur = metaOf(d.id).expires;
    const r = await form('Fecha de vencimiento', [{ k: 'date', label: 'Vence el', type: 'date', value: cur ? new Date(cur).toISOString().slice(0, 10) : '' }], 'Guardar', 'Te avisamos 7 días antes. Déjala vacía para quitar el aviso.');
    if (!r)
        return;
    const at = r.date ? new Date(r.date + 'T09:00:00').getTime() : undefined;
    setMeta(d.id, { expires: at });
    scheduleExpiry(d.id, d.name, at);
    toast(at ? 'Aviso de vencimiento guardado' : 'Aviso quitado');
    done?.();
}
// ---------- etiquetas ----------
export function tagMenu(d, done) {
    const cur = new Set(metaOf(d.id).tags ?? []);
    sheet(close => [h('h2', null, 'Etiquetas'), h('div', { class: 'chips wrap' }, ...TAGS.map(t => { const b = h('button', { class: 'chip tag-chip' + (cur.has(t.id) ? ' active' : ''), style: `--tag:${t.color}`, onclick: () => { cur.has(t.id) ? cur.delete(t.id) : cur.add(t.id); b.classList.toggle('active', cur.has(t.id)); } }, h('i', { class: 'tag-dot' }), t.label); return b; })),
        h('div', { class: 'btn-row', style: 'margin-top:14px' }, btn('Listo', async () => { setMeta(d.id, { tags: [...cur] }); await close(); done(); }))]);
}
export function tagDots(docId) {
    const t = metaOf(docId).tags;
    if (!t?.length)
        return null;
    return h('span', { class: 'tag-dots' }, ...t.map(id => h('i', { class: 'tag-dot', style: `--tag:${TAGS.find(x => x.id === id)?.color}`, title: id })));
}
// ---------- carpeta privada ----------
export async function openPrivate() {
    if (!privateUnlocked()) {
        if (isNative && nativeHas('authenticate')) {
            const r = await nativeAuth('Carpeta privada de ScanPro');
            if (r === 'cancel' || r.startsWith('error'))
                return;
            if (r === 'nolock')
                toast('Configura un bloqueo de pantalla (huella o PIN) en tu teléfono para proteger esta carpeta.', 'error', 4500);
        }
        else
            toast('En el navegador la carpeta privada no tiene huella; en la app instalada sí.', 'ok', 3500);
        setPrivateUnlocked(true);
    }
    go('privado', {});
}
export async function privateScreen() {
    if (!privateUnlocked()) {
        setTimeout(() => history.back(), 0);
        return h('div');
    }
    const docs = (await listDocs(true)).filter(d => metaOf(d.id).priv);
    const refresh = () => go('privado', {}, { replace: true });
    return h('div', { class: 'screen' }, topbar('Carpeta privada', { back: () => { setPrivateUnlocked(false); history.back(); } }), h('div', { class: 'content' }, note('Estos documentos no aparecen en Inicio, Documentos ni búsquedas. Al salir se vuelve a bloquear.', 'info'), docs.length ? h('div', { class: 'doc-list' }, ...docs.map(d => docItem(d, refresh))) : emptyState('lock', 'Vacía', 'Desde el menú ⋮ de un documento elige «Mover a privada».')));
}
export function togglePrivate(d, done) {
    const p = !metaOf(d.id).priv;
    setMeta(d.id, { priv: p });
    toast(p ? 'Movido a la carpeta privada' : 'Sacado de la carpeta privada');
    done();
}
// ---------- avisos (medicamentos y recordatorios) ----------
export async function remindersScreen() {
    const list = h('div');
    const paint = () => {
        const l = reminders().filter(r => !r.docId).sort((a, b) => a.at - b.at);
        list.replaceChildren(...(l.length ? l.map(r => listItem({ icon: 'clock', tint: 'peach', title: r.title, sub: r.repeatH ? `Cada ${r.repeatH} h desde ${new Date(r.at).toLocaleString(loc(), { dateStyle: 'short', timeStyle: 'short' })}` : new Date(r.at).toLocaleString(loc(), { dateStyle: 'medium', timeStyle: 'short' }), right: btn('Borrar', () => { deleteReminder(r.id); paint(); }, 'ghost', { sm: true, icon: 'trash' }) })) : [emptyState('clock', 'Sin avisos', 'Crea avisos de medicamentos, pagos o citas.')]));
    };
    paint();
    return h('div', { class: 'screen' }, topbar('Avisos', { back: true }), h('div', { class: 'content' }, btn('Nuevo aviso', async () => {
        const now = new Date(Date.now() + 3600000);
        now.setMinutes(0, 0, 0);
        const r = await form('Nuevo aviso', [{ k: 'title', label: 'Qué', placeholder: 'Ej.: Acetaminofén 500 mg' }, { k: 'at', label: 'Primera vez', type: 'datetime-local', value: new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16) }, { k: 'rep', label: 'Repetir', value: '0', options: [['0', 'No repetir'], ['4', 'Cada 4 horas'], ['6', 'Cada 6 horas'], ['8', 'Cada 8 horas'], ['12', 'Cada 12 horas'], ['24', 'Cada día'], ['168', 'Cada semana'], ['720', 'Cada mes (30 días)']] }], 'Guardar');
        if (!r?.title || !r.at)
            return;
        saveReminder({ id: Math.floor(Math.random() * 1e9), title: r.title, text: 'Aviso de ScanPro', at: new Date(r.at).getTime(), repeatH: Number(r.rep) });
        toast(isNative ? 'Aviso programado' : 'Aviso guardado (las notificaciones funcionan en la app instalada)');
        paint();
    }, 'primary', { block: true, icon: 'plus' }), list, note('Para fórmulas médicas: escanea la fórmula en «Salud» y crea aquí el aviso de cada medicamento.', 'info')));
}
// ---------- gastos desde recibos ----------
const CATS = ['Mercado', 'Servicios', 'Transporte', 'Comida', 'Salud', 'Hogar', 'Educación', 'Otros'];
export async function expenseFromPhoto() {
    const f = await captureForTool(1);
    if (!f.length)
        return;
    const r = await ocrBlobs(f);
    if (!r)
        return;
    const p = parseReceipt(r.text);
    const v = await form('Nuevo gasto', [{ k: 'merchant', label: 'Comercio', value: p.merchant }, { k: 'total', label: 'Total', type: 'number', value: p.total ? String(p.total) : '' }, { k: 'date', label: 'Fecha', type: 'date', value: new Date(p.date ?? Date.now()).toISOString().slice(0, 10) }, { k: 'cat', label: 'Categoría', value: /luz|agua|gas|energ|acueduct|internet|claro|movistar|tigo|air-e|epm/i.test(r.text) ? 'Servicios' : 'Otros', options: CATS.map(c => [c, c]) }], 'Guardar gasto', 'Revisa lo que se leyó del recibo.');
    if (!v)
        return;
    const im = await createImageBitmap(f[0]), c = makeCanvas(im.width, im.height);
    c.getContext('2d').drawImage(im, 0, 0);
    const d = await newDoc(`Recibo ${v.merchant}`, [await canvasToPage(c, r.text)]);
    setMeta(d.id, { tags: ['pagado'] });
    const e = expenses();
    e.unshift({ id: uid(), date: new Date(v.date + 'T12:00:00').getTime(), merchant: v.merchant, total: Number(v.total) || 0, category: v.cat, docId: d.id });
    saveExpenses(e);
    if (p.due && p.due > Date.now())
        saveReminder({ id: Math.floor(Math.random() * 1e9), title: `Pagar ${v.merchant}`, text: `Fecha límite: ${fmtDate(p.due)} · ${money(Number(v.total) || 0)}`, at: p.due - 2 * 86400000, repeatH: 0, docId: d.id });
    toast(p.due ? 'Gasto guardado y aviso de pago creado' : 'Gasto guardado');
    go('gastos', {}, { replace: true });
}
export async function expensesScreen() {
    let month = new Date();
    month = new Date(month.getFullYear(), month.getMonth(), 1);
    const body = h('div');
    const paint = () => {
        const m0 = month.getTime(), m1 = new Date(month.getFullYear(), month.getMonth() + 1, 1).getTime();
        const l = expenses().filter(e => e.date >= m0 && e.date < m1).sort((a, b) => b.date - a.date);
        const total = l.reduce((a, e) => a + e.total, 0), byCat = new Map();
        l.forEach(e => byCat.set(e.category, (byCat.get(e.category) ?? 0) + e.total));
        body.replaceChildren(h('div', { class: 'row', style: 'justify-content:space-between;margin:6px 0 10px' }, btn('', () => { month = new Date(month.getFullYear(), month.getMonth() - 1, 1); paint(); }, 'ghost', { icon: 'chevLeft', sm: true }), h('h3', null, month.toLocaleDateString(loc(), { month: 'long', year: 'numeric' })), btn('', () => { month = new Date(month.getFullYear(), month.getMonth() + 1, 1); paint(); }, 'ghost', { icon: 'chevRight', sm: true })), h('div', { class: 'card expense-total' }, h('div', { class: 'xs faint' }, 'Total del mes'), h('div', { class: 'big-num' }, money(total)), ...[...byCat].sort((a, b) => b[1] - a[1]).map(([c, v]) => h('div', { class: 'cat-bar' }, h('span', null, c), h('i', { style: `width:${Math.round(v / (total || 1) * 100)}%` }), h('b', null, money(v))))), ...(l.length ? l.map(e => listItem({ icon: 'fileText', tint: 'butter', title: `${e.merchant} · ${money(e.total)}`, sub: `${fmtDate(e.date)} · ${e.category}`, onclick: () => actionSheet(e.merchant, [...(e.docId ? [{ icon: 'eye', label: 'Ver recibo', run: () => go('doc', { id: e.docId }) }] : []), { icon: 'trash', label: 'Borrar gasto', danger: true, run: () => { saveExpenses(expenses().filter(x => x.id !== e.id)); paint(); } }]) })) : [emptyState('fileText', 'Sin gastos este mes', 'Fotografía un recibo o factura para registrarlo.')]));
    };
    paint();
    return h('div', { class: 'screen' }, topbar('Gastos', { back: true }), h('div', { class: 'content' }, h('div', { class: 'btn-row' }, btn('Escanear recibo', () => void expenseFromPhoto(), 'primary', { icon: 'camera' }), btn('Manual', async () => { const v = await form('Nuevo gasto', [{ k: 'merchant', label: 'Concepto' }, { k: 'total', label: 'Valor', type: 'number' }, { k: 'date', label: 'Fecha', type: 'date', value: new Date().toISOString().slice(0, 10) }, { k: 'cat', label: 'Categoría', value: 'Otros', options: CATS.map(c => [c, c]) }]); if (!v?.merchant)
        return; const e = expenses(); e.unshift({ id: uid(), merchant: v.merchant, total: Number(v.total) || 0, date: new Date(v.date + 'T12:00:00').getTime(), category: v.cat }); saveExpenses(e); paint(); }, 'secondary', { icon: 'plus' })), body, btn('Exportar a Excel', async () => { const rows = [['Fecha', 'Comercio', 'Categoría', 'Valor']]; expenses().sort((a, b) => a.date - b.date).forEach((e) => rows.push([new Date(e.date).toLocaleDateString(loc()), e.merchant, e.category, e.total])); await deliver([new File([await makeXlsx(rows, 'Gastos')], 'gastos-scanpro.xlsx', { type: XLSX_MIME })], 'Gastos'); }, 'ghost', { block: true, icon: 'download' })));
}
// ---------- inventario y catálogo ----------
async function photoThumb(f) { const im = await createImageBitmap(f), k = 240 / Math.max(im.width, im.height), c = makeCanvas(Math.round(im.width * k), Math.round(im.height * k)); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.75); }
async function editItem(it) {
    let code = it?.code ?? '';
    const scanCode = async () => { if (!nativeHas('scanCode')) {
        toast('Lectura de códigos en la app instalada.', 'error');
        return;
    } const r = await nativeScanCode(); if (r.startsWith('ok:'))
        code = JSON.parse(r.slice(3)).raw; };
    if (!it) {
        const go2 = await new Promise(res => { let x = false; sheet(close => [h('h2', null, 'Nuevo producto'), h('div', { class: 'tool-actions' }, btn('Leer código de barras', async () => { await scanCode(); x = true; await close(); }, 'primary', { icon: 'scan' }), btn('Sin código', async () => { x = true; await close(); }, 'secondary'))], () => res(x)); });
        if (!go2)
            return;
    }
    const exist = code ? items().find(x => x.code === code) : undefined;
    const base = exist ?? it ?? {};
    const v = await form(exist ? 'Producto existente' : 'Producto', [{ k: 'name', label: 'Nombre', value: base.name ?? '' }, { k: 'price', label: 'Precio', type: 'number', value: base.price ? String(base.price) : '' }, { k: 'qty', label: 'Cantidad', type: 'number', value: String(base.qty ?? 1) }, { k: 'code', label: 'Código', value: code }], 'Guardar', exist ? 'Ya existe: puedes cambiar la cantidad.' : undefined);
    if (!v?.name)
        return;
    let photo = base.photo;
    if (!photo) {
        const ok = await confirmDialog({ title: '¿Agregar foto?', confirm: 'Tomar foto', cancel: 'Sin foto', icon: 'camera' });
        if (ok) {
            const f = await captureForTool(1);
            if (f[0])
                photo = await photoThumb(f[0]);
        }
    }
    const l = items().filter(x => x.id !== base.id);
    l.unshift({ id: base.id ?? uid(), name: v.name, price: Number(v.price) || 0, qty: Number(v.qty) || 0, code: v.code || undefined, photo, updated: Date.now() });
    saveItems(l);
}
export async function inventoryScreen() {
    const list = h('div'), search = h('input', { type: 'search', placeholder: 'Buscar producto o código…', 'aria-label': 'Buscar' });
    const paint = () => {
        const q = search.value.toLowerCase(), l = items().filter(i => !q || i.name.toLowerCase().includes(q) || i.code?.includes(q));
        const total = l.reduce((a, i) => a + i.price * i.qty, 0);
        list.replaceChildren(h('p', { class: 'small muted' }, `${l.length} producto(s) · inventario valorizado ${money(total)}`), ...(l.length ? l.map(i => h('button', { class: 'inv-item', onclick: () => actionSheet(i.name, [{ icon: 'pencil', label: 'Editar', run: async () => { await editItem(i); paint(); } }, { icon: 'plus', label: 'Sumar 1', run: () => { saveItems(items().map(x => x.id === i.id ? { ...x, qty: x.qty + 1 } : x)); paint(); } }, { icon: 'minus', label: 'Restar 1 (venta)', run: () => { saveItems(items().map(x => x.id === i.id ? { ...x, qty: Math.max(0, x.qty - 1) } : x)); paint(); } }, { icon: 'trash', label: 'Borrar', danger: true, run: () => { saveItems(items().filter(x => x.id !== i.id)); paint(); } }]) }, i.photo ? h('img', { src: i.photo, alt: '' }) : h('div', { class: 'inv-ph' }, ic('image')), h('div', { class: 'grow' }, h('b', null, i.name), h('div', { class: 'xs faint' }, `${money(i.price)} · ${i.qty} und.${i.code ? ' · ' + i.code : ''}`)), i.qty <= 2 ? h('span', { class: 'badge warn' }, 'Poco') : null)) : [emptyState('archive', 'Sin productos', 'Agrega productos con su foto y código de barras.')]));
    };
    search.oninput = paint;
    paint();
    return h('div', { class: 'screen' }, topbar('Inventario', { back: true }), h('div', { class: 'content' }, h('div', { class: 'input-wrap' }, ic('search', 'sm faint'), search), h('div', { class: 'btn-row', style: 'margin:10px 0' }, btn('Agregar', async () => { await editItem(null); paint(); }, 'primary', { icon: 'plus' }), btn('Vender (leer código)', async () => { if (!nativeHas('scanCode')) {
        toast('Lectura de códigos en la app instalada.', 'error');
        return;
    } const r = await nativeScanCode(); if (!r.startsWith('ok:'))
        return; const code = JSON.parse(r.slice(3)).raw; const it = items().find(x => x.code === code); if (!it) {
        toast('Código no registrado.', 'error');
        return;
    } saveItems(items().map(x => x.id === it.id ? { ...x, qty: Math.max(0, x.qty - 1) } : x)); toast(`${it.name}: quedan ${Math.max(0, it.qty - 1)}`); paint(); }, 'secondary', { icon: 'scan' })), list, h('div', { class: 'tool-actions' }, btn('Exportar a Excel', async () => { const rows = [['Producto', 'Código', 'Precio', 'Cantidad', 'Total']]; items().forEach(i => rows.push([i.name, i.code ?? '', i.price, i.qty, i.price * i.qty])); await deliver([new File([await makeXlsx(rows, 'Inventario')], 'inventario-scanpro.xlsx', { type: XLSX_MIME })], 'Inventario'); }, 'ghost', { icon: 'download' }), btn('Crear catálogo en PDF', () => void catalog(), 'ghost', { icon: 'filePdf' }))));
}
async function catalog() {
    const l = items();
    if (!l.length) {
        toast('Agrega productos primero.', 'error');
        return;
    }
    const r = await form('Catálogo', [{ k: 'title', label: 'Nombre del negocio', value: 'Catálogo' }, { k: 'phone', label: 'WhatsApp de pedidos', value: '' }], 'Crear');
    if (!r)
        return;
    const b = busy('Creando catálogo…');
    try {
        const W = 1240, H = 1754, per = 6, pages = [];
        for (let p = 0; p < l.length; p += per) {
            const c = makeCanvas(W, H), g = c.getContext('2d');
            g.fillStyle = '#fff';
            g.fillRect(0, 0, W, H);
            g.fillStyle = '#6a59e0';
            g.fillRect(0, 0, W, 150);
            g.fillStyle = '#fff';
            g.font = '800 56px Helvetica, Arial';
            g.fillText(r.title, 70, 95);
            if (r.phone) {
                g.font = '500 30px Helvetica, Arial';
                g.textAlign = 'right';
                g.fillText(`Pedidos: ${r.phone}`, W - 70, 92);
                g.textAlign = 'left';
            }
            for (let k = 0; k < per && p + k < l.length; k++) {
                const it = l[p + k], x = 70 + (k % 2) * 560, y = 200 + Math.floor(k / 2) * 500;
                g.fillStyle = '#f4f2fb';
                g.beginPath();
                g.roundRect(x, y, 530, 470, 28);
                g.fill();
                if (it.photo) {
                    const im = new Image();
                    im.src = it.photo;
                    await im.decode().catch(() => { });
                    const s = Math.min(490 / im.width, 300 / im.height);
                    g.drawImage(im, x + 265 - im.width * s / 2, y + 20, im.width * s, im.height * s);
                }
                g.fillStyle = '#1b1a2a';
                g.font = '700 34px Helvetica, Arial';
                g.fillText(it.name.slice(0, 26), x + 24, y + 380);
                g.fillStyle = '#6a59e0';
                g.font = '800 40px Helvetica, Arial';
                g.fillText(money(it.price), x + 24, y + 435);
            }
            pages.push(await canvasToPage(c, l.slice(p, p + per).map(i => `${i.name} ${money(i.price)}`).join('\n')));
        }
        const d = await newDoc(`Catálogo ${r.title}`, pages);
        b.done();
        toast('Catálogo creado');
        go('doc', { id: d.id });
    }
    catch (e) {
        b.done();
        toast(e.message, 'error');
    }
}
