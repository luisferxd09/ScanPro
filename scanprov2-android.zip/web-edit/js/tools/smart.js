import { loc } from '../core/locale.js';
// Escáner inteligente y texto: QR, libro, lotes, tarjetas, copiar texto, traducir, leer en voz alta, tablas, listas y comparar.
import { h } from '../ui/dom.js';
import { LANGS as ALL_LANGS, curLang } from '../core/locale.js';
import { sheet, btn, toast, busy, topbar, emptyState, note } from '../ui/components.js';
import { go } from '../core/router.js';
import { getPages, getDoc } from '../core/db.js';
import { pickDocument, captureForTool, scanWithCamera } from '../screens/common.js';
import { recognize, cleanText } from '../core/ocr.js';
import { getSettings } from '../core/settings.js';
import { copyText, shareText } from '../core/share.js';
import { isNative, nativeHas, nativeScanCode, nativeTranslate, nativeSpeak, nativeStopSpeak, nativeDictate, nativeAddContact } from '../core/native.js';
import { parseContact, tableFromLines, checklist, diffWords, summarize, flashcards } from '../core/textintel.js';
import { splitBookPage, canvasToPage, newDoc, copyPage, textPage } from '../core/docops.js';
import { makeXlsx, XLSX_MIME } from '../core/xlsx.js';
import { fileSafe } from '../core/names.js';
import { docText, deliver, form } from './kit.js';
/** OCR de fotos sueltas (sin guardar). */
export async function ocrBlobs(blobs) {
    const b = busy('Reconociendo texto…', true);
    try {
        const r = await recognize(blobs, getSettings().ocrLang, p => b.set(p.status, p.total ? (p.page + p.progress) / p.total : 0));
        return { text: cleanText(r.texts.join('\n\n')), lines: r.lines.flat() };
    }
    catch (e) {
        toast(e.message, 'error');
        return null;
    }
    finally {
        b.done();
    }
}
// ---------- pantalla de texto con acciones ----------
let textPayload = { title: '', text: '' };
export function showText(title, text, docId) { textPayload = { title, text, docId }; go('texto', {}); }
export async function textScreen() {
    const { title, text, docId } = textPayload;
    const ta = h('textarea', { class: 'text-view', 'aria-label': 'Texto' });
    ta.value = text;
    let speaking = false;
    const speakBtn = btn('Escuchar', () => { if (!isNative || !nativeHas('speak')) {
        speakWeb(ta.value);
        return;
    } speaking = !speaking; speaking ? nativeSpeak(ta.value) : nativeStopSpeak(); speakBtn.querySelector('span').textContent = speaking ? 'Detener' : 'Escuchar'; }, 'secondary', { icon: 'zap' });
    return h('div', { class: 'screen' }, topbar(title, { back: () => { nativeStopSpeak(); history.back(); } }), h('div', { class: 'content' }, ta, h('div', { class: 'tool-actions grid2' }, btn('Copiar', async () => toast(await copyText(ta.value) ? 'Texto copiado' : 'No se pudo copiar', 'ok'), 'primary', { icon: 'copy' }), speakBtn, btn('Traducir', () => void translateText(ta.value, title), 'secondary', { icon: 'language' }), btn('Compartir', () => void shareText(ta.value, title), 'secondary', { icon: 'share' }), btn('Guardar como documento', async () => { const d = await newDoc(title, [await canvasToPage(textPage([{ t: title, size: 44, bold: true, gap: 20 }, ...ta.value.split('\n').map(t => ({ t: t || ' ', size: 28 }))]), ta.value)]); toast('Documento guardado'); go('doc', { id: d.id }); }, 'secondary', { icon: 'download' }), docId ? btn('Ver documento', () => go('doc', { id: docId }), 'ghost', { icon: 'eye' }) : null)));
}
function speakWeb(t) {
    const s = window.speechSynthesis;
    if (!s) {
        toast('Este navegador no puede leer en voz alta.', 'error');
        return;
    }
    if (s.speaking) {
        s.cancel();
        return;
    }
    const u = new SpeechSynthesisUtterance(t);
    u.lang = loc();
    s.speak(u);
}
// ---------- QR y códigos de barras ----------
export async function qrTool() {
    let raw = '';
    if (nativeHas('scanCode')) {
        const r = await nativeScanCode();
        if (r === 'cancel')
            return;
        if (!r.startsWith('ok:')) {
            toast(r.replace(/^error:/, ''), 'error');
            return;
        }
        raw = JSON.parse(r.slice(3)).raw ?? '';
    }
    else {
        const [f] = await captureForTool(1);
        if (!f)
            return;
        const BD = window.BarcodeDetector;
        if (!BD) {
            toast('Este navegador no lee códigos. Usa la app instalada.', 'error');
            return;
        }
        const codes = await new BD().detect(await createImageBitmap(f));
        raw = codes[0]?.rawValue ?? '';
        if (!raw) {
            toast('No se encontró ningún código en la foto.', 'error');
            return;
        }
    }
    const url = /^https?:\/\//i.test(raw) ? raw : null, wifi = raw.match(/^WIFI:.*?S:([^;]*);.*?(?:P:([^;]*);)?/i);
    const dian = /dian|cufe|nitfac|valfac/i.test(raw);
    sheet(close => [h('h2', null, wifi ? 'Red Wi-Fi' : url ? 'Enlace' : dian ? 'Factura electrónica' : 'Código leído'),
        h('div', { class: 'code-result' }, wifi ? `Red: ${wifi[1]}\nContraseña: ${wifi[2] ?? '(sin contraseña)'}` : raw),
        url && !/^https:\/\//i.test(url) ? note('Este enlace no es seguro (http). Ábrelo solo si confías en quien lo creó.', 'warn') : null,
        h('div', { class: 'tool-actions' }, btn('Copiar', async () => { await copyText(wifi?.[2] ?? raw); toast('Copiado'); }, 'primary', { icon: 'copy' }), url ? btn('Abrir enlace', () => { window.open(url, '_blank', 'noopener'); }, 'secondary', { icon: 'share' }) : null, btn('Guardar como nota', async () => { await close(); showText(dian ? 'Factura (QR)' : 'Código QR', raw); }, 'secondary', { icon: 'fileText' }), btn('Leer otro', async () => { await close(); void qrTool(); }, 'ghost', { icon: 'scan' }))]);
}
// ---------- libro abierto ----------
export function bookTool() {
    sheet(close => [h('h2', null, 'Escanear libro'), h('p', { class: 'small muted' }, 'Fotografía el libro abierto (dos páginas a la vez). ScanPro corta cada foto por el lomo y deja las páginas en orden.'),
        h('div', { class: 'tool-actions' }, btn('Escanear ahora', async () => { await close(); const files = await captureForTool(0); if (files.length)
            await bookFrom(files.map(f => f)); }, 'primary', { icon: 'camera' }), btn('Dividir un documento ya escaneado', async () => { await close(); void pickDocument('Dividir libro…', async (d) => { const ps = await getPages(d); await bookFrom(ps.map(p => p.image), d.name); }); }, 'secondary', { icon: 'book' }), btn('Cancelar', () => void close(), 'ghost'))]);
}
async function bookFrom(blobs, name = 'Libro') {
    const b = busy('Separando páginas…', true), out = [];
    try {
        for (let i = 0; i < blobs.length; i++) {
            b.set(`Foto ${i + 1} de ${blobs.length}…`, i / blobs.length);
            for (const c of await splitBookPage({ image: blobs[i], width: 0 }))
                out.push(await canvasToPage(c));
        }
        const d = await newDoc(`${name} (páginas)`, out);
        toast(`${out.length} páginas`);
        go('doc', { id: d.id });
    }
    catch (e) {
        toast(e.message, 'error');
    }
    finally {
        b.done();
    }
}
// ---------- lotes ----------
export function batchTool() {
    sheet(close => [h('h2', null, 'Escaneo por lotes'), h('p', { class: 'small muted' }, 'Escanea muchas hojas seguidas sin parar. Al final eliges si van en un solo documento o cada hoja en uno distinto.'),
        h('div', { class: 'tool-actions' }, btn('Todas en un documento', async () => { await close(); void scanWithCamera(); }, 'primary', { icon: 'layers' }), btn('Cada hoja en su documento', async () => {
            await close();
            const files = await captureForTool(0);
            if (!files.length)
                return;
            const b = busy('Guardando…', true);
            try {
                for (let i = 0; i < files.length; i++) {
                    b.set(`Hoja ${i + 1} de ${files.length}`, i / files.length);
                    const im = await createImageBitmap(files[i]);
                    const c = document.createElement('canvas');
                    c.width = im.width;
                    c.height = im.height;
                    c.getContext('2d').drawImage(im, 0, 0);
                    await newDoc(`Lote ${new Date().toLocaleDateString(loc())} · ${i + 1}`, [await canvasToPage(c)]);
                }
                toast(`${files.length} documentos`);
                go('docs');
            }
            finally {
                b.done();
            }
        }, 'secondary', { icon: 'files' }), btn('Cancelar', () => void close(), 'ghost'))]);
}
// ---------- tarjeta de presentación → contacto ----------
export async function cardTool() {
    const files = await captureForTool(1);
    if (!files.length)
        return;
    const r = await ocrBlobs(files);
    if (!r)
        return;
    const c = parseContact(r.text);
    const v = await form('Nuevo contacto', [{ k: 'name', label: 'Nombre', value: c.name ?? '' }, { k: 'phone', label: 'Teléfono', type: 'text', value: c.phone ?? '' }, { k: 'email', label: 'Correo', value: c.email ?? '' }, { k: 'company', label: 'Empresa', value: c.company ?? '' }, { k: 'title', label: 'Cargo', value: c.title ?? '' }], 'Guardar en contactos', 'Revisa los datos leídos de la tarjeta.');
    if (!v)
        return;
    const clean = Object.fromEntries(Object.entries(v).filter(([, x]) => x));
    if (isNative && nativeHas('addContact')) {
        nativeAddContact(clean);
        return;
    }
    const vcf = `BEGIN:VCARD\nVERSION:3.0\nFN:${v.name}\n${v.phone ? `TEL:${v.phone}\n` : ''}${v.email ? `EMAIL:${v.email}\n` : ''}${v.company ? `ORG:${v.company}\n` : ''}${v.title ? `TITLE:${v.title}\n` : ''}END:VCARD\n`;
    await deliver([new File([vcf], `${fileSafe(v.name || 'contacto')}.vcf`, { type: 'text/vcard' })], v.name);
}
// ---------- copiar texto al instante ----------
export async function copyTextTool() {
    const files = await captureForTool(1);
    if (!files.length)
        return;
    const r = await ocrBlobs(files);
    if (!r)
        return;
    if (!r.text.trim()) {
        toast('No se encontró texto legible', 'error');
        return;
    }
    await copyText(r.text);
    toast('Texto copiado al portapapeles');
    showText('Texto de la foto', r.text);
}
// ---------- traducir ----------
const LANGS = ALL_LANGS.map(l => [l.code, l.name]);
export async function translateText(text, title = 'Texto') {
    if (!nativeHas('translate')) {
        toast('La traducción funciona en la app instalada (Android).', 'error');
        return;
    }
    const r = await form('Traducir', [{ k: 'from', label: 'De', value: curLang(), options: LANGS }, { k: 'to', label: 'A', value: curLang() === 'en' ? 'es' : 'en', options: LANGS }], 'Traducir', 'La primera vez se descarga el idioma (≈30 MB, con internet). Después funciona sin conexión.');
    if (!r || r.from === r.to)
        return;
    const b = busy('Traduciendo…');
    const out = await nativeTranslate(text.slice(0, 20000), r.from, r.to);
    b.done();
    if (!out.startsWith('ok:')) {
        toast(out.replace(/^error:/, ''), 'error', 5000);
        return;
    }
    showText(`${title} (${LANGS.find(l => l[0] === r.to)?.[1]})`, out.slice(3));
}
export function translateTool() {
    sheet(close => [h('h2', null, 'Traducir'), h('div', { class: 'tool-actions' }, btn('Traducir un documento', async () => { await close(); void pickDocument('Traducir…', async (d) => { const t = await docText(d); if (t)
            await translateText(t.text, d.name); }); }, 'primary', { icon: 'fileText' }), btn('Traducir una foto', async () => { await close(); const f = await captureForTool(1); if (!f.length)
            return; const r = await ocrBlobs(f); if (r?.text)
            await translateText(r.text, 'Foto'); }, 'secondary', { icon: 'camera' }), btn('Cancelar', () => void close(), 'ghost'))]);
}
// ---------- leer en voz alta ----------
export function readAloudTool() { void pickDocument('Leer en voz alta…', async (d) => { const t = await docText(d); if (t) {
    showText(d.name, t.text, d.id);
    setTimeout(() => document.querySelector('.tool-actions .btn:nth-child(2)')?.click(), 400);
} }); }
// ---------- tabla → Excel ----------
export function tableTool() {
    sheet(close => [h('h2', null, 'Tabla a Excel'), h('p', { class: 'small muted' }, 'Funciona mejor con tablas impresas y simples, con columnas bien separadas.'), h('div', { class: 'tool-actions' }, btn('Fotografiar una tabla', async () => { await close(); const f = await captureForTool(1); if (!f.length)
            return; const r = await ocrBlobs(f); if (r)
            await tableOut(tableFromLines(r.lines, r.text), 'Tabla'); }, 'primary', { icon: 'camera' }), btn('Desde un documento', async () => { await close(); void pickDocument('Tabla de…', async (d) => { const t = await docText(d); if (t)
            await tableOut(t.pages.flatMap(p => tableFromLines(p.ocrLines ?? [], p.ocrText ?? '')), d.name); }); }, 'secondary', { icon: 'fileText' }), btn('Cancelar', () => void close(), 'ghost'))]);
}
async function tableOut(rows, name) {
    const fixed = rows.filter(r => r.length).map(r => r.map(c => /^\$?\s?-?[\d.,]+$/.test(c) && /\d/.test(c) ? Number(c.replace(/[$\s.]/g, '').replace(',', '.')) || c : c));
    if (!fixed.length) {
        toast('No se encontró una tabla.', 'error');
        return;
    }
    await deliver([new File([await makeXlsx(fixed)], `${fileSafe(name)}.xlsx`, { type: XLSX_MIME })], name);
}
// ---------- lista con casillas ----------
const CK = 'scanpro.checklists.v1';
const loadCk = () => { try {
    return JSON.parse(localStorage.getItem(CK) || '[]');
}
catch {
    return [];
} };
const saveCk = (l) => { try {
    localStorage.setItem(CK, JSON.stringify(l));
}
catch { /* */ } };
export async function checklistTool() {
    const f = await captureForTool(1);
    if (!f.length)
        return;
    const r = await ocrBlobs(f);
    if (!r)
        return;
    const items = checklist(r.text);
    if (!items.length) {
        toast('No se encontraron elementos.', 'error');
        return;
    }
    const l = loadCk();
    l.unshift({ id: Date.now().toString(36), title: `Lista ${new Date().toLocaleDateString(loc())}`, items: items.map(t => ({ t, ok: false })) });
    saveCk(l);
    go('listas', {});
}
export async function listsScreen() {
    const wrap = h('div');
    const paint = () => {
        const l = loadCk();
        wrap.replaceChildren(...(l.length ? l.map(c => h('div', { class: 'card check-card' }, h('div', { class: 'row' }, h('h3', { class: 'grow' }, c.title), btn('Borrar', () => { saveCk(loadCk().filter(x => x.id !== c.id)); paint(); }, 'ghost', { sm: true, icon: 'trash' })), ...c.items.map((it, i) => h('label', { class: 'check-row' + (it.ok ? ' done' : '') }, h('input', { type: 'checkbox', checked: it.ok, onchange: (e) => { const all = loadCk(); const x = all.find(y => y.id === c.id); x.items[i].ok = e.target.checked; saveCk(all); paint(); } }), h('span', null, it.t))))) : [emptyState('check', 'Sin listas', 'Fotografía una nota o lista escrita y aparecerá aquí con casillas.')]));
    };
    paint();
    return h('div', { class: 'screen' }, topbar('Listas', { back: true }), h('div', { class: 'content' }, btn('Nueva lista desde una foto', () => void checklistTool(), 'primary', { block: true, icon: 'camera' }), wrap));
}
// ---------- comparar documentos ----------
export function compareTool() {
    void pickDocument('Documento original…', a => void pickDocument('Comparar con…', async (b) => {
        const ta = await docText(a);
        if (!ta)
            return;
        const tb = await docText(b);
        if (!tb)
            return;
        const d = diffWords(ta.text, tb.text), changes = d.filter(x => x.k !== 'same' && x.t.trim()).length;
        textPayload = { title: '', text: '' };
        compareData = { a: a.name, b: b.name, d, changes };
        go('comparar', {});
    }));
}
let compareData = null;
export async function compareScreen() {
    const c = compareData;
    return h('div', { class: 'screen' }, topbar('Comparar', { back: true }), h('div', { class: 'content' }, c ? h('div', null, h('p', { class: 'small muted' }, `«${c.a}» → «${c.b}»: ${c.changes} cambio(s). `, h('span', { class: 'diff-del' }, 'quitado'), ' · ', h('span', { class: 'diff-add' }, 'añadido')), h('div', { class: 'diff-view' }, ...c.d.map(x => x.k === 'same' ? document.createTextNode(x.t) : h('span', { class: x.k === 'del' ? 'diff-del' : 'diff-add' }, x.t))))
        : emptyState('fileText', 'Nada que comparar', '')));
}
// ---------- estudio: resumen y tarjetas ----------
let studyData = null;
export function studyTool() {
    void pickDocument('Resumir apuntes de…', async (d) => {
        const t = await docText(d);
        if (!t)
            return;
        studyData = { name: d.name, sum: summarize(t.text), cards: flashcards(t.text) };
        go('estudio', {});
    });
}
export async function studyScreen() {
    const s = studyData;
    if (!s)
        return h('div', { class: 'screen' }, topbar('Estudio', { back: true }), emptyState('book', 'Sin apuntes', ''));
    let i = 0, flip = false;
    const card = h('button', { class: 'flashcard' });
    const paint = () => { const c = s.cards[i]; card.replaceChildren(c ? h('div', null, h('div', { class: 'xs faint' }, `${i + 1} de ${s.cards.length} · ${flip ? 'respuesta' : 'pregunta'}`), h('div', { class: 'fc-text' }, flip ? c.a : c.q)) : h('div', null, 'No se pudieron crear tarjetas con este texto.')); card.classList.toggle('flipped', flip); };
    card.onclick = () => { flip = !flip; paint(); };
    paint();
    const nav = h('div', { class: 'btn-row' }, btn('Anterior', () => { i = Math.max(0, i - 1); flip = false; paint(); }, 'secondary', { icon: 'chevLeft' }), btn('Siguiente', () => { i = Math.min(s.cards.length - 1, i + 1); flip = false; paint(); }, 'primary', { icon: 'chevRight' }));
    return h('div', { class: 'screen' }, topbar(`Estudiar · ${s.name}`, { back: true }), h('div', { class: 'content' }, h('h3', null, 'Resumen'), h('ul', { class: 'summary' }, ...s.sum.map(x => h('li', null, x))), btn('Copiar resumen', async () => { await copyText(s.sum.join('\n')); toast('Resumen copiado'); }, 'ghost', { icon: 'copy' }), h('h3', { style: 'margin-top:18px' }, 'Tarjetas de estudio'), card, nav, note('Resumen automático hecho en el teléfono (sin internet): elige las frases más importantes de tus apuntes.', 'info')));
}
// ---------- dictado ----------
export async function dictateTool() {
    if (!nativeHas('dictate')) {
        toast('El dictado funciona en la app instalada (Android).', 'error');
        return;
    }
    const r = await nativeDictate();
    if (r === 'cancel')
        return;
    if (!r.startsWith('ok:')) {
        toast(r.replace(/^error:/, ''), 'error');
        return;
    }
    showText('Dictado', r.slice(3));
}
// ---------- libro de apuntes: portada, índice y números ----------
export function notebookTool() {
    void (async () => {
        const { listDocs } = await import('../core/db.js');
        const docs = (await listDocs()).sort((a, b) => a.name.localeCompare(b.name, 'es', { numeric: true }));
        if (!docs.length) {
            toast('No tienes documentos.', 'error');
            return;
        }
        const sel = new Set();
        sheet(close => [h('h2', null, 'Libro de apuntes'), h('p', { class: 'small muted' }, 'Elige los documentos en el orden en que van (tócalos en orden).'),
            h('div', { class: 'doc-pick' }, ...docs.map(d => { const b = h('button', { class: 'chip', onclick: () => { sel.has(d.id) ? sel.delete(d.id) : sel.add(d.id); b.classList.toggle('active', sel.has(d.id)); b.dataset.n = sel.has(d.id) ? String([...sel].indexOf(d.id) + 1) : ''; } }, d.name); return b; })),
            h('div', { class: 'btn-row', style: 'margin-top:14px' }, btn('Cancelar', () => void close(), 'secondary'), btn('Crear libro', async () => {
                if (!sel.size) {
                    toast('Elige al menos un documento.', 'error');
                    return;
                }
                await close();
                const r = await form('Portada', [{ k: 'title', label: 'Título', value: 'Apuntes' }, { k: 'sub', label: 'Materia o subtítulo', value: '' }, { k: 'author', label: 'Autor', value: '' }], 'Crear');
                if (!r)
                    return;
                const b = busy('Armando el libro…');
                try {
                    const chosen = [...sel].map(id => docs.find(d => d.id === id));
                    const parts = [];
                    let page = 3;
                    for (const d of chosen) {
                        parts.push({ d, page });
                        page += d.pageIds.length;
                    }
                    const cover = textPage([{ t: ' ', size: 200 }, { t: r.title, size: 80, bold: true, align: 'center', gap: 20 }, { t: r.sub, size: 40, align: 'center', color: '#5d5675', gap: 60 }, { t: r.author, size: 34, align: 'center', color: '#5d5675' }, { t: new Date().toLocaleDateString(loc(), { year: 'numeric', month: 'long' }), size: 30, align: 'center', color: '#8a84a3' }]);
                    const index = textPage([{ t: 'Índice', size: 56, bold: true, gap: 30 }, ...parts.map(p => ({ t: `${p.d.name}  ·  pág. ${p.page}`, size: 32, gap: 6 }))]);
                    const out = [await canvasToPage(cover), await canvasToPage(index, parts.map(p => p.d.name).join('\n'))];
                    for (const p of parts) {
                        const d2 = await getDoc(p.d.id);
                        if (d2)
                            for (const pg of await getPages(d2))
                                out.push(await copyPage(pg));
                    }
                    const nd = await newDoc(r.title || 'Libro de apuntes', out);
                    toast('Libro creado. Usa «Numerar páginas» si quieres números.', 'ok', 3500);
                    go('doc', { id: nd.id });
                }
                finally {
                    b.done();
                }
            })),
        ]);
    })();
}
