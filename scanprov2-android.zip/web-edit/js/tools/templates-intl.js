// Plantillas de documentos para otros idiomas. Los nombres de los campos están en español y la interfaz los traduce.
import { fmtDay, fmtMoney } from '../core/locale.js';
const d = () => fmtDay(Date.now());
const items = (txt) => (txt || '').split('\n').map(l => l.split(';').map(x => x.trim())).filter(r => r[0]).map(r => ({ n: r[0], q: Number(r[1]) || 1, p: Number(r[2]) || 0 }));
const F = {
    complaint: [['ciudad', 'Ciudad'], ['entidad', 'Empresa o entidad'], ['nombre', 'Tu nombre completo'], ['cc', 'Documento de identidad'], ['hechos', 'Hechos (qué pasó)'], ['peticion', 'Qué solicitas'], ['correo', 'Correo para respuesta']],
    invoice: [['negocio', 'Tu nombre o negocio'], ['cc', 'Documento o número fiscal'], ['cliente', 'Cliente'], ['items', 'Productos (uno por línea: nombre ; cantidad ; precio)'], ['cuenta', 'Datos de pago']],
    auth: [['ciudad', 'Ciudad'], ['nombre', 'Quien autoriza'], ['cc', 'Su documento'], ['autorizado', 'Persona autorizada'], ['cca', 'Documento del autorizado'], ['tramite', 'Qué puede hacer (reclamar, firmar…)'], ['entidad', 'Ante qué entidad']],
    poa: [['ciudad', 'Ciudad'], ['nombre', 'Poderdante (quien da el poder)'], ['cc', 'Su documento'], ['apoderado', 'Apoderado'], ['ccap', 'Documento del apoderado'], ['asunto', 'Para qué asunto']],
    resign: [['ciudad', 'Ciudad'], ['empresa', 'Empresa'], ['jefe', 'Dirigida a'], ['nombre', 'Tu nombre'], ['cargo', 'Cargo'], ['fecha', 'Último día de trabajo']],
    quote: [['negocio', 'Tu negocio'], ['cliente', 'Cliente'], ['items', 'Productos (uno por línea: nombre ; cantidad ; precio)'], ['validez', 'Validez (días)'], ['contacto', 'Teléfono o WhatsApp']],
};
const list = (txt, tot) => { const it = items(txt), total = it.reduce((a, r) => a + r.q * r.p, 0); return `<ul>${it.map(r => `<li>${r.n} — ${r.q} × ${fmtMoney(r.p)} = <b>${fmtMoney(r.q * r.p)}</b></li>`).join('')}</ul><h2>${tot}: ${fmtMoney(total)}</h2>`; };
const W = {
    en: { complaint: 'Formal complaint', re: 'Re: Formal complaint and request', facts: 'Facts', request: 'Request', reply: 'Please reply to', sincerely: 'Sincerely,', date: 'Date',
        intro: v => `I, ${v.nombre}, ID ${v.cc}, respectfully submit the following complaint and request:`, invoice: 'INVOICE', billTo: 'Bill to', payTo: 'Payment details', total: 'Total',
        auth: 'AUTHORIZATION LETTER', authText: v => `I, ${v.nombre}, ID ${v.cc}, hereby authorize <b>${v.autorizado}</b>, ID ${v.cca}, to ${v.tramite} on my behalf before ${v.entidad}. Copies of both IDs are attached.`,
        poa: 'POWER OF ATTORNEY', poaText: v => `I, ${v.nombre}, ID ${v.cc}, appoint ${v.apoderado}, ID ${v.ccap}, as my attorney-in-fact to act in my name regarding ${v.asunto}, with full power to sign, request, receive and carry out all necessary steps.`,
        resign: 'Resignation letter', resignText: v => `Please accept this letter as formal notice of my resignation from my position as ${v.cargo} at ${v.empresa}. My last day of work will be ${v.fecha}.`, thanks: 'Thank you for the opportunity and everything I have learned.',
        quote: 'QUOTATION', client: 'Client', valid: v => `This quotation is valid for ${v.validez || 15} days. Contact: ${v.contacto}` },
    pt: { complaint: 'Reclamação formal', re: 'Assunto: Reclamação e solicitação', facts: 'Fatos', request: 'Solicitação', reply: 'Resposta para', sincerely: 'Atenciosamente,', date: 'Data',
        intro: v => `Eu, ${v.nombre}, documento ${v.cc}, venho respeitosamente apresentar a seguinte reclamação e solicitação:`, invoice: 'RECIBO / FATURA', billTo: 'Cliente', payTo: 'Dados para pagamento', total: 'Total',
        auth: 'AUTORIZAÇÃO', authText: v => `Eu, ${v.nombre}, documento ${v.cc}, autorizo <b>${v.autorizado}</b>, documento ${v.cca}, a ${v.tramite} em meu nome perante ${v.entidad}. Seguem cópias de ambos os documentos.`,
        poa: 'PROCURAÇÃO', poaText: v => `Eu, ${v.nombre}, documento ${v.cc}, nomeio ${v.apoderado}, documento ${v.ccap}, como meu procurador para agir em meu nome em relação a ${v.asunto}, com poderes para assinar, solicitar, receber e realizar todos os atos necessários.`,
        resign: 'Carta de demissão', resignText: v => `Venho por meio desta comunicar meu pedido de demissão do cargo de ${v.cargo} na empresa ${v.empresa}. Meu último dia de trabalho será ${v.fecha}.`, thanks: 'Agradeço a oportunidade e todo o aprendizado.',
        quote: 'ORÇAMENTO', client: 'Cliente', valid: v => `Validade do orçamento: ${v.validez || 15} dias. Contato: ${v.contacto}` },
    fr: { complaint: 'Réclamation', re: 'Objet : Réclamation et demande', facts: 'Faits', request: 'Demande', reply: 'Réponse à', sincerely: 'Veuillez agréer mes salutations distinguées.', date: 'Date',
        intro: v => `Je soussigné(e) ${v.nombre}, pièce d'identité ${v.cc}, présente la réclamation et la demande suivantes :`, invoice: 'FACTURE', billTo: 'Client', payTo: 'Coordonnées de paiement', total: 'Total',
        auth: 'AUTORISATION', authText: v => `Je soussigné(e) ${v.nombre}, pièce d'identité ${v.cc}, autorise <b>${v.autorizado}</b>, pièce d'identité ${v.cca}, à ${v.tramite} en mon nom auprès de ${v.entidad}. Copies des deux pièces d'identité jointes.`,
        poa: 'PROCURATION', poaText: v => `Je soussigné(e) ${v.nombre}, pièce d'identité ${v.cc}, donne procuration à ${v.apoderado}, pièce d'identité ${v.ccap}, pour agir en mon nom concernant ${v.asunto}, avec tout pouvoir de signer, demander, recevoir et accomplir toutes les démarches nécessaires.`,
        resign: 'Lettre de démission', resignText: v => `Je vous informe par la présente de ma démission de mon poste de ${v.cargo} au sein de ${v.empresa}. Mon dernier jour de travail sera le ${v.fecha}.`, thanks: "Je vous remercie pour l'opportunité et tout ce que j'ai appris.",
        quote: 'DEVIS', client: 'Client', valid: v => `Devis valable ${v.validez || 15} jours. Contact : ${v.contacto}` },
    de: { complaint: 'Beschwerde', re: 'Betreff: Beschwerde und Antrag', facts: 'Sachverhalt', request: 'Antrag', reply: 'Antwort bitte an', sincerely: 'Mit freundlichen Grüßen', date: 'Datum',
        intro: v => `Ich, ${v.nombre}, Ausweis ${v.cc}, reiche hiermit folgende Beschwerde und folgenden Antrag ein:`, invoice: 'RECHNUNG', billTo: 'Rechnungsempfänger', payTo: 'Zahlungsdaten', total: 'Gesamt',
        auth: 'VOLLMACHT (EINZELN)', authText: v => `Hiermit bevollmächtige ich, ${v.nombre}, Ausweis ${v.cc}, <b>${v.autorizado}</b>, Ausweis ${v.cca}, in meinem Namen bei ${v.entidad} ${v.tramite}. Kopien beider Ausweise liegen bei.`,
        poa: 'VOLLMACHT', poaText: v => `Ich, ${v.nombre}, Ausweis ${v.cc}, bevollmächtige ${v.apoderado}, Ausweis ${v.ccap}, mich in der Angelegenheit ${v.asunto} zu vertreten, einschließlich Unterzeichnung, Antragstellung, Empfang und aller notwendigen Handlungen.`,
        resign: 'Kündigung', resignText: v => `Hiermit kündige ich mein Arbeitsverhältnis als ${v.cargo} bei ${v.empresa}. Mein letzter Arbeitstag ist der ${v.fecha}.`, thanks: 'Vielen Dank für die Gelegenheit und alles, was ich lernen durfte.',
        quote: 'ANGEBOT', client: 'Kunde', valid: v => `Dieses Angebot ist ${v.validez || 15} Tage gültig. Kontakt: ${v.contacto}` },
    it: { complaint: 'Reclamo', re: 'Oggetto: Reclamo e richiesta', facts: 'Fatti', request: 'Richiesta', reply: 'Risposta a', sincerely: 'Distinti saluti,', date: 'Data',
        intro: v => `Io sottoscritto/a ${v.nombre}, documento ${v.cc}, presento il seguente reclamo e la seguente richiesta:`, invoice: 'FATTURA / RICEVUTA', billTo: 'Cliente', payTo: 'Dati per il pagamento', total: 'Totale',
        auth: 'DELEGA', authText: v => `Io sottoscritto/a ${v.nombre}, documento ${v.cc}, delego <b>${v.autorizado}</b>, documento ${v.cca}, a ${v.tramite} a mio nome presso ${v.entidad}. Si allegano copie di entrambi i documenti.`,
        poa: 'PROCURA', poaText: v => `Io sottoscritto/a ${v.nombre}, documento ${v.cc}, nomino ${v.apoderado}, documento ${v.ccap}, mio procuratore per agire a mio nome riguardo a ${v.asunto}, con facoltà di firmare, richiedere, ricevere e compiere tutti gli atti necessari.`,
        resign: 'Lettera di dimissioni', resignText: v => `Con la presente comunico le mie dimissioni dal ruolo di ${v.cargo} presso ${v.empresa}. Il mio ultimo giorno di lavoro sarà il ${v.fecha}.`, thanks: "Ringrazio per l'opportunità e per tutto ciò che ho imparato.",
        quote: 'PREVENTIVO', client: 'Cliente', valid: v => `Preventivo valido ${v.validez || 15} giorni. Contatti: ${v.contacto}` },
};
export function intlTemplates(lang) {
    const w = W[lang] ?? W.en;
    const sign = (v) => `<p><br><br>${v.nombre ?? ''}<br>${v.cc ?? ''}</p>`;
    return [
        { id: 'complaint', name: 'Carta de reclamo', fields: F.complaint, body: v => `<p>${v.ciudad}, ${d()}</p><p><b>${v.entidad}</b></p><p><b>${w.re}</b></p><p>${w.intro(v)}</p><h2>${w.facts}</h2><p>${v.hechos}</p><h2>${w.request}</h2><p>${v.peticion}</p><p>${w.reply}: ${v.correo}</p><p>${w.sincerely}</p>${sign(v)}` },
        { id: 'invoice', name: 'Factura simple', fields: F.invoice, body: v => `<h1>${w.invoice}</h1><p>${w.date}: ${d()}<br><b>${v.negocio}</b> · ${v.cc}</p><p>${w.billTo}: <b>${v.cliente}</b></p>${list(v.items, w.total)}<p>${w.payTo}: ${v.cuenta}</p>` },
        { id: 'auth', name: 'Autorización', fields: F.auth, body: v => `<p>${v.ciudad}, ${d()}</p><h1>${w.auth}</h1><p>${w.authText(v)}</p>${sign(v)}` },
        { id: 'poa', name: 'Poder simple', fields: F.poa, body: v => `<p>${v.ciudad}, ${d()}</p><h1>${w.poa}</h1><p>${w.poaText(v)}</p>${sign(v)}<p><br>${v.apoderado}<br>${v.ccap}</p>` },
        { id: 'resign', name: 'Carta de renuncia', fields: F.resign, body: v => `<p>${v.ciudad}, ${d()}</p><p>${v.jefe}<br><b>${v.empresa}</b></p><p><b>${w.resign}</b></p><p>${w.resignText(v)}</p><p>${w.thanks}</p><p>${w.sincerely}</p><p><br><br>${v.nombre}</p>` },
        { id: 'quote', name: 'Cotización', fields: F.quote, body: v => `<h1>${w.quote} · ${v.negocio}</h1><p>${w.date}: ${d()}<br>${w.client}: <b>${v.cliente}</b></p>${list(v.items, w.total)}<p>${w.valid(v)}</p>` },
    ];
}
