// Punto de entrada de ScanPro.
import { register, start, setBeforeRender, setAfterRender } from './core/router.js';
import { applyTheme, getSettings } from './core/settings.js';
import { initInstall } from './core/install.js';
import { initI18n } from './i18n/index.js';
import { helloScreen } from './screens/hello.js';
import { feedback } from './ui/components.js';
import { runTours } from './ui/tour.js';
import { textScreen, listsScreen, compareScreen, studyScreen } from './tools/smart.js';
import { lifeScreen, privateScreen, remindersScreen, expensesScreen, inventoryScreen } from './tools/life.js';
import { presentScreen, magnifierScreen } from './tools/media.js';
import { askScreen, reviewScreen as docReviewScreen } from './tools/ai.js';
import { rescheduleAll, settingsX } from './core/meta.js';
import { isNative } from './core/native.js';
import { showChangelogIfUpdated, maybeCheckUpdate } from './core/update.js';
import { revokeAll, toast, initChrome, updateChrome } from './ui/components.js';
import { newScanSheet, importFiles, takeScanTarget, takeToolHook } from './screens/common.js';
import './imaging/engine.js'; // arranca el procesador de imágenes en segundo plano
import { onboardingScreen } from './screens/onboarding.js';
import { homeScreen } from './screens/home.js';
import { libraryScreen } from './screens/library.js';
import { detailScreen } from './screens/detail.js';
import { pagesScreen } from './screens/pages.js';
import { renameScreen } from './screens/rename.js';
import { mergeScreen } from './screens/merge.js';
import { shareScreen } from './screens/share.js';
import { ocrScreen } from './screens/ocr.js';
import { toolsScreen } from './screens/tools.js';
import { settingsScreen } from './screens/settings.js';
import { scannerScreen } from './screens/scanner.js';
import { cropScreen } from './screens/crop.js';
import { adjustScreen } from './screens/adjust.js';
import { annotateScreen } from './screens/annotate.js';
import { textEditScreen } from './screens/textedit.js';
import { reviewScreen } from './screens/review.js';
applyTheme();
await initI18n();
rescheduleAll();
{
    const x = settingsX();
    document.documentElement.classList.toggle('hi-contrast', !!x.contrast);
    document.documentElement.classList.toggle('big-text', !!x.bigText);
    document.documentElement.classList.toggle('easy-read', !!x.dyslexia);
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (getSettings().theme === 'system')
    applyTheme(); });
initInstall();
register('onboarding', onboardingScreen);
register('home', homeScreen);
register('docs', libraryScreen);
register('folder', libraryScreen);
register('doc', detailScreen);
register('pages', pagesScreen);
register('rename', renameScreen);
register('merge', mergeScreen);
register('share', shareScreen);
register('ocr', ocrScreen);
register('tools', toolsScreen);
register('settings', settingsScreen);
register('scan', scannerScreen, { transient: true, modal: true });
register('crop', cropScreen, { transient: true, modal: true });
register('adjust', adjustScreen, { transient: true, modal: true });
register('review', reviewScreen, { transient: true });
register('annotate', annotateScreen, { modal: true });
register('textedit', textEditScreen);
register('texto', textScreen);
register('listas', listsScreen);
register('comparar', compareScreen);
register('estudio', studyScreen);
register('vida', lifeScreen);
register('privado', privateScreen);
register('avisos', remindersScreen);
register('gastos', expensesScreen);
register('inventario', inventoryScreen);
register('presentar', presentScreen, { modal: true });
register('preguntar', askScreen);
register('revisar', docReviewScreen);
register('hola', helloScreen, { transient: true });
register('lupa', magnifierScreen, { transient: true, modal: true });
// toque: sonido + vibración en botones, chips, interruptores y tarjetas
document.addEventListener('pointerdown', e => {
    const el = e.target?.closest('button, a, [role=button], .tap, .chip, input[type=checkbox], .switch, label.check-row, .tool-card, .doc-item');
    if (!el || el.disabled)
        return;
    feedback(el.matches('.switch, input[type=checkbox], [role=switch]') || el.closest('.switch, .seg') ? 'toggle' : 'tap');
}, { passive: true, capture: true });
// libera URLs de imágenes de la pantalla anterior
setBeforeRender(revokeAll);
initChrome(() => newScanSheet());
setAfterRender(r => { updateChrome(r.name); runTours(r.name); });
const root = document.getElementById('app');
// el primer inicio siempre muestra la bienvenida, aunque se abra con un enlace interno
if (!getSettings().onboardingDone)
    history.replaceState(null, '', location.pathname + location.search);
else if (/^#\/onboarding(?!.*again)/.test(location.hash))
    history.replaceState(null, '', location.pathname + location.search + '#/home');
start(root, { name: !getSettings().helloDone && !getSettings().onboardingDone ? 'hola' : getSettings().onboardingDone ? 'home' : 'onboarding', params: {} });
// novedades tras una actualización y búsqueda periódica de versiones nuevas (solo APK)
showChangelogIfUpdated();
setTimeout(() => maybeCheckUpdate(), 8000);
window.addEventListener('unhandledrejection', e => {
    console.error(e.reason);
    const msg = e.reason?.message;
    if (msg)
        toast(msg, 'error', 4000);
});
// en el APK los archivos ya van dentro de la app: no hace falta el service worker
if ('serviceWorker' in navigator && location.protocol !== 'file:' && !isNative) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').then(reg => {
            reg.addEventListener('updatefound', () => {
                const nw = reg.installing;
                nw?.addEventListener('statechange', () => {
                    if (nw.state === 'installed' && navigator.serviceWorker.controller)
                        toast('Nueva versión disponible: se aplicará al reabrir la app.', 'ok', 4500);
                });
            });
        }).catch(() => { });
    });
}
// «Abrir con ScanPro»: fotos y PDF que llegan desde otras apps (WhatsApp, galería…)
const takeShared = async () => {
    const br = globalThis.ScanProAndroid;
    if (!br?.takeShared)
        return;
    let list = [];
    try {
        list = JSON.parse(br.takeShared());
    }
    catch {
        return;
    }
    if (!list.length)
        return;
    const files = [], scanned = list.length > 0 && list.every(it => it.scanned);
    for (const it of list) {
        try {
            const b = await (await fetch(it.url)).blob();
            files.push(new File([b], it.name, { type: it.mime || b.type }));
        }
        catch { /* omitido */ }
    }
    if (!files.length)
        return;
    const hook = scanned ? takeToolHook() : null;
    if (hook) {
        hook(files);
        return;
    }
    const t = scanned ? takeScanTarget() : { target: null };
    await importFiles(files, t.target, false, false, scanned, t.mode);
};
globalThis.__scanproShared = () => { if (getSettings().onboardingDone)
    void takeShared(); };
setTimeout(() => { if (getSettings().onboardingDone)
    void takeShared(); }, 600);
