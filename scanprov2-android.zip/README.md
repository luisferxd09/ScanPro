# ScanPro para Android (APK nativo, sin Internet)

La app completa va **dentro del APK**: no abre ninguna página web, no necesita Netlify ni Wi‑Fi.
La cámara, los filtros, el PDF, el Word y el OCR en español funcionan sin conexión.

## Compilar el APK con GitHub (sin instalar nada)

1. Crea una cuenta en github.com y un repositorio nuevo **privado** (botón **New**). Nombre: `scanpro`.
2. En el repositorio vacío toca **uploading an existing file** y arrastra **todo el contenido** de esta carpeta
   (incluida la carpeta `.github`). Pulsa **Commit changes**.
3. Ve a la pestaña **Actions**. La compilación «Compilar APK» empieza sola y tarda unos 5–8 minutos.
4. Cuando aparezca el círculo verde ✓, entra en ella y descarga **ScanPro-apk** (abajo, en *Artifacts*).
   Es un .zip con `ScanPro.apk` dentro.
5. Pasa `ScanPro.apk` al teléfono, ábrelo y permite «Instalar apps desconocidas».

Si en *Actions* no aparece nada, es que la carpeta `.github` no se subió: en GitHub toca
**Add file › Create new file**, escribe el nombre `.github/workflows/build.yml` y pega el contenido de ese archivo.

## Compilar con Android Studio

Abre esta carpeta con Android Studio y usa **Build › Build APK(s)**.
Para incluir el OCR sin conexión, ejecuta antes `bash scripts/fetch-ocr.sh` (necesita Node y curl).

## Notas

- Las actualizaciones se instalan encima sin borrar tus documentos, porque todas se firman con la misma
  clave (`app/scanpro.jks`). Si desinstalas la app, sus documentos se borran: haz antes una copia de
  seguridad desde Ajustes.
- Esa clave sirve para uso personal. Para publicar en Google Play crea una clave propia y no la compartas.
- Los archivos exportados se guardan en **Descargas › ScanPro**.
- Requiere Android 7.0 o superior con «Android System WebView» actualizado desde Play Store.
- `web/scanpro-web.zip` es la app ya compilada. Para cambiarla se edita el proyecto web y se ejecuta `npm run android`.
