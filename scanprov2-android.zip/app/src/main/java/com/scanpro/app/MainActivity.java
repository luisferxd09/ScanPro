package com.scanpro.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.content.SharedPreferences;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.widget.FrameLayout;
import android.media.AudioManager;
import android.provider.OpenableColumns;
import android.database.Cursor;
import org.json.JSONObject;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;
import android.graphics.Bitmap;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.provider.ContactsContract;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.app.AlarmManager;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation;
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.common.model.DownloadConditions;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * ScanPro nativo: la app web va dentro del APK (assets/www) y se sirve desde
 * https://appassets.androidplatform.net, un origen seguro local. No usa Internet.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/index.html";
    private static final int REQ_CAMERA = 1, REQ_CAPTURE_PERM = 2, REQ_FILE = 3, REQ_CAPTURE = 4, REQ_STORAGE = 5, REQ_SCAN = 6, REQ_DICTATE = 7, REQ_AUTH = 8, REQ_NOTIF = 9;

    private WebView web;
    private WebViewAssetLoader assets;
    private PermissionRequest pendingPermission;
    private ValueCallback<Uri[]> fileCallback;
    private WebChromeClient.FileChooserParams fileParams;
    private Uri captureUri;

    // ---------- anuncios (AdMob) ----------
    private static final String AD_INTER = "ca-app-pub-8282937177814828/8938048441";
    private static final String AD_REWARD = "ca-app-pub-8282937177814828/1721903406";
    private static final String TEST_INTER = "ca-app-pub-3940256099942544/1033173712";   // IDs de prueba oficiales de Google
    private static final String TEST_REWARD = "ca-app-pub-3940256099942544/5224354917";
    private InterstitialAd inter;
    private RewardedAd rewarded;
    private boolean testAds, adsReady;

    private boolean loadingInter, loadingReward;
    private String interErr = "cargando", rewardErr = "cargando";
    private String pendingKind, pendingCb;
    private final android.os.Handler adHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable pendingTimeout = () -> { if (pendingCb != null) { String cb = pendingCb; pendingKind = null; pendingCb = null; adResult(cb, "none"); } };

    // ---------- estado VIP / permisos ----------
    private static final String VIP_SUB_ID = "scanpro_vip_monthly"; // suscripción futura; no se usa todavía
    private String vipTier = "free";
    private long vipUntil = 0;

    private void loadAds() {
        if (!adsReady || isVipEquivalent()) return;
        AdRequest req = new AdRequest.Builder().build();
        if (inter == null && !loadingInter) { loadingInter = true; InterstitialAd.load(this, testAds ? TEST_INTER : AD_INTER, req, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) { loadingInter = false; inter = ad; interErr = "listo"; if ("interstitial".equals(pendingKind)) { String cb = pendingCb; pendingKind = null; pendingCb = null; adHandler.removeCallbacks(pendingTimeout); showAd("interstitial", cb); } }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { loadingInter = false; inter = null; interErr = e.getCode() + " " + e.getMessage(); if ("interstitial".equals(pendingKind)) pendingTimeout.run(); adHandler.postDelayed(MainActivity.this::loadAds, 30000); }
        }); }
        if (rewarded == null && !loadingReward) { loadingReward = true; RewardedAd.load(this, testAds ? TEST_REWARD : AD_REWARD, req, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull RewardedAd ad) { loadingReward = false; rewarded = ad; rewardErr = "listo"; if ("rewarded".equals(pendingKind)) { String cb = pendingCb; pendingKind = null; pendingCb = null; adHandler.removeCallbacks(pendingTimeout); showAd("rewarded", cb); } }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { loadingReward = false; rewarded = null; rewardErr = e.getCode() + " " + e.getMessage(); if ("rewarded".equals(pendingKind)) pendingTimeout.run(); adHandler.postDelayed(MainActivity.this::loadAds, 30000); }
        }); }
    }
    /** Si el anuncio aún no está cargado, espera hasta 8 s a que llegue antes de rendirse. */
    private void waitForAd(String kind, String cb) {
        if (pendingCb != null) adResult(pendingCb, "none");
        pendingKind = kind; pendingCb = cb;
        adHandler.removeCallbacks(pendingTimeout); adHandler.postDelayed(pendingTimeout, 8000);
        loadAds();
    }

    private void adResult(String cb, String r) {
        final String id = cb == null ? "" : cb.replaceAll("[^A-Za-z0-9]", "");
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproAd&&__scanproAd('" + id + "','" + r + "')", null); });
    }

    private void showAd(String kind, String cb) {
        if (isVipEquivalent()) { adResult(cb, "none"); return; }
        if ("rewarded".equals(kind)) {
            RewardedAd ad = rewarded;
            if (ad == null) { waitForAd(kind, cb); return; }
            rewarded = null;
            final boolean[] earned = {false};
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { adResult(cb, earned[0] ? "rewarded" : "closed"); loadAds(); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { adResult(cb, "none"); loadAds(); }
            });
            ad.show(this, item -> earned[0] = true);
        } else {
            InterstitialAd ad = inter;
            if (ad == null) { waitForAd("interstitial", cb); return; }
            inter = null;
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { adResult(cb, "closed"); loadAds(); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { adResult(cb, "none"); loadAds(); }
            });
            ad.show(this);
        }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        clearDir(new File(getCacheDir(), "share"));

        final WebViewAssetLoader.AssetsPathHandler files = new WebViewAssetLoader.AssetsPathHandler(this);
        assets = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/shared/", new WebViewAssetLoader.InternalStoragePathHandler(this, new File(getCacheDir(), "shared")))
                .addPathHandler("/", path -> files.handle("www/" + (path.isEmpty() ? "index.html" : path)))
                .build();

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);

        // de borde a borde (obligatorio desde Android 15): la app se aparta de las barras y del teclado
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        root = new FrameLayout(this);
        root.setBackgroundColor(isNight() ? 0xFF0F0E17 : 0xFFF3F1F8);
        web = new WebView(this);
        web.setBackgroundColor(isNight() ? 0xFF0F0E17 : 0xFFF3F1F8);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, ins) -> {
            Insets b = ins.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        bars(isNight());

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        // respeta el tamaño de letra del teléfono (con un tope para no romper el diseño)
        s.setTextZoom(Math.round(Math.max(.85f, Math.min(1.3f, getResources().getConfiguration().fontScale)) * 100));
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "ScanProAndroid");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        setContentView(root);

        // botón Atrás (gesto predictivo de Android 13+)
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::goBack);

        if (saved == null || web.restoreState(saved) == null) web.loadUrl(START);
        handleShared(getIntent());

        SharedPreferences prefs = getSharedPreferences("scanpro", MODE_PRIVATE);
        testAds = prefs.getBoolean("testAds", false);
        pro = prefs.getBoolean("pro", false);
        loadVipState(prefs);
        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(() -> { adsReady = true; loadAds(); }))).start();
        startBilling();
    }

    private FrameLayout root;
    private void goBack() { if (web != null && web.canGoBack()) web.goBack(); else finish(); }
    private void bars(boolean dark) {
        WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(!dark); c.setAppearanceLightNavigationBars(!dark);
    }

    // ---------- «Abrir con ScanPro»: fotos y PDF recibidos de otras apps ----------
    private final JSONArray shared = new JSONArray();
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); handleShared(i); }
    private void handleShared(Intent i) {
        if (i == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        String a = i.getAction();
        if (Intent.ACTION_SEND.equals(a)) { Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM); if (u != null) uris.add(u); }
        else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) { ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if (l != null) uris.addAll(l); }
        else if (Intent.ACTION_VIEW.equals(a) && i.getData() != null) uris.add(i.getData());
        if (uris.isEmpty()) return;
        importUris(uris, false);
        setIntent(new Intent());
    }

    /** Copia archivos a cache/shared y avisa a la web para importarlos. scanned: páginas ya recortadas por el escáner de Google. */
    private void importUris(final java.util.List<Uri> list, final boolean scanned) {
        new Thread(() -> {
            File dir = new File(getCacheDir(), "shared"); //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            int n = 0;
            for (Uri u : list) {
                try {
                    n++;
                    String name = scanned ? "Escaneo " + n + ".jpg" : "archivo", mime = scanned ? "image/jpeg" : getContentResolver().getType(u);
                    if (!scanned) try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) { if (c != null && c.moveToFirst()) name = c.getString(0); } catch (Exception ignored) { }
                    String fn = System.currentTimeMillis() + "_" + n + "_" + safeName(name);
                    try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(new File(dir, fn))) { if (in != null) copy(in, out); }
                    JSONObject o = new JSONObject(); o.put("url", "/shared/" + fn); o.put("name", name); o.put("mime", mime == null ? "" : mime); o.put("scanned", scanned);
                    synchronized (shared) { shared.put(o); }
                } catch (Exception ignored) { }
            }
            runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproShared&&__scanproShared()", null); });
        }).start();
    }

    // ---------- escáner de documentos de Google (ML Kit): enfoque, bordes y recorte nativos ----------
    private void scanEvent(String r) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproScan&&__scanproScan(" + JSONObject.quote(r) + ")", null); }); }
    private void startScan(int limit) {
        try {
            GmsDocumentScannerOptions.Builder b = new GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL);
            if (limit > 0) b.setPageLimit(limit);
            GmsDocumentScanner scanner = GmsDocumentScanning.getClient(b.build());
            scanner.getStartScanIntent(this)
                .addOnSuccessListener(sender -> { try { startIntentSenderForResult(sender, REQ_SCAN, null, 0, 0, 0); } catch (Exception e) { scanEvent("error:" + e.getMessage()); } })
                .addOnFailureListener(e -> scanEvent("error:" + e.getMessage()));
        } catch (Throwable e) { scanEvent("error:" + e.getMessage()); }
    }

    /** Convierte una imagen que la web no sabe leer (HEIC, AVIF, DNG…) a JPEG con los decodificadores de Android. */
    private String convertToJpeg(File src) {
        try {
            Bitmap bmp;
            final int MAX = 4096;
            if (Build.VERSION.SDK_INT >= 28) {
                bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(src), (dec, info, s) -> {
                    int w = info.getSize().getWidth(), h = info.getSize().getHeight(), m = Math.max(w, h);
                    if (m > MAX) dec.setTargetSize(Math.round(w * (float) MAX / m), Math.round(h * (float) MAX / m));
                    dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                });
            } else {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(src.getPath(), o);
                int ss = 1; while (Math.max(o.outWidth, o.outHeight) / ss > MAX) ss *= 2;
                o = new BitmapFactory.Options(); o.inSampleSize = ss; bmp = BitmapFactory.decodeFile(src.getPath(), o);
            }
            if (bmp == null) return "error:formato no compatible";
            File dir = new File(getCacheDir(), "shared"); //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            String fn = "conv_" + System.currentTimeMillis() + ".jpg";
            try (OutputStream out = new FileOutputStream(new File(dir, fn))) { bmp.compress(Bitmap.CompressFormat.JPEG, 93, out); }
            bmp.recycle();
            return "/shared/" + fn;
        } catch (Throwable e) { return "error:" + e.getMessage(); }
        finally { //noinspection ResultOfMethodCallIgnored
            src.delete(); }
    }

    // ---------- herramientas nativas: códigos, traducción, voz, dictado, contactos, impresión, huella, avisos, fondo ----------
    private void jsCall(String fn, String cb, String result) {
        final String id = cb == null ? "" : cb.replaceAll("[^A-Za-z0-9]", "");
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window." + fn + "&&" + fn + "('" + id + "'," + JSONObject.quote(result == null ? "" : result) + ")", null); });
    }
    private void scanCode(String cb) {
        try {
            GmsBarcodeScanner sc = GmsBarcodeScanning.getClient(this);
            sc.startScan()
                .addOnSuccessListener(b -> { try { JSONObject o = new JSONObject(); o.put("raw", b.getRawValue()); o.put("type", b.getValueType()); o.put("format", b.getFormat()); jsCall("__scanproCb", cb, "ok:" + o); } catch (Exception e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); } })
                .addOnCanceledListener(() -> jsCall("__scanproCb", cb, "cancel"))
                .addOnFailureListener(e -> jsCall("__scanproCb", cb, "error:" + e.getMessage()));
        } catch (Throwable e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); }
    }
    private void translate(String text, String from, String to, String cb) {
        try {
            String f = TranslateLanguage.fromLanguageTag(from), t = TranslateLanguage.fromLanguageTag(to);
            if (f == null || t == null) { jsCall("__scanproCb", cb, "error:idioma no disponible"); return; }
            final Translator tr = Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(f).setTargetLanguage(t).build());
            tr.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> {
                    final String[] parts = text.split("\n");
                    final String[] out = new String[parts.length];
                    final int[] left = { parts.length };
                    if (parts.length == 0) { jsCall("__scanproCb", cb, "ok:"); tr.close(); return; }
                    for (int k = 0; k < parts.length; k++) {
                        final int idx = k;
                        if (parts[k].trim().isEmpty()) { out[idx] = parts[k]; if (--left[0] == 0) { jsCall("__scanproCb", cb, "ok:" + String.join("\n", out)); tr.close(); } continue; }
                        tr.translate(parts[k]).addOnCompleteListener(task -> {
                            out[idx] = task.isSuccessful() ? task.getResult() : parts[idx];
                            if (--left[0] == 0) { jsCall("__scanproCb", cb, "ok:" + String.join("\n", out)); tr.close(); }
                        });
                    }
                })
                .addOnFailureListener(e -> { jsCall("__scanproCb", cb, "error:Se necesita internet la primera vez para descargar el idioma. " + e.getMessage()); tr.close(); });
        } catch (Throwable e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); }
    }
    private TextToSpeech tts;
    private void speak(String text, String lang) {
        if (tts == null) {
            tts = new TextToSpeech(this, st -> { if (st == TextToSpeech.SUCCESS) speak(text, lang); });
            return;
        }
        tts.setLanguage(java.util.Locale.forLanguageTag(lang == null || lang.isEmpty() ? "es-CO" : lang));
        tts.stop();
        String[] chunks = text.split("(?<=[.!?\n])");
        for (int k = 0; k < chunks.length; k++) if (!chunks[k].trim().isEmpty()) tts.speak(chunks[k], TextToSpeech.QUEUE_ADD, null, "s" + k);
    }
    private String dictateCb;
    private void dictate(String cb, String lang) {
        dictateCb = cb;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang == null || lang.isEmpty() ? java.util.Locale.getDefault().toLanguageTag() : lang);
        try { startActivityForResult(i, REQ_DICTATE); } catch (Exception e) { dictateCb = null; jsCall("__scanproCb", cb, "error:nodictation"); }
    }
    private void addContact(String json) {
        try {
            JSONObject o = new JSONObject(json);
            Intent i = new Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE);
            if (o.has("name")) i.putExtra(ContactsContract.Intents.Insert.NAME, o.getString("name"));
            if (o.has("phone")) i.putExtra(ContactsContract.Intents.Insert.PHONE, o.getString("phone"));
            if (o.has("email")) i.putExtra(ContactsContract.Intents.Insert.EMAIL, o.getString("email"));
            if (o.has("company")) i.putExtra(ContactsContract.Intents.Insert.COMPANY, o.getString("company"));
            if (o.has("title")) i.putExtra(ContactsContract.Intents.Insert.JOB_TITLE, o.getString("title"));
            if (o.has("notes")) i.putExtra(ContactsContract.Intents.Insert.NOTES, o.getString("notes"));
            startActivity(i);
        } catch (Exception ignored) { }
    }
    private void printPdf(final File f, final String name) {
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        pm.print(name, new PrintDocumentAdapter() {
            @Override public void onLayout(PrintAttributes o, PrintAttributes n, CancellationSignal c, LayoutResultCallback cb, Bundle e) {
                if (c.isCanceled()) { cb.onLayoutCancelled(); return; }
                cb.onLayoutFinished(new PrintDocumentInfo.Builder(name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true);
            }
            @Override public void onWrite(android.print.PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal c, WriteResultCallback cb) {
                try (InputStream in = new FileInputStream(f); OutputStream out = new FileOutputStream(dest.getFileDescriptor())) { copy(in, out); cb.onWriteFinished(new android.print.PageRange[]{ android.print.PageRange.ALL_PAGES }); }
                catch (Exception e) { cb.onWriteFailed(e.getMessage()); }
            }
        }, null);
    }
    private String authCb;
    private void authenticate(String cb, String title) {
        authCb = cb;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                android.hardware.biometrics.BiometricPrompt bp = new android.hardware.biometrics.BiometricPrompt.Builder(this).setTitle(title)
                    .setAllowedAuthenticators(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK | android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL).build();
                bp.authenticate(new CancellationSignal(), getMainExecutor(), authCallback());
                return;
            }
            if (Build.VERSION.SDK_INT >= 29) {
                android.hardware.biometrics.BiometricPrompt bp = new android.hardware.biometrics.BiometricPrompt.Builder(this).setTitle(title).setDeviceCredentialAllowed(true).build();
                bp.authenticate(new CancellationSignal(), getMainExecutor(), authCallback());
                return;
            }
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km == null || !km.isKeyguardSecure()) { jsCall("__scanproCb", cb, "nolock"); authCb = null; return; }
            Intent i = km.createConfirmDeviceCredentialIntent(title, null);
            if (i == null) { jsCall("__scanproCb", cb, "nolock"); authCb = null; return; }
            startActivityForResult(i, REQ_AUTH);
        } catch (Throwable e) { jsCall("__scanproCb", cb, "nolock"); authCb = null; }
    }
    private android.hardware.biometrics.BiometricPrompt.AuthenticationCallback authCallback() {
        return new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r) { if (authCb != null) jsCall("__scanproCb", authCb, "ok"); authCb = null; }
            @Override public void onAuthenticationError(int code, CharSequence msg) {
                // sin bloqueo de pantalla configurado: se deja pasar avisando
                if (authCb != null) jsCall("__scanproCb", authCb, code == android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT || code == 14 /* NO_DEVICE_CREDENTIAL */ || code == android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS ? "nolock" : "cancel");
                authCb = null;
            }
        };
    }
    /** Aviso programado (vencimientos y medicamentos). repeatMs = 0: una sola vez. */
    private void schedule(int id, long at, long repeatMs, String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        Intent i = new Intent(this, ReminderReceiver.class).putExtra("id", id).putExtra("title", title).putExtra("text", text);
        PendingIntent pi = PendingIntent.getBroadcast(this, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (am == null) return;
        if (repeatMs > 0) am.setInexactRepeating(AlarmManager.RTC_WAKEUP, at, repeatMs, pi); else am.set(AlarmManager.RTC_WAKEUP, at, pi);
    }
    private void unschedule(int id) {
        PendingIntent pi = PendingIntent.getBroadcast(this, id, new Intent(this, ReminderReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (am != null) am.cancel(pi);
    }
    /** Quita el fondo de una foto (ML Kit, en el teléfono). Devuelve un PNG con transparencia en /shared/. */
    private void removeBg(File src, String cb) {
        try {
            Bitmap bmp;
            if (Build.VERSION.SDK_INT >= 28) bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(src), (d, info, s2) -> { int m = Math.max(info.getSize().getWidth(), info.getSize().getHeight()); if (m > 2048) d.setTargetSize(info.getSize().getWidth() * 2048 / m, info.getSize().getHeight() * 2048 / m); d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE); });
            else { BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = 2; bmp = BitmapFactory.decodeFile(src.getPath(), o); }
            final Bitmap in = bmp.copy(Bitmap.Config.ARGB_8888, false);
            SubjectSegmentation.getClient(new SubjectSegmenterOptions.Builder().enableForegroundBitmap().build())
                .process(InputImage.fromBitmap(in, 0))
                .addOnSuccessListener(r -> {
                    try {
                        Bitmap fg = r.getForegroundBitmap();
                        if (fg == null) { jsCall("__scanproCb", cb, "error:No se encontró un objeto o persona en la foto."); return; }
                        File dir = new File(getCacheDir(), "shared"); //noinspection ResultOfMethodCallIgnored
                        dir.mkdirs();
                        String fn = "sinfondo_" + System.currentTimeMillis() + ".png";
                        try (OutputStream out = new FileOutputStream(new File(dir, fn))) { fg.compress(Bitmap.CompressFormat.PNG, 100, out); }
                        jsCall("__scanproCb", cb, "ok:/shared/" + fn);
                    } catch (Exception e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); }
                })
                .addOnFailureListener(e -> jsCall("__scanproCb", cb, "error:El modelo se está descargando (necesita internet la primera vez). Intenta en un minuto. " + e.getMessage()));
        } catch (Throwable e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); }
        finally { //noinspection ResultOfMethodCallIgnored
            src.delete(); }
    }

    // ---------- ScanPro Pro legado y VIP ----------
    private static final String PRO_ID = "scanpro_pro";
    private BillingClient billing;
    private boolean pro;

    private void loadVipState(SharedPreferences prefs) {
        vipTier = prefs.getString("vipTier", pro ? "legacy_pro_local" : "free");
        vipUntil = prefs.getLong("vipUntil", 0);
        if (vipUntil > 0 && System.currentTimeMillis() >= vipUntil) {
            vipTier = "free";
            vipUntil = 0;
        }
    }

    private void setPro(boolean v) {
        pro = v; getSharedPreferences("scanpro", MODE_PRIVATE).edit().putBoolean("pro", v).apply();
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproPro&&__scanproPro(" + v + ")", null); });
    }

    private void setVipTier(String tier, long until) {
        vipTier = tier;
        vipUntil = until;
        getSharedPreferences("scanpro", MODE_PRIVATE).edit()
            .putString("vipTier", tier)
            .putLong("vipUntil", until)
            .apply();
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproVip&&__scanproVip(" + JSONObject.quote(tier) + "," + until + ",'')", null); });
    }

    /** true si el usuario tiene derecho a beneficios VIP (Pro legado, suscripción o recompensa activa). */
    private boolean isVipEquivalent() {
        if ("free".equals(vipTier)) return false;
        if (vipUntil > 0 && System.currentTimeMillis() >= vipUntil) return false;
        return true;
    }

    private boolean hasProPurchase(java.util.List<Purchase> list) {
        if (list == null) return false;
        for (Purchase p : list) if (p.getProducts().contains(PRO_ID) && p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) return true;
        return false;
    }

    private void handlePurchases(java.util.List<Purchase> list) {
        if (hasProPurchase(list)) {
            setPro(true);
            setVipTier("legacy_pro_verified", 0);
            for (Purchase p : list) if (p.getProducts().contains(PRO_ID) && !p.isAcknowledged())
                billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(), r -> { });
        }
    }

    private void startBilling() {
        try {
            billing = BillingClient.newBuilder(this).setListener((r, list) -> { if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) handlePurchases(list); })
                    .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).build();
            billing.startConnection(new BillingClientStateListener() {
                @Override public void onBillingSetupFinished(@NonNull BillingResult r) {
                    if (r.getResponseCode() == BillingClient.BillingResponseCode.OK)
                        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(), (r2, list) -> {
                            if (r2.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                                handlePurchases(list);
                                if (!hasProPurchase(list) && "legacy_pro_local".equals(vipTier)) {
                                    // Play Billing estuvo disponible y no encontró la compra:
                                    // el indicador local no está verificado, se revierte a gratuito.
                                    setPro(false);
                                    setVipTier("free", 0);
                                }
                            }
                        });
                }
                @Override public void onBillingServiceDisconnected() { }
            });
        } catch (Exception ignored) { billing = null; }
    }

    private String buyPro() {
        if (billing == null || !billing.isReady()) return "error:Las compras solo funcionan con la app instalada desde Google Play.";
        java.util.List<QueryProductDetailsParams.Product> prods = java.util.Collections.singletonList(QueryProductDetailsParams.Product.newBuilder().setProductId(PRO_ID).setProductType(BillingClient.ProductType.INAPP).build());
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(prods).build(), (r, details) -> {
            if (details == null || details.isEmpty()) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__scanproPro&&__scanproPro(false,'ScanPro Pro aún no está disponible en Google Play.')", null); }); return; }
            ProductDetails d = details.get(0);
            BillingFlowParams f = BillingFlowParams.newBuilder().setProductDetailsParamsList(java.util.Collections.singletonList(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build())).build();
            runOnUiThread(() -> billing.launchBillingFlow(MainActivity.this, f));
        });
        return "ok";
    }

    private String buyVip() {
        // Las suscripciones VIP son una integración futura. No se activan cobros todavía.
        return "error:Las suscripciones VIP aún no están activas. Se habilitarán cuando ScanPro esté disponible en Google Play.";
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    @Override protected void onSaveInstanceState(@NonNull Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }
    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        // Re-verificar compras al volver a primer plano, sin exceso de frecuencia.
        if (billing != null && billing.isReady()) {
            billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(), (r, list) -> {
                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    handlePurchases(list);
                    if (!hasProPurchase(list) && "legacy_pro_local".equals(vipTier)) {
                        setPro(false);
                        setVipTier("free", 0);
                    }
                }
            });
        }
    }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() { goBack(); }

    private boolean hasCamera() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------- carga de la app local ----------
    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            return assets.shouldInterceptRequest(req.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
            return true; // los enlaces externos se abren fuera de la app
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // en teléfonos con poca memoria Android puede cerrar el motor web: se reinicia la pantalla
            if (web != null) { web.destroy(); web = null; }
            recreate();
            return true;
        }
    }

    // ---------- cámara y selector de archivos ----------
    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> {
                boolean wantsVideo = false;
                for (String r : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsVideo = true;
                if (!wantsVideo) { req.deny(); return; }
                if (hasCamera()) { req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); return; }
                if (pendingPermission != null) pendingPermission.deny();
                pendingPermission = req;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            fileParams = params;
            if (params.isCaptureEnabled() && wantsImages(params)) {
                if (hasCamera()) launchCapture();
                else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAPTURE_PERM);
            } else {
                launchPicker();
            }
            return true;
        }
    }

    private static boolean wantsImages(WebChromeClient.FileChooserParams p) {
        for (String t : p.getAcceptTypes()) for (String x : t.split(",")) if (x.trim().startsWith("image/")) return true;
        return false;
    }

    private void launchCapture() {
        try {
            File dir = new File(getCacheDir(), "captures");
            clearDir(dir);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File f = new File(dir, "foto-" + System.currentTimeMillis() + ".jpg");
            captureUri = FileProvider.getUriForFile(this, "com.scanpro.app.files", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, captureUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAPTURE);
        } catch (Exception e) {
            launchPicker();
        }
    }

    private void launchPicker() {
        ArrayList<String> mimes = new ArrayList<>();
        if (fileParams != null) for (String t : fileParams.getAcceptTypes()) for (String raw : t.split(",")) {
            String x = raw.trim().toLowerCase();
            if (x.isEmpty()) continue;
            if (x.startsWith(".")) {
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(x.substring(1));
                if (m == null && x.equals(".json")) m = "application/json";
                if (m != null) mimes.add(m);
                mimes.add("application/octet-stream");
            } else mimes.add(x);
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (mimes.size() == 1) i.setType(mimes.get(0));
        else {
            i.setType("*/*");
            if (!mimes.isEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
        }
        if (fileParams != null && fileParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_FILE); }
        catch (ActivityNotFoundException e) { finishChooser(null); }
    }

    private void finishChooser(Uri[] result) {
        if (fileCallback != null) fileCallback.onReceiveValue(result);
        fileCallback = null;
        fileParams = null;
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_DICTATE) {
            String cb = dictateCb; dictateCb = null;
            ArrayList<String> r = result == RESULT_OK && data != null ? data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) : null;
            if (cb != null) jsCall("__scanproCb", cb, r != null && !r.isEmpty() ? "ok:" + r.get(0) : "cancel");
            return;
        }
        if (code == REQ_AUTH) { if (authCb != null) jsCall("__scanproCb", authCb, result == RESULT_OK ? "ok" : "cancel"); authCb = null; return; }
        if (code == REQ_SCAN) {
            if (result != RESULT_OK) { scanEvent("cancel"); return; }
            GmsDocumentScanningResult r = GmsDocumentScanningResult.fromActivityResultIntent(data);
            ArrayList<Uri> uris = new ArrayList<>();
            if (r != null && r.getPages() != null) for (GmsDocumentScanningResult.Page pg : r.getPages()) uris.add(pg.getImageUri());
            if (uris.isEmpty()) { scanEvent("cancel"); return; }
            scanEvent("ok:" + uris.size());
            importUris(uris, true);
        } else if (code == REQ_CAPTURE) {
            finishChooser(result == RESULT_OK && captureUri != null ? new Uri[]{captureUri} : null);
        } else if (code == REQ_FILE) {
            Uri[] out = null;
            if (result == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    out = new Uri[clip.getItemCount()];
                    for (int k = 0; k < out.length; k++) out[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            finishChooser(out);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (code == REQ_CAMERA && pendingPermission != null) {
            if (ok) pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingPermission.deny();
            pendingPermission = null;
        } else if (code == REQ_CAPTURE_PERM) {
            if (ok) launchCapture(); else launchPicker();
        }
    }

    // ---------- puente con la app web: guardar y compartir archivos ----------
    private static final class Staged {
        final File file; final String name; final String mime; OutputStream out;
        Staged(File f, String n, String m, OutputStream o) { file = f; name = n; mime = m; out = o; }
    }

    private final Map<String, Staged> staged = new HashMap<>();
    private volatile String sharePkg, shareEmail;

    private static String safeName(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        return s.isEmpty() ? "archivo" : s;
    }

    private Staged take(String token) throws IOException {
        Staged st;
        synchronized (staged) { st = staged.remove(token); }
        if (st == null) throw new IOException("Archivo no preparado");
        if (st.out != null) { st.out.close(); st.out = null; }
        return st;
    }

    // ---------- actualizaciones: revisa GitHub Releases del repositorio público ----------
    private static final String UPDATE_REPO = "luisferxd09/ScanPro";
    private volatile long updateId = -1;
    private BroadcastReceiver updateRx;

    private String currentVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "0"; }
    }
    private static int vNum(String s) { try { return Integer.parseInt(s.replaceAll("[^0-9]", "")); } catch (Exception e) { return 0; } }
    private static int compareVersions(String a, String b) {
        String[] pa = a.split("\\."), pb = b.split("\\.");
        for (int i = 0; i < Math.max(pa.length, pb.length); i++) {
            int d = vNum(i < pa.length ? pa[i] : "0") - vNum(i < pb.length ? pb[i] : "0");
            if (d != 0) return d;
        }
        return 0;
    }
    /** Compara la versión instalada con el último release público. Devuelve JSON (bloquea: se llama desde el hilo del puente JS). */
    private String checkUpdate() {
        JSONObject out = new JSONObject();
        try {
            String cur = currentVersion();
            out.put("current", cur);
            HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + UPDATE_REPO + "/releases/latest").openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("Accept", "application/vnd.github+json");
            InputStream in = c.getResponseCode() == 200 ? c.getInputStream() : null;
            if (in == null) { out.put("available", false); out.put("error", "HTTP " + c.getResponseCode()); return out.toString(); }
            StringBuilder b = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String l;
            while ((l = r.readLine()) != null) b.append(l);
            r.close();
            JSONObject rel = new JSONObject(b.toString());
            JSONArray assets = rel.optJSONArray("assets");
            String url = "";
            if (assets != null) for (int i = 0; i < assets.length(); i++) {
                JSONObject a = assets.getJSONObject(i);
                if (a.optString("name", "").endsWith(".apk")) { url = a.optString("browser_download_url"); break; }
            }
            String tag = rel.optString("tag_name", "").replaceFirst("^[vV]", "");
            out.put("version", tag);
            out.put("notes", rel.optString("body", ""));
            out.put("url", url);
            out.put("available", !tag.isEmpty() && !url.isEmpty() && compareVersions(tag, cur) > 0);
        } catch (Throwable e) {
            try { out.put("available", false); out.put("error", String.valueOf(e.getMessage())); } catch (Throwable ignored) {}
        }
        return out.toString();
    }
    /** Descarga el APK con DownloadManager; al terminar se abre solo el instalador del sistema. */
    private void startUpdateDownload(String url) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
            rq.setTitle("ScanPro · actualización");
            rq.setDescription("Nueva versión de ScanPro");
            rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            rq.setMimeType("application/vnd.android.package-archive");
            updateId = dm.enqueue(rq);
            if (updateRx == null) {
                updateRx = new BroadcastReceiver() {
                    @Override public void onReceive(Context ctx, Intent i) {
                        long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                        if (id != -1 && id == updateId) openUpdate(id);
                    }
                };
                ContextCompat.registerReceiver(this, updateRx, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED);
            }
        } catch (Throwable ignored) { /* sin red o URL inválida */ }
    }
    private void openUpdate(long id) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri uri = dm.getUriForDownloadedFile(id);
            if (uri == null) return;
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignored) { /* el usuario puede abrir el APK desde la notificación */ }
    }

    private class Bridge {
        @JavascriptInterface public String version() { return currentVersion(); }
        @JavascriptInterface public String checkUpdate() { return MainActivity.this.checkUpdate(); }
        @JavascriptInterface public void startUpdateDownload(String url) { MainActivity.this.startUpdateDownload(url); }

        @JavascriptInterface public void showAd(String kind, String cb) { runOnUiThread(() -> MainActivity.this.showAd(kind, cb)); }

        @JavascriptInterface public void setTestAds(boolean on) {
            getSharedPreferences("scanpro", MODE_PRIVATE).edit().putBoolean("testAds", on).apply();
            runOnUiThread(() -> { testAds = on; inter = null; rewarded = null; loadingInter = false; loadingReward = false; loadAds(); });
        }

        @JavascriptInterface
        public String begin(String name, String mime) {
            try {
                String token = UUID.randomUUID().toString();
                File dir = new File(new File(getCacheDir(), "share"), token);
                if (!dir.mkdirs()) return "";
                File f = new File(dir, safeName(name));
                Staged st = new Staged(f, f.getName(), mime == null || mime.isEmpty() ? "application/octet-stream" : mime.split(";")[0], new FileOutputStream(f));
                synchronized (staged) { staged.put(token, st); }
                return token;
            } catch (IOException e) { return ""; }
        }

        @JavascriptInterface
        public boolean append(String token, String b64) {
            Staged st;
            synchronized (staged) { st = staged.get(token); }
            if (st == null || st.out == null) return false;
            try { st.out.write(Base64.decode(b64, Base64.DEFAULT)); return true; }
            catch (IOException | IllegalArgumentException e) { return false; }
        }

        @JavascriptInterface
        public String save(String token) {
            try {
                Staged st = take(token);
                String where = saveToDownloads(st);
                //noinspection ResultOfMethodCallIgnored
                st.file.delete();
                return where.startsWith("error:") ? where : "ok:" + where;
            } catch (Exception e) {
                return "error:No se pudo guardar el archivo (" + e.getMessage() + ").";
            }
        }

        @JavascriptInterface
        public String share(String tokensJson, String title) {
            try {
                JSONArray arr = new JSONArray(tokensJson);
                final ArrayList<Uri> uris = new ArrayList<>();
                String mime = null;
                for (int k = 0; k < arr.length(); k++) {
                    Staged st = take(arr.getString(k));
                    uris.add(FileProvider.getUriForFile(MainActivity.this, "com.scanpro.app.files", st.file));
                    mime = mime == null || mime.equals(st.mime) ? st.mime : "*/*";
                }
                if (uris.isEmpty()) return "error";
                final Intent i = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
                i.setType(mime);
                if (uris.size() == 1) i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                ClipData clip = ClipData.newRawUri(title, uris.get(0));
                for (int k = 1; k < uris.size(); k++) clip.addItem(new ClipData.Item(uris.get(k)));
                i.setClipData(clip);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                final String t = title;
                final String pkg = sharePkg;
                if (shareEmail != null) { i.putExtra(Intent.EXTRA_EMAIL, new String[]{shareEmail}); i.putExtra(Intent.EXTRA_SUBJECT, title); }
                runOnUiThread(() -> {
                    if (pkg != null) { Intent d = new Intent(i).setPackage(pkg); try { startActivity(d); return; } catch (ActivityNotFoundException ignored) { } }
                    startActivity(Intent.createChooser(i, t));
                });
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public String shareText(String text, String title) {
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            runOnUiThread(() -> startActivity(Intent.createChooser(i, title)));
            return "ok";
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean dark) {
            runOnUiThread(() -> { try { int c = Color.parseColor(color); if (root != null) root.setBackgroundColor(c); if (web != null) web.setBackgroundColor(c); bars(dark); } catch (IllegalArgumentException ignored) { } });
        }

        @JavascriptInterface public boolean silent() { AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE); return am != null && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL; }

        @JavascriptInterface public String takeShared() { synchronized (shared) { String r = shared.toString(); while (shared.length() > 0) shared.remove(0); return r; } }

        @JavascriptInterface public boolean isPro() { return isVipEquivalent(); }
        @JavascriptInterface public boolean isVip() { return isVipEquivalent(); }
        @JavascriptInterface public String tier() { return vipTier; }
        @JavascriptInterface public long vipUntil() { return vipUntil; }
        @JavascriptInterface public String vipFeature() { return ""; }
        @JavascriptInterface public void haptic(String kind) {
            runOnUiThread(() -> { if (web == null) return;
                int c = "success".equals(kind) && Build.VERSION.SDK_INT >= 30 ? android.view.HapticFeedbackConstants.CONFIRM
                    : "error".equals(kind) && Build.VERSION.SDK_INT >= 30 ? android.view.HapticFeedbackConstants.REJECT
                    : "medium".equals(kind) ? android.view.HapticFeedbackConstants.VIRTUAL_KEY
                    : Build.VERSION.SDK_INT >= 27 ? android.view.HapticFeedbackConstants.KEYBOARD_TAP : android.view.HapticFeedbackConstants.VIRTUAL_KEY;
                web.performHapticFeedback(c); });
        }
        @JavascriptInterface public void scanCode(String cb) { runOnUiThread(() -> MainActivity.this.scanCode(cb)); }
        @JavascriptInterface public void translate(String text, String from, String to, String cb) { runOnUiThread(() -> MainActivity.this.translate(text, from, to, cb)); }
        @JavascriptInterface public void speak(String text, String lang) { runOnUiThread(() -> MainActivity.this.speak(text, lang)); }
        @JavascriptInterface public void stopSpeak() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void dictate(String cb, String lang) { runOnUiThread(() -> MainActivity.this.dictate(cb, lang)); }
        @JavascriptInterface public void addContact(String json) { runOnUiThread(() -> MainActivity.this.addContact(json)); }
        @JavascriptInterface public String print(String token, String name) { try { final Staged st = take(token); runOnUiThread(() -> printPdf(st.file, name)); return "ok"; } catch (Exception e) { return "error:" + e.getMessage(); } }
        @JavascriptInterface public void authenticate(String cb, String title) { runOnUiThread(() -> MainActivity.this.authenticate(cb, title)); }
        @JavascriptInterface public void schedule(int id, double at, double repeatMs, String title, String text) { runOnUiThread(() -> MainActivity.this.schedule(id, (long) at, (long) repeatMs, title, text)); }
        @JavascriptInterface public void unschedule(int id) { runOnUiThread(() -> MainActivity.this.unschedule(id)); }
        @JavascriptInterface public void removeBg(String token, String cb) { try { final Staged st = take(token); new Thread(() -> MainActivity.this.removeBg(st.file, cb)).start(); } catch (Exception e) { jsCall("__scanproCb", cb, "error:" + e.getMessage()); } }
        @JavascriptInterface public String shareEmail(String tokensJson, String title, String to) { shareEmail = to; try { return share(tokensJson, title); } finally { shareEmail = null; } }
        @JavascriptInterface public void scanDocs(int limit) { runOnUiThread(() -> startScan(limit)); }
        @JavascriptInterface public String convertImage(String token) {
            try { Staged st = take(token); return convertToJpeg(st.file); } catch (Exception e) { return "error:" + e.getMessage(); }
        }
        @JavascriptInterface public String adStatus() { return (testAds ? "prueba" : "reales") + " · intersticial: " + interErr + " · recompensa: " + rewardErr; }
        @JavascriptInterface public String buyPro() { return MainActivity.this.buyPro(); }
        @JavascriptInterface public String buyVip() { return MainActivity.this.buyVip(); }

        @JavascriptInterface public void email(String to, String subject, String body) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to)));
            i.putExtra(Intent.EXTRA_SUBJECT, subject); i.putExtra(Intent.EXTRA_TEXT, body);
            runOnUiThread(() -> { try { startActivity(i); } catch (ActivityNotFoundException ignored) { } });
        }

        /** Comparte con una app concreta (p. ej. Google Drive); si no está instalada, abre el menú normal. */
        @JavascriptInterface public String shareTo(String tokensJson, String title, String pkg) { sharePkg = pkg; try { return share(tokensJson, title); } finally { sharePkg = null; } }
    }

    /** Copia a Descargas/ScanPro y devuelve el lugar en palabras sencillas. */
    private String saveToDownloads(Staged st) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, st.name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, st.mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ScanPro");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("sin acceso a Descargas");
            try (InputStream in = new FileInputStream(st.file); OutputStream out = cr.openOutputStream(uri)) {
                if (out == null) throw new IOException("sin acceso a Descargas");
                copy(in, out);
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, v, null, null);
            return "Descargas › ScanPro";
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
            return "error:Permite el acceso a los archivos y vuelve a tocar «Descargar».";
        }
        @SuppressWarnings("deprecation")
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ScanPro");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File dest = new File(dir, st.name);
        int dot = st.name.lastIndexOf('.');
        String base = dot > 0 ? st.name.substring(0, dot) : st.name, ext = dot > 0 ? st.name.substring(dot) : "";
        for (int n = 1; dest.exists(); n++) dest = new File(dir, base + " (" + n + ")" + ext);
        try (InputStream in = new FileInputStream(st.file); OutputStream out = new FileOutputStream(dest)) { copy(in, out); }
        MediaScannerConnection.scanFile(this, new String[]{dest.getAbsolutePath()}, new String[]{st.mime}, null);
        return "Descargas › ScanPro";
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
    }

    private static void clearDir(File d) {
        File[] list = d.listFiles();
        if (list != null) for (File f : list) { if (f.isDirectory()) clearDir(f); //noinspection ResultOfMethodCallIgnored
            f.delete(); }
    }
}
