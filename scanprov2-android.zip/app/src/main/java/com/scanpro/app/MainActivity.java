package com.scanpro.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * ScanPro nativo: la app web va dentro del APK (assets/www) y se sirve desde
 * https://appassets.androidplatform.net, un origen seguro local. No usa Internet.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/index.html";
    private static final int REQ_CAMERA = 1, REQ_CAPTURE_PERM = 2, REQ_FILE = 3, REQ_CAPTURE = 4, REQ_STORAGE = 5;

    private WebView web;
    private WebViewAssetLoader assets;
    private PermissionRequest pendingPermission;
    private ValueCallback<Uri[]> fileCallback;
    private WebChromeClient.FileChooserParams fileParams;
    private Uri captureUri;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        clearDir(new File(getCacheDir(), "share"));

        final WebViewAssetLoader.AssetsPathHandler files = new WebViewAssetLoader.AssetsPathHandler(this);
        assets = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/", path -> files.handle("www/" + (path.isEmpty() ? "index.html" : path)))
                .build();

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);

        web = new WebView(this);
        web.setBackgroundColor(isNight() ? 0xFF0F0E17 : 0xFFF3F1F8);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "ScanProAndroid");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        setContentView(web);

        if (saved == null || web.restoreState(saved) == null) web.loadUrl(START);
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    @Override protected void onSaveInstanceState(@NonNull Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }
    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private boolean hasCamera() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------- carga de la app local ----------
    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            return assets.shouldInterceptRequest(req.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
            return true; // los enlaces externos se abren fuera de la app
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // en teléfonos con poca memoria Android puede cerrar el motor web: se reinicia la pantalla
            if (web != null) { web.destroy(); web = null; }
            recreate();
            return true;
        }
    }

    // ---------- cámara y selector de archivos ----------
    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> {
                boolean wantsVideo = false;
                for (String r : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsVideo = true;
                if (!wantsVideo) { req.deny(); return; }
                if (hasCamera()) { req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); return; }
                if (pendingPermission != null) pendingPermission.deny();
                pendingPermission = req;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            fileParams = params;
            if (params.isCaptureEnabled() && wantsImages(params)) {
                if (hasCamera()) launchCapture();
                else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAPTURE_PERM);
            } else {
                launchPicker();
            }
            return true;
        }
    }

    private static boolean wantsImages(WebChromeClient.FileChooserParams p) {
        for (String t : p.getAcceptTypes()) for (String x : t.split(",")) if (x.trim().startsWith("image/")) return true;
        return false;
    }

    private void launchCapture() {
        try {
            File dir = new File(getCacheDir(), "captures");
            clearDir(dir);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File f = new File(dir, "foto-" + System.currentTimeMillis() + ".jpg");
            captureUri = FileProvider.getUriForFile(this, "com.scanpro.app.files", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, captureUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAPTURE);
        } catch (Exception e) {
            launchPicker();
        }
    }

    private void launchPicker() {
        ArrayList<String> mimes = new ArrayList<>();
        if (fileParams != null) for (String t : fileParams.getAcceptTypes()) for (String raw : t.split(",")) {
            String x = raw.trim().toLowerCase();
            if (x.isEmpty()) continue;
            if (x.startsWith(".")) {
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(x.substring(1));
                if (m == null && x.equals(".json")) m = "application/json";
                if (m != null) mimes.add(m);
                mimes.add("application/octet-stream");
            } else mimes.add(x);
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (mimes.size() == 1) i.setType(mimes.get(0));
        else {
            i.setType("*/*");
            if (!mimes.isEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
        }
        if (fileParams != null && fileParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_FILE); }
        catch (ActivityNotFoundException e) { finishChooser(null); }
    }

    private void finishChooser(Uri[] result) {
        if (fileCallback != null) fileCallback.onReceiveValue(result);
        fileCallback = null;
        fileParams = null;
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_CAPTURE) {
            finishChooser(result == RESULT_OK && captureUri != null ? new Uri[]{captureUri} : null);
        } else if (code == REQ_FILE) {
            Uri[] out = null;
            if (result == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    out = new Uri[clip.getItemCount()];
                    for (int k = 0; k < out.length; k++) out[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            finishChooser(out);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (code == REQ_CAMERA && pendingPermission != null) {
            if (ok) pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingPermission.deny();
            pendingPermission = null;
        } else if (code == REQ_CAPTURE_PERM) {
            if (ok) launchCapture(); else launchPicker();
        }
    }

    // ---------- puente con la app web: guardar y compartir archivos ----------
    private static final class Staged {
        final File file; final String name; final String mime; OutputStream out;
        Staged(File f, String n, String m, OutputStream o) { file = f; name = n; mime = m; out = o; }
    }

    private final Map<String, Staged> staged = new HashMap<>();

    private static String safeName(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        return s.isEmpty() ? "archivo" : s;
    }

    private Staged take(String token) throws IOException {
        Staged st;
        synchronized (staged) { st = staged.remove(token); }
        if (st == null) throw new IOException("Archivo no preparado");
        if (st.out != null) { st.out.close(); st.out = null; }
        return st;
    }

    private class Bridge {
        @JavascriptInterface public String version() { return "1.3.0"; }

        @JavascriptInterface
        public String begin(String name, String mime) {
            try {
                String token = UUID.randomUUID().toString();
                File dir = new File(new File(getCacheDir(), "share"), token);
                if (!dir.mkdirs()) return "";
                File f = new File(dir, safeName(name));
                Staged st = new Staged(f, f.getName(), mime == null || mime.isEmpty() ? "application/octet-stream" : mime.split(";")[0], new FileOutputStream(f));
                synchronized (staged) { staged.put(token, st); }
                return token;
            } catch (IOException e) { return ""; }
        }

        @JavascriptInterface
        public boolean append(String token, String b64) {
            Staged st;
            synchronized (staged) { st = staged.get(token); }
            if (st == null || st.out == null) return false;
            try { st.out.write(Base64.decode(b64, Base64.DEFAULT)); return true; }
            catch (IOException | IllegalArgumentException e) { return false; }
        }

        @JavascriptInterface
        public String save(String token) {
            try {
                Staged st = take(token);
                String where = saveToDownloads(st);
                //noinspection ResultOfMethodCallIgnored
                st.file.delete();
                return where.startsWith("error:") ? where : "ok:" + where;
            } catch (Exception e) {
                return "error:No se pudo guardar el archivo (" + e.getMessage() + ").";
            }
        }

        @JavascriptInterface
        public String share(String tokensJson, String title) {
            try {
                JSONArray arr = new JSONArray(tokensJson);
                final ArrayList<Uri> uris = new ArrayList<>();
                String mime = null;
                for (int k = 0; k < arr.length(); k++) {
                    Staged st = take(arr.getString(k));
                    uris.add(FileProvider.getUriForFile(MainActivity.this, "com.scanpro.app.files", st.file));
                    mime = mime == null || mime.equals(st.mime) ? st.mime : "*/*";
                }
                if (uris.isEmpty()) return "error";
                final Intent i = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
                i.setType(mime);
                if (uris.size() == 1) i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                ClipData clip = ClipData.newRawUri(title, uris.get(0));
                for (int k = 1; k < uris.size(); k++) clip.addItem(new ClipData.Item(uris.get(k)));
                i.setClipData(clip);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                final String t = title;
                runOnUiThread(() -> startActivity(Intent.createChooser(i, t)));
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public String shareText(String text, String title) {
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            runOnUiThread(() -> startActivity(Intent.createChooser(i, title)));
            return "ok";
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean dark) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    Window w = getWindow();
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    if (web != null) web.setBackgroundColor(c);
                    View d = w.getDecorView();
                    int f = d.getSystemUiVisibility();
                    f = dark ? f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    if (Build.VERSION.SDK_INT >= 26)
                        f = dark ? f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    d.setSystemUiVisibility(f);
                } catch (IllegalArgumentException ignored) { }
            });
        }
    }

    /** Copia a Descargas/ScanPro y devuelve el lugar en palabras sencillas. */
    private String saveToDownloads(Staged st) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, st.name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, st.mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ScanPro");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("sin acceso a Descargas");
            try (InputStream in = new FileInputStream(st.file); OutputStream out = cr.openOutputStream(uri)) {
                if (out == null) throw new IOException("sin acceso a Descargas");
                copy(in, out);
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, v, null, null);
            return "Descargas › ScanPro";
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
            return "error:Permite el acceso a los archivos y vuelve a tocar «Descargar».";
        }
        @SuppressWarnings("deprecation")
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ScanPro");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File dest = new File(dir, st.name);
        int dot = st.name.lastIndexOf('.');
        String base = dot > 0 ? st.name.substring(0, dot) : st.name, ext = dot > 0 ? st.name.substring(dot) : "";
        for (int n = 1; dest.exists(); n++) dest = new File(dir, base + " (" + n + ")" + ext);
        try (InputStream in = new FileInputStream(st.file); OutputStream out = new FileOutputStream(dest)) { copy(in, out); }
        MediaScannerConnection.scanFile(this, new String[]{dest.getAbsolutePath()}, new String[]{st.mime}, null);
        return "Descargas › ScanPro";
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
    }

    private static void clearDir(File d) {
        File[] list = d.listFiles();
        if (list != null) for (File f : list) { if (f.isDirectory()) clearDir(f); //noinspection ResultOfMethodCallIgnored
            f.delete(); }
    }
}
