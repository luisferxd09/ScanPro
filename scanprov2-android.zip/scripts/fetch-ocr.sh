#!/usr/bin/env bash
# Descarga el motor de OCR (Tesseract.js) y los idiomas para meterlos dentro del APK.
# Así el OCR funciona sin Internet. Lo ejecuta GitHub Actions antes de compilar.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/ocr/www/vendor/tesseract"
rm -rf "$OUT"; mkdir -p "$OUT"
TMP="$(mktemp -d)"; cd "$TMP"

npm pack --silent tesseract.js@5.1.1 >/dev/null
tar xzf tesseract.js-5.1.1.tgz
cp package/dist/tesseract.min.js package/dist/worker.min.js "$OUT/"
rm -rf package

npm pack --silent 'tesseract.js-core@5' >/dev/null
tar xzf tesseract.js-core-*.tgz
cp package/tesseract-core*.wasm.js "$OUT/"
cp package/tesseract-core*.wasm "$OUT/" 2>/dev/null || true
rm -rf package

for L in spa eng; do
  curl -fsSL --retry 3 -o "$OUT/$L.traineddata" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$L.traineddata"
done

ls -la "$OUT"
test -s "$OUT/tesseract.min.js" && test -s "$OUT/worker.min.js" && test -s "$OUT/spa.traineddata"
ls "$OUT"/tesseract-core*.wasm.js >/dev/null
echo "OCR sin conexión listo"
