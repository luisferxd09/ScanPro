#!/usr/bin/env bash
# Descarga el motor de OCR (Tesseract.js) y los idiomas para meterlos dentro del APK.
# Así el OCR funciona sin Internet. Lo ejecuta GitHub Actions antes de compilar.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/ocr/www/vendor/tesseract"
rm -rf "$OUT"; mkdir -p "$OUT"
TMP="$(mktemp -d)"; cd "$TMP"

npm pack --silent tesseract.js@5.1.1 >/dev/null
tar xzf tesseract.js-5.1.1.tgz
cp package/dist/tesseract.min.js package/dist/worker.min.js "$OUT/"
rm -rf package

npm pack --silent 'tesseract.js-core@5' >/dev/null
tar xzf tesseract.js-core-*.tgz
cp package/tesseract-core*.wasm.js "$OUT/"
cp package/tesseract-core*.wasm "$OUT/" 2>/dev/null || true
rm -rf package

# español con el modelo de mayor precisión; inglés con el rápido
curl -fsSL --retry 3 -o "$OUT/spa.traineddata" "https://github.com/tesseract-ocr/tessdata_best/raw/main/spa.traineddata"
curl -fsSL --retry 3 -o "$OUT/eng.traineddata" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata"
for L in por fra deu ita; do curl -fsSL --retry 3 -o "$OUT/$L.traineddata" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$L.traineddata"; done

ls -la "$OUT"
test -s "$OUT/tesseract.min.js" && test -s "$OUT/worker.min.js" && test -s "$OUT/spa.traineddata"
ls "$OUT"/tesseract-core*.wasm.js >/dev/null
echo "OCR sin conexión listo"

# lector de PDF (para importar PDF sin internet)
PDF="$ROOT/app/ocr/www/vendor/pdfjs"; rm -rf "$PDF"; mkdir -p "$PDF"; cd "$TMP"
npm pack --silent pdfjs-dist@4.10.38 >/dev/null
tar xzf pdfjs-dist-4.10.38.tgz
cp package/legacy/build/pdf.min.mjs package/legacy/build/pdf.worker.min.mjs "$PDF/"
rm -rf package
test -s "$PDF/pdf.min.mjs"
echo "Lector de PDF listo"

# lector de TIFF (para importar escaneos .tif sin internet)
curl -fsSL --retry 3 -o "$ROOT/app/ocr/www/vendor/utif.js" "https://cdn.jsdelivr.net/npm/utif@3.1.0/UTIF.js"
test -s "$ROOT/app/ocr/www/vendor/utif.js"
echo "Lector de TIFF listo"

# PowerPoint (para exportar presentaciones sin internet)
curl -fsSL --retry 3 -o "$ROOT/app/ocr/www/vendor/pptxgen.bundle.js" "https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js"
test -s "$ROOT/app/ocr/www/vendor/pptxgen.bundle.js"
echo "PowerPoint listo"
